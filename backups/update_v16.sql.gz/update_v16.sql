--
-- PostgreSQL database dump
--

\restrict aGH4uXWl4GeUpAcFud7oeIkDnt3r0eMjHaXrZ4H3KtQKGjCuU6oYOgqSmEagvUr

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: program
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO program;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: program
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.approval_logs (
    id integer NOT NULL,
    entity_type character varying(30) NOT NULL,
    entity_id integer NOT NULL,
    step character varying(30) NOT NULL,
    action character varying(20) NOT NULL,
    reviewer_id integer,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.approval_logs OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.approval_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_logs_id_seq OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.approval_logs_id_seq OWNED BY public.approval_logs.id;


--
-- Name: assessment_plans; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.assessment_plans (
    id integer NOT NULL,
    version_id integer,
    plo_id integer,
    pi_id integer,
    sample_course_id integer,
    assessment_tool character varying(200),
    criteria character varying(200),
    threshold character varying(200),
    semester character varying(30),
    assessor character varying(200),
    dept_code character varying(20),
    direct_evidence character varying(200),
    expected_result character varying(200),
    contributing_course_codes text
);


ALTER TABLE public.assessment_plans OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.assessment_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assessment_plans_id_seq OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.assessment_plans_id_seq OWNED BY public.assessment_plans.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100),
    target character varying(200),
    details text,
    ip character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clo_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.clo_plo_map (
    clo_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 1
);


ALTER TABLE public.clo_plo_map OWNER TO program;

--
-- Name: course_clos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_clos (
    id integer NOT NULL,
    version_course_id integer,
    code character varying(20),
    description text
);


ALTER TABLE public.course_clos OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.course_clos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_clos_id_seq OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.course_clos_id_seq OWNED BY public.course_clos.id;


--
-- Name: course_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_plo_map (
    version_id integer,
    course_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.course_plo_map OWNER TO program;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(300) NOT NULL,
    credits integer DEFAULT 3,
    credits_theory integer DEFAULT 0,
    credits_practice integer DEFAULT 0,
    credits_project integer DEFAULT 0,
    credits_internship integer DEFAULT 0,
    department_id integer,
    description text
);


ALTER TABLE public.courses OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    parent_id integer,
    code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(20) DEFAULT 'KHOA'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.departments OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: knowledge_blocks; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.knowledge_blocks (
    id integer NOT NULL,
    version_id integer,
    name character varying(200) NOT NULL,
    parent_id integer,
    total_credits integer DEFAULT 0,
    required_credits integer DEFAULT 0,
    elective_credits integer DEFAULT 0,
    sort_order integer DEFAULT 0,
    level integer DEFAULT 1
);


ALTER TABLE public.knowledge_blocks OWNER TO program;

--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.knowledge_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knowledge_blocks_id_seq OWNER TO program;

--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.knowledge_blocks_id_seq OWNED BY public.knowledge_blocks.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    code character varying(60) NOT NULL,
    module character varying(30) NOT NULL,
    description character varying(200)
);


ALTER TABLE public.permissions OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: plo_pis; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.plo_pis (
    id integer NOT NULL,
    plo_id integer,
    pi_code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.plo_pis OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.plo_pis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plo_pis_id_seq OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.plo_pis_id_seq OWNED BY public.plo_pis.id;


--
-- Name: po_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.po_plo_map (
    version_id integer,
    po_id integer NOT NULL,
    plo_id integer NOT NULL
);


ALTER TABLE public.po_plo_map OWNER TO program;

--
-- Name: program_versions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.program_versions (
    id integer NOT NULL,
    program_id integer,
    academic_year character varying(20) NOT NULL,
    version_name character varying(300),
    status character varying(30) DEFAULT 'draft'::character varying,
    is_locked boolean DEFAULT false,
    copied_from_id integer,
    completion_pct integer DEFAULT 0,
    total_credits integer,
    training_duration character varying(50),
    change_type character varying(50),
    effective_date date,
    change_summary text,
    grading_scale text,
    graduation_requirements text,
    job_positions text,
    further_education text,
    reference_programs text,
    training_process text,
    admission_targets text,
    admission_criteria text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_rejected boolean DEFAULT false,
    rejection_reason text,
    general_objective text
);


ALTER TABLE public.program_versions OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.program_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_versions_id_seq OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.program_versions_id_seq OWNED BY public.program_versions.id;


--
-- Name: programs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.programs (
    id integer NOT NULL,
    department_id integer,
    name character varying(300) NOT NULL,
    name_en character varying(300),
    code character varying(30),
    degree character varying(50) DEFAULT 'Đại học'::character varying,
    total_credits integer,
    institution character varying(300),
    degree_name character varying(300),
    training_mode character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    archived_at timestamp with time zone
);


ALTER TABLE public.programs OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.programs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.programs_id_seq OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.programs_id_seq OWNED BY public.programs.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO program;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    is_system boolean DEFAULT true
);


ALTER TABLE public.roles OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: syllabus_assignments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.syllabus_assignments (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    assigned_to integer,
    assigned_by integer,
    assigner_role_level integer DEFAULT 1,
    deadline date,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.syllabus_assignments OWNER TO program;

--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.syllabus_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.syllabus_assignments_id_seq OWNER TO program;

--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.syllabus_assignments_id_seq OWNED BY public.syllabus_assignments.id;


--
-- Name: teaching_plan; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.teaching_plan (
    id integer NOT NULL,
    version_course_id integer,
    total_hours integer DEFAULT 0,
    hours_theory integer DEFAULT 0,
    hours_practice integer DEFAULT 0,
    hours_project integer DEFAULT 0,
    hours_internship integer DEFAULT 0,
    software character varying(500),
    managing_dept character varying(200),
    batch character varying(10),
    notes text
);


ALTER TABLE public.teaching_plan OWNER TO program;

--
-- Name: teaching_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.teaching_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teaching_plan_id_seq OWNER TO program;

--
-- Name: teaching_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.teaching_plan_id_seq OWNED BY public.teaching_plan.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    department_id integer
);


ALTER TABLE public.user_roles OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(200) NOT NULL,
    email character varying(200),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_courses (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    semester integer,
    course_type character varying(20) DEFAULT 'required'::character varying,
    prerequisite_course_ids integer[],
    corequisite_course_ids integer[],
    elective_group character varying(100),
    knowledge_block_id integer
);


ALTER TABLE public.version_courses OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_courses_id_seq OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_courses_id_seq OWNED BY public.version_courses.id;


--
-- Name: version_objectives; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_objectives (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.version_objectives OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_objectives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_objectives_id_seq OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_objectives_id_seq OWNED BY public.version_objectives.id;


--
-- Name: version_pi_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_pi_courses (
    id integer NOT NULL,
    version_id integer,
    pi_id integer,
    course_id integer,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.version_pi_courses OWNER TO program;

--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_pi_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_pi_courses_id_seq OWNER TO program;

--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_pi_courses_id_seq OWNED BY public.version_pi_courses.id;


--
-- Name: version_plos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_plos (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    bloom_level integer DEFAULT 1,
    description text
);


ALTER TABLE public.version_plos OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_plos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_plos_id_seq OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_plos_id_seq OWNED BY public.version_plos.id;


--
-- Name: version_syllabi; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_syllabi (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    author_id integer,
    status character varying(30) DEFAULT 'draft'::character varying,
    content jsonb DEFAULT '{}'::jsonb,
    is_rejected boolean DEFAULT false,
    rejection_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.version_syllabi OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_syllabi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_syllabi_id_seq OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_syllabi_id_seq OWNED BY public.version_syllabi.id;


--
-- Name: approval_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs ALTER COLUMN id SET DEFAULT nextval('public.approval_logs_id_seq'::regclass);


--
-- Name: assessment_plans id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans ALTER COLUMN id SET DEFAULT nextval('public.assessment_plans_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: course_clos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos ALTER COLUMN id SET DEFAULT nextval('public.course_clos_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: knowledge_blocks id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks ALTER COLUMN id SET DEFAULT nextval('public.knowledge_blocks_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: plo_pis id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis ALTER COLUMN id SET DEFAULT nextval('public.plo_pis_id_seq'::regclass);


--
-- Name: program_versions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions ALTER COLUMN id SET DEFAULT nextval('public.program_versions_id_seq'::regclass);


--
-- Name: programs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs ALTER COLUMN id SET DEFAULT nextval('public.programs_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: syllabus_assignments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments ALTER COLUMN id SET DEFAULT nextval('public.syllabus_assignments_id_seq'::regclass);


--
-- Name: teaching_plan id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan ALTER COLUMN id SET DEFAULT nextval('public.teaching_plan_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses ALTER COLUMN id SET DEFAULT nextval('public.version_courses_id_seq'::regclass);


--
-- Name: version_objectives id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives ALTER COLUMN id SET DEFAULT nextval('public.version_objectives_id_seq'::regclass);


--
-- Name: version_pi_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses ALTER COLUMN id SET DEFAULT nextval('public.version_pi_courses_id_seq'::regclass);


--
-- Name: version_plos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos ALTER COLUMN id SET DEFAULT nextval('public.version_plos_id_seq'::regclass);


--
-- Name: version_syllabi id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi ALTER COLUMN id SET DEFAULT nextval('public.version_syllabi_id_seq'::regclass);


--
-- Data for Name: approval_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.approval_logs (id, entity_type, entity_id, step, action, reviewer_id, notes, created_at) FROM stdin;
1	syllabus	1	submit	submitted	2	Nộp duyệt	2026-03-26 17:48:58.858106+00
2	syllabus	1	submitted	rejected	3	Yêu cầu chỉnh sửa	2026-03-26 17:50:40.141083+00
3	program_version	1	submit	submitted	3	Nộp duyệt	2026-03-26 17:53:45.028411+00
4	program_version	1	submitted	rejected	4	Yêu cầu chỉnh sửa	2026-03-26 17:54:10.119339+00
5	program_version	1	submit	submitted	3	Nộp duyệt	2026-03-26 17:56:59.538377+00
6	program_version	1	submitted	rejected	4	Yêu cầu chỉnh sửa	2026-03-26 17:57:49.175018+00
7	syllabus	1	submit	submitted	2	Nộp duyệt	2026-03-26 18:10:28.673601+00
8	syllabus	1	submitted	rejected	3	Yêu cầu chỉnh sửa	2026-03-26 18:10:49.265033+00
9	program_version	1	submit	submitted	3	Nộp duyệt	2026-03-26 18:13:10.57747+00
10	syllabus	1	submit	submitted	2	Nộp duyệt	2026-03-26 18:17:02.095046+00
11	syllabus	1	submitted	rejected	3	Yêu cầu chỉnh sửa	2026-03-26 18:17:14.134156+00
12	program_version	1	submitted	rejected	1	dỡ quá	2026-03-26 18:28:04.419432+00
13	program_version	1	submit	submitted	2	Nộp duyệt	2026-03-26 18:51:34.842918+00
14	program_version	1	submitted	approved	4	Đã duyệt	2026-03-26 18:51:46.656422+00
15	program_version	1	approved_khoa	approved	5	Đã duyệt	2026-03-26 18:52:06.044865+00
16	program_version	1	approved_pdt	approved	6	Đã duyệt	2026-03-26 18:53:09.486304+00
17	program_version	17	submit	submitted	1	Nộp duyệt	2026-03-26 18:55:20.551086+00
18	program_version	17	submitted	approved	1	Đã duyệt	2026-03-26 18:55:30.106988+00
19	program_version	17	approved_khoa	approved	1	Đã duyệt	2026-03-26 18:55:31.573294+00
20	program_version	17	approved_pdt	rejected	1	Yêu cầu chỉnh sửa	2026-03-26 18:55:32.855157+00
21	program_version	17	submit	submitted	3	Nộp duyệt	2026-03-26 19:02:54.77536+00
22	program_version	17	submitted	approved	4	Đã duyệt	2026-03-26 19:03:05.873352+00
23	program_version	17	approved_khoa	rejected	5	Yêu cầu chỉnh sửa	2026-03-26 19:03:34.511618+00
24	program_version	17	submit	submitted	3	Nộp duyệt	2026-03-26 19:13:49.285384+00
25	program_version	17	submitted	approved	4	Đã duyệt	2026-03-26 19:14:16.973949+00
26	program_version	17	approved_khoa	rejected	5	Yêu cầu chỉnh sửa	2026-03-26 19:14:29.712086+00
27	program_version	18	submit	submitted	3	Nộp duyệt	2026-03-27 02:29:36.866871+00
28	program_version	18	submitted	rejected	4	Yêu cầu chỉnh sửa	2026-03-27 02:29:48.526206+00
29	program_version	18	submit	submitted	3	Nộp duyệt	2026-03-27 02:30:14.828182+00
30	program_version	18	submitted	approved	1	Đã duyệt	2026-03-27 02:30:27.720274+00
31	program_version	18	approved_khoa	approved	1	Đã duyệt	2026-03-27 02:30:29.657113+00
32	program_version	18	approved_pdt	rejected	1	Yêu cầu chỉnh sửa	2026-03-27 02:30:31.420796+00
33	program_version	19	submit	submitted	3	Nộp duyệt	2026-03-27 02:43:39.418158+00
34	program_version	19	submitted	rejected	4	Yêu cầu chỉnh sửa	2026-03-27 02:43:56.733573+00
35	program_version	54	submit	submitted	1	Nộp duyệt	2026-04-04 08:13:00.679839+00
38	program_version	56	submit	submitted	1	Nộp duyệt	2026-04-04 08:13:05.151883+00
39	program_version	57	submit	submitted	1	Nộp duyệt	2026-04-04 08:13:07.946127+00
40	program_version	57	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 08:13:07.96023+00
41	program_version	84	submit	submitted	1	Nộp duyệt	2026-04-04 08:23:32.444761+00
44	program_version	88	submit	submitted	1	Nộp duyệt	2026-04-04 08:23:36.580281+00
45	program_version	89	submit	submitted	1	Nộp duyệt	2026-04-04 08:23:39.219604+00
46	program_version	89	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 08:23:39.249302+00
47	program_version	102	submit	submitted	1	Nộp duyệt	2026-04-04 08:25:18.244519+00
50	program_version	104	submit	submitted	1	Nộp duyệt	2026-04-04 08:25:21.967264+00
51	program_version	105	submit	submitted	1	Nộp duyệt	2026-04-04 08:25:24.653881+00
52	program_version	105	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 08:25:24.668113+00
53	program_version	132	submit	submitted	1	Nộp duyệt	2026-04-04 08:30:06.375546+00
56	program_version	134	submit	submitted	1	Nộp duyệt	2026-04-04 08:30:10.085601+00
57	program_version	135	submit	submitted	1	Nộp duyệt	2026-04-04 08:30:12.559795+00
58	program_version	135	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 08:30:12.571666+00
59	program_version	165	submit	submitted	1	Nộp duyệt	2026-04-04 08:41:06.585342+00
62	program_version	167	submit	submitted	1	Nộp duyệt	2026-04-04 08:41:11.228684+00
63	program_version	168	submit	submitted	1	Nộp duyệt	2026-04-04 08:41:14.165649+00
64	program_version	168	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 08:41:14.181827+00
65	program_version	210	submit	submitted	1	Nộp duyệt	2026-04-04 08:48:15.044546+00
68	program_version	213	submit	submitted	1	Nộp duyệt	2026-04-04 08:48:19.467307+00
69	program_version	214	submit	submitted	1	Nộp duyệt	2026-04-04 08:48:22.261832+00
70	program_version	214	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 08:48:22.272138+00
71	program_version	280	submit	submitted	1	Nộp duyệt	2026-04-04 09:23:13.068369+00
74	program_version	282	submit	submitted	1	Nộp duyệt	2026-04-04 09:23:17.754626+00
75	program_version	283	submit	submitted	1	Nộp duyệt	2026-04-04 09:23:20.579295+00
76	program_version	283	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 09:23:20.589427+00
77	program_version	294	submit	submitted	1	Nộp duyệt	2026-04-04 09:35:06.089068+00
80	program_version	296	submit	submitted	1	Nộp duyệt	2026-04-04 09:35:10.123513+00
81	program_version	297	submit	submitted	1	Nộp duyệt	2026-04-04 09:35:12.790884+00
82	program_version	297	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 09:35:12.804708+00
83	program_version	302	submit	submitted	1	Nộp duyệt	2026-04-04 09:47:53.987834+00
86	program_version	304	submit	submitted	1	Nộp duyệt	2026-04-04 09:47:58.488724+00
87	program_version	305	submit	submitted	1	Nộp duyệt	2026-04-04 09:48:01.181747+00
88	program_version	305	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 09:48:01.194104+00
89	program_version	310	submit	submitted	1	Nộp duyệt	2026-04-04 09:51:29.064676+00
92	program_version	312	submit	submitted	1	Nộp duyệt	2026-04-04 09:51:33.055823+00
93	program_version	313	submit	submitted	1	Nộp duyệt	2026-04-04 09:51:35.610701+00
94	program_version	313	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 09:51:35.626073+00
95	program_version	318	submit	submitted	1	Nộp duyệt	2026-04-04 09:57:40.928647+00
98	program_version	320	submit	submitted	1	Nộp duyệt	2026-04-04 09:57:45.266889+00
99	program_version	321	submit	submitted	1	Nộp duyệt	2026-04-04 09:57:47.95737+00
100	program_version	321	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 09:57:47.970895+00
101	program_version	326	submit	submitted	1	Nộp duyệt	2026-04-04 10:01:29.130161+00
104	program_version	328	submit	submitted	1	Nộp duyệt	2026-04-04 10:01:33.844801+00
105	program_version	329	submit	submitted	1	Nộp duyệt	2026-04-04 10:01:36.732072+00
106	program_version	329	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 10:01:36.744584+00
107	program_version	334	submit	submitted	1	Nộp duyệt	2026-04-04 10:05:08.002515+00
110	program_version	336	submit	submitted	1	Nộp duyệt	2026-04-04 10:05:12.236081+00
111	program_version	337	submit	submitted	1	Nộp duyệt	2026-04-04 10:05:14.951039+00
112	program_version	337	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 10:05:14.963534+00
113	program_version	342	submit	submitted	1	Nộp duyệt	2026-04-04 10:08:46.897819+00
116	program_version	344	submit	submitted	1	Nộp duyệt	2026-04-04 10:08:51.426852+00
117	program_version	345	submit	submitted	1	Nộp duyệt	2026-04-04 10:08:54.47035+00
118	program_version	345	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 10:08:54.484271+00
119	program_version	350	submit	submitted	1	Nộp duyệt	2026-04-04 10:12:26.048566+00
122	program_version	352	submit	submitted	1	Nộp duyệt	2026-04-04 10:12:30.06896+00
123	program_version	353	submit	submitted	1	Nộp duyệt	2026-04-04 10:12:32.784276+00
124	program_version	353	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 10:12:32.798116+00
125	program_version	358	submit	submitted	1	Nộp duyệt	2026-04-04 10:16:43.224386+00
128	program_version	360	submit	submitted	1	Nộp duyệt	2026-04-04 10:16:47.403731+00
129	program_version	361	submit	submitted	1	Nộp duyệt	2026-04-04 10:16:50.503395+00
130	program_version	361	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-04 10:16:50.516552+00
131	program_version	364	submit	submitted	1	Nộp duyệt	2026-04-05 05:04:01.517491+00
132	program_version	364	submitted	approved	1	Đã duyệt	2026-04-05 05:04:01.529245+00
133	program_version	364	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:04:01.534445+00
134	program_version	364	approved_pdt	approved	1	Đã duyệt	2026-04-05 05:04:01.539204+00
135	program_version	367	submit	submitted	1	Nộp duyệt	2026-04-05 05:05:28.936606+00
136	program_version	368	submit	submitted	1	Nộp duyệt	2026-04-05 05:05:29.862012+00
137	program_version	369	submit	submitted	1	Nộp duyệt	2026-04-05 05:05:42.199631+00
138	program_version	369	submitted	approved	1	Đã duyệt	2026-04-05 05:05:42.212348+00
139	program_version	370	submit	submitted	1	Nộp duyệt	2026-04-05 05:05:54.431759+00
140	program_version	370	submitted	approved	1	Đã duyệt	2026-04-05 05:05:54.444188+00
141	program_version	370	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:05:54.44882+00
144	program_version	372	submit	submitted	1	Nộp duyệt	2026-04-05 05:06:07.713594+00
145	program_version	373	submit	submitted	1	Nộp duyệt	2026-04-05 05:06:10.529153+00
146	program_version	373	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-05 05:06:10.541127+00
147	program_version	374	submit	submitted	1	Nộp duyệt	2026-04-05 05:06:11.556294+00
150	program_version	376	submit	submitted	1	Nộp duyệt	2026-04-05 05:06:24.862163+00
151	program_version	376	submitted	rejected	1	Needs fixes	2026-04-05 05:06:24.873181+00
152	program_version	376	submit	submitted	1	Nộp duyệt	2026-04-05 05:06:24.882014+00
153	program_version	378	submit	submitted	1	Nộp duyệt	2026-04-05 05:08:44.590548+00
154	program_version	379	submit	submitted	1	Nộp duyệt	2026-04-05 05:10:16.839951+00
155	program_version	379	submitted	approved	4	Đã duyệt	2026-04-05 05:10:17.195007+00
156	program_version	380	submit	submitted	1	Nộp duyệt	2026-04-05 05:10:18.355503+00
157	program_version	380	submitted	approved	1	Đã duyệt	2026-04-05 05:10:18.364078+00
158	program_version	380	approved_khoa	approved	5	Đã duyệt	2026-04-05 05:10:18.700519+00
159	program_version	381	submit	submitted	1	Nộp duyệt	2026-04-05 05:10:19.966576+00
160	program_version	381	submitted	approved	1	Đã duyệt	2026-04-05 05:10:19.971137+00
161	program_version	381	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:10:19.978441+00
162	program_version	381	approved_pdt	approved	6	Đã duyệt	2026-04-05 05:10:20.219532+00
163	program_version	382	submit	submitted	1	Nộp duyệt	2026-04-05 05:10:21.478324+00
164	program_version	384	submit	submitted	1	Nộp duyệt	2026-04-05 05:11:15.887398+00
165	program_version	384	submitted	approved	1	Đã duyệt	2026-04-05 05:11:15.89854+00
166	program_version	384	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:11:15.902799+00
167	program_version	384	approved_pdt	approved	1	Đã duyệt	2026-04-05 05:11:15.906413+00
168	program_version	387	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:34.215274+00
169	program_version	388	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:34.956878+00
170	program_version	388	submitted	approved	4	Đã duyệt	2026-04-05 05:12:35.151536+00
171	program_version	389	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:36.202409+00
172	program_version	389	submitted	approved	1	Đã duyệt	2026-04-05 05:12:36.207712+00
173	program_version	389	approved_khoa	approved	5	Đã duyệt	2026-04-05 05:12:36.400935+00
174	program_version	390	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:37.324415+00
175	program_version	390	submitted	approved	1	Đã duyệt	2026-04-05 05:12:37.332495+00
176	program_version	390	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:12:37.337178+00
180	program_version	392	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:39.273453+00
181	program_version	393	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:41.767473+00
182	program_version	393	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-05 05:12:41.775516+00
183	program_version	394	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:42.52499+00
177	program_version	390	approved_pdt	approved	6	Đã duyệt	2026-04-05 05:12:37.636907+00
186	program_version	396	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:44.418122+00
187	program_version	396	submitted	rejected	1	Needs fixes	2026-04-05 05:12:44.422248+00
188	program_version	396	submit	submitted	1	Nộp duyệt	2026-04-05 05:12:44.430497+00
189	program_version	399	submit	submitted	1	Nộp duyệt	2026-04-05 05:16:22.436845+00
190	program_version	399	submitted	approved	1	Đã duyệt	2026-04-05 05:16:22.440873+00
191	program_version	399	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:16:22.449603+00
192	program_version	399	approved_pdt	approved	1	Đã duyệt	2026-04-05 05:16:22.453787+00
193	program_version	402	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:41.77463+00
194	program_version	403	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:42.590388+00
195	program_version	403	submitted	approved	4	Đã duyệt	2026-04-05 05:17:42.82739+00
196	program_version	404	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:43.830228+00
197	program_version	404	submitted	approved	1	Đã duyệt	2026-04-05 05:17:43.835171+00
198	program_version	404	approved_khoa	approved	5	Đã duyệt	2026-04-05 05:17:44.15461+00
199	program_version	405	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:45.212821+00
200	program_version	405	submitted	approved	1	Đã duyệt	2026-04-05 05:17:45.217278+00
201	program_version	405	approved_khoa	approved	1	Đã duyệt	2026-04-05 05:17:45.221546+00
202	program_version	405	approved_pdt	approved	6	Đã duyệt	2026-04-05 05:17:45.558099+00
205	program_version	407	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:47.444829+00
206	program_version	408	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:49.928816+00
207	program_version	408	submitted	rejected	1	Yêu cầu chỉnh sửa	2026-04-05 05:17:49.941609+00
208	program_version	409	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:50.67539+00
211	program_version	411	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:52.529249+00
212	program_version	411	submitted	rejected	1	Needs fixes	2026-04-05 05:17:52.533123+00
213	program_version	411	submit	submitted	1	Nộp duyệt	2026-04-05 05:17:52.544045+00
\.


--
-- Data for Name: assessment_plans; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.assessment_plans (id, version_id, plo_id, pi_id, sample_course_id, assessment_tool, criteria, threshold, semester, assessor, dept_code, direct_evidence, expected_result, contributing_course_codes) FROM stdin;
1	1	1	\N	2	Bài kiểm tra cuối kỳ	Giải đúng bài toán CTDL	≥70% SV đạt từ 5/10	HK2	GV phụ trách	\N	\N	\N	\N
2	1	2	\N	6	Đồ án môn học	Thiết kế đúng quy trình UML	≥70% SV đạt yêu cầu	HK4	GV + Doanh nghiệp	\N	\N	\N	\N
3	1	3	\N	7	Bài tập thực hành	Chạy đúng chức năng web app	≥80% SV hoàn thành	HK4	GV phụ trách	\N	\N	\N	\N
4	1	4	\N	3	Bài kiểm tra cuối kỳ	Thiết kế CSDL chuẩn 3NF	≥70% SV đạt từ 5/10	HK3	GV phụ trách	\N	\N	\N	\N
5	1	5	\N	9	Báo cáo nhóm	Trình bày rõ ràng, logic	≥75% SV đạt	HK6	Hội đồng chấm	\N	\N	\N	\N
6	1	6	\N	8	Tiểu luận	Phân tích công nghệ AI mới	≥70% SV đạt	HK5	GV phụ trách	\N	\N	\N	\N
215	29	135	273	37	Điểm chuyên cần	Nhận biết các vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK1 / năm 3	Trần Phương Anh	\N	Chuyên cần	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,LAW158,MAN116,ENG183,SLK122,CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN120,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211,AIT129
216	29	135	273	37	Điểm chuyên cần	Nhận biết các vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK1 / năm 3	Trần Phương Anh	\N	Chuyên cần	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,LAW158,MAN116,ENG183,SLK122,CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN120,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211,AIT129
217	29	135	274	29	Rubric	Xây dựng phương án để giải quyết các vấn đề về chính trị và pháp luật, khoa học xã hội và nhânvăn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK2 / năm 1	\N	VJIT	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	LAW158,SKL115,ENG183,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318
218	29	135	275	54	Thang điểm bài thi viết	Kết hợp các kiến thức cơ bản, kiến thức chuyên ngành để đóng góp hữu hiệu vào sự phát triển bền vững của xã hội, cộng đồng	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	ENS192,SOS118,CHN5002,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211
219	29	136	276	52	Thang điểm bài thi viết	Nhận biết các thành phần cấu tạo nên ngôn ngữ Trung Quốc	\N	HK1/ năm 3	Khuất Thị Tú Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN117,CHN118,CHN122,CHN123,CHN124,CHN125,CHN126,CHN134
220	29	136	277	37	Thang điểm bài thi viết	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc	\N	HK1/ năm 3	Trần Phương Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN118,CHN119,CHN120,CHN121,CHN134,CHN135,AIT1021,CHN1003,CHN4005
221	29	136	278	47	Thang điểm bài thi viết	Sử dụng thành thạo 4 kỹ năng tiếng Trung	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126
222	29	137	279	25	Thang điểm bài thi viết	Sử dụng ngoại ngữ 2 tiếng Anh trong các tình huống quen thuộc để nâng cao cơ hội việc làm và mở rộng hiểu biết về các nền văn hóa khác.	\N	HK2/ năm 2	\N	K.TA	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	ENC120,ENC121,ENC122,ENC123
223	29	138	280	57	Thang điểm bài thi viết	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Trần Phương Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
224	29	138	280	61	Thang điểm bài thi viết	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Khuất Thị Tú Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
225	29	138	280	64	Rubric	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Lê Quốc Huỳnh	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
226	29	138	281	47	Thang điểm bài thi viết	Nhận biết chữ Hán phồn thể và thành thạo chữ Hán giản thể trong công việc.	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN121,CHN122,CHN123,CHN124,CHN125,CHN126
227	29	138	282	54	Thang điểm bài thi viết	Khai thác thông tin và cập nhật kiến thức chuyên ngành thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c) văn hóa Trung Hoa, hoặc (d) khóa luận tốt nghiệp.	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	SOS118,CHN5002,CHN546,CHN135,CHN128,CHN144,AIT1021,AIT1022,CHN4005
228	29	139	283	53	Thang điểm bài thi viết	Phân tích thông tin, đưa ra luận điểm có căn cứ.	\N	HK2/ năm 3	Sú Xuân Thanh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN119,CHN120,CHN134,CHN137,CHN139,AIT1022,CHN4005,CHN1003
229	29	139	284	47	Thang điểm bài thi viết	Hệ thống lại vấn đề, đưa ra kết luận về cách thức vận hành của vấn đề hệ thống.	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,CHN121
230	29	140	285	27	Rubric	Lập kế hoạch, thực hiện và đánh giá công việc chuyên môn	\N	HK2/ năm 2	\N	K.TA	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	ENS192,LAW158,SOS118,CHN5002,CHN546
231	29	140	286	59	Thang điểm bài thi viết	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Lê Quốc Huỳnh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
232	29	140	286	60	Thang điểm bài thi viết	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Đào Thị Châu Giang	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
233	29	140	286	615	Rubric	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Thái Thị Ngọc Hương	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
234	29	140	287	55	Rubric	Áp dụng thành thạo kỹ năng giao tiếp ứng xử cần thiết để thực hiện các nhiệm vụ phức tạp.	\N	HK2/ năm 3	Ngô Thế Sử	K.TQH	Bài thu hoạch	Tối thiểu 70% người học đáp ứng	SOS118,CHN5002
235	29	140	288	56	Rubric	Ứng dụng công nghệ thông tin để soạn thảo, trình bày các loại văn bản  trong học tập, nghiên cứu và công việc có hiệu quả.	\N	HK1/ năm 4	Đào Thị Châu Giang	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	MAN116,CHN546
236	29	140	289	578	Rubric	Sử dụng có hiệu quả các phần mềm chuyên dụng để phục vụ học tập và công việc chuyên môn liên quan đến tiếng Trung	\N	HK1/ năm1	\N	K.CNTT	Đồ án	Tối thiểu 70% người học đáp ứng	AIT129,SOS118,CHN139,AIT1022,CHN1004,CHN4005
237	29	141	290	\N	Rubric	Đưa ra các nhận định cá nhân trong điều kiện làm việc thay đổi	\N	HK2 / năm 1	\N	VJIT	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	POS103,ENG183,SLK122
238	29	141	291	56	Rubric	Xác định được đầy đủ mục tiêu của nhóm, vai trò, trách nhiệm của các thành viên	\N	HK1/ năm 4	Đào Thị Châu Giang	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN546
239	29	141	292	54	Thang điểm bài thi viết	Tham gia hoạch định, lên chương trình và phối hợp trong thực hiện hoạt động nhóm đạt được mục tiêu đã đề ra.	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	POS104,POS106,POS107,ENS192,SKL115,MAN116,SLK122,SOS118,CHN5002
240	29	141	293	53	Điểm chuyên cần	Nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.	\N	HK2/ năm 3	Sú Xuân Thanh	K.TQH	Chuyên cần	Tối thiểu 70% người học đáp ứng	LAW158,SKL115,MAN116,SLK122,CHN134,SOS118,CHN5002,CHN135,CHN128,CHN137,CHN139,CHN144,AIT1021,CHN1003,CHN1004,AIT1022,CHN4005,NDF108,NDF109,NDF210,NDF211
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.audit_logs (id, user_id, action, target, details, ip, created_at) FROM stdin;
1	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:23:30.661034+00
2	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 09:24:13.773942+00
3	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-25 09:27:04.502129+00
4	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-25 09:27:18.799021+00
5	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:30:47.424145+00
6	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:35:15.254903+00
7	1	DELETE /api/programs/2	/api/programs/2	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:45:40.754262+00
8	1	PUT /api/programs/1	/api/programs/1	{"params":{"id":"1"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-03-25 09:45:53.226523+00
9	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:46:02.928121+00
10	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:47:20.3843+00
11	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 09:48:01.640783+00
12	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 10:45:17.058544+00
13	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:12:35.754412+00
14	1	DELETE /api/programs/3	/api/programs/3	{"params":{"id":"3"},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:25.846238+00
15	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:31.906452+00
16	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:41.139763+00
17	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:40:24.894399+00
18	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 11:40:39.845973+00
19	1	POST /api/versions/1/assignments	/api/versions/1/assignments	{"params":{"vId":"1"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-25 16:01:29.145986+00
20	2	POST /api/my-assignments/1/create-syllabus	/api/my-assignments/1/create-syllabus	{"params":{"assignmentId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:01:39.037698+00
21	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:29:59.750868+00
22	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:29:59.7676+00
23	1	POST /api/versions/4/assignments	/api/versions/4/assignments	{"params":{"vId":"4"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-25 16:34:20.695698+00
24	2	POST /api/my-assignments/2/create-syllabus	/api/my-assignments/2/create-syllabus	{"params":{"assignmentId":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:35:43.326965+00
25	2	POST /api/syllabi/2/import-pdf	/api/syllabi/2/import-pdf	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:35:52.671848+00
26	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:35:52.713731+00
27	2	POST /api/syllabi/2/import-pdf	/api/syllabi/2/import-pdf	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:39:31.010983+00
28	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:31.053356+00
29	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:35.479796+00
30	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.97764+00
31	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.984787+00
32	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.991555+00
33	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:39.002067+00
34	2	PUT /api/syllabi/2/clo-plo-map	/api/syllabi/2/clo-plo-map	{"params":{"sId":"2"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-25 16:39:39.010138+00
35	2	PUT /api/syllabi/2/clo-plo-map	/api/syllabi/2/clo-plo-map	{"params":{"sId":"2"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-25 16:39:49.155541+00
36	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:54.767459+00
37	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:56.988855+00
38	1	PUT /api/versions/1	/api/versions/1	{"params":{"id":"1"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-25 17:19:05.283295+00
39	1	PUT /api/versions/1	/api/versions/1	{"params":{"id":"1"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-25 17:19:08.479909+00
40	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:26:39.837052+00
41	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:26:52.457649+00
42	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:27:55.651607+00
43	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:28:49.327553+00
44	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:29:59.442515+00
45	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:30:09.231489+00
46	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:30:28.310459+00
47	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:36:32.045461+00
48	1	DELETE /api/programs/4	/api/programs/4	{"params":{"id":"4"},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:37:26.43357+00
49	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:37:30.592353+00
50	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 05:09:35.837338+00
51	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 05:09:35.860188+00
52	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.40093+00
53	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.411296+00
54	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.421176+00
55	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.430976+00
56	2	PUT /api/syllabi/1/clo-plo-map	/api/syllabi/1/clo-plo-map	{"params":{"sId":"1"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-26 05:09:46.447184+00
57	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 05:11:25.546117+00
58	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 06:30:19.217774+00
59	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 06:30:19.260318+00
60	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 06:30:49.304025+00
61	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 06:30:49.345982+00
62	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	127.0.0.1	2026-03-26 07:17:42.072728+00
63	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	127.0.0.1	2026-03-26 07:17:42.082392+00
64	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 07:20:05.107968+00
65	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 07:20:56.605184+00
66	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 07:21:12.66151+00
67	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 08:09:10.144588+00
68	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 08:28:16.744112+00
69	1	PUT /api/courses/67	/api/courses/67	{"params":{"id":"67"},"bodyKeys":["code","name","credits","credits_theory","credits_practice","credits_project","credits_internship","department_id","description"]}	127.0.0.1	2026-03-26 09:21:39.025677+00
70	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 09:23:06.721232+00
71	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name"]}	127.0.0.1	2026-03-26 09:31:16.115496+00
72	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name"]}	127.0.0.1	2026-03-26 09:31:16.122904+00
73	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name","parent_id"]}	127.0.0.1	2026-03-26 09:31:16.130069+00
74	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name","parent_id"]}	127.0.0.1	2026-03-26 09:31:16.138977+00
75	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name"]}	127.0.0.1	2026-03-26 09:31:16.143749+00
76	1	DELETE /api/programs/5	/api/programs/5	{"params":{"id":"5"},"bodyKeys":[]}	127.0.0.1	2026-03-26 09:31:33.525165+00
77	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 09:31:37.141983+00
78	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 09:31:47.552843+00
79	1	DELETE /api/programs/6	/api/programs/6	{"params":{"id":"6"},"bodyKeys":[]}	127.0.0.1	2026-03-26 11:49:56.784201+00
80	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 11:50:00.845715+00
81	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 11:50:09.417915+00
82	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:48:59.169083+00
83	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:51:41.19564+00
84	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 12:56:06.415183+00
85	1	DELETE /api/versions/11	/api/versions/11	{"params":{"id":"11"},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:56:26.075192+00
86	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:56:32.528098+00
87	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.271977+00
88	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.281656+00
89	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.297212+00
90	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.307684+00
91	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.316465+00
92	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.322664+00
93	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 15:28:12.255438+00
1051	1	DELETE /api/roles/462	/api/roles/462	{"params":{"id":"462"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:31:07.938133+00
94	1	DELETE /api/users/2/roles/TRUONG_NGANH/16	/api/users/2/roles/TRUONG_NGANH/16	{"params":{"userId":"2","roleCode":"TRUONG_NGANH","deptId":"16"},"bodyKeys":[]}	172.18.0.1	2026-03-26 15:28:26.758255+00
95	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 15:28:32.504205+00
96	1	DELETE /api/users/2/roles/TRUONG_NGANH/15	/api/users/2/roles/TRUONG_NGANH/15	{"params":{"userId":"2","roleCode":"TRUONG_NGANH","deptId":"15"},"bodyKeys":[]}	172.18.0.1	2026-03-26 15:54:13.437296+00
97	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:13.072871+00
98	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:13.080645+00
99	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:13.090058+00
100	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:13.100332+00
101	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:13.108348+00
102	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:13.115921+00
103	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:20.057424+00
104	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:20.06491+00
105	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:20.081592+00
106	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:20.092188+00
107	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:20.100539+00
108	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:00:20.108818+00
109	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:07:48.088175+00
110	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:07:48.096167+00
111	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:07:48.105261+00
112	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:07:48.115537+00
113	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:07:48.123465+00
114	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:07:48.130669+00
115	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:08:05.175897+00
116	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:08:05.184701+00
117	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:08:05.194024+00
118	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:08:05.204118+00
119	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:08:05.212566+00
120	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:08:05.225002+00
121	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:09:05.205157+00
122	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:09:05.212598+00
123	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:09:05.222408+00
124	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:09:05.233026+00
125	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:09:05.241048+00
126	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 16:09:05.252653+00
127	1	PUT /api/users/1/toggle-active	/api/users/1/toggle-active	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:12:28.160687+00
128	1	PUT /api/users/1/toggle-active	/api/users/1/toggle-active	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:12:28.865867+00
129	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 16:12:34.991949+00
130	1	DELETE /api/users/2/roles/GIANG_VIEN/16	/api/users/2/roles/GIANG_VIEN/16	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"16"},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:12:46.045356+00
131	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 16:16:20.038508+00
132	1	DELETE /api/users/2/roles/GIANG_VIEN/16	/api/users/2/roles/GIANG_VIEN/16	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"16"},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:16:25.837723+00
133	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:20:45.145881+00
134	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:29:42.542604+00
135	1	PUT /api/courses/62	/api/courses/62	{"params":{"id":"62"},"bodyKeys":["code","name","credits","credits_theory","credits_practice","credits_project","credits_internship","department_id","description"]}	172.18.0.1	2026-03-26 16:30:17.843012+00
136	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:31:39.877061+00
137	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:35:46.514323+00
138	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 16:36:23.515449+00
139	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["name","type","parent_id","code"]}	172.18.0.1	2026-03-26 16:48:29.851213+00
140	1	PUT /api/versions/1	/api/versions/1	{"params":{"id":"1"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-26 17:03:11.203955+00
141	1	PUT /api/versions/1	/api/versions/1	{"params":{"id":"1"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-26 17:03:13.982676+00
142	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:29:04.375624+00
143	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:29:04.382568+00
144	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:29:04.39206+00
145	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:29:04.401415+00
146	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:29:04.408617+00
147	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:29:04.418579+00
148	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-26 17:40:06.191198+00
149	1	POST /api/users/3/roles	/api/users/3/roles	{"params":{"id":"3"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 17:40:16.173805+00
150	1	DELETE /api/programs/7	/api/programs/7	{"params":{"id":"7"},"bodyKeys":[]}	172.18.0.1	2026-03-26 17:40:25.778383+00
151	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 17:40:30.370707+00
152	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	172.18.0.1	2026-03-26 17:40:43.440419+00
153	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-26 17:41:22.872197+00
154	1	POST /api/users/4/roles	/api/users/4/roles	{"params":{"id":"4"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 17:41:50.025815+00
155	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-26 17:42:21.131678+00
156	1	POST /api/users/5/roles	/api/users/5/roles	{"params":{"id":"5"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 17:42:40.079663+00
157	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-26 17:43:00.767306+00
158	1	POST /api/users/6/roles	/api/users/6/roles	{"params":{"id":"6"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 17:43:07.233045+00
159	2	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 17:48:58.86037+00
160	3	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 17:50:40.142718+00
161	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:53:28.245534+00
162	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:53:28.252308+00
163	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:53:28.259055+00
164	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:53:28.268474+00
165	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:53:28.274998+00
166	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:53:28.285363+00
167	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 17:53:45.029691+00
168	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 17:54:10.120872+00
169	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:54:45.557532+00
170	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:54:45.56455+00
171	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:54:45.573919+00
172	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:54:45.583844+00
173	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:54:45.590884+00
174	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 17:54:45.602619+00
175	1	PUT /api/courses/65	/api/courses/65	{"params":{"id":"65"},"bodyKeys":["code","name","credits","credits_theory","credits_practice","credits_project","credits_internship","department_id","description"]}	172.18.0.1	2026-03-26 17:56:23.006766+00
176	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 17:56:59.539894+00
177	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 17:57:49.176892+00
178	2	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 18:10:28.67574+00
179	3	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 18:10:49.266965+00
180	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 18:13:10.579554+00
181	2	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 18:17:02.096989+00
182	3	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 18:17:14.135914+00
183	1	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 18:26:19.197156+00
184	1	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 18:26:19.211269+00
185	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 18:28:04.421234+00
186	1	POST /api/versions/1/courses	/api/versions/1/courses	{"params":{"vId":"1"},"bodyKeys":["course_id","semester","course_type"]}	172.18.0.1	2026-03-26 18:29:50.657404+00
187	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 18:46:29.213245+00
188	2	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 18:51:34.845352+00
189	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 18:51:46.657946+00
190	5	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 18:52:06.04834+00
191	6	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 18:53:09.488227+00
192	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 18:54:15.015772+00
193	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 18:54:15.023518+00
194	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 18:54:15.03458+00
195	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 18:54:15.04426+00
196	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 18:54:15.051725+00
197	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 18:54:15.063093+00
198	1	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-26 18:55:11.473138+00
199	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 18:55:20.552614+00
200	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 18:55:30.108505+00
201	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 18:55:31.574426+00
202	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 18:55:32.856527+00
203	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 19:02:54.776997+00
204	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 19:03:05.875038+00
205	5	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 19:03:34.513599+00
206	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:04:27.171272+00
207	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:04:27.178248+00
208	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:04:27.186089+00
209	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:04:27.196328+00
210	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:04:27.202837+00
211	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:04:27.212735+00
212	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:13:07.680045+00
213	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:13:07.688273+00
214	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:13:07.697018+00
215	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:13:07.706982+00
216	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:13:07.715247+00
217	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:13:07.726793+00
218	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-26 19:13:49.287169+00
219	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-26 19:14:16.975323+00
220	5	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-26 19:14:29.713629+00
221	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:15:31.400977+00
222	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:15:31.408258+00
223	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:15:31.416916+00
224	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:15:31.426459+00
225	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:15:31.433339+00
226	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 19:15:31.444862+00
227	1	DELETE /api/users/2/roles/TRUONG_NGANH/15	/api/users/2/roles/TRUONG_NGANH/15	{"params":{"userId":"2","roleCode":"TRUONG_NGANH","deptId":"15"},"bodyKeys":[]}	172.18.0.1	2026-03-27 01:35:40.746984+00
228	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:35:54.586698+00
229	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:35:54.611761+00
230	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:35:54.66243+00
231	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:35:54.6778+00
232	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:35:54.694587+00
233	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:35:54.728544+00
234	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:36:25.323913+00
235	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:36:25.349776+00
236	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:36:25.372622+00
237	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:36:25.397449+00
238	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:36:25.416628+00
239	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 01:36:25.446268+00
240	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-27 01:54:16.215251+00
241	1	DELETE /api/users/2/roles/GIANG_VIEN/15	/api/users/2/roles/GIANG_VIEN/15	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"15"},"bodyKeys":[]}	172.18.0.1	2026-03-27 01:54:19.285138+00
242	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-27 01:58:45.655991+00
243	1	DELETE /api/users/2/roles/TRUONG_NGANH/16	/api/users/2/roles/TRUONG_NGANH/16	{"params":{"userId":"2","roleCode":"TRUONG_NGANH","deptId":"16"},"bodyKeys":[]}	172.18.0.1	2026-03-27 01:58:48.029706+00
244	1	POST /api/versions/17/assignments	/api/versions/17/assignments	{"params":{"vId":"17"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-27 02:21:01.600539+00
245	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-27 02:21:53.51072+00
246	1	POST /api/users/7/roles	/api/users/7/roles	{"params":{"id":"7"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-27 02:22:03.980657+00
247	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:26:37.507014+00
248	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-27 02:29:36.8717+00
249	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-27 02:29:48.530377+00
250	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-27 02:30:14.83219+00
251	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-27 02:30:27.723638+00
252	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-27 02:30:29.659136+00
253	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-27 02:30:31.422993+00
254	1	DELETE /api/versions/18	/api/versions/18	{"params":{"id":"18"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:36:03.083583+00
255	1	DELETE /api/versions/17	/api/versions/17	{"params":{"id":"17"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:36:04.871405+00
256	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:41:50.996734+00
257	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:41:51.020646+00
258	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:41:51.038338+00
259	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:41:51.062047+00
260	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:41:51.080323+00
261	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:41:51.108915+00
262	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:42:09.973885+00
263	3	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-27 02:43:39.422135+00
264	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-27 02:43:56.735915+00
265	3	PUT /api/versions/19	/api/versions/19	{"params":{"id":"19"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-27 02:44:05.45392+00
266	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:44:07.02899+00
267	1	DELETE /api/versions/20	/api/versions/20	{"params":{"id":"20"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:44:57.029201+00
268	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:46:41.74384+00
269	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:46:41.769049+00
270	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:46:41.790586+00
271	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:46:41.813719+00
272	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:46:41.830814+00
273	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-27 02:46:41.855884+00
274	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:47:00.538472+00
275	3	DELETE /api/versions/21	/api/versions/21	{"params":{"id":"21"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:47:45.785238+00
276	3	DELETE /api/versions/19	/api/versions/19	{"params":{"id":"19"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:47:47.626439+00
277	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:48:24.080323+00
278	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:48:31.382323+00
279	3	DELETE /api/versions/23	/api/versions/23	{"params":{"id":"23"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:49:35.242417+00
280	3	DELETE /api/versions/22	/api/versions/22	{"params":{"id":"22"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:49:36.768951+00
281	1	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:50:24.267112+00
282	1	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:50:28.813801+00
283	1	DELETE /api/versions/25	/api/versions/25	{"params":{"id":"25"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:50:33.939047+00
284	1	DELETE /api/versions/24	/api/versions/24	{"params":{"id":"24"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:50:35.426387+00
285	1	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 02:50:39.931567+00
286	1	DELETE /api/versions/26	/api/versions/26	{"params":{"id":"26"},"bodyKeys":[]}	172.18.0.1	2026-03-27 02:50:45.958724+00
287	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 03:01:01.483193+00
288	3	POST /api/programs/1/versions	/api/programs/1/versions	{"params":{"programId":"1"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-27 03:08:04.795033+00
289	2	PUT /api/syllabi/1/clo-plo-map	/api/syllabi/1/clo-plo-map	{"params":{"sId":"1"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-27 03:09:38.994303+00
290	1	DELETE /api/versions/28	/api/versions/28	{"params":{"id":"28"},"bodyKeys":[]}	172.18.0.1	2026-03-27 03:14:25.478246+00
291	1	PUT /api/programs/1	/api/programs/1	{"params":{"id":"1"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-03-27 05:46:44.676652+00
292	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-27 06:20:24.158309+00
293	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-27 07:24:15.497865+00
294	1	DELETE /api/programs/8	/api/programs/8	{"params":{"id":"8"},"bodyKeys":[]}	172.18.0.1	2026-03-27 07:24:26.312623+00
295	1	DELETE /api/courses/26	/api/courses/26	{"params":{"id":"26"},"bodyKeys":[]}	172.18.0.1	2026-03-27 07:24:32.917696+00
296	1	DELETE /api/courses/63	/api/courses/63	{"params":{"id":"63"},"bodyKeys":[]}	172.18.0.1	2026-03-27 07:24:36.671306+00
297	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-27 07:24:46.955453+00
298	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	172.18.0.1	2026-03-27 07:25:01.504098+00
299	1	PUT /api/versions/27	/api/versions/27	{"params":{"id":"27"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-27 07:50:09.708759+00
300	1	POST /api/programs/1/archive	/api/programs/1/archive	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-04-04 04:54:05.191937+00
301	1	PUT /api/versions/29/course-relations	/api/versions/29/course-relations	{"params":{"vId":"29"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 06:00:09.160156+00
302	1	PUT /api/versions/29/course-relations	/api/versions/29/course-relations	{"params":{"vId":"29"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 06:00:19.463249+00
303	1	POST /api/users/3/roles	/api/users/3/roles	{"params":{"id":"3"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 06:02:28.121957+00
304	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:10:13.474281+00
305	1	DELETE /api/programs/10	/api/programs/10	{"params":{"id":"10"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:13.510497+00
306	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:15.038297+00
307	1	PUT /api/programs/11	/api/programs/11	{"params":{"id":"11"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:10:16.364851+00
308	1	DELETE /api/programs/11	/api/programs/11	{"params":{"id":"11"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:16.383081+00
309	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:17.837107+00
310	1	DELETE /api/programs/12	/api/programs/12	{"params":{"id":"12"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:17.845225+00
311	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:19.253707+00
312	1	POST /api/programs/13/archive	/api/programs/13/archive	{"params":{"id":"13"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:19.264497+00
313	1	POST /api/programs/13/unarchive	/api/programs/13/unarchive	{"params":{"id":"13"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:20.366325+00
314	1	DELETE /api/programs/13	/api/programs/13	{"params":{"id":"13"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:20.370624+00
315	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:21.721991+00
316	1	POST /api/programs/14/versions	/api/programs/14/versions	{"params":{"programId":"14"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:21.736446+00
317	1	DELETE /api/versions/30	/api/versions/30	{"params":{"id":"30"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:21.749527+00
318	1	DELETE /api/programs/14	/api/programs/14	{"params":{"id":"14"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:21.753368+00
319	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:26.411895+00
320	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:10:26.734602+00
321	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:30.866048+00
322	1	POST /api/programs/17/versions	/api/programs/17/versions	{"params":{"programId":"17"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:30.875055+00
323	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:36.334719+00
324	1	POST /api/programs/18/archive	/api/programs/18/archive	{"params":{"id":"18"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:36.340428+00
325	1	POST /api/programs/18/unarchive	/api/programs/18/unarchive	{"params":{"id":"18"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:36.350903+00
326	1	DELETE /api/programs/18	/api/programs/18	{"params":{"id":"18"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:36.358922+00
327	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:37.200162+00
328	1	POST /api/programs/19/versions	/api/programs/19/versions	{"params":{"programId":"19"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:37.211053+00
329	1	PUT /api/versions/32	/api/versions/32	{"params":{"id":"32"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:10:41.050821+00
330	1	PUT /api/versions/32	/api/versions/32	{"params":{"id":"32"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:41.944679+00
331	1	DELETE /api/versions/32	/api/versions/32	{"params":{"id":"32"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:42.880078+00
332	1	DELETE /api/programs/19	/api/programs/19	{"params":{"id":"19"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:42.885609+00
333	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:45.019836+00
334	1	POST /api/programs/20/versions	/api/programs/20/versions	{"params":{"programId":"20"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:45.029994+00
336	1	DELETE /api/versions/33	/api/versions/33	{"params":{"id":"33"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:48.613581+00
337	1	DELETE /api/programs/20	/api/programs/20	{"params":{"id":"20"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:48.618616+00
338	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:50.64407+00
339	1	POST /api/programs/21/versions	/api/programs/21/versions	{"params":{"programId":"21"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:50.650024+00
340	1	DELETE /api/versions/34	/api/versions/34	{"params":{"id":"34"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:52.390761+00
341	1	DELETE /api/programs/21	/api/programs/21	{"params":{"id":"21"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:52.394625+00
346	1	POST /api/versions/35/objectives	/api/versions/35/objectives	{"params":{"vId":"35"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:10:56.185628+00
351	1	POST /api/versions/36/objectives	/api/versions/36/objectives	{"params":{"vId":"36"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:11:00.013623+00
352	1	POST /api/versions/36/objectives	/api/versions/36/objectives	{"params":{"vId":"36"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:11:00.024414+00
1248	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:41:06.560429+00
1249	1	POST /api/programs/191/versions	/api/programs/191/versions	{"params":{"programId":"191"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:41:06.566628+00
1250	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:41:06.586467+00
1251	1	DELETE /api/programs/191	/api/programs/191	{"params":{"id":"191"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:06.600887+00
1258	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:41:11.2196+00
1259	1	POST /api/programs/193/versions	/api/programs/193/versions	{"params":{"programId":"193"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:41:11.224955+00
1260	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:41:11.22934+00
1261	1	DELETE /api/programs/193	/api/programs/193	{"params":{"id":"193"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:11.252849+00
1374	1	POST /api/versions/180/plos	/api/versions/180/plos	{"params":{"vId":"180"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:28.715944+00
1571	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:48:34.481514+00
1572	1	POST /api/users/74/roles	/api/users/74/roles	{"params":{"id":"74"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:48:34.495285+00
1573	1	DELETE /api/users/74/roles/GIANG_VIEN/5	/api/users/74/roles/GIANG_VIEN/5	{"params":{"userId":"74","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:34.506997+00
1574	1	DELETE /api/users/74	/api/users/74	{"params":{"id":"74"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:34.518287+00
1582	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:47.025914+00
1583	1	POST /api/programs/256/versions	/api/programs/256/versions	{"params":{"programId":"256"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:47.033968+00
1585	1	DELETE /api/versions/216	/api/versions/216	{"params":{"id":"216"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:50.703645+00
1586	1	DELETE /api/programs/256	/api/programs/256	{"params":{"id":"256"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:50.709854+00
1637	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:49:29.628773+00
1638	1	DELETE /api/roles/513	/api/roles/513	{"params":{"id":"513"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:29.634229+00
1721	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:51:50.240014+00
1722	1	POST /api/programs/279/versions	/api/programs/279/versions	{"params":{"programId":"279"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:51:50.247446+00
1812	1	POST /api/programs/299/versions	/api/programs/299/versions	{"params":{"programId":"299"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:13.534486+00
1813	1	POST /api/versions/259/knowledge-blocks	/api/versions/259/knowledge-blocks	{"params":{"vId":"259"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:04:13.563609+00
1814	1	POST /api/versions/259/knowledge-blocks	/api/versions/259/knowledge-blocks	{"params":{"vId":"259"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:04:20.979893+00
1815	1	POST /api/versions/259/knowledge-blocks	/api/versions/259/knowledge-blocks	{"params":{"vId":"259"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:04:21.013083+00
1816	1	DELETE /api/knowledge-blocks/1369	/api/knowledge-blocks/1369	{"params":{"id":"1369"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:21.045797+00
1946	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:59.514999+00
1947	1	POST /api/programs/326/versions	/api/programs/326/versions	{"params":{"programId":"326"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:59.526421+00
1949	1	DELETE /api/versions/277	/api/versions/277	{"params":{"id":"277"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:02.304719+00
1950	1	DELETE /api/programs/326	/api/programs/326	{"params":{"id":"326"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:02.309792+00
2073	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:28:29.080345+00
2074	1	POST /api/programs/339/versions	/api/programs/339/versions	{"params":{"programId":"339"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:28:29.091798+00
2256	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:38:19.72992+00
2257	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:38:19.74631+00
2258	1	DELETE /api/courses/656	/api/courses/656	{"params":{"id":"656"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:38:24.33918+00
2259	1	DELETE /api/departments/1852	/api/departments/1852	{"params":{"id":"1852"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:38:24.349963+00
2437	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:48:54.820301+00
335	1	PUT /api/versions/33	/api/versions/33	{"params":{"id":"33"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:10:45.90402+00
342	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:54.504538+00
343	1	POST /api/programs/22/versions	/api/programs/22/versions	{"params":{"programId":"22"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:54.514664+00
344	1	POST /api/versions/35/objectives	/api/versions/35/objectives	{"params":{"vId":"35"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:10:55.355362+00
345	1	DELETE /api/objectives/76	/api/objectives/76	{"params":{"id":"76"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:55.36405+00
347	1	DELETE /api/versions/35	/api/versions/35	{"params":{"id":"35"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:57.048438+00
348	1	DELETE /api/programs/22	/api/programs/22	{"params":{"id":"22"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:10:57.053636+00
349	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:10:59.118801+00
350	1	POST /api/programs/23/versions	/api/programs/23/versions	{"params":{"programId":"23"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:10:59.127592+00
353	1	DELETE /api/versions/36	/api/versions/36	{"params":{"id":"36"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:00.90163+00
354	1	DELETE /api/programs/23	/api/programs/23	{"params":{"id":"23"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:00.90715+00
355	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:03.004181+00
356	1	POST /api/programs/24/versions	/api/programs/24/versions	{"params":{"programId":"24"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:03.012862+00
357	1	DELETE /api/versions/37	/api/versions/37	{"params":{"id":"37"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:04.77662+00
358	1	DELETE /api/programs/24	/api/programs/24	{"params":{"id":"24"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:04.781057+00
359	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:06.853697+00
360	1	POST /api/programs/25/versions	/api/programs/25/versions	{"params":{"programId":"25"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:06.862494+00
361	1	DELETE /api/versions/38	/api/versions/38	{"params":{"id":"38"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:08.581138+00
362	1	DELETE /api/programs/25	/api/programs/25	{"params":{"id":"25"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:08.584589+00
363	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:10.689056+00
364	1	POST /api/programs/26/versions	/api/programs/26/versions	{"params":{"programId":"26"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:10.698514+00
365	1	DELETE /api/versions/39	/api/versions/39	{"params":{"id":"39"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:12.498155+00
366	1	DELETE /api/programs/26	/api/programs/26	{"params":{"id":"26"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:12.502339+00
367	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:14.601354+00
368	1	POST /api/programs/27/versions	/api/programs/27/versions	{"params":{"programId":"27"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:14.610499+00
369	1	POST /api/versions/40/plos	/api/versions/40/plos	{"params":{"vId":"40"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:11:15.497189+00
370	1	DELETE /api/versions/40	/api/versions/40	{"params":{"id":"40"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:16.399362+00
371	1	DELETE /api/programs/27	/api/programs/27	{"params":{"id":"27"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:16.404271+00
372	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:18.392777+00
373	1	POST /api/programs/28/versions	/api/programs/28/versions	{"params":{"programId":"28"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:18.399198+00
374	1	POST /api/versions/41/plos	/api/versions/41/plos	{"params":{"vId":"41"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:11:20.138242+00
375	1	DELETE /api/versions/41	/api/versions/41	{"params":{"id":"41"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:21.029611+00
376	1	DELETE /api/programs/28	/api/programs/28	{"params":{"id":"28"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:21.035277+00
377	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:23.045756+00
378	1	POST /api/programs/29/versions	/api/programs/29/versions	{"params":{"programId":"29"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:23.05635+00
379	1	DELETE /api/versions/42	/api/versions/42	{"params":{"id":"42"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:24.890852+00
380	1	DELETE /api/programs/29	/api/programs/29	{"params":{"id":"29"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:24.894356+00
381	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:26.817363+00
382	1	POST /api/programs/30/versions	/api/programs/30/versions	{"params":{"programId":"30"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:26.826495+00
383	1	DELETE /api/versions/43	/api/versions/43	{"params":{"id":"43"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:28.677819+00
384	1	DELETE /api/programs/30	/api/programs/30	{"params":{"id":"30"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:28.681886+00
385	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:30.717834+00
386	1	POST /api/programs/31/versions	/api/programs/31/versions	{"params":{"programId":"31"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:30.726777+00
387	1	POST /api/versions/44/objectives	/api/versions/44/objectives	{"params":{"vId":"44"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:11:32.405754+00
388	1	DELETE /api/versions/44	/api/versions/44	{"params":{"id":"44"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:33.289042+00
389	1	DELETE /api/programs/31	/api/programs/31	{"params":{"id":"31"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:33.292482+00
390	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:35.414103+00
391	1	POST /api/programs/32/versions	/api/programs/32/versions	{"params":{"programId":"32"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:35.423545+00
392	1	DELETE /api/versions/45	/api/versions/45	{"params":{"id":"45"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:37.278715+00
393	1	DELETE /api/programs/32	/api/programs/32	{"params":{"id":"32"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:37.283936+00
394	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:39.380593+00
395	1	POST /api/programs/33/versions	/api/programs/33/versions	{"params":{"programId":"33"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:39.387785+00
396	1	DELETE /api/versions/46	/api/versions/46	{"params":{"id":"46"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:41.145632+00
397	1	DELETE /api/programs/33	/api/programs/33	{"params":{"id":"33"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:41.15043+00
398	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:43.087397+00
399	1	POST /api/programs/34/versions	/api/programs/34/versions	{"params":{"programId":"34"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:43.093962+00
400	1	POST /api/versions/47/knowledge-blocks	/api/versions/47/knowledge-blocks	{"params":{"vId":"47"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:11:43.966461+00
401	1	POST /api/versions/47/knowledge-blocks	/api/versions/47/knowledge-blocks	{"params":{"vId":"47"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:11:44.82897+00
402	1	POST /api/versions/47/knowledge-blocks	/api/versions/47/knowledge-blocks	{"params":{"vId":"47"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:11:46.604708+00
403	1	DELETE /api/versions/47	/api/versions/47	{"params":{"id":"47"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:47.441069+00
404	1	DELETE /api/programs/34	/api/programs/34	{"params":{"id":"34"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:47.445551+00
405	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:49.440592+00
406	1	POST /api/programs/35/versions	/api/programs/35/versions	{"params":{"programId":"35"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:49.447929+00
407	1	POST /api/versions/48/courses	/api/versions/48/courses	{"params":{"vId":"48"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:11:50.406802+00
408	1	DELETE /api/version-courses/843	/api/version-courses/843	{"params":{"id":"843"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:50.414515+00
409	1	POST /api/versions/48/courses	/api/versions/48/courses	{"params":{"vId":"48"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:11:51.226685+00
410	1	DELETE /api/version-courses/844	/api/version-courses/844	{"params":{"id":"844"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:51.233254+00
411	1	POST /api/versions/48/courses	/api/versions/48/courses	{"params":{"vId":"48"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:11:52.197087+00
412	1	POST /api/versions/48/courses	/api/versions/48/courses	{"params":{"vId":"48"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:11:52.202934+00
413	1	DELETE /api/version-courses/845	/api/version-courses/845	{"params":{"id":"845"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:52.209446+00
414	1	DELETE /api/versions/48	/api/versions/48	{"params":{"id":"48"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:53.041962+00
415	1	DELETE /api/programs/35	/api/programs/35	{"params":{"id":"35"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:53.045905+00
418	1	POST /api/versions/49/courses	/api/versions/49/courses	{"params":{"vId":"49"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:11:55.969403+00
419	1	PUT /api/version-courses/847	/api/version-courses/847	{"params":{"id":"847"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 08:11:55.975288+00
420	1	DELETE /api/version-courses/847	/api/version-courses/847	{"params":{"id":"847"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:55.982066+00
421	1	DELETE /api/versions/49	/api/versions/49	{"params":{"id":"49"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:58.427045+00
422	1	DELETE /api/programs/36	/api/programs/36	{"params":{"id":"36"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:11:58.432425+00
423	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:12:00.422568+00
424	1	POST /api/programs/37/versions	/api/programs/37/versions	{"params":{"programId":"37"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:12:00.430468+00
425	1	DELETE /api/versions/50	/api/versions/50	{"params":{"id":"50"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:02.209645+00
426	1	DELETE /api/programs/37	/api/programs/37	{"params":{"id":"37"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:02.214482+00
427	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:12:04.211364+00
428	1	POST /api/programs/38/versions	/api/programs/38/versions	{"params":{"programId":"38"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:12:04.218776+00
429	1	DELETE /api/versions/51	/api/versions/51	{"params":{"id":"51"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:06.825793+00
430	1	DELETE /api/programs/38	/api/programs/38	{"params":{"id":"38"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:06.830165+00
431	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:12:08.807827+00
432	1	POST /api/programs/39/versions	/api/programs/39/versions	{"params":{"programId":"39"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:12:08.814569+00
433	1	DELETE /api/versions/52	/api/versions/52	{"params":{"id":"52"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:11.442338+00
434	1	DELETE /api/programs/39	/api/programs/39	{"params":{"id":"39"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:11.447122+00
437	1	DELETE /api/versions/53	/api/versions/53	{"params":{"id":"53"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:20.18461+00
438	1	DELETE /api/programs/40	/api/programs/40	{"params":{"id":"40"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:20.189823+00
441	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:13:00.663301+00
442	1	POST /api/programs/41/versions	/api/programs/41/versions	{"params":{"programId":"41"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:13:00.670661+00
443	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:13:00.688052+00
444	1	DELETE /api/programs/41	/api/programs/41	{"params":{"id":"41"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:00.699216+00
1252	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:41:10.266053+00
1253	1	POST /api/programs/192/versions	/api/programs/192/versions	{"params":{"programId":"192"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:41:10.277243+00
1254	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:41:10.282108+00
1255	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:41:10.291748+00
1256	1	DELETE /api/approval/rejected/program_version/166	/api/approval/rejected/program_version/166	{"params":{"entityType":"program_version","entityId":"166"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:10.301531+00
1257	1	DELETE /api/programs/192	/api/programs/192	{"params":{"id":"192"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:10.312937+00
1274	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:26.837325+00
1275	1	POST /api/users/63/roles	/api/users/63/roles	{"params":{"id":"63"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:41:26.84891+00
416	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:11:55.054038+00
417	1	POST /api/programs/36/versions	/api/programs/36/versions	{"params":{"programId":"36"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:11:55.06064+00
435	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:12:13.454191+00
436	1	POST /api/programs/40/versions	/api/programs/40/versions	{"params":{"programId":"40"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:12:13.459982+00
439	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:12:41.276591+00
440	1	DELETE /api/courses/638	/api/courses/638	{"params":{"id":"638"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:12:41.312637+00
445	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:13:04.171371+00
446	1	POST /api/programs/42/versions	/api/programs/42/versions	{"params":{"programId":"42"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:13:04.179223+00
447	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:13:04.184322+00
448	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:13:04.197023+00
449	1	DELETE /api/approval/rejected/program_version/55	/api/approval/rejected/program_version/55	{"params":{"entityType":"program_version","entityId":"55"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:04.20827+00
450	1	DELETE /api/programs/42	/api/programs/42	{"params":{"id":"42"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:04.214544+00
451	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:13:05.140044+00
452	1	POST /api/programs/43/versions	/api/programs/43/versions	{"params":{"programId":"43"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:13:05.147229+00
453	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:13:05.152877+00
454	1	DELETE /api/programs/43	/api/programs/43	{"params":{"id":"43"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:05.17034+00
455	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:13:07.935581+00
456	1	POST /api/programs/44/versions	/api/programs/44/versions	{"params":{"programId":"44"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:13:07.942429+00
457	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:13:07.947157+00
458	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:13:07.961183+00
459	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:14.06604+00
460	1	DELETE /api/users/8	/api/users/8	{"params":{"id":"8"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:14.078902+00
461	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:16.148273+00
462	1	PUT /api/users/9	/api/users/9	{"params":{"id":"9"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 08:13:16.158052+00
463	1	DELETE /api/users/9	/api/users/9	{"params":{"id":"9"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:16.173259+00
464	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:18.130927+00
465	1	POST /api/users/10/roles	/api/users/10/roles	{"params":{"id":"10"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:13:18.155843+00
466	1	DELETE /api/users/10	/api/users/10	{"params":{"id":"10"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:18.166181+00
467	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:20.173628+00
468	1	POST /api/users/11/roles	/api/users/11/roles	{"params":{"id":"11"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:13:20.187778+00
469	1	DELETE /api/users/11/roles/GIANG_VIEN/5	/api/users/11/roles/GIANG_VIEN/5	{"params":{"userId":"11","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:20.198998+00
470	1	DELETE /api/users/11	/api/users/11	{"params":{"id":"11"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:20.20738+00
471	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:22.228884+00
472	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:25.696795+00
473	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:28.883978+00
474	1	DELETE /api/users/14	/api/users/14	{"params":{"id":"14"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:28.970439+00
475	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:30.903996+00
476	1	DELETE /api/users/16	/api/users/16	{"params":{"id":"16"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:30.917508+00
477	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:32.823892+00
478	1	PUT /api/users/17/toggle-active	/api/users/17/toggle-active	{"params":{"id":"17"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:32.8323+00
479	1	DELETE /api/users/17	/api/users/17	{"params":{"id":"17"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:32.841282+00
480	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:13:34.883757+00
481	1	DELETE /api/users/18	/api/users/18	{"params":{"id":"18"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:34.895485+00
482	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:13:45.496306+00
483	1	DELETE /api/roles/415	/api/roles/415	{"params":{"id":"415"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:45.500643+00
484	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:13:53.994731+00
485	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:13:56.951656+00
486	1	DELETE /api/roles/417	/api/roles/417	{"params":{"id":"417"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:13:56.979866+00
487	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:14:02.370177+00
488	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:14:07.482857+00
489	1	DELETE /api/roles/419	/api/roles/419	{"params":{"id":"419"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:14:07.488327+00
490	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:14:09.221654+00
491	1	PUT /api/roles/420	/api/roles/420	{"params":{"id":"420"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:14:09.225364+00
492	1	DELETE /api/roles/420	/api/roles/420	{"params":{"id":"420"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:14:09.228852+00
493	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 08:14:15.976464+00
494	1	DELETE /api/departments/1520	/api/departments/1520	{"params":{"id":"1520"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:14:15.983163+00
495	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:14:16.818898+00
498	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:14:20.50173+00
499	1	DELETE /api/departments/1524	/api/departments/1524	{"params":{"id":"1524"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:14:20.507542+00
1262	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:41:14.156846+00
1263	1	POST /api/programs/194/versions	/api/programs/194/versions	{"params":{"programId":"194"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:41:14.162549+00
1264	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:41:14.167229+00
1265	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:41:14.182415+00
1375	1	DELETE /api/versions/180	/api/versions/180	{"params":{"id":"180"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:29.727095+00
1376	1	DELETE /api/programs/213	/api/programs/213	{"params":{"id":"213"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:29.731793+00
1379	1	DELETE /api/versions/181	/api/versions/181	{"params":{"id":"181"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:33.907654+00
1380	1	DELETE /api/programs/214	/api/programs/214	{"params":{"id":"214"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:33.911298+00
1575	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:48:38.423565+00
1593	1	POST /api/versions/218/objectives	/api/versions/218/objectives	{"params":{"vId":"218"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:48:57.640966+00
1594	1	DELETE /api/objectives/111	/api/objectives/111	{"params":{"id":"111"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:57.652062+00
1600	1	POST /api/versions/219/objectives	/api/versions/219/objectives	{"params":{"vId":"219"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:49:02.473038+00
1601	1	POST /api/versions/219/objectives	/api/versions/219/objectives	{"params":{"vId":"219"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:49:02.481644+00
1614	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:49:14.20067+00
1615	1	DELETE /api/users/79	/api/users/79	{"params":{"id":"79"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:14.214996+00
1725	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:51:58.407846+00
1726	1	POST /api/programs/280/versions	/api/programs/280/versions	{"params":{"programId":"280"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:51:58.414943+00
1817	1	DELETE /api/versions/259	/api/versions/259	{"params":{"id":"259"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.17834+00
1818	1	DELETE /api/programs/295	/api/programs/295	{"params":{"id":"295"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.193775+00
1819	1	DELETE /api/programs/296	/api/programs/296	{"params":{"id":"296"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.315959+00
1820	1	DELETE /api/programs/297	/api/programs/297	{"params":{"id":"297"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.443285+00
1821	1	DELETE /api/programs/298	/api/programs/298	{"params":{"id":"298"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.562508+00
1948	1	POST /api/versions/277/objectives	/api/versions/277/objectives	{"params":{"vId":"277"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:22:01.513971+00
2075	1	DELETE /api/versions/289	/api/versions/289	{"params":{"id":"289"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:28:33.32+00
2076	1	DELETE /api/programs/339	/api/programs/339	{"params":{"id":"339"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:28:33.325472+00
2260	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:42:24.99051+00
2261	1	PUT /api/courses/657	/api/courses/657	{"params":{"id":"657"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:42:25.023599+00
2262	1	DELETE /api/courses/657	/api/courses/657	{"params":{"id":"657"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:42:25.035766+00
2438	1	DELETE /api/roles/554	/api/roles/554	{"params":{"id":"554"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:54.826052+00
2442	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:49:00.047747+00
2443	1	DELETE /api/departments/1877	/api/departments/1877	{"params":{"id":"1877"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:00.054245+00
2449	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:49:03.386597+00
2572	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:51:10.178313+00
2573	1	DELETE /api/courses/668	/api/courses/668	{"params":{"id":"668"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:10.185154+00
2574	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:51:12.888549+00
2575	1	DELETE /api/courses/669	/api/courses/669	{"params":{"id":"669"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:12.893137+00
2576	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:51:29.048748+00
2577	1	POST /api/programs/383/versions	/api/programs/383/versions	{"params":{"programId":"383"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:51:29.05557+00
2578	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:51:29.065791+00
2579	1	DELETE /api/programs/383	/api/programs/383	{"params":{"id":"383"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:29.088388+00
2596	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:40.30014+00
2597	1	DELETE /api/users/118	/api/users/118	{"params":{"id":"118"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:40.309954+00
2644	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:53:09.880131+00
2645	1	DELETE /api/programs/388	/api/programs/388	{"params":{"id":"388"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:53:10.991312+00
2671	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:08.187763+00
2672	1	POST /api/programs/394/versions	/api/programs/394/versions	{"params":{"programId":"394"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:56:08.203655+00
2673	1	DELETE /api/versions/315	/api/versions/315	{"params":{"id":"315"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:08.217972+00
2674	1	DELETE /api/programs/394	/api/programs/394	{"params":{"id":"394"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:08.222085+00
496	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:14:18.761598+00
497	1	DELETE /api/departments/1522	/api/departments/1522	{"params":{"id":"1522"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:14:18.773728+00
500	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:15:24.666012+00
501	1	POST /api/programs/45/versions	/api/programs/45/versions	{"params":{"programId":"45"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:15:24.674869+00
502	1	DELETE /api/versions/58	/api/versions/58	{"params":{"id":"58"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:15:24.684038+00
503	1	DELETE /api/programs/45	/api/programs/45	{"params":{"id":"45"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:15:24.691399+00
504	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:20:32.129744+00
505	1	DELETE /api/programs/46	/api/programs/46	{"params":{"id":"46"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:32.248555+00
506	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:33.837363+00
507	1	PUT /api/programs/47	/api/programs/47	{"params":{"id":"47"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:20:35.185272+00
508	1	DELETE /api/programs/47	/api/programs/47	{"params":{"id":"47"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:35.269238+00
509	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:36.723369+00
510	1	DELETE /api/programs/48	/api/programs/48	{"params":{"id":"48"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:36.732918+00
511	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:38.207616+00
512	1	POST /api/programs/49/archive	/api/programs/49/archive	{"params":{"id":"49"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:38.217861+00
513	1	POST /api/programs/49/unarchive	/api/programs/49/unarchive	{"params":{"id":"49"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:39.352851+00
514	1	DELETE /api/programs/49	/api/programs/49	{"params":{"id":"49"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:39.357333+00
515	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:40.820865+00
516	1	POST /api/programs/50/versions	/api/programs/50/versions	{"params":{"programId":"50"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:20:40.831455+00
517	1	DELETE /api/versions/59	/api/versions/59	{"params":{"id":"59"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:40.844702+00
518	1	DELETE /api/programs/50	/api/programs/50	{"params":{"id":"50"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:40.848499+00
519	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:45.735022+00
520	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:20:46.035356+00
521	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:50.458907+00
522	1	POST /api/programs/53/versions	/api/programs/53/versions	{"params":{"programId":"53"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:20:50.465944+00
523	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:56.131074+00
524	1	POST /api/programs/54/archive	/api/programs/54/archive	{"params":{"id":"54"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:56.135695+00
525	1	POST /api/programs/54/unarchive	/api/programs/54/unarchive	{"params":{"id":"54"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:56.146945+00
526	1	DELETE /api/programs/54	/api/programs/54	{"params":{"id":"54"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:20:56.158398+00
527	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:20:57.163873+00
528	1	POST /api/programs/55/versions	/api/programs/55/versions	{"params":{"programId":"55"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:20:57.18032+00
529	1	PUT /api/versions/61	/api/versions/61	{"params":{"id":"61"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:21:01.236562+00
530	1	PUT /api/versions/61	/api/versions/61	{"params":{"id":"61"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:21:02.211427+00
531	1	DELETE /api/versions/61	/api/versions/61	{"params":{"id":"61"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:03.116086+00
532	1	DELETE /api/programs/55	/api/programs/55	{"params":{"id":"55"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:03.119969+00
533	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:05.326611+00
534	1	POST /api/programs/56/versions	/api/programs/56/versions	{"params":{"programId":"56"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:21:05.334883+00
535	1	PUT /api/versions/62	/api/versions/62	{"params":{"id":"62"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:21:06.319798+00
536	1	DELETE /api/versions/62	/api/versions/62	{"params":{"id":"62"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:09.122451+00
537	1	DELETE /api/programs/56	/api/programs/56	{"params":{"id":"56"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:09.127024+00
538	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:21:40.274316+00
539	1	DELETE /api/programs/57	/api/programs/57	{"params":{"id":"57"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:40.369887+00
540	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:41.845613+00
541	1	PUT /api/programs/58	/api/programs/58	{"params":{"id":"58"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:21:43.240797+00
542	1	DELETE /api/programs/58	/api/programs/58	{"params":{"id":"58"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:43.318704+00
543	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:44.919113+00
544	1	DELETE /api/programs/59	/api/programs/59	{"params":{"id":"59"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:44.940252+00
545	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:46.386223+00
546	1	POST /api/programs/60/archive	/api/programs/60/archive	{"params":{"id":"60"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:46.397349+00
547	1	POST /api/programs/60/unarchive	/api/programs/60/unarchive	{"params":{"id":"60"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:47.572886+00
548	1	DELETE /api/programs/60	/api/programs/60	{"params":{"id":"60"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:47.578274+00
555	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:58.751842+00
556	1	POST /api/programs/64/versions	/api/programs/64/versions	{"params":{"programId":"64"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:21:58.758572+00
1266	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:20.694673+00
1267	1	DELETE /api/users/60	/api/users/60	{"params":{"id":"60"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:20.711606+00
1286	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:40.68087+00
1287	1	DELETE /api/users/70	/api/users/70	{"params":{"id":"70"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:40.690226+00
1301	1	DELETE /api/departments/1743	/api/departments/1743	{"params":{"id":"1743"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:42:25.714403+00
1381	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:36.153673+00
1382	1	POST /api/programs/215/versions	/api/programs/215/versions	{"params":{"programId":"215"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:36.166743+00
1400	1	POST /api/versions/186/knowledge-blocks	/api/versions/186/knowledge-blocks	{"params":{"vId":"186"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:44:55.114193+00
1407	1	POST /api/versions/187/courses	/api/versions/187/courses	{"params":{"vId":"187"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:45:02.188687+00
1408	1	DELETE /api/version-courses/863	/api/version-courses/863	{"params":{"id":"863"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:02.195506+00
1416	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:45:07.438292+00
1417	1	POST /api/programs/221/versions	/api/programs/221/versions	{"params":{"programId":"221"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:45:07.444399+00
1441	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:46:40.968906+00
1442	1	DELETE /api/programs/226	/api/programs/226	{"params":{"id":"226"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:41.157536+00
1464	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:50.610801+00
1465	1	POST /api/programs/233/versions	/api/programs/233/versions	{"params":{"programId":"233"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:50.618381+00
1589	1	DELETE /api/versions/217	/api/versions/217	{"params":{"id":"217"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:54.604999+00
1590	1	DELETE /api/programs/257	/api/programs/257	{"params":{"id":"257"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:54.611227+00
1595	1	POST /api/versions/218/objectives	/api/versions/218/objectives	{"params":{"vId":"218"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:48:58.569873+00
1602	1	DELETE /api/versions/219	/api/versions/219	{"params":{"id":"219"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:03.396969+00
1603	1	DELETE /api/programs/259	/api/programs/259	{"params":{"id":"259"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:03.402047+00
1606	1	DELETE /api/versions/220	/api/versions/220	{"params":{"id":"220"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:07.349983+00
1607	1	DELETE /api/programs/260	/api/programs/260	{"params":{"id":"260"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:07.353905+00
1623	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:49:18.484299+00
1627	1	POST /api/versions/223/plos	/api/versions/223/plos	{"params":{"vId":"223"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:49:19.682636+00
1630	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:22.828321+00
1631	1	POST /api/programs/264/versions	/api/programs/264/versions	{"params":{"programId":"264"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:22.834908+00
1727	1	DELETE /api/versions/240	/api/versions/240	{"params":{"id":"240"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:00.26764+00
1728	1	DELETE /api/programs/280	/api/programs/280	{"params":{"id":"280"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:00.273707+00
1731	1	DELETE /api/versions/241	/api/versions/241	{"params":{"id":"241"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:08.537806+00
1732	1	DELETE /api/programs/281	/api/programs/281	{"params":{"id":"281"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:08.541836+00
1737	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:52:23.401591+00
1738	1	POST /api/programs/283/versions	/api/programs/283/versions	{"params":{"programId":"283"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:52:23.409227+00
1822	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:33.631971+00
1823	1	POST /api/programs/300/versions	/api/programs/300/versions	{"params":{"programId":"300"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:33.663612+00
1824	1	DELETE /api/versions/260	/api/versions/260	{"params":{"id":"260"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.724128+00
1825	1	DELETE /api/programs/300	/api/programs/300	{"params":{"id":"300"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:33.733215+00
1826	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:04:42.726244+00
1827	1	POST /api/users/84/roles	/api/users/84/roles	{"params":{"id":"84"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:04:42.75904+00
1828	1	POST /api/users/84/roles	/api/users/84/roles	{"params":{"id":"84"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:04:42.768259+00
1829	1	DELETE /api/users/84	/api/users/84	{"params":{"id":"84"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:42.777776+00
1830	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:42.791724+00
1831	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:42.842142+00
1832	1	DELETE /api/programs/301	/api/programs/301	{"params":{"id":"301"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:42.852533+00
1951	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:22:04.590903+00
1952	1	POST /api/programs/327/versions	/api/programs/327/versions	{"params":{"programId":"327"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:22:04.601575+00
2077	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:29:00.251633+00
2078	1	POST /api/programs/340/versions	/api/programs/340/versions	{"params":{"programId":"340"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:29:00.261966+00
549	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:48.989595+00
550	1	POST /api/programs/61/versions	/api/programs/61/versions	{"params":{"programId":"61"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:21:49.003137+00
551	1	DELETE /api/versions/63	/api/versions/63	{"params":{"id":"63"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:49.014361+00
552	1	DELETE /api/programs/61	/api/programs/61	{"params":{"id":"61"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:21:49.018571+00
1268	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:22.748838+00
1269	1	PUT /api/users/61	/api/users/61	{"params":{"id":"61"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 08:41:22.75733+00
1270	1	DELETE /api/users/61	/api/users/61	{"params":{"id":"61"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:22.774291+00
1291	1	DELETE /api/roles/497	/api/roles/497	{"params":{"id":"497"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:42:02.439258+00
1383	1	DELETE /api/versions/182	/api/versions/182	{"params":{"id":"182"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:38.084902+00
1384	1	DELETE /api/programs/215	/api/programs/215	{"params":{"id":"215"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:38.094744+00
1390	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:45.616875+00
1391	1	POST /api/programs/217/versions	/api/programs/217/versions	{"params":{"programId":"217"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:45.629741+00
1591	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:56.775488+00
1592	1	POST /api/programs/258/versions	/api/programs/258/versions	{"params":{"programId":"258"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:56.784881+00
1729	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:52:06.777936+00
1730	1	POST /api/programs/281/versions	/api/programs/281/versions	{"params":{"programId":"281"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:52:06.786503+00
1833	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:53.670456+00
1953	1	PUT /api/versions/278/po-plo-map	/api/versions/278/po-plo-map	{"params":{"vId":"278"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:22:05.572474+00
1968	1	POST /api/versions/279/courses	/api/versions/279/courses	{"params":{"vId":"279"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:22:16.47872+00
1969	1	POST /api/versions/279/courses	/api/versions/279/courses	{"params":{"vId":"279"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:22:16.485258+00
1970	1	DELETE /api/version-courses/880	/api/version-courses/880	{"params":{"id":"880"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:16.49324+00
1975	1	PUT /api/versions/279/course-plo-map	/api/versions/279/course-plo-map	{"params":{"vId":"279"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:22:20.365312+00
1977	1	POST /api/versions/279/courses	/api/versions/279/courses	{"params":{"vId":"279"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:22:23.941676+00
1978	1	PUT /api/versions/279/course-relations	/api/versions/279/course-relations	{"params":{"vId":"279"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 09:22:23.947993+00
1979	1	DELETE /api/version-courses/883	/api/version-courses/883	{"params":{"id":"883"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:23.955801+00
1980	1	DELETE /api/versions/279	/api/versions/279	{"params":{"id":"279"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:30.532905+00
1981	1	DELETE /api/programs/328	/api/programs/328	{"params":{"id":"328"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:30.537183+00
2079	1	DELETE /api/versions/290	/api/versions/290	{"params":{"id":"290"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:29:02.337464+00
2080	1	DELETE /api/programs/340	/api/programs/340	{"params":{"id":"340"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:29:02.343122+00
2263	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:43:10.581157+00
2264	1	DELETE /api/programs/357	/api/programs/357	{"params":{"id":"357"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:43:11.709805+00
2450	1	DELETE /api/departments/1881	/api/departments/1881	{"params":{"id":"1881"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:03.400922+00
2580	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:51:32.176523+00
2581	1	POST /api/programs/384/versions	/api/programs/384/versions	{"params":{"programId":"384"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:51:32.182353+00
2582	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:51:32.187295+00
2583	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:51:32.196671+00
2584	1	DELETE /api/approval/rejected/program_version/311	/api/approval/rejected/program_version/311	{"params":{"entityType":"program_version","entityId":"311"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:32.219354+00
2585	1	DELETE /api/programs/384	/api/programs/384	{"params":{"id":"384"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:32.226051+00
2601	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:44.060608+00
2602	1	POST /api/users/120/roles	/api/users/120/roles	{"params":{"id":"120"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:51:44.086242+00
2603	1	DELETE /api/users/120	/api/users/120	{"params":{"id":"120"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:44.099808+00
2646	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:53:20.347309+00
2647	1	DELETE /api/programs/389	/api/programs/389	{"params":{"id":"389"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:53:21.487919+00
2675	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:12.971877+00
2676	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:12.987595+00
2677	1	DELETE /api/programs/396	/api/programs/396	{"params":{"id":"396"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:12.996881+00
2678	1	DELETE /api/programs/395	/api/programs/395	{"params":{"id":"395"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:13.00572+00
2688	1	PUT /api/versions/317	/api/versions/317	{"params":{"id":"317"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:56:27.557974+00
2697	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:34.663386+00
2698	1	DELETE /api/objectives/157	/api/objectives/157	{"params":{"id":"157"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:34.668762+00
2703	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:36.551359+00
553	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:21:54.110385+00
554	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:21:54.345923+00
557	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:04.622+00
558	1	POST /api/programs/65/archive	/api/programs/65/archive	{"params":{"id":"65"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:04.627878+00
559	1	POST /api/programs/65/unarchive	/api/programs/65/unarchive	{"params":{"id":"65"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:04.647387+00
560	1	DELETE /api/programs/65	/api/programs/65	{"params":{"id":"65"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:04.660869+00
561	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:05.548203+00
562	1	POST /api/programs/66/versions	/api/programs/66/versions	{"params":{"programId":"66"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:05.557611+00
563	1	PUT /api/versions/65	/api/versions/65	{"params":{"id":"65"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:22:09.394515+00
564	1	PUT /api/versions/65	/api/versions/65	{"params":{"id":"65"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:10.274964+00
565	1	DELETE /api/versions/65	/api/versions/65	{"params":{"id":"65"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:11.139863+00
566	1	DELETE /api/programs/66	/api/programs/66	{"params":{"id":"66"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:11.144155+00
567	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:13.523377+00
568	1	POST /api/programs/67/versions	/api/programs/67/versions	{"params":{"programId":"67"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:13.531402+00
569	1	PUT /api/versions/66	/api/versions/66	{"params":{"id":"66"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:22:14.439093+00
570	1	DELETE /api/versions/66	/api/versions/66	{"params":{"id":"66"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:17.222052+00
571	1	DELETE /api/programs/67	/api/programs/67	{"params":{"id":"67"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:17.227015+00
572	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:19.514993+00
573	1	POST /api/programs/68/versions	/api/programs/68/versions	{"params":{"programId":"68"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:19.522713+00
574	1	DELETE /api/versions/67	/api/versions/67	{"params":{"id":"67"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:21.082725+00
575	1	DELETE /api/programs/68	/api/programs/68	{"params":{"id":"68"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:21.087385+00
576	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:23.213539+00
577	1	POST /api/programs/69/versions	/api/programs/69/versions	{"params":{"programId":"69"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:23.219768+00
578	1	POST /api/versions/68/objectives	/api/versions/68/objectives	{"params":{"vId":"68"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:22:24.010718+00
579	1	DELETE /api/objectives/81	/api/objectives/81	{"params":{"id":"81"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:24.022045+00
580	1	POST /api/versions/68/objectives	/api/versions/68/objectives	{"params":{"vId":"68"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:22:24.709854+00
581	1	DELETE /api/versions/68	/api/versions/68	{"params":{"id":"68"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:25.569148+00
582	1	DELETE /api/programs/69	/api/programs/69	{"params":{"id":"69"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:25.574682+00
583	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:27.89919+00
584	1	POST /api/programs/70/versions	/api/programs/70/versions	{"params":{"programId":"70"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:27.908615+00
585	1	POST /api/versions/69/objectives	/api/versions/69/objectives	{"params":{"vId":"69"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:22:28.699108+00
586	1	POST /api/versions/69/objectives	/api/versions/69/objectives	{"params":{"vId":"69"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:22:28.721808+00
587	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:22:28.817758+00
588	1	DELETE /api/programs/71	/api/programs/71	{"params":{"id":"71"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:28.898482+00
589	1	DELETE /api/versions/69	/api/versions/69	{"params":{"id":"69"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:29.682748+00
590	1	DELETE /api/programs/70	/api/programs/70	{"params":{"id":"70"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:29.687628+00
591	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:30.371367+00
592	1	PUT /api/programs/72	/api/programs/72	{"params":{"id":"72"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:22:31.667316+00
593	1	DELETE /api/programs/72	/api/programs/72	{"params":{"id":"72"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:31.774168+00
594	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:31.829402+00
595	1	POST /api/programs/73/versions	/api/programs/73/versions	{"params":{"programId":"73"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:31.838446+00
596	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:33.199944+00
597	1	DELETE /api/programs/74	/api/programs/74	{"params":{"id":"74"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:33.222162+00
598	1	DELETE /api/versions/70	/api/versions/70	{"params":{"id":"70"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:33.572943+00
599	1	DELETE /api/programs/73	/api/programs/73	{"params":{"id":"73"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:33.57687+00
600	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:34.576862+00
601	1	POST /api/programs/75/archive	/api/programs/75/archive	{"params":{"id":"75"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:34.58761+00
602	1	POST /api/programs/75/unarchive	/api/programs/75/unarchive	{"params":{"id":"75"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:35.688117+00
603	1	DELETE /api/programs/75	/api/programs/75	{"params":{"id":"75"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:35.70074+00
604	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:35.767085+00
614	1	DELETE /api/versions/73	/api/versions/73	{"params":{"id":"73"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:41.548476+00
605	1	POST /api/programs/76/versions	/api/programs/76/versions	{"params":{"programId":"76"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:35.774657+00
1271	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:24.785236+00
1272	1	POST /api/users/62/roles	/api/users/62/roles	{"params":{"id":"62"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:41:24.803395+00
1273	1	DELETE /api/users/62	/api/users/62	{"params":{"id":"62"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:24.816894+00
1279	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:34.375793+00
1385	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:40.37611+00
1386	1	POST /api/programs/216/versions	/api/programs/216/versions	{"params":{"programId":"216"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:40.386011+00
1610	1	DELETE /api/versions/221	/api/versions/221	{"params":{"id":"221"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:11.83973+00
1612	1	DELETE /api/programs/261	/api/programs/261	{"params":{"id":"261"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:11.853523+00
1733	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:52:15.273087+00
1734	1	POST /api/programs/282/versions	/api/programs/282/versions	{"params":{"programId":"282"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:52:15.28168+00
1834	1	POST /api/programs/303/versions	/api/programs/303/versions	{"params":{"programId":"303"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:53.715209+00
1835	1	PUT /api/versions/261/po-plo-map	/api/versions/261/po-plo-map	{"params":{"vId":"261"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:04:53.768596+00
1836	1	PUT /api/versions/261/course-plo-map	/api/versions/261/course-plo-map	{"params":{"vId":"261"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:04:53.794377+00
1837	1	PUT /api/versions/261/course-pi-map	/api/versions/261/course-pi-map	{"params":{"vId":"261"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 09:04:53.812959+00
1838	1	DELETE /api/versions/261	/api/versions/261	{"params":{"id":"261"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:53.828248+00
1839	1	DELETE /api/programs/303	/api/programs/303	{"params":{"id":"303"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:53.841891+00
1840	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:05:03.539544+00
1841	1	POST /api/programs/304/versions	/api/programs/304/versions	{"params":{"programId":"304"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:05:03.575117+00
1842	1	POST /api/versions/262/plos	/api/versions/262/plos	{"params":{"vId":"262"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:05:03.608406+00
1843	1	POST /api/plos/160/pis	/api/plos/160/pis	{"params":{"ploId":"160"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:05:03.652709+00
1844	1	DELETE /api/versions/262	/api/versions/262	{"params":{"id":"262"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:05:03.66314+00
1845	1	DELETE /api/programs/304	/api/programs/304	{"params":{"id":"304"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:05:03.676716+00
1954	1	DELETE /api/versions/278	/api/versions/278	{"params":{"id":"278"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:07.653599+00
1955	1	DELETE /api/programs/327	/api/programs/327	{"params":{"id":"327"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:07.663407+00
1959	1	POST /api/versions/279/knowledge-blocks	/api/versions/279/knowledge-blocks	{"params":{"vId":"279"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:22:11.809665+00
1960	1	POST /api/versions/279/knowledge-blocks	/api/versions/279/knowledge-blocks	{"params":{"vId":"279"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:22:13.571442+00
1961	1	POST /api/versions/279/knowledge-blocks	/api/versions/279/knowledge-blocks	{"params":{"vId":"279"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:22:13.578282+00
1962	1	POST /api/versions/279/knowledge-blocks	/api/versions/279/knowledge-blocks	{"params":{"vId":"279"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:22:13.583457+00
1963	1	DELETE /api/knowledge-blocks/1474	/api/knowledge-blocks/1474	{"params":{"id":"1474"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:13.596608+00
2081	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:33:14.10628+00
2082	1	DELETE /api/programs/341	/api/programs/341	{"params":{"id":"341"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:14.295566+00
2265	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:43:20.654685+00
2266	1	DELETE /api/departments/1853	/api/departments/1853	{"params":{"id":"1853"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:43:20.660481+00
2451	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:49:05.183858+00
2452	1	DELETE /api/departments/1883	/api/departments/1883	{"params":{"id":"1883"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:05.19131+00
2590	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:51:35.601299+00
2591	1	POST /api/programs/386/versions	/api/programs/386/versions	{"params":{"programId":"386"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:51:35.6072+00
2592	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:51:35.611664+00
2593	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:51:35.626704+00
2594	1	DELETE /api/versions/313	/api/versions/313	{"params":{"id":"313"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:35.635769+00
2595	1	DELETE /api/programs/386	/api/programs/386	{"params":{"id":"386"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:35.63881+00
2604	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:46.068051+00
2605	1	POST /api/users/121/roles	/api/users/121/roles	{"params":{"id":"121"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:51:46.093151+00
2606	1	DELETE /api/users/121/roles/GIANG_VIEN/5	/api/users/121/roles/GIANG_VIEN/5	{"params":{"userId":"121","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:46.101233+00
2607	1	DELETE /api/users/121	/api/users/121	{"params":{"id":"121"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:46.10997+00
2648	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:53:56.498402+00
2649	1	PUT /api/courses/670	/api/courses/670	{"params":{"id":"670"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:53:56.504258+00
2650	1	DELETE /api/courses/670	/api/courses/670	{"params":{"id":"670"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:53:56.5113+00
2679	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:15.877152+00
606	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:37.084296+00
607	1	POST /api/programs/77/versions	/api/programs/77/versions	{"params":{"programId":"77"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:37.096079+00
608	1	DELETE /api/versions/72	/api/versions/72	{"params":{"id":"72"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:37.107171+00
609	1	DELETE /api/programs/77	/api/programs/77	{"params":{"id":"77"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:37.11152+00
610	1	DELETE /api/versions/71	/api/versions/71	{"params":{"id":"71"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:37.512647+00
611	1	DELETE /api/programs/76	/api/programs/76	{"params":{"id":"76"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:37.517923+00
612	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:39.763592+00
613	1	POST /api/programs/78/versions	/api/programs/78/versions	{"params":{"programId":"78"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:39.770765+00
1276	1	DELETE /api/users/63/roles/GIANG_VIEN/5	/api/users/63/roles/GIANG_VIEN/5	{"params":{"userId":"63","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:26.860668+00
1277	1	DELETE /api/users/63	/api/users/63	{"params":{"id":"63"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:26.875617+00
1293	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:42:13.965689+00
1294	1	DELETE /api/roles/499	/api/roles/499	{"params":{"id":"499"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:42:13.974357+00
1387	1	POST /api/versions/183/objectives	/api/versions/183/objectives	{"params":{"vId":"183"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:42.321824+00
1611	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:49:11.846257+00
1613	1	DELETE /api/users/77	/api/users/77	{"params":{"id":"77"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:12.047091+00
1616	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:14.289818+00
1617	1	POST /api/programs/262/versions	/api/programs/262/versions	{"params":{"programId":"262"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:14.297535+00
1624	1	DELETE /api/users/81	/api/users/81	{"params":{"id":"81"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:18.496804+00
1735	1	DELETE /api/versions/242	/api/versions/242	{"params":{"id":"242"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:17.151914+00
1736	1	DELETE /api/programs/282	/api/programs/282	{"params":{"id":"282"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:17.160213+00
1739	1	DELETE /api/versions/243	/api/versions/243	{"params":{"id":"243"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:25.144683+00
1740	1	DELETE /api/programs/283	/api/programs/283	{"params":{"id":"283"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:25.148493+00
1846	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:05:49.427258+00
1847	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:05:49.43795+00
1848	1	PUT /api/departments/1797	/api/departments/1797	{"params":{"id":"1797"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:05:49.46929+00
1849	1	DELETE /api/departments/1797	/api/departments/1797	{"params":{"id":"1797"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:05:49.480712+00
1956	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:22:10.019519+00
1957	1	POST /api/programs/328/versions	/api/programs/328/versions	{"params":{"programId":"328"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:22:10.035643+00
1966	1	POST /api/versions/279/courses	/api/versions/279/courses	{"params":{"vId":"279"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:22:15.464074+00
1967	1	DELETE /api/version-courses/879	/api/version-courses/879	{"params":{"id":"879"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:15.469745+00
1974	1	PUT /api/versions/279/course-plo-map	/api/versions/279/course-plo-map	{"params":{"vId":"279"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:22:19.386596+00
2083	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:15.782322+00
2084	1	PUT /api/programs/342	/api/programs/342	{"params":{"id":"342"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:33:17.234313+00
2085	1	DELETE /api/programs/342	/api/programs/342	{"params":{"id":"342"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:17.334822+00
2100	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:31.314606+00
2101	1	POST /api/programs/348/versions	/api/programs/348/versions	{"params":{"programId":"348"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:33:31.321871+00
2267	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:43:21.637915+00
2268	1	PUT /api/departments/1854	/api/departments/1854	{"params":{"id":"1854"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:43:21.643364+00
2269	1	DELETE /api/departments/1854	/api/departments/1854	{"params":{"id":"1854"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:43:21.64963+00
2457	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:49:51.13934+00
2458	1	DELETE /api/programs/373	/api/programs/373	{"params":{"id":"373"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:51.249826+00
2464	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:49:56.791464+00
2465	1	POST /api/programs/376/archive	/api/programs/376/archive	{"params":{"id":"376"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:56.80437+00
2466	1	POST /api/programs/376/unarchive	/api/programs/376/unarchive	{"params":{"id":"376"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:57.934918+00
2467	1	DELETE /api/programs/376	/api/programs/376	{"params":{"id":"376"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:57.938377+00
2476	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:50:06.402286+00
2477	1	POST /api/programs/380/versions	/api/programs/380/versions	{"params":{"programId":"380"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:50:06.409063+00
2599	1	PUT /api/users/119	/api/users/119	{"params":{"id":"119"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 09:51:42.179956+00
2600	1	DELETE /api/users/119	/api/users/119	{"params":{"id":"119"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:42.19058+00
2617	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:57.78343+00
2618	1	DELETE /api/users/128	/api/users/128	{"params":{"id":"128"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:57.795957+00
2622	1	DELETE /api/roles/564	/api/roles/564	{"params":{"id":"564"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:18.178071+00
615	1	DELETE /api/programs/78	/api/programs/78	{"params":{"id":"78"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:41.552599+00
616	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:41.810379+00
617	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:22:42.076168+00
1278	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:30.919279+00
1280	1	DELETE /api/users/66	/api/users/66	{"params":{"id":"66"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:34.473597+00
1288	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:41:51.568619+00
1289	1	DELETE /api/roles/495	/api/roles/495	{"params":{"id":"495"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:51.576906+00
1388	1	DELETE /api/versions/183	/api/versions/183	{"params":{"id":"183"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:43.348635+00
1389	1	DELETE /api/programs/216	/api/programs/216	{"params":{"id":"216"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:43.358688+00
1392	1	DELETE /api/versions/184	/api/versions/184	{"params":{"id":"184"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:47.646272+00
1393	1	DELETE /api/programs/217	/api/programs/217	{"params":{"id":"217"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:47.654976+00
1618	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:49:16.311882+00
1628	1	DELETE /api/versions/223	/api/versions/223	{"params":{"id":"223"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:20.593472+00
1629	1	DELETE /api/programs/263	/api/programs/263	{"params":{"id":"263"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:20.598436+00
1741	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:52:34.993895+00
1742	1	POST /api/programs/284/versions	/api/programs/284/versions	{"params":{"programId":"284"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:52:35.003798+00
1745	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:52:40.917657+00
1746	1	POST /api/programs/285/versions	/api/programs/285/versions	{"params":{"programId":"285"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:52:40.924608+00
1747	1	DELETE /api/versions/245	/api/versions/245	{"params":{"id":"245"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:40.93497+00
1748	1	DELETE /api/programs/285	/api/programs/285	{"params":{"id":"285"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:40.942722+00
1850	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:14:10.375429+00
1958	1	POST /api/versions/279/knowledge-blocks	/api/versions/279/knowledge-blocks	{"params":{"vId":"279"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:22:10.980383+00
1971	1	POST /api/versions/279/courses	/api/versions/279/courses	{"params":{"vId":"279"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:22:17.485132+00
1972	1	PUT /api/version-courses/882	/api/version-courses/882	{"params":{"id":"882"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 09:22:17.496355+00
1973	1	DELETE /api/version-courses/882	/api/version-courses/882	{"params":{"id":"882"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:17.502104+00
1983	1	DELETE /api/courses/652	/api/courses/652	{"params":{"id":"652"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:51.941157+00
2086	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:18.950368+00
2087	1	DELETE /api/programs/343	/api/programs/343	{"params":{"id":"343"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:18.975457+00
2096	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:28.271334+00
2097	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:28.285231+00
2098	1	DELETE /api/programs/347	/api/programs/347	{"params":{"id":"347"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:28.296897+00
2099	1	DELETE /api/programs/346	/api/programs/346	{"params":{"id":"346"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:28.30722+00
2270	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:46:10.472006+00
2271	1	DELETE /api/programs/358	/api/programs/358	{"params":{"id":"358"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:10.659786+00
2289	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:26.970286+00
2290	1	POST /api/programs/365/versions	/api/programs/365/versions	{"params":{"programId":"365"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:46:26.979818+00
2459	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:49:52.646563+00
2460	1	PUT /api/programs/374	/api/programs/374	{"params":{"id":"374"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:49:53.913382+00
2461	1	DELETE /api/programs/374	/api/programs/374	{"params":{"id":"374"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:53.99981+00
2472	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:50:03.747044+00
2473	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:50:03.764899+00
2608	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:49.95079+00
2609	1	DELETE /api/users/123	/api/users/123	{"params":{"id":"123"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:49.961162+00
2610	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:51.899838+00
2651	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:54:10.365395+00
2652	1	PUT /api/courses/671	/api/courses/671	{"params":{"id":"671"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:54:10.370974+00
2653	1	DELETE /api/courses/671	/api/courses/671	{"params":{"id":"671"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:54:10.378124+00
2680	1	POST /api/programs/397/versions	/api/programs/397/versions	{"params":{"programId":"397"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:56:15.891145+00
2689	1	PUT /api/versions/317	/api/versions/317	{"params":{"id":"317"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:56:28.50999+00
2704	1	DELETE /api/plos/206	/api/plos/206	{"params":{"id":"206"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:36.565594+00
2705	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:37.427099+00
618	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:43.844189+00
619	1	POST /api/programs/81/versions	/api/programs/81/versions	{"params":{"programId":"81"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:43.852332+00
620	1	POST /api/versions/74/plos	/api/versions/74/plos	{"params":{"vId":"74"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:22:44.778128+00
1281	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:36.524164+00
1282	1	DELETE /api/users/68	/api/users/68	{"params":{"id":"68"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:36.549393+00
1283	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:41:38.632688+00
1284	1	PUT /api/users/69/toggle-active	/api/users/69/toggle-active	{"params":{"id":"69"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:38.647293+00
1285	1	DELETE /api/users/69	/api/users/69	{"params":{"id":"69"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:41:38.65668+00
1394	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:49.835963+00
1395	1	POST /api/programs/218/versions	/api/programs/218/versions	{"params":{"programId":"218"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:49.842013+00
1402	1	POST /api/versions/186/knowledge-blocks	/api/versions/186/knowledge-blocks	{"params":{"vId":"186"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:44:58.011267+00
1421	1	DELETE /api/versions/188	/api/versions/188	{"params":{"id":"188"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:11.411442+00
1422	1	DELETE /api/programs/221	/api/programs/221	{"params":{"id":"221"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:11.422625+00
1427	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:45:17.898726+00
1428	1	POST /api/programs/223/versions	/api/programs/223/versions	{"params":{"programId":"223"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:45:17.906932+00
1429	1	DELETE /api/versions/190	/api/versions/190	{"params":{"id":"190"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:20.44948+00
1430	1	DELETE /api/programs/223	/api/programs/223	{"params":{"id":"223"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:20.454226+00
1435	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:45:27.514522+00
1436	1	POST /api/programs/225/versions	/api/programs/225/versions	{"params":{"programId":"225"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:45:27.521994+00
1450	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:45.44206+00
1451	1	DELETE /api/programs/229	/api/programs/229	{"params":{"id":"229"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:45.458667+00
1619	1	DELETE /api/versions/222	/api/versions/222	{"params":{"id":"222"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:16.312374+00
1620	1	DELETE /api/programs/262	/api/programs/262	{"params":{"id":"262"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:16.317612+00
1621	1	PUT /api/users/80/toggle-active	/api/users/80/toggle-active	{"params":{"id":"80"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:16.322996+00
1622	1	DELETE /api/users/80	/api/users/80	{"params":{"id":"80"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:16.336764+00
1641	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:32.270112+00
1642	1	POST /api/programs/266/versions	/api/programs/266/versions	{"params":{"programId":"266"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:32.279321+00
1743	1	DELETE /api/versions/244	/api/versions/244	{"params":{"id":"244"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:36.963218+00
1744	1	DELETE /api/programs/284	/api/programs/284	{"params":{"id":"284"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:36.967972+00
1851	1	POST /api/programs/305/versions	/api/programs/305/versions	{"params":{"programId":"305"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:14:10.414002+00
1852	1	POST /api/versions/263/courses	/api/versions/263/courses	{"params":{"vId":"263"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:14:10.464124+00
1853	1	PUT /api/versions/263/course-relations	/api/versions/263/course-relations	{"params":{"vId":"263"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 09:14:10.496439+00
1854	1	DELETE /api/version-courses/877	/api/version-courses/877	{"params":{"id":"877"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:14:10.509491+00
1855	1	DELETE /api/versions/263	/api/versions/263	{"params":{"id":"263"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:14:10.524495+00
1856	1	DELETE /api/programs/305	/api/programs/305	{"params":{"id":"305"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:14:10.534681+00
1964	1	POST /api/versions/279/courses	/api/versions/279/courses	{"params":{"vId":"279"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:22:14.589659+00
1965	1	DELETE /api/version-courses/878	/api/version-courses/878	{"params":{"id":"878"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:22:14.598647+00
1976	1	PUT /api/versions/279/course-pi-map	/api/versions/279/course-pi-map	{"params":{"vId":"279"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 09:22:22.23059+00
2088	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:20.492174+00
2089	1	POST /api/programs/344/archive	/api/programs/344/archive	{"params":{"id":"344"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:20.509478+00
2090	1	POST /api/programs/344/unarchive	/api/programs/344/unarchive	{"params":{"id":"344"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:21.709682+00
2091	1	DELETE /api/programs/344	/api/programs/344	{"params":{"id":"344"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:21.718365+00
2272	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:12.204737+00
2273	1	PUT /api/programs/359	/api/programs/359	{"params":{"id":"359"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:46:13.499537+00
2274	1	DELETE /api/programs/359	/api/programs/359	{"params":{"id":"359"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:13.581233+00
2462	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:49:55.37315+00
2463	1	DELETE /api/programs/375	/api/programs/375	{"params":{"id":"375"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:55.383469+00
2611	1	DELETE /api/users/124	/api/users/124	{"params":{"id":"124"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:51.999912+00
2640	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:52:57.974623+00
2641	1	POST /api/programs/387/versions	/api/programs/387/versions	{"params":{"programId":"387"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:52:57.983609+00
2642	1	DELETE /api/versions/314	/api/versions/314	{"params":{"id":"314"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:57.995208+00
621	1	DELETE /api/versions/74	/api/versions/74	{"params":{"id":"74"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:45.679476+00
622	1	DELETE /api/programs/81	/api/programs/81	{"params":{"id":"81"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:45.684773+00
623	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:46.371472+00
624	1	POST /api/programs/82/versions	/api/programs/82/versions	{"params":{"programId":"82"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:46.379257+00
625	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:52.298505+00
626	1	POST /api/programs/83/archive	/api/programs/83/archive	{"params":{"id":"83"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:52.305686+00
627	1	POST /api/programs/83/unarchive	/api/programs/83/unarchive	{"params":{"id":"83"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:52.315851+00
628	1	DELETE /api/programs/83	/api/programs/83	{"params":{"id":"83"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:52.325813+00
629	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:22:53.195015+00
630	1	POST /api/programs/84/versions	/api/programs/84/versions	{"params":{"programId":"84"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:53.220319+00
631	1	PUT /api/versions/76	/api/versions/76	{"params":{"id":"76"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:22:56.838899+00
632	1	PUT /api/versions/76	/api/versions/76	{"params":{"id":"76"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:22:57.632624+00
633	1	DELETE /api/versions/76	/api/versions/76	{"params":{"id":"76"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:58.530747+00
634	1	DELETE /api/programs/84	/api/programs/84	{"params":{"id":"84"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:22:58.535962+00
635	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:00.653574+00
636	1	POST /api/programs/85/versions	/api/programs/85/versions	{"params":{"programId":"85"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:00.662854+00
637	1	PUT /api/versions/77	/api/versions/77	{"params":{"id":"77"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:23:01.566383+00
638	1	DELETE /api/versions/77	/api/versions/77	{"params":{"id":"77"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:04.481226+00
639	1	DELETE /api/programs/85	/api/programs/85	{"params":{"id":"85"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:04.48651+00
640	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:06.742536+00
641	1	POST /api/programs/86/versions	/api/programs/86/versions	{"params":{"programId":"86"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:06.751478+00
642	1	DELETE /api/versions/78	/api/versions/78	{"params":{"id":"78"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:08.482271+00
643	1	DELETE /api/programs/86	/api/programs/86	{"params":{"id":"86"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:08.486618+00
644	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:23:10.44078+00
645	1	DELETE /api/courses/640	/api/courses/640	{"params":{"id":"640"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:10.505547+00
646	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:10.811509+00
647	1	POST /api/programs/87/versions	/api/programs/87/versions	{"params":{"programId":"87"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:10.821257+00
648	1	POST /api/versions/79/objectives	/api/versions/79/objectives	{"params":{"vId":"79"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:11.748333+00
649	1	DELETE /api/objectives/85	/api/objectives/85	{"params":{"id":"85"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:11.758409+00
650	1	POST /api/versions/79/objectives	/api/versions/79/objectives	{"params":{"vId":"79"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:12.621653+00
651	1	DELETE /api/versions/79	/api/versions/79	{"params":{"id":"79"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:13.561694+00
652	1	DELETE /api/programs/87	/api/programs/87	{"params":{"id":"87"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:13.567893+00
653	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:15.845305+00
654	1	POST /api/programs/88/versions	/api/programs/88/versions	{"params":{"programId":"88"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:15.851856+00
655	1	POST /api/versions/80/objectives	/api/versions/80/objectives	{"params":{"vId":"80"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:16.928091+00
656	1	POST /api/versions/80/objectives	/api/versions/80/objectives	{"params":{"vId":"80"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:16.941798+00
657	1	DELETE /api/versions/80	/api/versions/80	{"params":{"id":"80"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:17.833877+00
658	1	DELETE /api/programs/88	/api/programs/88	{"params":{"id":"88"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:17.839212+00
659	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:20.086742+00
660	1	POST /api/programs/89/versions	/api/programs/89/versions	{"params":{"programId":"89"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:20.094084+00
661	1	DELETE /api/versions/81	/api/versions/81	{"params":{"id":"81"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:21.879505+00
662	1	DELETE /api/programs/89	/api/programs/89	{"params":{"id":"89"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:21.884833+00
663	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:24.169052+00
664	1	POST /api/programs/90/versions	/api/programs/90/versions	{"params":{"programId":"90"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:24.17537+00
665	1	DELETE /api/versions/82	/api/versions/82	{"params":{"id":"82"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:26.004054+00
666	1	DELETE /api/programs/90	/api/programs/90	{"params":{"id":"90"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:26.009384+00
667	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:28.320996+00
668	1	POST /api/programs/91/versions	/api/programs/91/versions	{"params":{"programId":"91"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:28.332197+00
669	1	DELETE /api/versions/83	/api/versions/83	{"params":{"id":"83"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:30.16335+00
670	1	DELETE /api/programs/91	/api/programs/91	{"params":{"id":"91"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:30.167556+00
671	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:32.430106+00
672	1	POST /api/programs/92/versions	/api/programs/92/versions	{"params":{"programId":"92"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:32.435799+00
673	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:23:32.445962+00
676	1	DELETE /api/programs/92	/api/programs/92	{"params":{"id":"92"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:32.465683+00
680	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:35.6656+00
681	1	POST /api/programs/94/versions	/api/programs/94/versions	{"params":{"programId":"94"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:35.672206+00
682	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:23:35.677477+00
683	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:23:35.68912+00
684	1	DELETE /api/approval/rejected/program_version/86	/api/approval/rejected/program_version/86	{"params":{"entityType":"program_version","entityId":"86"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:35.702488+00
685	1	DELETE /api/programs/94	/api/programs/94	{"params":{"id":"94"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:35.711473+00
701	1	DELETE /api/versions/90	/api/versions/90	{"params":{"id":"90"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:43.114593+00
702	1	DELETE /api/programs/98	/api/programs/98	{"params":{"id":"98"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:43.119789+00
713	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:49.397163+00
714	1	POST /api/programs/100/versions	/api/programs/100/versions	{"params":{"programId":"100"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:49.405837+00
715	1	POST /api/users/21/roles	/api/users/21/roles	{"params":{"id":"21"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:23:49.421676+00
716	1	DELETE /api/users/21	/api/users/21	{"params":{"id":"21"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:49.431735+00
730	1	POST /api/programs/102/versions	/api/programs/102/versions	{"params":{"programId":"102"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:58.028485+00
733	1	DELETE /api/versions/94	/api/versions/94	{"params":{"id":"94"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:59.841835+00
734	1	DELETE /api/programs/102	/api/programs/102	{"params":{"id":"102"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:59.847007+00
735	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:24:00.981964+00
736	1	DELETE /api/users/27	/api/users/27	{"params":{"id":"27"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:01.010503+00
1290	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:42:02.414289+00
1396	1	DELETE /api/versions/185	/api/versions/185	{"params":{"id":"185"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:51.816795+00
1397	1	DELETE /api/programs/218	/api/programs/218	{"params":{"id":"218"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:51.826413+00
1401	1	POST /api/versions/186/knowledge-blocks	/api/versions/186/knowledge-blocks	{"params":{"vId":"186"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:44:56.072269+00
1411	1	POST /api/versions/187/courses	/api/versions/187/courses	{"params":{"vId":"187"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:45:04.084831+00
1412	1	POST /api/versions/187/courses	/api/versions/187/courses	{"params":{"vId":"187"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:45:04.091719+00
1413	1	DELETE /api/version-courses/865	/api/version-courses/865	{"params":{"id":"865"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:04.098864+00
1625	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:18.684574+00
1626	1	POST /api/programs/263/versions	/api/programs/263/versions	{"params":{"programId":"263"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:18.691626+00
1632	1	POST /api/versions/224/plos	/api/versions/224/plos	{"params":{"vId":"224"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:49:24.638786+00
1749	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:52:51.822725+00
1750	1	POST /api/programs/286/versions	/api/programs/286/versions	{"params":{"programId":"286"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:52:51.834721+00
1857	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:15:42.540253+00
1982	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:22:51.90318+00
2092	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:23.297972+00
2093	1	POST /api/programs/345/versions	/api/programs/345/versions	{"params":{"programId":"345"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:33:23.312978+00
2094	1	DELETE /api/versions/291	/api/versions/291	{"params":{"id":"291"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:23.327915+00
2095	1	DELETE /api/programs/345	/api/programs/345	{"params":{"id":"345"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:23.337286+00
2275	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:15.137667+00
2276	1	DELETE /api/programs/360	/api/programs/360	{"params":{"id":"360"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:15.153073+00
2468	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:49:59.275031+00
2469	1	POST /api/programs/377/versions	/api/programs/377/versions	{"params":{"programId":"377"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:49:59.289168+00
2470	1	DELETE /api/versions/307	/api/versions/307	{"params":{"id":"307"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:59.30388+00
2471	1	DELETE /api/programs/377	/api/programs/377	{"params":{"id":"377"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:59.307018+00
2612	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:53.931215+00
2613	1	DELETE /api/users/126	/api/users/126	{"params":{"id":"126"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:53.942483+00
2614	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:55.820584+00
2615	1	PUT /api/users/127/toggle-active	/api/users/127/toggle-active	{"params":{"id":"127"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:55.845853+00
2616	1	DELETE /api/users/127	/api/users/127	{"params":{"id":"127"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:55.853405+00
2619	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:52:07.96158+00
2620	1	DELETE /api/roles/562	/api/roles/562	{"params":{"id":"562"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:07.96692+00
2623	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:52:23.750899+00
2626	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:52:29.449649+00
674	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:32.45752+00
675	1	POST /api/programs/93/versions	/api/programs/93/versions	{"params":{"programId":"93"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:32.463293+00
703	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:45.383173+00
704	1	POST /api/programs/99/versions	/api/programs/99/versions	{"params":{"programId":"99"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:45.390809+00
705	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:23:45.471071+00
706	1	DELETE /api/users/19	/api/users/19	{"params":{"id":"19"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:45.502598+00
1292	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:42:08.270353+00
1295	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:42:15.964875+00
1296	1	PUT /api/roles/500	/api/roles/500	{"params":{"id":"500"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:42:15.972149+00
1297	1	DELETE /api/roles/500	/api/roles/500	{"params":{"id":"500"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:42:15.976987+00
1398	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:54.11106+00
1399	1	POST /api/programs/219/versions	/api/programs/219/versions	{"params":{"programId":"219"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:54.124084+00
1403	1	DELETE /api/versions/186	/api/versions/186	{"params":{"id":"186"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:58.928943+00
1404	1	DELETE /api/programs/219	/api/programs/219	{"params":{"id":"219"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:58.932913+00
1414	1	DELETE /api/versions/187	/api/versions/187	{"params":{"id":"187"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:05.139462+00
1415	1	DELETE /api/programs/220	/api/programs/220	{"params":{"id":"220"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:05.145065+00
1433	1	DELETE /api/versions/191	/api/versions/191	{"params":{"id":"191"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:25.257876+00
1434	1	DELETE /api/programs/224	/api/programs/224	{"params":{"id":"224"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:25.262777+00
1437	1	DELETE /api/versions/192	/api/versions/192	{"params":{"id":"192"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:34.062423+00
1438	1	DELETE /api/programs/225	/api/programs/225	{"params":{"id":"225"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:34.06697+00
1439	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:45:55.127952+00
1633	1	DELETE /api/versions/224	/api/versions/224	{"params":{"id":"224"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:25.642372+00
1634	1	DELETE /api/programs/264	/api/programs/264	{"params":{"id":"264"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:25.647395+00
1751	1	DELETE /api/versions/246	/api/versions/246	{"params":{"id":"246"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:53.680841+00
1752	1	DELETE /api/programs/286	/api/programs/286	{"params":{"id":"286"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:52:53.685807+00
1858	1	POST /api/programs/306/versions	/api/programs/306/versions	{"params":{"programId":"306"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:15:42.581397+00
1859	1	POST /api/versions/264/plos	/api/versions/264/plos	{"params":{"vId":"264"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:15:42.6137+00
1860	1	POST /api/versions/264/plos	/api/versions/264/plos	{"params":{"vId":"264"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:15:42.624035+00
1861	1	POST /api/versions/264/plos	/api/versions/264/plos	{"params":{"vId":"264"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:15:42.634224+00
1862	1	DELETE /api/versions/264	/api/versions/264	{"params":{"id":"264"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:15:42.651211+00
1863	1	DELETE /api/programs/306	/api/programs/306	{"params":{"id":"306"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:15:42.662436+00
1984	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:23:13.04357+00
1985	1	POST /api/programs/329/versions	/api/programs/329/versions	{"params":{"programId":"329"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:23:13.051496+00
1986	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:23:13.069787+00
1987	1	DELETE /api/programs/329	/api/programs/329	{"params":{"id":"329"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:13.083102+00
1988	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:23:16.669956+00
1989	1	POST /api/programs/330/versions	/api/programs/330/versions	{"params":{"programId":"330"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:23:16.675238+00
1990	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:23:16.679511+00
1991	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:23:16.69588+00
1992	1	DELETE /api/approval/rejected/program_version/281	/api/approval/rejected/program_version/281	{"params":{"entityType":"program_version","entityId":"281"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:16.70573+00
1993	1	DELETE /api/programs/330	/api/programs/330	{"params":{"id":"330"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:16.713161+00
2102	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:37.533339+00
2103	1	POST /api/programs/349/archive	/api/programs/349/archive	{"params":{"id":"349"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:37.544957+00
2104	1	POST /api/programs/349/unarchive	/api/programs/349/unarchive	{"params":{"id":"349"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:37.557974+00
2105	1	DELETE /api/programs/349	/api/programs/349	{"params":{"id":"349"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:37.568642+00
2116	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:50.17652+00
2117	1	DELETE /api/objectives/129	/api/objectives/129	{"params":{"id":"129"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:50.185332+00
2128	1	DELETE /api/plos/171	/api/plos/171	{"params":{"id":"171"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:53.84997+00
2141	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:58.593709+00
2142	1	POST /api/plos/177/pis	/api/plos/177/pis	{"params":{"ploId":"177"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:33:58.603383+00
2143	1	PUT /api/pis/307	/api/pis/307	{"params":{"id":"307"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:33:58.620495+00
2144	1	DELETE /api/pis/307	/api/pis/307	{"params":{"id":"307"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:58.635593+00
2145	1	DELETE /api/plos/177	/api/plos/177	{"params":{"id":"177"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:58.640227+00
677	1	POST /api/versions/85/plos	/api/versions/85/plos	{"params":{"vId":"85"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:33.323723+00
1298	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 08:42:23.764195+00
1299	1	DELETE /api/departments/1741	/api/departments/1741	{"params":{"id":"1741"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:42:23.772263+00
1409	1	POST /api/versions/187/courses	/api/versions/187/courses	{"params":{"vId":"187"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:45:03.091325+00
1410	1	DELETE /api/version-courses/864	/api/version-courses/864	{"params":{"id":"864"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:03.097919+00
1425	1	DELETE /api/versions/189	/api/versions/189	{"params":{"id":"189"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:15.755357+00
1426	1	DELETE /api/programs/222	/api/programs/222	{"params":{"id":"222"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:15.760295+00
1431	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:45:22.632862+00
1432	1	POST /api/programs/224/versions	/api/programs/224/versions	{"params":{"programId":"224"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:45:22.641473+00
1635	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:27.980468+00
1636	1	POST /api/programs/265/versions	/api/programs/265/versions	{"params":{"programId":"265"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:27.987939+00
1753	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:53:19.247476+00
1754	1	POST /api/programs/287/versions	/api/programs/287/versions	{"params":{"programId":"287"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:53:19.256401+00
1864	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:18:00.754653+00
1994	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:23:17.740577+00
1995	1	POST /api/programs/331/versions	/api/programs/331/versions	{"params":{"programId":"331"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:23:17.749675+00
1996	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:23:17.755835+00
1997	1	DELETE /api/programs/331	/api/programs/331	{"params":{"id":"331"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:17.779308+00
2009	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:29.342485+00
2010	1	POST /api/users/87/roles	/api/users/87/roles	{"params":{"id":"87"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:23:29.359343+00
2011	1	DELETE /api/users/87	/api/users/87	{"params":{"id":"87"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:29.370631+00
2106	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:33:38.484667+00
2107	1	POST /api/programs/350/versions	/api/programs/350/versions	{"params":{"programId":"350"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:33:38.493012+00
2110	1	PUT /api/versions/293	/api/versions/293	{"params":{"id":"293"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:33:44.594387+00
2120	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:52.060528+00
2121	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:52.070048+00
2122	1	DELETE /api/objectives/132	/api/objectives/132	{"params":{"id":"132"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:52.075335+00
2123	1	DELETE /api/objectives/131	/api/objectives/131	{"params":{"id":"131"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:52.089321+00
2149	1	DELETE /api/plos/178	/api/plos/178	{"params":{"id":"178"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:59.622707+00
2158	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:34:03.423271+00
2159	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:34:03.427772+00
2160	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:34:03.432681+00
2161	1	PUT /api/versions/293/po-plo-map	/api/versions/293/po-plo-map	{"params":{"vId":"293"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:34:03.45211+00
2162	1	DELETE /api/objectives/134	/api/objectives/134	{"params":{"id":"134"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:03.462795+00
2163	1	DELETE /api/objectives/135	/api/objectives/135	{"params":{"id":"135"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:03.466547+00
2164	1	DELETE /api/plos/181	/api/plos/181	{"params":{"id":"181"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:03.470268+00
2181	1	PUT /api/versions/293/course-plo-map	/api/versions/293/course-plo-map	{"params":{"vId":"293"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:34:12.574013+00
2277	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:16.572332+00
2278	1	POST /api/programs/361/archive	/api/programs/361/archive	{"params":{"id":"361"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:16.584788+00
2279	1	POST /api/programs/361/unarchive	/api/programs/361/unarchive	{"params":{"id":"361"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:17.715239+00
2280	1	DELETE /api/programs/361	/api/programs/361	{"params":{"id":"361"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:17.720378+00
2285	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:24.018725+00
2286	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:24.043991+00
2287	1	DELETE /api/programs/364	/api/programs/364	{"params":{"id":"364"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:24.051775+00
2288	1	DELETE /api/programs/363	/api/programs/363	{"params":{"id":"363"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:24.062362+00
2474	1	DELETE /api/programs/379	/api/programs/379	{"params":{"id":"379"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:03.772325+00
2475	1	DELETE /api/programs/378	/api/programs/378	{"params":{"id":"378"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:03.781634+00
2621	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:52:18.161648+00
2654	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:54:35.186148+00
2655	1	PUT /api/courses/672	/api/courses/672	{"params":{"id":"672"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:54:35.192408+00
2656	1	DELETE /api/courses/672	/api/courses/672	{"params":{"id":"672"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:54:35.199448+00
2681	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:21.754543+00
678	1	DELETE /api/versions/85	/api/versions/85	{"params":{"id":"85"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:34.191397+00
1300	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:42:25.689237+00
1440	1	DELETE /api/courses/648	/api/courses/648	{"params":{"id":"648"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:55.170941+00
1447	1	DELETE /api/programs/228	/api/programs/228	{"params":{"id":"228"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:43.965932+00
1466	1	DELETE /api/versions/196	/api/versions/196	{"params":{"id":"196"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:52.578142+00
1467	1	DELETE /api/programs/233	/api/programs/233	{"params":{"id":"233"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:52.582682+00
1639	1	DELETE /api/versions/225	/api/versions/225	{"params":{"id":"225"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:30.001411+00
1640	1	DELETE /api/programs/265	/api/programs/265	{"params":{"id":"265"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:30.005792+00
1661	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:49:52.368016+00
1662	1	DELETE /api/roles/517	/api/roles/517	{"params":{"id":"517"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:52.373585+00
1755	1	DELETE /api/versions/247	/api/versions/247	{"params":{"id":"247"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:53:21.983363+00
1756	1	DELETE /api/programs/287	/api/programs/287	{"params":{"id":"287"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:53:21.988688+00
1865	1	POST /api/programs/307/versions	/api/programs/307/versions	{"params":{"programId":"307"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:18:00.80086+00
1866	1	POST /api/versions/265/plos	/api/versions/265/plos	{"params":{"vId":"265"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:18:00.833924+00
1867	1	POST /api/versions/265/plos	/api/versions/265/plos	{"params":{"vId":"265"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:18:00.843511+00
1868	1	POST /api/versions/265/plos	/api/versions/265/plos	{"params":{"vId":"265"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:18:00.857498+00
1869	1	DELETE /api/versions/265	/api/versions/265	{"params":{"id":"265"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:18:00.872916+00
1870	1	DELETE /api/programs/307	/api/programs/307	{"params":{"id":"307"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:18:00.882102+00
1998	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:23:20.564788+00
1999	1	POST /api/programs/332/versions	/api/programs/332/versions	{"params":{"programId":"332"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:23:20.574383+00
2000	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:23:20.580488+00
2001	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:23:20.59006+00
2002	1	DELETE /api/versions/283	/api/versions/283	{"params":{"id":"283"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:20.602173+00
2003	1	DELETE /api/programs/332	/api/programs/332	{"params":{"id":"332"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:20.606108+00
2004	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:25.347327+00
2005	1	DELETE /api/users/85	/api/users/85	{"params":{"id":"85"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:25.360479+00
2039	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:24:25.381482+00
2108	1	PUT /api/versions/293	/api/versions/293	{"params":{"id":"293"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:33:42.572734+00
2124	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:52.955976+00
2125	1	DELETE /api/plos/170	/api/plos/170	{"params":{"id":"170"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:52.968776+00
2133	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:56.749316+00
2134	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:56.761289+00
2135	1	DELETE /api/plos/175	/api/plos/175	{"params":{"id":"175"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:56.765782+00
2137	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:57.713023+00
2138	1	POST /api/plos/176/pis	/api/plos/176/pis	{"params":{"ploId":"176"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:33:57.723214+00
2139	1	DELETE /api/pis/306	/api/pis/306	{"params":{"id":"306"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:57.738341+00
2140	1	DELETE /api/plos/176	/api/plos/176	{"params":{"id":"176"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:57.747528+00
2165	1	POST /api/versions/293/knowledge-blocks	/api/versions/293/knowledge-blocks	{"params":{"vId":"293"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:34:04.306745+00
2175	1	POST /api/versions/293/courses	/api/versions/293/courses	{"params":{"vId":"293"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:34:09.919639+00
2176	1	POST /api/versions/293/courses	/api/versions/293/courses	{"params":{"vId":"293"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:34:09.924341+00
2177	1	DELETE /api/version-courses/886	/api/version-courses/886	{"params":{"id":"886"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:09.929103+00
2190	1	DELETE /api/courses/654	/api/courses/654	{"params":{"id":"654"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:45.296852+00
2191	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:35:06.075432+00
2192	1	POST /api/programs/351/versions	/api/programs/351/versions	{"params":{"programId":"351"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:35:06.081343+00
2193	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:35:06.090151+00
2194	1	DELETE /api/programs/351	/api/programs/351	{"params":{"id":"351"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:06.10414+00
2234	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:35:45.101239+00
2235	1	DELETE /api/roles/538	/api/roles/538	{"params":{"id":"538"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:45.106888+00
2281	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:19.184912+00
2282	1	POST /api/programs/362/versions	/api/programs/362/versions	{"params":{"programId":"362"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:46:19.198608+00
2283	1	DELETE /api/versions/299	/api/versions/299	{"params":{"id":"299"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:19.214913+00
2284	1	DELETE /api/programs/362	/api/programs/362	{"params":{"id":"362"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:19.21898+00
2478	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:50:12.083993+00
679	1	DELETE /api/programs/93	/api/programs/93	{"params":{"id":"93"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:34.197181+00
699	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:41.452907+00
700	1	POST /api/programs/98/versions	/api/programs/98/versions	{"params":{"programId":"98"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:41.460205+00
1302	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:42:27.583297+00
1303	1	DELETE /api/departments/1745	/api/departments/1745	{"params":{"id":"1745"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:42:27.588339+00
1443	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:42.208001+00
1444	1	POST /api/programs/227/versions	/api/programs/227/versions	{"params":{"programId":"227"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:42.215943+00
1445	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:42.619965+00
1468	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:54.721763+00
1643	1	DELETE /api/versions/226	/api/versions/226	{"params":{"id":"226"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:34.273075+00
1644	1	DELETE /api/programs/266	/api/programs/266	{"params":{"id":"266"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:34.280269+00
1757	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:53:47.052458+00
1758	1	POST /api/programs/288/versions	/api/programs/288/versions	{"params":{"programId":"288"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:53:47.05979+00
1871	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:20:46.521799+00
1872	1	DELETE /api/programs/308	/api/programs/308	{"params":{"id":"308"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:46.709787+00
1890	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:03.353876+00
1891	1	POST /api/programs/315/versions	/api/programs/315/versions	{"params":{"programId":"315"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:03.364177+00
2006	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:27.45573+00
2007	1	PUT /api/users/86	/api/users/86	{"params":{"id":"86"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 09:23:27.464267+00
2008	1	DELETE /api/users/86	/api/users/86	{"params":{"id":"86"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:27.481097+00
2022	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:41.643125+00
2023	1	PUT /api/users/94/toggle-active	/api/users/94/toggle-active	{"params":{"id":"94"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:41.653078+00
2024	1	DELETE /api/users/94	/api/users/94	{"params":{"id":"94"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:41.66847+00
2109	1	PUT /api/versions/293	/api/versions/293	{"params":{"id":"293"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:33:43.635395+00
2118	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:51.168151+00
2119	1	DELETE /api/objectives/130	/api/objectives/130	{"params":{"id":"130"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:51.175058+00
2136	1	DELETE /api/plos/174	/api/plos/174	{"params":{"id":"174"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:56.776038+00
2152	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:34:01.543346+00
2153	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:34:01.548207+00
2154	1	PUT /api/versions/293/po-plo-map	/api/versions/293/po-plo-map	{"params":{"vId":"293"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:34:01.556892+00
2155	1	DELETE /api/objectives/133	/api/objectives/133	{"params":{"id":"133"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:01.568505+00
2156	1	DELETE /api/plos/180	/api/plos/180	{"params":{"id":"180"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:01.572959+00
2173	1	POST /api/versions/293/courses	/api/versions/293/courses	{"params":{"vId":"293"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:34:09.052195+00
2174	1	DELETE /api/version-courses/885	/api/version-courses/885	{"params":{"id":"885"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:09.059562+00
2182	1	PUT /api/versions/293/course-plo-map	/api/versions/293/course-plo-map	{"params":{"vId":"293"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:34:13.359241+00
2184	1	POST /api/versions/293/courses	/api/versions/293/courses	{"params":{"vId":"293"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:34:17.043448+00
2185	1	PUT /api/versions/293/course-relations	/api/versions/293/course-relations	{"params":{"vId":"293"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 09:34:17.048418+00
2186	1	DELETE /api/version-courses/889	/api/version-courses/889	{"params":{"id":"889"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:17.05231+00
2205	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:35:12.78025+00
2206	1	POST /api/programs/354/versions	/api/programs/354/versions	{"params":{"programId":"354"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:35:12.78686+00
2207	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:35:12.79213+00
2208	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:35:12.805635+00
2209	1	DELETE /api/versions/297	/api/versions/297	{"params":{"id":"297"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:12.821862+00
2210	1	DELETE /api/programs/354	/api/programs/354	{"params":{"id":"354"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:12.825493+00
2232	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:34.830483+00
2233	1	DELETE /api/users/106	/api/users/106	{"params":{"id":"106"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:34.841495+00
2291	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:32.946896+00
2292	1	POST /api/programs/366/archive	/api/programs/366/archive	{"params":{"id":"366"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:32.952637+00
2293	1	POST /api/programs/366/unarchive	/api/programs/366/unarchive	{"params":{"id":"366"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:32.963989+00
2294	1	DELETE /api/programs/366	/api/programs/366	{"params":{"id":"366"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:32.975006+00
2479	1	POST /api/programs/381/archive	/api/programs/381/archive	{"params":{"id":"381"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:12.09087+00
686	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:36.541912+00
687	1	POST /api/programs/95/versions	/api/programs/95/versions	{"params":{"programId":"95"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:36.549692+00
688	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:36.56731+00
689	1	POST /api/programs/96/versions	/api/programs/96/versions	{"params":{"programId":"96"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:36.575139+00
690	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:23:36.581494+00
691	1	DELETE /api/programs/96	/api/programs/96	{"params":{"id":"96"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:36.60263+00
692	1	POST /api/versions/87/plos	/api/versions/87/plos	{"params":{"vId":"87"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:38.248354+00
727	1	DELETE /api/versions/93	/api/versions/93	{"params":{"id":"93"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:55.82835+00
728	1	DELETE /api/programs/101	/api/programs/101	{"params":{"id":"101"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:55.832491+00
1304	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:43:18.799108+00
1305	1	DELETE /api/programs/195	/api/programs/195	{"params":{"id":"195"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:18.9868+00
1446	1	PUT /api/programs/228	/api/programs/228	{"params":{"id":"228"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:46:43.875697+00
1456	1	POST /api/programs/231/unarchive	/api/programs/231/unarchive	{"params":{"id":"231"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:48.180732+00
1457	1	DELETE /api/programs/231	/api/programs/231	{"params":{"id":"231"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:48.185372+00
1645	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:36.519481+00
1646	1	POST /api/programs/267/versions	/api/programs/267/versions	{"params":{"programId":"267"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:36.528309+00
1647	1	POST /api/versions/227/objectives	/api/versions/227/objectives	{"params":{"vId":"227"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:49:38.386209+00
1759	1	DELETE /api/versions/248	/api/versions/248	{"params":{"id":"248"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:53:50.692398+00
1873	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:20:48.35265+00
1874	1	PUT /api/programs/309	/api/programs/309	{"params":{"id":"309"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:20:49.6532+00
1875	1	DELETE /api/programs/309	/api/programs/309	{"params":{"id":"309"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:49.74871+00
1878	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:20:52.85575+00
1879	1	POST /api/programs/311/archive	/api/programs/311/archive	{"params":{"id":"311"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:52.880981+00
1880	1	POST /api/programs/311/unarchive	/api/programs/311/unarchive	{"params":{"id":"311"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:54.022399+00
1881	1	DELETE /api/programs/311	/api/programs/311	{"params":{"id":"311"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:54.026343+00
2012	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:31.399218+00
2013	1	POST /api/users/88/roles	/api/users/88/roles	{"params":{"id":"88"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:23:31.412998+00
2014	1	DELETE /api/users/88/roles/GIANG_VIEN/5	/api/users/88/roles/GIANG_VIEN/5	{"params":{"userId":"88","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:31.424368+00
2015	1	DELETE /api/users/88	/api/users/88	{"params":{"id":"88"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:31.434921+00
2111	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:46.589939+00
2112	1	DELETE /api/objectives/127	/api/objectives/127	{"params":{"id":"127"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:48.198271+00
2131	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:55.798912+00
2132	1	DELETE /api/plos/173	/api/plos/173	{"params":{"id":"173"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:55.805186+00
2157	1	PUT /api/versions/293/po-plo-map	/api/versions/293/po-plo-map	{"params":{"vId":"293"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:34:02.468168+00
2178	1	POST /api/versions/293/courses	/api/versions/293/courses	{"params":{"vId":"293"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:34:10.794017+00
2179	1	PUT /api/version-courses/888	/api/version-courses/888	{"params":{"id":"888"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 09:34:10.799862+00
2180	1	DELETE /api/version-courses/888	/api/version-courses/888	{"params":{"id":"888"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:10.804948+00
2295	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:46:33.940672+00
2296	1	POST /api/programs/367/versions	/api/programs/367/versions	{"params":{"programId":"367"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:46:33.953408+00
2305	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:44.687802+00
2306	1	DELETE /api/objectives/138	/api/objectives/138	{"params":{"id":"138"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:44.696141+00
2322	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:50.952239+00
2323	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:50.959945+00
2324	1	DELETE /api/plos/187	/api/plos/187	{"params":{"id":"187"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:50.965779+00
2325	1	DELETE /api/plos/186	/api/plos/186	{"params":{"id":"186"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:50.975377+00
2347	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:57.452449+00
2348	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:57.458299+00
2349	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:57.463588+00
2350	1	PUT /api/versions/301/po-plo-map	/api/versions/301/po-plo-map	{"params":{"vId":"301"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:46:57.478487+00
693	1	DELETE /api/versions/87	/api/versions/87	{"params":{"id":"87"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:39.168878+00
694	1	DELETE /api/programs/95	/api/programs/95	{"params":{"id":"95"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:39.173574+00
695	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:39.207638+00
696	1	POST /api/programs/97/versions	/api/programs/97/versions	{"params":{"programId":"97"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:39.214551+00
697	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:23:39.220952+00
698	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:23:39.250037+00
707	1	DELETE /api/versions/91	/api/versions/91	{"params":{"id":"91"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:47.15459+00
708	1	DELETE /api/programs/99	/api/programs/99	{"params":{"id":"99"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:47.159805+00
709	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:23:47.457361+00
710	1	PUT /api/users/20	/api/users/20	{"params":{"id":"20"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 08:23:47.467604+00
711	1	DELETE /api/users/20	/api/users/20	{"params":{"id":"20"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:47.485154+00
718	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:23:51.46281+00
719	1	POST /api/users/22/roles	/api/users/22/roles	{"params":{"id":"22"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:23:51.477206+00
720	1	DELETE /api/users/22/roles/GIANG_VIEN/5	/api/users/22/roles/GIANG_VIEN/5	{"params":{"userId":"22","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:51.500921+00
721	1	DELETE /api/users/22	/api/users/22	{"params":{"id":"22"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:51.50963+00
732	1	DELETE /api/users/25	/api/users/25	{"params":{"id":"25"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:58.923059+00
1306	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:20.461209+00
1307	1	PUT /api/programs/196	/api/programs/196	{"params":{"id":"196"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:43:21.76218+00
1308	1	DELETE /api/programs/196	/api/programs/196	{"params":{"id":"196"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:21.855013+00
1315	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:27.728832+00
1316	1	POST /api/programs/199/versions	/api/programs/199/versions	{"params":{"programId":"199"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:43:27.753909+00
1317	1	DELETE /api/versions/169	/api/versions/169	{"params":{"id":"169"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:27.767756+00
1318	1	DELETE /api/programs/199	/api/programs/199	{"params":{"id":"199"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:27.774288+00
1448	1	DELETE /api/versions/193	/api/versions/193	{"params":{"id":"193"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:44.153753+00
1449	1	DELETE /api/programs/227	/api/programs/227	{"params":{"id":"227"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:44.157704+00
1460	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:49.679862+00
1461	1	POST /api/programs/232/versions	/api/programs/232/versions	{"params":{"programId":"232"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:49.69992+00
1462	1	DELETE /api/versions/195	/api/versions/195	{"params":{"id":"195"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:49.714086+00
1463	1	DELETE /api/programs/232	/api/programs/232	{"params":{"id":"232"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:49.71875+00
1648	1	DELETE /api/versions/227	/api/versions/227	{"params":{"id":"227"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:39.44028+00
1649	1	DELETE /api/programs/267	/api/programs/267	{"params":{"id":"267"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:39.445187+00
1650	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:49:40.582938+00
1760	1	DELETE /api/programs/288	/api/programs/288	{"params":{"id":"288"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:53:50.697284+00
1876	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:20:51.172207+00
1877	1	DELETE /api/programs/310	/api/programs/310	{"params":{"id":"310"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:51.184552+00
2016	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:35.550964+00
2017	1	DELETE /api/users/90	/api/users/90	{"params":{"id":"90"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:35.557728+00
2018	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:37.560826+00
2113	1	POST /api/versions/293/objectives	/api/versions/293/objectives	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:49.178925+00
2114	1	PUT /api/objectives/128	/api/objectives/128	{"params":{"id":"128"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:33:49.189517+00
2115	1	DELETE /api/objectives/128	/api/objectives/128	{"params":{"id":"128"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:49.205645+00
2126	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:53.822404+00
2127	1	PUT /api/plos/171	/api/plos/171	{"params":{"id":"171"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:33:53.839812+00
2129	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:54.829813+00
2130	1	DELETE /api/plos/172	/api/plos/172	{"params":{"id":"172"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:54.841085+00
2146	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:33:59.590514+00
2147	1	POST /api/plos/178/pis	/api/plos/178/pis	{"params":{"ploId":"178"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:33:59.600202+00
2148	1	DELETE /api/pis/308	/api/pis/308	{"params":{"id":"308"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:33:59.608529+00
2150	1	POST /api/versions/293/plos	/api/versions/293/plos	{"params":{"vId":"293"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:34:00.582473+00
2151	1	DELETE /api/plos/179	/api/plos/179	{"params":{"id":"179"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:00.60031+00
2166	1	POST /api/versions/293/knowledge-blocks	/api/versions/293/knowledge-blocks	{"params":{"vId":"293"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:34:05.300207+00
2171	1	POST /api/versions/293/courses	/api/versions/293/courses	{"params":{"vId":"293"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:34:08.054978+00
2624	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:52:27.662973+00
712	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:23:49.396754+00
717	1	POST /api/versions/92/objectives	/api/versions/92/objectives	{"params":{"vId":"92"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:23:51.154608+00
722	1	DELETE /api/versions/92	/api/versions/92	{"params":{"id":"92"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:52.05411+00
723	1	DELETE /api/programs/100	/api/programs/100	{"params":{"id":"100"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:23:52.0584+00
724	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:54.217444+00
725	1	POST /api/programs/101/versions	/api/programs/101/versions	{"params":{"programId":"101"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:23:54.229149+00
726	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:23:55.394063+00
729	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:23:58.02209+00
731	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:23:58.826618+00
737	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:02.092562+00
738	1	POST /api/programs/103/versions	/api/programs/103/versions	{"params":{"programId":"103"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:02.099723+00
739	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:24:02.993017+00
740	1	POST /api/versions/95/knowledge-blocks	/api/versions/95/knowledge-blocks	{"params":{"vId":"95"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:24:02.998082+00
741	1	PUT /api/users/28/toggle-active	/api/users/28/toggle-active	{"params":{"id":"28"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:03.015847+00
742	1	DELETE /api/users/28	/api/users/28	{"params":{"id":"28"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:03.027527+00
743	1	POST /api/versions/95/knowledge-blocks	/api/versions/95/knowledge-blocks	{"params":{"vId":"95"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:24:03.861845+00
744	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:24:04.98251+00
745	1	DELETE /api/users/29	/api/users/29	{"params":{"id":"29"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:05.012248+00
746	1	POST /api/versions/95/knowledge-blocks	/api/versions/95/knowledge-blocks	{"params":{"vId":"95"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:24:05.582122+00
747	1	DELETE /api/versions/95	/api/versions/95	{"params":{"id":"95"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:06.466895+00
748	1	DELETE /api/programs/103	/api/programs/103	{"params":{"id":"103"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:06.472287+00
749	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:08.631527+00
750	1	POST /api/programs/104/versions	/api/programs/104/versions	{"params":{"programId":"104"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:08.639719+00
751	1	POST /api/versions/96/courses	/api/versions/96/courses	{"params":{"vId":"96"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:24:09.407312+00
752	1	DELETE /api/version-courses/848	/api/version-courses/848	{"params":{"id":"848"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:09.415351+00
753	1	POST /api/versions/96/courses	/api/versions/96/courses	{"params":{"vId":"96"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:24:10.302557+00
754	1	DELETE /api/version-courses/849	/api/version-courses/849	{"params":{"id":"849"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:10.310247+00
755	1	POST /api/versions/96/courses	/api/versions/96/courses	{"params":{"vId":"96"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:24:11.122371+00
756	1	POST /api/versions/96/courses	/api/versions/96/courses	{"params":{"vId":"96"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:24:11.128256+00
757	1	DELETE /api/version-courses/850	/api/version-courses/850	{"params":{"id":"850"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:11.135496+00
758	1	DELETE /api/versions/96	/api/versions/96	{"params":{"id":"96"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:12.038435+00
759	1	DELETE /api/programs/104	/api/programs/104	{"params":{"id":"104"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:12.046052+00
760	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:14.162277+00
761	1	POST /api/programs/105/versions	/api/programs/105/versions	{"params":{"programId":"105"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:14.168876+00
762	1	POST /api/versions/97/courses	/api/versions/97/courses	{"params":{"vId":"97"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:24:15.064372+00
763	1	PUT /api/version-courses/852	/api/version-courses/852	{"params":{"id":"852"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 08:24:15.07084+00
764	1	DELETE /api/version-courses/852	/api/version-courses/852	{"params":{"id":"852"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:15.076256+00
765	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:24:15.41164+00
766	1	DELETE /api/roles/439	/api/roles/439	{"params":{"id":"439"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:15.416338+00
767	1	DELETE /api/versions/97	/api/versions/97	{"params":{"id":"97"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:17.579567+00
768	1	DELETE /api/programs/105	/api/programs/105	{"params":{"id":"105"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:17.584557+00
769	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:19.643799+00
770	1	POST /api/programs/106/versions	/api/programs/106/versions	{"params":{"programId":"106"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:19.651931+00
771	1	DELETE /api/versions/98	/api/versions/98	{"params":{"id":"98"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:21.395011+00
772	1	DELETE /api/programs/106	/api/programs/106	{"params":{"id":"106"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:21.399632+00
773	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:23.486408+00
774	1	POST /api/programs/107/versions	/api/programs/107/versions	{"params":{"programId":"107"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:23.496228+00
775	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:24:25.771819+00
776	1	DELETE /api/roles/441	/api/roles/441	{"params":{"id":"441"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:25.797095+00
777	1	DELETE /api/versions/99	/api/versions/99	{"params":{"id":"99"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:25.852431+00
778	1	DELETE /api/programs/107	/api/programs/107	{"params":{"id":"107"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:25.857141+00
779	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:27.971292+00
780	1	POST /api/programs/108/versions	/api/programs/108/versions	{"params":{"programId":"108"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:27.978183+00
781	1	DELETE /api/versions/100	/api/versions/100	{"params":{"id":"100"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:30.393303+00
782	1	DELETE /api/programs/108	/api/programs/108	{"params":{"id":"108"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:30.39749+00
783	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:24:31.346222+00
1309	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:23.541655+00
1310	1	DELETE /api/programs/197	/api/programs/197	{"params":{"id":"197"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:23.553864+00
1319	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:32.925182+00
1320	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:43:33.185753+00
1452	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:46.514185+00
1453	1	POST /api/programs/230/versions	/api/programs/230/versions	{"params":{"programId":"230"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:46.522043+00
1454	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:47.056986+00
1455	1	POST /api/programs/231/archive	/api/programs/231/archive	{"params":{"id":"231"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:47.067776+00
1458	1	DELETE /api/versions/194	/api/versions/194	{"params":{"id":"194"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:48.395825+00
1459	1	DELETE /api/programs/230	/api/programs/230	{"params":{"id":"230"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:48.400024+00
1469	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:54.780238+00
1470	1	POST /api/programs/235/versions	/api/programs/235/versions	{"params":{"programId":"235"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:54.788074+00
1471	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:46:54.991507+00
1472	1	DELETE /api/versions/197	/api/versions/197	{"params":{"id":"197"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:56.691335+00
1473	1	DELETE /api/programs/235	/api/programs/235	{"params":{"id":"235"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:46:56.695032+00
1651	1	DELETE /api/roles/515	/api/roles/515	{"params":{"id":"515"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:40.608561+00
1656	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:45.802127+00
1657	1	POST /api/programs/269/versions	/api/programs/269/versions	{"params":{"programId":"269"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:45.81065+00
1658	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:49:46.695361+00
1761	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:54:15.784098+00
1882	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:20:55.43745+00
1883	1	POST /api/programs/312/versions	/api/programs/312/versions	{"params":{"programId":"312"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:20:55.451953+00
1884	1	DELETE /api/versions/266	/api/versions/266	{"params":{"id":"266"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:55.469098+00
1885	1	DELETE /api/programs/312	/api/programs/312	{"params":{"id":"312"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:20:55.472956+00
2019	1	DELETE /api/users/91	/api/users/91	{"params":{"id":"91"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:37.646591+00
2167	1	POST /api/versions/293/knowledge-blocks	/api/versions/293/knowledge-blocks	{"params":{"vId":"293"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:34:07.079141+00
2168	1	POST /api/versions/293/knowledge-blocks	/api/versions/293/knowledge-blocks	{"params":{"vId":"293"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:34:07.087751+00
2169	1	POST /api/versions/293/knowledge-blocks	/api/versions/293/knowledge-blocks	{"params":{"vId":"293"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:34:07.092938+00
2170	1	DELETE /api/knowledge-blocks/1549	/api/knowledge-blocks/1549	{"params":{"id":"1549"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:07.102665+00
2297	1	PUT /api/versions/301	/api/versions/301	{"params":{"id":"301"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:46:37.712457+00
2309	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:46.575817+00
2310	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:46.586664+00
2311	1	DELETE /api/objectives/141	/api/objectives/141	{"params":{"id":"141"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:46.592314+00
2312	1	DELETE /api/objectives/140	/api/objectives/140	{"params":{"id":"140"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:46.601142+00
2320	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:50.069881+00
2321	1	DELETE /api/plos/185	/api/plos/185	{"params":{"id":"185"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:50.078315+00
2330	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:52.780626+00
2331	1	POST /api/plos/189/pis	/api/plos/189/pis	{"params":{"ploId":"189"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:46:52.791639+00
2332	1	PUT /api/pis/311	/api/pis/311	{"params":{"id":"311"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:46:52.805597+00
2333	1	DELETE /api/pis/311	/api/pis/311	{"params":{"id":"311"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:52.817771+00
2334	1	DELETE /api/plos/189	/api/plos/189	{"params":{"id":"189"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:52.82214+00
2362	1	POST /api/versions/301/courses	/api/versions/301/courses	{"params":{"vId":"301"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:47:02.677541+00
2363	1	DELETE /api/version-courses/891	/api/version-courses/891	{"params":{"id":"891"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:02.684707+00
2380	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:47:27.02148+00
2381	1	PUT /api/courses/659	/api/courses/659	{"params":{"id":"659"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:47:27.026555+00
2382	1	DELETE /api/courses/659	/api/courses/659	{"params":{"id":"659"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:27.032774+00
2383	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:47:33.218482+00
784	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:24:32.576598+00
785	1	POST /api/programs/109/versions	/api/programs/109/versions	{"params":{"programId":"109"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:24:32.583337+00
786	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:24:36.889563+00
787	1	DELETE /api/roles/443	/api/roles/443	{"params":{"id":"443"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:36.895098+00
788	1	DELETE /api/versions/101	/api/versions/101	{"params":{"id":"101"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:38.241662+00
800	1	DELETE /api/courses/642	/api/courses/642	{"params":{"id":"642"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:59.664864+00
801	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:25:18.226875+00
811	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:25:21.953427+00
812	1	POST /api/programs/112/versions	/api/programs/112/versions	{"params":{"programId":"112"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:25:21.961898+00
813	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:25:21.968364+00
814	1	DELETE /api/programs/112	/api/programs/112	{"params":{"id":"112"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:21.991199+00
821	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:32.621645+00
822	1	PUT /api/users/31	/api/users/31	{"params":{"id":"31"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 08:25:32.629852+00
823	1	DELETE /api/users/31	/api/users/31	{"params":{"id":"31"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:32.645367+00
833	1	DELETE /api/users/36	/api/users/36	{"params":{"id":"36"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:43.653781+00
848	1	DELETE /api/roles/447	/api/roles/447	{"params":{"id":"447"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:26:09.637206+00
849	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:26:14.98909+00
852	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:26:22.135488+00
853	1	PUT /api/roles/450	/api/roles/450	{"params":{"id":"450"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:26:22.140138+00
854	1	DELETE /api/roles/450	/api/roles/450	{"params":{"id":"450"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:26:22.145235+00
1311	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:25.078918+00
1312	1	POST /api/programs/198/archive	/api/programs/198/archive	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:25.089354+00
1313	1	POST /api/programs/198/unarchive	/api/programs/198/unarchive	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:26.198998+00
1314	1	DELETE /api/programs/198	/api/programs/198	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:26.207417+00
1321	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:37.755939+00
1322	1	POST /api/programs/202/versions	/api/programs/202/versions	{"params":{"programId":"202"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:43:37.7632+00
1474	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:58.952613+00
1475	1	POST /api/programs/237/versions	/api/programs/237/versions	{"params":{"programId":"237"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:58.959857+00
1476	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:46:59.514805+00
1477	1	POST /api/programs/238/versions	/api/programs/238/versions	{"params":{"programId":"238"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:46:59.520809+00
1652	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:41.709686+00
1653	1	POST /api/programs/268/versions	/api/programs/268/versions	{"params":{"programId":"268"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:41.718412+00
1672	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:50:20.048322+00
1673	1	POST /api/programs/270/versions	/api/programs/270/versions	{"params":{"programId":"270"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:50:20.057236+00
1685	1	POST /api/versions/231/courses	/api/versions/231/courses	{"params":{"vId":"231"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:50:29.735488+00
1762	1	POST /api/programs/289/versions	/api/programs/289/versions	{"params":{"programId":"289"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:54:15.810692+00
1763	1	POST /api/versions/249/objectives	/api/versions/249/objectives	{"params":{"vId":"249"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:54:15.829037+00
1764	1	DELETE /api/objectives/116	/api/objectives/116	{"params":{"id":"116"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:54:15.857909+00
1765	1	DELETE /api/versions/249	/api/versions/249	{"params":{"id":"249"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:54:15.872985+00
1766	1	DELETE /api/programs/289	/api/programs/289	{"params":{"id":"289"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:54:15.882684+00
1886	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:00.425159+00
1887	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:00.450309+00
1888	1	DELETE /api/programs/314	/api/programs/314	{"params":{"id":"314"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:00.454538+00
1889	1	DELETE /api/programs/313	/api/programs/313	{"params":{"id":"313"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:00.467543+00
2020	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:39.651902+00
2021	1	DELETE /api/users/93	/api/users/93	{"params":{"id":"93"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:39.665701+00
2025	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:23:43.665834+00
2026	1	DELETE /api/users/95	/api/users/95	{"params":{"id":"95"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:43.676691+00
2027	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:23:54.160301+00
2028	1	DELETE /api/roles/526	/api/roles/526	{"params":{"id":"526"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:23:54.166979+00
2030	1	DELETE /api/roles/528	/api/roles/528	{"params":{"id":"528"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:04.925783+00
2031	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:24:10.551502+00
2034	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:24:16.690884+00
789	1	DELETE /api/programs/109	/api/programs/109	{"params":{"id":"109"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:38.246346+00
790	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:24:38.770401+00
791	1	PUT /api/roles/444	/api/roles/444	{"params":{"id":"444"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:24:38.782241+00
792	1	DELETE /api/roles/444	/api/roles/444	{"params":{"id":"444"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:38.793732+00
793	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 08:24:46.193107+00
794	1	DELETE /api/departments/1591	/api/departments/1591	{"params":{"id":"1591"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:46.201989+00
795	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:24:47.82708+00
796	1	DELETE /api/departments/1593	/api/departments/1593	{"params":{"id":"1593"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:47.841838+00
797	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:24:49.410588+00
798	1	DELETE /api/departments/1595	/api/departments/1595	{"params":{"id":"1595"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:24:49.416692+00
799	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:24:59.628589+00
802	1	POST /api/programs/110/versions	/api/programs/110/versions	{"params":{"programId":"110"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:25:18.234949+00
803	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:25:18.252218+00
804	1	DELETE /api/programs/110	/api/programs/110	{"params":{"id":"110"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:18.267104+00
805	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:25:21.142637+00
806	1	POST /api/programs/111/versions	/api/programs/111/versions	{"params":{"programId":"111"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:25:21.150226+00
807	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:25:21.155379+00
808	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:25:21.168356+00
809	1	DELETE /api/approval/rejected/program_version/103	/api/approval/rejected/program_version/103	{"params":{"entityType":"program_version","entityId":"103"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:21.177283+00
810	1	DELETE /api/programs/111	/api/programs/111	{"params":{"id":"111"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:21.184124+00
815	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:25:24.642986+00
816	1	POST /api/programs/113/versions	/api/programs/113/versions	{"params":{"programId":"113"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:25:24.649894+00
817	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:25:24.654977+00
818	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:25:24.668884+00
819	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:30.681196+00
820	1	DELETE /api/users/30	/api/users/30	{"params":{"id":"30"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:30.693431+00
824	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:34.554997+00
825	1	POST /api/users/32/roles	/api/users/32/roles	{"params":{"id":"32"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:25:34.578013+00
826	1	DELETE /api/users/32	/api/users/32	{"params":{"id":"32"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:34.588795+00
827	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:36.456588+00
828	1	POST /api/users/33/roles	/api/users/33/roles	{"params":{"id":"33"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:25:36.468133+00
829	1	DELETE /api/users/33/roles/GIANG_VIEN/5	/api/users/33/roles/GIANG_VIEN/5	{"params":{"userId":"33","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:36.48136+00
830	1	DELETE /api/users/33	/api/users/33	{"params":{"id":"33"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:36.490523+00
831	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:40.336777+00
832	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:43.567727+00
834	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:45.589859+00
835	1	DELETE /api/users/38	/api/users/38	{"params":{"id":"38"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:45.605121+00
836	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:47.505514+00
837	1	PUT /api/users/39/toggle-active	/api/users/39/toggle-active	{"params":{"id":"39"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:47.515302+00
838	1	DELETE /api/users/39	/api/users/39	{"params":{"id":"39"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:47.530261+00
839	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:25:49.448006+00
840	1	DELETE /api/users/40	/api/users/40	{"params":{"id":"40"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:49.461515+00
841	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:25:53.908663+00
842	1	POST /api/programs/114/versions	/api/programs/114/versions	{"params":{"programId":"114"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:25:53.916447+00
843	1	DELETE /api/versions/106	/api/versions/106	{"params":{"id":"106"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:53.924797+00
844	1	DELETE /api/programs/114	/api/programs/114	{"params":{"id":"114"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:53.934154+00
845	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:25:59.614761+00
846	1	DELETE /api/roles/445	/api/roles/445	{"params":{"id":"445"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:25:59.619974+00
847	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:26:09.611998+00
850	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:26:20.290305+00
851	1	DELETE /api/roles/449	/api/roles/449	{"params":{"id":"449"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:26:20.295691+00
855	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 08:26:29.262689+00
856	1	DELETE /api/departments/1596	/api/departments/1596	{"params":{"id":"1596"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:26:29.273417+00
857	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:26:30.906978+00
1323	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:43.80452+00
1324	1	POST /api/programs/203/archive	/api/programs/203/archive	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:43.810709+00
1325	1	POST /api/programs/203/unarchive	/api/programs/203/unarchive	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:43.82527+00
1326	1	DELETE /api/programs/203	/api/programs/203	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:43.839574+00
1335	1	PUT /api/versions/172	/api/versions/172	{"params":{"id":"172"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:43:54.148795+00
1338	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:59.150898+00
1339	1	POST /api/programs/206/versions	/api/programs/206/versions	{"params":{"programId":"206"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:43:59.160032+00
1340	1	DELETE /api/versions/173	/api/versions/173	{"params":{"id":"173"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:00.942449+00
1341	1	DELETE /api/programs/206	/api/programs/206	{"params":{"id":"206"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:00.946134+00
1478	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:05.267923+00
1479	1	POST /api/programs/239/archive	/api/programs/239/archive	{"params":{"id":"239"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:05.273559+00
1480	1	POST /api/programs/239/unarchive	/api/programs/239/unarchive	{"params":{"id":"239"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:05.285586+00
1481	1	DELETE /api/programs/239	/api/programs/239	{"params":{"id":"239"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:05.295352+00
1492	1	POST /api/versions/201/knowledge-blocks	/api/versions/201/knowledge-blocks	{"params":{"vId":"201"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:47:14.01168+00
1511	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:24.42559+00
1512	1	POST /api/programs/245/versions	/api/programs/245/versions	{"params":{"programId":"245"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:24.434877+00
1520	1	DELETE /api/versions/206	/api/versions/206	{"params":{"id":"206"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:30.381835+00
1521	1	DELETE /api/programs/246	/api/programs/246	{"params":{"id":"246"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:30.386867+00
1522	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:30.44521+00
1523	1	POST /api/programs/247/versions	/api/programs/247/versions	{"params":{"programId":"247"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:30.45142+00
1531	1	PUT /api/versions/208	/api/versions/208	{"params":{"id":"208"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:01.241191+00
1654	1	DELETE /api/versions/228	/api/versions/228	{"params":{"id":"228"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:43.604997+00
1655	1	DELETE /api/programs/268	/api/programs/268	{"params":{"id":"268"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:43.611284+00
1681	1	POST /api/versions/231/courses	/api/versions/231/courses	{"params":{"vId":"231"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:50:27.654158+00
1682	1	DELETE /api/version-courses/870	/api/version-courses/870	{"params":{"id":"870"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:27.660849+00
1688	1	DELETE /api/versions/231	/api/versions/231	{"params":{"id":"231"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:30.770585+00
1689	1	DELETE /api/programs/271	/api/programs/271	{"params":{"id":"271"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:30.774585+00
1695	1	DELETE /api/versions/232	/api/versions/232	{"params":{"id":"232"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:36.402506+00
1696	1	DELETE /api/programs/272	/api/programs/272	{"params":{"id":"272"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:36.40754+00
1701	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:50:42.344125+00
1702	1	POST /api/programs/274/versions	/api/programs/274/versions	{"params":{"programId":"274"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:50:42.352079+00
1767	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:54:32.273576+00
1768	1	POST /api/programs/290/versions	/api/programs/290/versions	{"params":{"programId":"290"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:54:32.283324+00
1892	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:09.590968+00
1893	1	POST /api/programs/316/archive	/api/programs/316/archive	{"params":{"id":"316"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:09.600272+00
1894	1	POST /api/programs/316/unarchive	/api/programs/316/unarchive	{"params":{"id":"316"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:09.615535+00
1895	1	DELETE /api/programs/316	/api/programs/316	{"params":{"id":"316"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:09.625632+00
2029	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:24:04.900618+00
2172	1	DELETE /api/version-courses/884	/api/version-courses/884	{"params":{"id":"884"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:08.061099+00
2183	1	PUT /api/versions/293/course-pi-map	/api/versions/293/course-pi-map	{"params":{"vId":"293"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 09:34:15.154453+00
2187	1	DELETE /api/versions/293	/api/versions/293	{"params":{"id":"293"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:24.082451+00
2188	1	DELETE /api/programs/350	/api/programs/350	{"params":{"id":"350"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:34:24.086669+00
2216	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:21.251121+00
2217	1	POST /api/users/98/roles	/api/users/98/roles	{"params":{"id":"98"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:35:21.275813+00
2218	1	DELETE /api/users/98	/api/users/98	{"params":{"id":"98"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:21.285394+00
2237	1	DELETE /api/roles/540	/api/roles/540	{"params":{"id":"540"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:55.212959+00
2298	1	PUT /api/versions/301	/api/versions/301	{"params":{"id":"301"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:46:38.581995+00
2313	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:47.45089+00
2314	1	DELETE /api/plos/182	/api/plos/182	{"params":{"id":"182"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:47.463016+00
2346	1	PUT /api/versions/301/po-plo-map	/api/versions/301/po-plo-map	{"params":{"vId":"301"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:46:56.585343+00
2364	1	POST /api/versions/301/courses	/api/versions/301/courses	{"params":{"vId":"301"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:47:03.514513+00
858	1	DELETE /api/departments/1598	/api/departments/1598	{"params":{"id":"1598"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:26:30.920472+00
1327	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:44.806426+00
1328	1	POST /api/programs/204/versions	/api/programs/204/versions	{"params":{"programId":"204"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:43:44.818735+00
1331	1	DELETE /api/versions/171	/api/versions/171	{"params":{"id":"171"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:50.729057+00
1332	1	DELETE /api/programs/204	/api/programs/204	{"params":{"id":"204"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:50.738663+00
1482	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:06.250084+00
1483	1	POST /api/programs/240/versions	/api/programs/240/versions	{"params":{"programId":"240"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:06.260931+00
1487	1	PUT /api/versions/200	/api/versions/200	{"params":{"id":"200"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:11.128092+00
1518	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:29.351154+00
1519	1	POST /api/programs/246/versions	/api/programs/246/versions	{"params":{"programId":"246"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:29.357718+00
1659	1	DELETE /api/versions/229	/api/versions/229	{"params":{"id":"229"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:47.824924+00
1660	1	DELETE /api/programs/269	/api/programs/269	{"params":{"id":"269"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:47.831331+00
1663	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:49:54.391919+00
1664	1	PUT /api/roles/518	/api/roles/518	{"params":{"id":"518"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:49:54.39714+00
1665	1	DELETE /api/roles/518	/api/roles/518	{"params":{"id":"518"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:49:54.401597+00
1769	1	DELETE /api/versions/250	/api/versions/250	{"params":{"id":"250"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:54:33.764287+00
1770	1	DELETE /api/programs/290	/api/programs/290	{"params":{"id":"290"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:54:33.76919+00
1896	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:10.601341+00
1897	1	POST /api/programs/317/versions	/api/programs/317/versions	{"params":{"programId":"317"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:10.611461+00
2032	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:24:14.706662+00
2033	1	DELETE /api/roles/530	/api/roles/530	{"params":{"id":"530"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:14.710572+00
2189	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:34:45.251593+00
2299	1	PUT /api/versions/301	/api/versions/301	{"params":{"id":"301"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:46:39.439266+00
2307	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:45.644838+00
2308	1	DELETE /api/objectives/139	/api/objectives/139	{"params":{"id":"139"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:45.651583+00
2326	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:51.808259+00
2327	1	POST /api/plos/188/pis	/api/plos/188/pis	{"params":{"ploId":"188"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:46:51.820434+00
2328	1	DELETE /api/pis/310	/api/pis/310	{"params":{"id":"310"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:51.833017+00
2329	1	DELETE /api/plos/188	/api/plos/188	{"params":{"id":"188"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:51.838422+00
2341	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:55.591584+00
2342	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:55.598064+00
2343	1	PUT /api/versions/301/po-plo-map	/api/versions/301/po-plo-map	{"params":{"vId":"301"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:46:55.616982+00
2344	1	DELETE /api/objectives/142	/api/objectives/142	{"params":{"id":"142"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:55.625761+00
2345	1	DELETE /api/plos/192	/api/plos/192	{"params":{"id":"192"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:55.630283+00
2480	1	POST /api/programs/381/unarchive	/api/programs/381/unarchive	{"params":{"id":"381"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:12.108857+00
2481	1	DELETE /api/programs/381	/api/programs/381	{"params":{"id":"381"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:12.121103+00
2489	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:22.462973+00
2490	1	PUT /api/objectives/146	/api/objectives/146	{"params":{"id":"146"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:50:22.474483+00
2491	1	DELETE /api/objectives/146	/api/objectives/146	{"params":{"id":"146"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:22.488335+00
2502	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:26.204005+00
2503	1	PUT /api/plos/195	/api/plos/195	{"params":{"id":"195"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:50:26.21415+00
2504	1	DELETE /api/plos/195	/api/plos/195	{"params":{"id":"195"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:26.229096+00
2517	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:30.599564+00
2518	1	POST /api/plos/201/pis	/api/plos/201/pis	{"params":{"ploId":"201"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:50:30.611063+00
2519	1	PUT /api/pis/315	/api/pis/315	{"params":{"id":"315"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:50:30.62627+00
2520	1	DELETE /api/pis/315	/api/pis/315	{"params":{"id":"315"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:30.643469+00
2521	1	DELETE /api/plos/201	/api/plos/201	{"params":{"id":"201"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:30.648831+00
2541	1	POST /api/versions/309/knowledge-blocks	/api/versions/309/knowledge-blocks	{"params":{"vId":"309"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:50:35.678572+00
2549	1	POST /api/versions/309/courses	/api/versions/309/courses	{"params":{"vId":"309"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:50:39.671963+00
2550	1	DELETE /api/version-courses/897	/api/version-courses/897	{"params":{"id":"897"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:39.679097+00
2625	1	DELETE /api/roles/566	/api/roles/566	{"params":{"id":"566"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:27.668486+00
2629	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:52:32.600937+00
2630	1	DELETE /api/departments/1906	/api/departments/1906	{"params":{"id":"1906"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:32.607851+00
859	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:26:32.310555+00
860	1	DELETE /api/departments/1600	/api/departments/1600	{"params":{"id":"1600"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:26:32.316139+00
861	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:27:31.4315+00
862	1	DELETE /api/programs/115	/api/programs/115	{"params":{"id":"115"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:31.620518+00
863	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:32.924297+00
864	1	PUT /api/programs/116	/api/programs/116	{"params":{"id":"116"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:27:34.286723+00
865	1	DELETE /api/programs/116	/api/programs/116	{"params":{"id":"116"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:34.378448+00
866	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:35.798504+00
867	1	DELETE /api/programs/117	/api/programs/117	{"params":{"id":"117"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:35.809979+00
868	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:37.066594+00
869	1	POST /api/programs/118/archive	/api/programs/118/archive	{"params":{"id":"118"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:37.078539+00
870	1	POST /api/programs/118/unarchive	/api/programs/118/unarchive	{"params":{"id":"118"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:38.171752+00
871	1	DELETE /api/programs/118	/api/programs/118	{"params":{"id":"118"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:38.176416+00
872	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:39.431773+00
873	1	POST /api/programs/119/versions	/api/programs/119/versions	{"params":{"programId":"119"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:27:39.444173+00
874	1	DELETE /api/versions/107	/api/versions/107	{"params":{"id":"107"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:39.458737+00
875	1	DELETE /api/programs/119	/api/programs/119	{"params":{"id":"119"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:39.46229+00
876	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:43.783819+00
877	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:27:44.110597+00
878	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:47.949569+00
879	1	POST /api/programs/122/versions	/api/programs/122/versions	{"params":{"programId":"122"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:27:47.958386+00
880	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:53.460605+00
881	1	POST /api/programs/123/archive	/api/programs/123/archive	{"params":{"id":"123"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:53.464484+00
882	1	POST /api/programs/123/unarchive	/api/programs/123/unarchive	{"params":{"id":"123"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:53.473882+00
883	1	DELETE /api/programs/123	/api/programs/123	{"params":{"id":"123"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:53.485005+00
884	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:54.217879+00
885	1	POST /api/programs/124/versions	/api/programs/124/versions	{"params":{"programId":"124"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:27:54.227654+00
886	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:27:55.727598+00
887	1	POST /api/programs/125/versions	/api/programs/125/versions	{"params":{"programId":"125"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:27:55.735098+00
888	1	DELETE /api/versions/110	/api/versions/110	{"params":{"id":"110"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:55.743128+00
889	1	DELETE /api/programs/125	/api/programs/125	{"params":{"id":"125"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:55.752445+00
890	1	PUT /api/versions/109	/api/versions/109	{"params":{"id":"109"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:27:57.923117+00
891	1	PUT /api/versions/109	/api/versions/109	{"params":{"id":"109"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:27:58.581278+00
892	1	DELETE /api/versions/109	/api/versions/109	{"params":{"id":"109"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:59.403396+00
893	1	DELETE /api/programs/124	/api/programs/124	{"params":{"id":"124"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:27:59.409103+00
894	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:01.389306+00
895	1	POST /api/programs/126/versions	/api/programs/126/versions	{"params":{"programId":"126"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:01.396461+00
896	1	PUT /api/versions/111	/api/versions/111	{"params":{"id":"111"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:28:02.235635+00
897	1	DELETE /api/versions/111	/api/versions/111	{"params":{"id":"111"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:04.872109+00
898	1	DELETE /api/programs/126	/api/programs/126	{"params":{"id":"126"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:04.877526+00
899	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:06.878213+00
900	1	POST /api/programs/127/versions	/api/programs/127/versions	{"params":{"programId":"127"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:06.887334+00
901	1	DELETE /api/versions/112	/api/versions/112	{"params":{"id":"112"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:08.456908+00
902	1	DELETE /api/programs/127	/api/programs/127	{"params":{"id":"127"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:08.463291+00
903	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:10.439979+00
904	1	POST /api/programs/128/versions	/api/programs/128/versions	{"params":{"programId":"128"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:10.448404+00
905	1	POST /api/versions/113/objectives	/api/versions/113/objectives	{"params":{"vId":"113"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:11.215479+00
906	1	DELETE /api/objectives/90	/api/objectives/90	{"params":{"id":"90"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:11.228042+00
907	1	POST /api/versions/113/objectives	/api/versions/113/objectives	{"params":{"vId":"113"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:11.966886+00
908	1	DELETE /api/versions/113	/api/versions/113	{"params":{"id":"113"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:12.758822+00
909	1	DELETE /api/programs/128	/api/programs/128	{"params":{"id":"128"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:12.764126+00
916	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:18.14682+00
917	1	POST /api/programs/130/versions	/api/programs/130/versions	{"params":{"programId":"130"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:18.153111+00
1329	1	PUT /api/versions/171	/api/versions/171	{"params":{"id":"171"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:43:48.803393+00
1484	1	PUT /api/versions/200	/api/versions/200	{"params":{"id":"200"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:47:10.159687+00
1490	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:12.98261+00
1491	1	POST /api/programs/241/versions	/api/programs/241/versions	{"params":{"programId":"241"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:12.990039+00
1507	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:20.492533+00
1508	1	POST /api/programs/244/versions	/api/programs/244/versions	{"params":{"programId":"244"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:20.500314+00
1524	1	DELETE /api/versions/207	/api/versions/207	{"params":{"id":"207"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:32.454305+00
1525	1	DELETE /api/programs/247	/api/programs/247	{"params":{"id":"247"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:32.458623+00
1666	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 08:50:01.996307+00
1667	1	DELETE /api/departments/1790	/api/departments/1790	{"params":{"id":"1790"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:02.003958+00
1679	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:50:26.624117+00
1680	1	POST /api/programs/271/versions	/api/programs/271/versions	{"params":{"programId":"271"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:50:26.634794+00
1690	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:50:32.937623+00
1691	1	POST /api/programs/272/versions	/api/programs/272/versions	{"params":{"programId":"272"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:50:32.945912+00
1771	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:54:59.596591+00
1772	1	POST /api/programs/291/versions	/api/programs/291/versions	{"params":{"programId":"291"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:54:59.605338+00
1898	1	PUT /api/versions/268	/api/versions/268	{"params":{"id":"268"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:21:14.709964+00
1901	1	DELETE /api/versions/268	/api/versions/268	{"params":{"id":"268"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:19.31807+00
1902	1	DELETE /api/programs/317	/api/programs/317	{"params":{"id":"317"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:19.322287+00
1911	1	POST /api/versions/270/objectives	/api/versions/270/objectives	{"params":{"vId":"270"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:21:27.951405+00
1912	1	DELETE /api/objectives/121	/api/objectives/121	{"params":{"id":"121"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:27.956878+00
1923	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:37.550073+00
1924	1	POST /api/programs/321/versions	/api/programs/321/versions	{"params":{"programId":"321"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:37.561507+00
2035	1	PUT /api/roles/531	/api/roles/531	{"params":{"id":"531"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:24:16.696013+00
2036	1	DELETE /api/roles/531	/api/roles/531	{"params":{"id":"531"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:16.700935+00
2195	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:35:09.281806+00
2196	1	POST /api/programs/352/versions	/api/programs/352/versions	{"params":{"programId":"352"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:35:09.290197+00
2197	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:35:09.296075+00
2198	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:35:09.307293+00
2199	1	DELETE /api/approval/rejected/program_version/295	/api/approval/rejected/program_version/295	{"params":{"entityType":"program_version","entityId":"295"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:09.327521+00
2200	1	DELETE /api/programs/352	/api/programs/352	{"params":{"id":"352"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:09.333859+00
2213	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:19.314628+00
2214	1	PUT /api/users/97	/api/users/97	{"params":{"id":"97"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 09:35:19.323216+00
2215	1	DELETE /api/users/97	/api/users/97	{"params":{"id":"97"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:19.33193+00
2300	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:41.384637+00
2301	1	DELETE /api/objectives/136	/api/objectives/136	{"params":{"id":"136"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:42.99413+00
2318	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:49.224263+00
2319	1	DELETE /api/plos/184	/api/plos/184	{"params":{"id":"184"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:49.23626+00
2335	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:53.758222+00
2336	1	POST /api/plos/190/pis	/api/plos/190/pis	{"params":{"ploId":"190"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:46:53.767868+00
2337	1	DELETE /api/pis/312	/api/pis/312	{"params":{"id":"312"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:53.78368+00
2338	1	DELETE /api/plos/190	/api/plos/190	{"params":{"id":"190"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:53.791556+00
2354	1	POST /api/versions/301/knowledge-blocks	/api/versions/301/knowledge-blocks	{"params":{"vId":"301"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:46:58.283055+00
2360	1	POST /api/versions/301/courses	/api/versions/301/courses	{"params":{"vId":"301"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:47:01.828302+00
2361	1	DELETE /api/version-courses/890	/api/version-courses/890	{"params":{"id":"890"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:01.835559+00
2372	1	PUT /api/versions/301/course-pi-map	/api/versions/301/course-pi-map	{"params":{"vId":"301"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 09:47:08.626105+00
2389	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:47:53.962975+00
2390	1	POST /api/programs/368/versions	/api/programs/368/versions	{"params":{"programId":"368"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:47:53.969646+00
910	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:14.619371+00
911	1	POST /api/programs/129/versions	/api/programs/129/versions	{"params":{"programId":"129"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:14.627419+00
933	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:32.095193+00
934	1	POST /api/programs/134/versions	/api/programs/134/versions	{"params":{"programId":"134"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:32.103047+00
957	1	DELETE /api/versions/124	/api/versions/124	{"params":{"id":"124"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:52.683971+00
958	1	DELETE /api/programs/139	/api/programs/139	{"params":{"id":"139"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:52.689255+00
966	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:29:00.623074+00
967	1	POST /api/programs/141/versions	/api/programs/141/versions	{"params":{"programId":"141"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:29:00.630643+00
977	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:29:05.77542+00
978	1	POST /api/programs/142/versions	/api/programs/142/versions	{"params":{"programId":"142"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:29:05.783691+00
986	1	DELETE /api/versions/128	/api/versions/128	{"params":{"id":"128"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:12.130474+00
987	1	DELETE /api/programs/143	/api/programs/143	{"params":{"id":"143"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:12.136083+00
1001	1	DELETE /api/courses/644	/api/courses/644	{"params":{"id":"644"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:48.818411+00
1330	1	PUT /api/versions/171	/api/versions/171	{"params":{"id":"171"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:43:49.768387+00
1485	1	DELETE /api/versions/198	/api/versions/198	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:10.700754+00
1486	1	DELETE /api/programs/237	/api/programs/237	{"params":{"id":"237"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:10.705094+00
1495	1	DELETE /api/versions/201	/api/versions/201	{"params":{"id":"201"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:14.921889+00
1496	1	DELETE /api/programs/241	/api/programs/241	{"params":{"id":"241"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:14.927457+00
1668	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:50:03.899492+00
1773	1	DELETE /api/versions/251	/api/versions/251	{"params":{"id":"251"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:55:01.329532+00
1774	1	DELETE /api/programs/291	/api/programs/291	{"params":{"id":"291"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:55:01.334517+00
1899	1	PUT /api/versions/268	/api/versions/268	{"params":{"id":"268"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:15.522927+00
2037	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 09:24:24.014913+00
2038	1	DELETE /api/departments/1820	/api/departments/1820	{"params":{"id":"1820"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:24.020148+00
2041	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:24:27.12135+00
2042	1	DELETE /api/departments/1824	/api/departments/1824	{"params":{"id":"1824"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:27.127337+00
2201	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:35:10.112507+00
2202	1	POST /api/programs/353/versions	/api/programs/353/versions	{"params":{"programId":"353"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:35:10.119811+00
2203	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:35:10.124546+00
2204	1	DELETE /api/programs/353	/api/programs/353	{"params":{"id":"353"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:10.150098+00
2211	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:17.387413+00
2212	1	DELETE /api/users/96	/api/users/96	{"params":{"id":"96"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:17.404132+00
2219	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:23.180217+00
2220	1	POST /api/users/99/roles	/api/users/99/roles	{"params":{"id":"99"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:35:23.197095+00
2221	1	DELETE /api/users/99/roles/GIANG_VIEN/5	/api/users/99/roles/GIANG_VIEN/5	{"params":{"userId":"99","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:23.205754+00
2222	1	DELETE /api/users/99	/api/users/99	{"params":{"id":"99"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:23.216454+00
2226	1	DELETE /api/users/102	/api/users/102	{"params":{"id":"102"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:28.991634+00
2238	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:36:00.755677+00
2302	1	POST /api/versions/301/objectives	/api/versions/301/objectives	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:43.861866+00
2303	1	PUT /api/objectives/137	/api/objectives/137	{"params":{"id":"137"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:46:43.874296+00
2304	1	DELETE /api/objectives/137	/api/objectives/137	{"params":{"id":"137"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:43.887429+00
2315	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:48.31917+00
2316	1	PUT /api/plos/183	/api/plos/183	{"params":{"id":"183"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:46:48.328374+00
2317	1	DELETE /api/plos/183	/api/plos/183	{"params":{"id":"183"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:48.34483+00
2339	1	POST /api/versions/301/plos	/api/versions/301/plos	{"params":{"vId":"301"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:46:54.636782+00
2340	1	DELETE /api/plos/191	/api/plos/191	{"params":{"id":"191"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:54.66196+00
2355	1	POST /api/versions/301/knowledge-blocks	/api/versions/301/knowledge-blocks	{"params":{"vId":"301"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:46:59.214869+00
2367	1	POST /api/versions/301/courses	/api/versions/301/courses	{"params":{"vId":"301"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:47:04.376345+00
2368	1	PUT /api/version-courses/894	/api/version-courses/894	{"params":{"id":"894"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 09:47:04.38264+00
2369	1	DELETE /api/version-courses/894	/api/version-courses/894	{"params":{"id":"894"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:04.389873+00
2376	1	DELETE /api/versions/301	/api/versions/301	{"params":{"id":"301"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:17.070442+00
2377	1	DELETE /api/programs/367	/api/programs/367	{"params":{"id":"367"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:17.075469+00
2378	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:47:24.462822+00
912	1	POST /api/versions/114/objectives	/api/versions/114/objectives	{"params":{"vId":"114"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:15.481235+00
913	1	POST /api/versions/114/objectives	/api/versions/114/objectives	{"params":{"vId":"114"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:15.492508+00
1333	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:43:53.110129+00
1334	1	POST /api/programs/205/versions	/api/programs/205/versions	{"params":{"programId":"205"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:43:53.121399+00
1336	1	DELETE /api/versions/172	/api/versions/172	{"params":{"id":"172"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:57.093912+00
1337	1	DELETE /api/programs/205	/api/programs/205	{"params":{"id":"205"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:43:57.098686+00
1488	1	DELETE /api/versions/200	/api/versions/200	{"params":{"id":"200"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:12.072016+00
1489	1	DELETE /api/programs/240	/api/programs/240	{"params":{"id":"240"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:12.083866+00
1497	1	PUT /api/versions/202	/api/versions/202	{"params":{"id":"202"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:47:15.27277+00
1501	1	POST /api/versions/203/courses	/api/versions/203/courses	{"params":{"vId":"203"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:47:18.296168+00
1502	1	DELETE /api/programs/242	/api/programs/242	{"params":{"id":"242"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:18.304687+00
1505	1	DELETE /api/versions/203	/api/versions/203	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:19.32071+00
1506	1	DELETE /api/programs/243	/api/programs/243	{"params":{"id":"243"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:19.325711+00
1515	1	POST /api/versions/205/objectives	/api/versions/205/objectives	{"params":{"vId":"205"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:47:26.252636+00
1527	1	DELETE /api/courses/650	/api/courses/650	{"params":{"id":"650"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:52.712616+00
1669	1	DELETE /api/departments/1792	/api/departments/1792	{"params":{"id":"1792"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:03.913981+00
1775	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:55:35.316079+00
1900	1	PUT /api/versions/268	/api/versions/268	{"params":{"id":"268"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:21:16.354356+00
1903	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:21.579824+00
1904	1	POST /api/programs/318/versions	/api/programs/318/versions	{"params":{"programId":"318"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:21.588995+00
1905	1	DELETE /api/versions/269	/api/versions/269	{"params":{"id":"269"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:23.619752+00
1906	1	DELETE /api/programs/318	/api/programs/318	{"params":{"id":"318"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:23.623695+00
1925	1	DELETE /api/versions/272	/api/versions/272	{"params":{"id":"272"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:39.368308+00
1926	1	DELETE /api/programs/321	/api/programs/321	{"params":{"id":"321"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:39.373489+00
1936	1	DELETE /api/versions/274	/api/versions/274	{"params":{"id":"274"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:48.50514+00
1937	1	DELETE /api/programs/323	/api/programs/323	{"params":{"id":"323"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:48.510253+00
2040	1	DELETE /api/departments/1822	/api/departments/1822	{"params":{"id":"1822"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:25.395734+00
2043	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:24:48.27511+00
2044	1	POST /api/programs/333/versions	/api/programs/333/versions	{"params":{"programId":"333"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:24:48.283459+00
2045	1	DELETE /api/versions/284	/api/versions/284	{"params":{"id":"284"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:48.291167+00
2046	1	DELETE /api/programs/333	/api/programs/333	{"params":{"id":"333"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:24:48.300261+00
2223	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:26.962009+00
2224	1	DELETE /api/users/101	/api/users/101	{"params":{"id":"101"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:26.968024+00
2225	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:28.906526+00
2351	1	DELETE /api/objectives/143	/api/objectives/143	{"params":{"id":"143"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:57.486344+00
2352	1	DELETE /api/objectives/144	/api/objectives/144	{"params":{"id":"144"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:57.49003+00
2353	1	DELETE /api/plos/193	/api/plos/193	{"params":{"id":"193"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:46:57.493585+00
2356	1	POST /api/versions/301/knowledge-blocks	/api/versions/301/knowledge-blocks	{"params":{"vId":"301"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:47:00.98841+00
2357	1	POST /api/versions/301/knowledge-blocks	/api/versions/301/knowledge-blocks	{"params":{"vId":"301"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:47:00.993624+00
2358	1	POST /api/versions/301/knowledge-blocks	/api/versions/301/knowledge-blocks	{"params":{"vId":"301"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:47:00.998106+00
2359	1	DELETE /api/knowledge-blocks/1594	/api/knowledge-blocks/1594	{"params":{"id":"1594"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:01.003045+00
2370	1	PUT /api/versions/301/course-plo-map	/api/versions/301/course-plo-map	{"params":{"vId":"301"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:47:06.093347+00
2384	1	DELETE /api/courses/660	/api/courses/660	{"params":{"id":"660"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:33.256345+00
2411	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:08.053649+00
2412	1	PUT /api/users/108	/api/users/108	{"params":{"id":"108"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 09:48:08.064592+00
2413	1	DELETE /api/users/108	/api/users/108	{"params":{"id":"108"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:08.078661+00
2482	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:50:12.928589+00
2483	1	POST /api/programs/382/versions	/api/programs/382/versions	{"params":{"programId":"382"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:50:12.938637+00
2485	1	PUT /api/versions/309	/api/versions/309	{"params":{"id":"309"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:50:17.453213+00
2494	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:24.068042+00
2495	1	DELETE /api/objectives/148	/api/objectives/148	{"params":{"id":"148"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:24.07533+00
2513	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:29.644691+00
914	1	DELETE /api/versions/114	/api/versions/114	{"params":{"id":"114"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:16.225531+00
915	1	DELETE /api/programs/129	/api/programs/129	{"params":{"id":"129"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:16.23086+00
918	1	DELETE /api/versions/115	/api/versions/115	{"params":{"id":"115"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:19.567233+00
919	1	DELETE /api/programs/130	/api/programs/130	{"params":{"id":"130"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:19.571303+00
920	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:21.509509+00
921	1	POST /api/programs/131/versions	/api/programs/131/versions	{"params":{"programId":"131"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:21.518594+00
922	1	DELETE /api/versions/116	/api/versions/116	{"params":{"id":"116"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:22.976779+00
923	1	DELETE /api/programs/131	/api/programs/131	{"params":{"id":"131"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:22.982142+00
924	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:24.900459+00
925	1	POST /api/programs/132/versions	/api/programs/132/versions	{"params":{"programId":"132"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:24.909588+00
926	1	DELETE /api/versions/117	/api/versions/117	{"params":{"id":"117"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:26.560426+00
927	1	DELETE /api/programs/132	/api/programs/132	{"params":{"id":"132"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:26.566677+00
928	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:28.494651+00
929	1	POST /api/programs/133/versions	/api/programs/133/versions	{"params":{"programId":"133"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:28.504627+00
931	1	DELETE /api/versions/118	/api/versions/118	{"params":{"id":"118"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:30.010329+00
932	1	DELETE /api/programs/133	/api/programs/133	{"params":{"id":"133"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:30.015266+00
935	1	POST /api/versions/119/plos	/api/versions/119/plos	{"params":{"vId":"119"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:33.551168+00
1342	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:02.859803+00
1343	1	POST /api/programs/207/versions	/api/programs/207/versions	{"params":{"programId":"207"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:02.869248+00
1355	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:11.411192+00
1356	1	POST /api/programs/209/versions	/api/programs/209/versions	{"params":{"programId":"209"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:11.419104+00
1493	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:14.282673+00
1494	1	POST /api/programs/242/versions	/api/programs/242/versions	{"params":{"programId":"242"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:14.291167+00
1516	1	DELETE /api/versions/205	/api/versions/205	{"params":{"id":"205"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:27.148103+00
1517	1	DELETE /api/programs/245	/api/programs/245	{"params":{"id":"245"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:27.152795+00
1670	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:50:05.708292+00
1671	1	DELETE /api/departments/1794	/api/departments/1794	{"params":{"id":"1794"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:05.714986+00
1676	1	POST /api/versions/230/knowledge-blocks	/api/versions/230/knowledge-blocks	{"params":{"vId":"230"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:50:23.508635+00
1683	1	POST /api/versions/231/courses	/api/versions/231/courses	{"params":{"vId":"231"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:50:28.63962+00
1684	1	DELETE /api/version-courses/871	/api/version-courses/871	{"params":{"id":"871"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:28.646272+00
1703	1	DELETE /api/versions/234	/api/versions/234	{"params":{"id":"234"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:44.101413+00
1704	1	DELETE /api/programs/274	/api/programs/274	{"params":{"id":"274"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:44.105846+00
1776	1	POST /api/programs/292/versions	/api/programs/292/versions	{"params":{"programId":"292"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:55:35.352822+00
1777	1	DELETE /api/versions/252	/api/versions/252	{"params":{"id":"252"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:55:35.384653+00
1778	1	DELETE /api/programs/292	/api/programs/292	{"params":{"id":"292"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:55:35.39459+00
1907	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:25.968565+00
1908	1	POST /api/programs/319/versions	/api/programs/319/versions	{"params":{"programId":"319"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:25.975457+00
1917	1	DELETE /api/versions/270	/api/versions/270	{"params":{"id":"270"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:30.811348+00
1918	1	DELETE /api/programs/319	/api/programs/319	{"params":{"id":"319"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:30.815573+00
2047	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:25:06.194529+00
2048	1	DELETE /api/programs/334	/api/programs/334	{"params":{"id":"334"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:25:07.322046+00
2227	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:30.913128+00
2228	1	DELETE /api/users/104	/api/users/104	{"params":{"id":"104"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:30.922814+00
2229	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:35:32.899895+00
2230	1	PUT /api/users/105/toggle-active	/api/users/105/toggle-active	{"params":{"id":"105"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:32.90939+00
2231	1	DELETE /api/users/105	/api/users/105	{"params":{"id":"105"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:35:32.924513+00
2365	1	POST /api/versions/301/courses	/api/versions/301/courses	{"params":{"vId":"301"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:47:03.520394+00
2366	1	DELETE /api/version-courses/892	/api/version-courses/892	{"params":{"id":"892"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:03.527681+00
2371	1	PUT /api/versions/301/course-plo-map	/api/versions/301/course-plo-map	{"params":{"vId":"301"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:47:06.986144+00
2373	1	POST /api/versions/301/courses	/api/versions/301/courses	{"params":{"vId":"301"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:47:10.36538+00
2374	1	PUT /api/versions/301/course-relations	/api/versions/301/course-relations	{"params":{"vId":"301"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 09:47:10.372389+00
930	1	POST /api/versions/118/plos	/api/versions/118/plos	{"params":{"vId":"118"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:29.278349+00
936	1	DELETE /api/versions/119	/api/versions/119	{"params":{"id":"119"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:34.304367+00
937	1	DELETE /api/programs/134	/api/programs/134	{"params":{"id":"134"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:34.309701+00
938	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:36.343046+00
939	1	POST /api/programs/135/versions	/api/programs/135/versions	{"params":{"programId":"135"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:36.352231+00
940	1	DELETE /api/versions/120	/api/versions/120	{"params":{"id":"120"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:37.955385+00
941	1	DELETE /api/programs/135	/api/programs/135	{"params":{"id":"135"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:37.959095+00
942	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:39.910627+00
943	1	POST /api/programs/136/versions	/api/programs/136/versions	{"params":{"programId":"136"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:39.918952+00
944	1	DELETE /api/versions/121	/api/versions/121	{"params":{"id":"121"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:41.5238+00
945	1	DELETE /api/programs/136	/api/programs/136	{"params":{"id":"136"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:41.527991+00
946	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:43.408749+00
947	1	POST /api/programs/137/versions	/api/programs/137/versions	{"params":{"programId":"137"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:43.417614+00
948	1	POST /api/versions/122/objectives	/api/versions/122/objectives	{"params":{"vId":"122"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:28:44.845568+00
949	1	DELETE /api/versions/122	/api/versions/122	{"params":{"id":"122"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:45.609827+00
950	1	DELETE /api/programs/137	/api/programs/137	{"params":{"id":"137"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:45.619113+00
951	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:47.679446+00
952	1	POST /api/programs/138/versions	/api/programs/138/versions	{"params":{"programId":"138"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:47.684969+00
953	1	DELETE /api/versions/123	/api/versions/123	{"params":{"id":"123"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:49.240832+00
954	1	DELETE /api/programs/138	/api/programs/138	{"params":{"id":"138"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:49.24608+00
955	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:51.211307+00
956	1	POST /api/programs/139/versions	/api/programs/139/versions	{"params":{"programId":"139"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:51.21963+00
959	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:28:54.628119+00
960	1	POST /api/programs/140/versions	/api/programs/140/versions	{"params":{"programId":"140"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:28:54.636644+00
961	1	POST /api/versions/125/knowledge-blocks	/api/versions/125/knowledge-blocks	{"params":{"vId":"125"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:28:55.468217+00
962	1	POST /api/versions/125/knowledge-blocks	/api/versions/125/knowledge-blocks	{"params":{"vId":"125"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:28:56.286216+00
963	1	POST /api/versions/125/knowledge-blocks	/api/versions/125/knowledge-blocks	{"params":{"vId":"125"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:28:57.965521+00
964	1	DELETE /api/versions/125	/api/versions/125	{"params":{"id":"125"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:58.647727+00
965	1	DELETE /api/programs/140	/api/programs/140	{"params":{"id":"140"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:28:58.652329+00
968	1	POST /api/versions/126/courses	/api/versions/126/courses	{"params":{"vId":"126"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:29:01.433197+00
969	1	DELETE /api/version-courses/853	/api/version-courses/853	{"params":{"id":"853"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:01.438966+00
970	1	POST /api/versions/126/courses	/api/versions/126/courses	{"params":{"vId":"126"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:29:02.147716+00
971	1	DELETE /api/version-courses/854	/api/version-courses/854	{"params":{"id":"854"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:02.155633+00
972	1	POST /api/versions/126/courses	/api/versions/126/courses	{"params":{"vId":"126"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:29:02.955824+00
973	1	POST /api/versions/126/courses	/api/versions/126/courses	{"params":{"vId":"126"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:29:02.961093+00
974	1	DELETE /api/version-courses/855	/api/version-courses/855	{"params":{"id":"855"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:02.966444+00
975	1	DELETE /api/versions/126	/api/versions/126	{"params":{"id":"126"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:03.803+00
976	1	DELETE /api/programs/141	/api/programs/141	{"params":{"id":"141"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:03.806987+00
979	1	POST /api/versions/127/courses	/api/versions/127/courses	{"params":{"vId":"127"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:29:06.522335+00
980	1	PUT /api/version-courses/857	/api/version-courses/857	{"params":{"id":"857"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 08:29:06.527173+00
981	1	DELETE /api/version-courses/857	/api/version-courses/857	{"params":{"id":"857"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:06.530968+00
982	1	DELETE /api/versions/127	/api/versions/127	{"params":{"id":"127"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:08.653925+00
983	1	DELETE /api/programs/142	/api/programs/142	{"params":{"id":"142"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:08.658662+00
984	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:29:10.557748+00
985	1	POST /api/programs/143/versions	/api/programs/143/versions	{"params":{"programId":"143"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:29:10.566404+00
988	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:29:14.022862+00
989	1	POST /api/programs/144/versions	/api/programs/144/versions	{"params":{"programId":"144"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:29:14.031733+00
990	1	DELETE /api/versions/129	/api/versions/129	{"params":{"id":"129"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:16.175182+00
991	1	DELETE /api/programs/144	/api/programs/144	{"params":{"id":"144"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:16.17958+00
992	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:29:18.177043+00
993	1	POST /api/programs/145/versions	/api/programs/145/versions	{"params":{"programId":"145"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:29:18.186449+00
996	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:29:22.468935+00
997	1	POST /api/programs/146/versions	/api/programs/146/versions	{"params":{"programId":"146"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:29:22.474346+00
1344	1	POST /api/versions/174/objectives	/api/versions/174/objectives	{"params":{"vId":"174"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:03.657847+00
1345	1	DELETE /api/objectives/103	/api/objectives/103	{"params":{"id":"103"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:03.667362+00
1349	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:07.665177+00
1350	1	POST /api/programs/208/versions	/api/programs/208/versions	{"params":{"programId":"208"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:07.679152+00
1498	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:17.351817+00
1499	1	POST /api/programs/243/versions	/api/programs/243/versions	{"params":{"programId":"243"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:17.359633+00
1674	1	POST /api/versions/230/knowledge-blocks	/api/versions/230/knowledge-blocks	{"params":{"vId":"230"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:50:20.958181+00
1677	1	DELETE /api/versions/230	/api/versions/230	{"params":{"id":"230"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:24.533952+00
1678	1	DELETE /api/programs/270	/api/programs/270	{"params":{"id":"270"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:24.53927+00
1699	1	DELETE /api/versions/233	/api/versions/233	{"params":{"id":"233"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:40.565648+00
1700	1	DELETE /api/programs/273	/api/programs/273	{"params":{"id":"273"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:40.570424+00
1779	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:56:05.27981+00
1780	1	POST /api/programs/293/versions	/api/programs/293/versions	{"params":{"programId":"293"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:56:05.289366+00
1909	1	POST /api/versions/270/objectives	/api/versions/270/objectives	{"params":{"vId":"270"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:21:26.881609+00
1910	1	DELETE /api/objectives/120	/api/objectives/120	{"params":{"id":"120"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:26.893159+00
2049	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:25:16.708838+00
2050	1	POST /api/programs/335/versions	/api/programs/335/versions	{"params":{"programId":"335"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:25:16.71625+00
2236	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:35:55.193156+00
2375	1	DELETE /api/version-courses/895	/api/version-courses/895	{"params":{"id":"895"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:10.377595+00
2387	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:47:37.563847+00
2388	1	DELETE /api/courses/663	/api/courses/663	{"params":{"id":"663"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:37.570731+00
2424	1	DELETE /api/users/113	/api/users/113	{"params":{"id":"113"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:18.180946+00
2432	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:48:34.684839+00
2433	1	DELETE /api/roles/550	/api/roles/550	{"params":{"id":"550"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:34.6907+00
2447	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 09:49:01.750564+00
2448	1	DELETE /api/departments/1879	/api/departments/1879	{"params":{"id":"1879"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:01.754976+00
2484	1	PUT /api/versions/309	/api/versions/309	{"params":{"id":"309"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:50:16.617417+00
2496	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:24.777439+00
2497	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:24.789784+00
2498	1	DELETE /api/objectives/150	/api/objectives/150	{"params":{"id":"150"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:24.795598+00
2526	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:32.381228+00
2527	1	DELETE /api/plos/203	/api/plos/203	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:32.406277+00
2542	1	POST /api/versions/309/knowledge-blocks	/api/versions/309/knowledge-blocks	{"params":{"vId":"309"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:50:36.369712+00
2560	1	POST /api/versions/309/courses	/api/versions/309/courses	{"params":{"vId":"309"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:50:46.772507+00
2561	1	PUT /api/versions/309/course-relations	/api/versions/309/course-relations	{"params":{"vId":"309"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 09:50:46.778618+00
2562	1	DELETE /api/version-courses/901	/api/version-courses/901	{"params":{"id":"901"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:46.784085+00
2627	1	PUT /api/roles/567	/api/roles/567	{"params":{"id":"567"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:52:29.454614+00
2628	1	DELETE /api/roles/567	/api/roles/567	{"params":{"id":"567"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:29.458041+00
2657	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:54:52.91305+00
2658	1	PUT /api/courses/673	/api/courses/673	{"params":{"id":"673"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:54:52.918413+00
2659	1	DELETE /api/courses/673	/api/courses/673	{"params":{"id":"673"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:54:52.925776+00
2682	1	POST /api/programs/398/archive	/api/programs/398/archive	{"params":{"id":"398"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:21.760243+00
2683	1	POST /api/programs/398/unarchive	/api/programs/398/unarchive	{"params":{"id":"398"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:21.77915+00
2684	1	DELETE /api/programs/398	/api/programs/398	{"params":{"id":"398"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:21.790143+00
2695	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:33.764203+00
2696	1	DELETE /api/objectives/156	/api/objectives/156	{"params":{"id":"156"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:33.774237+00
2702	1	DELETE /api/objectives/158	/api/objectives/158	{"params":{"id":"158"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:35.612158+00
2706	1	PUT /api/plos/207	/api/plos/207	{"params":{"id":"207"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:56:37.440512+00
994	1	DELETE /api/versions/130	/api/versions/130	{"params":{"id":"130"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:20.477428+00
995	1	DELETE /api/programs/145	/api/programs/145	{"params":{"id":"145"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:20.481133+00
998	1	DELETE /api/versions/131	/api/versions/131	{"params":{"id":"131"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:28.654486+00
999	1	DELETE /api/programs/146	/api/programs/146	{"params":{"id":"146"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:29:28.659454+00
1000	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:29:48.781764+00
1002	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:30:06.350875+00
1003	1	POST /api/programs/147/versions	/api/programs/147/versions	{"params":{"programId":"147"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:30:06.358958+00
1004	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:30:06.376869+00
1005	1	DELETE /api/programs/147	/api/programs/147	{"params":{"id":"147"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:06.395259+00
1006	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:30:09.315566+00
1007	1	POST /api/programs/148/versions	/api/programs/148/versions	{"params":{"programId":"148"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:30:09.322062+00
1008	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:30:09.326852+00
1009	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:30:09.341381+00
1010	1	DELETE /api/approval/rejected/program_version/133	/api/approval/rejected/program_version/133	{"params":{"entityType":"program_version","entityId":"133"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:09.351215+00
1011	1	DELETE /api/programs/148	/api/programs/148	{"params":{"id":"148"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:09.358079+00
1012	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:30:10.072767+00
1013	1	POST /api/programs/149/versions	/api/programs/149/versions	{"params":{"programId":"149"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:30:10.080911+00
1014	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:30:10.086981+00
1015	1	DELETE /api/programs/149	/api/programs/149	{"params":{"id":"149"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:10.109956+00
1016	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:30:12.546953+00
1017	1	POST /api/programs/150/versions	/api/programs/150/versions	{"params":{"programId":"150"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:30:12.555611+00
1018	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:30:12.561058+00
1019	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:30:12.572585+00
1020	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:18.241632+00
1021	1	DELETE /api/users/41	/api/users/41	{"params":{"id":"41"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:18.25537+00
1022	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:20.089174+00
1023	1	PUT /api/users/42	/api/users/42	{"params":{"id":"42"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 08:30:20.100483+00
1024	1	DELETE /api/users/42	/api/users/42	{"params":{"id":"42"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:20.114188+00
1025	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:21.937775+00
1026	1	POST /api/users/43/roles	/api/users/43/roles	{"params":{"id":"43"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:30:21.955377+00
1027	1	DELETE /api/users/43	/api/users/43	{"params":{"id":"43"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:21.964287+00
1028	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:23.765174+00
1029	1	POST /api/users/44/roles	/api/users/44/roles	{"params":{"id":"44"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:30:23.779254+00
1030	1	DELETE /api/users/44/roles/GIANG_VIEN/5	/api/users/44/roles/GIANG_VIEN/5	{"params":{"userId":"44","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:23.790312+00
1031	1	DELETE /api/users/44	/api/users/44	{"params":{"id":"44"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:23.799662+00
1032	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:27.415779+00
1033	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:30.54248+00
1034	1	DELETE /api/users/47	/api/users/47	{"params":{"id":"47"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:30.63279+00
1035	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:32.469369+00
1036	1	DELETE /api/users/49	/api/users/49	{"params":{"id":"49"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:32.48087+00
1037	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:34.336153+00
1038	1	PUT /api/users/50/toggle-active	/api/users/50/toggle-active	{"params":{"id":"50"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:34.344176+00
1039	1	DELETE /api/users/50	/api/users/50	{"params":{"id":"50"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:34.35394+00
1040	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:30:36.147506+00
1041	1	DELETE /api/users/51	/api/users/51	{"params":{"id":"51"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:36.158281+00
1042	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:30:46.021805+00
1043	1	DELETE /api/roles/457	/api/roles/457	{"params":{"id":"457"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:46.028287+00
1044	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:30:55.856353+00
1045	1	DELETE /api/roles/459	/api/roles/459	{"params":{"id":"459"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:30:55.881496+00
1046	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:31:01.092237+00
1047	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:31:06.154976+00
1048	1	DELETE /api/roles/461	/api/roles/461	{"params":{"id":"461"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:31:06.161412+00
1049	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:31:07.928736+00
1050	1	PUT /api/roles/462	/api/roles/462	{"params":{"id":"462"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:31:07.933555+00
1052	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 08:31:14.843762+00
1053	1	DELETE /api/departments/1623	/api/departments/1623	{"params":{"id":"1623"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:31:14.851338+00
1346	1	POST /api/versions/174/objectives	/api/versions/174/objectives	{"params":{"vId":"174"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:04.471893+00
1500	1	DELETE /api/versions/202	/api/versions/202	{"params":{"id":"202"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:18.295349+00
1503	1	POST /api/versions/203/courses	/api/versions/203/courses	{"params":{"vId":"203"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:47:18.306191+00
1504	1	DELETE /api/version-courses/868	/api/version-courses/868	{"params":{"id":"868"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:18.312642+00
1509	1	DELETE /api/versions/204	/api/versions/204	{"params":{"id":"204"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:22.245078+00
1510	1	DELETE /api/programs/244	/api/programs/244	{"params":{"id":"244"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:22.250148+00
1513	1	POST /api/versions/205/objectives	/api/versions/205/objectives	{"params":{"vId":"205"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:47:25.378128+00
1514	1	DELETE /api/objectives/108	/api/objectives/108	{"params":{"id":"108"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:47:25.389895+00
1675	1	POST /api/versions/230/knowledge-blocks	/api/versions/230/knowledge-blocks	{"params":{"vId":"230"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:50:21.811715+00
1686	1	POST /api/versions/231/courses	/api/versions/231/courses	{"params":{"vId":"231"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:50:29.741711+00
1687	1	DELETE /api/version-courses/872	/api/version-courses/872	{"params":{"id":"872"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:29.747449+00
1781	1	DELETE /api/versions/253	/api/versions/253	{"params":{"id":"253"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:56:07.087962+00
1782	1	DELETE /api/programs/293	/api/programs/293	{"params":{"id":"293"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:56:07.093318+00
1913	1	POST /api/versions/270/objectives	/api/versions/270/objectives	{"params":{"vId":"270"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:21:28.986525+00
1914	1	POST /api/versions/270/objectives	/api/versions/270/objectives	{"params":{"vId":"270"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:21:29.002113+00
1915	1	DELETE /api/objectives/123	/api/objectives/123	{"params":{"id":"123"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:29.01189+00
1916	1	DELETE /api/objectives/122	/api/objectives/122	{"params":{"id":"122"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:29.020154+00
2051	1	DELETE /api/versions/285	/api/versions/285	{"params":{"id":"285"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:25:18.588323+00
2052	1	DELETE /api/programs/335	/api/programs/335	{"params":{"id":"335"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:25:18.593425+00
2239	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:36:04.771759+00
2240	1	DELETE /api/roles/542	/api/roles/542	{"params":{"id":"542"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:04.777019+00
2379	1	DELETE /api/courses/658	/api/courses/658	{"params":{"id":"658"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:25.593477+00
2414	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:10.090036+00
2415	1	POST /api/users/109/roles	/api/users/109/roles	{"params":{"id":"109"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:48:10.115507+00
2416	1	DELETE /api/users/109	/api/users/109	{"params":{"id":"109"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:10.125434+00
2435	1	DELETE /api/roles/552	/api/roles/552	{"params":{"id":"552"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:45.149532+00
2436	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:48:50.728257+00
2439	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:48:56.75294+00
2440	1	PUT /api/roles/555	/api/roles/555	{"params":{"id":"555"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:48:56.75765+00
2441	1	DELETE /api/roles/555	/api/roles/555	{"params":{"id":"555"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:56.761722+00
2453	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:49:26.748821+00
2454	1	POST /api/programs/372/versions	/api/programs/372/versions	{"params":{"programId":"372"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:49:26.75419+00
2455	1	DELETE /api/versions/306	/api/versions/306	{"params":{"id":"306"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:26.758798+00
2456	1	DELETE /api/programs/372	/api/programs/372	{"params":{"id":"372"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:26.762493+00
2486	1	PUT /api/versions/309	/api/versions/309	{"params":{"id":"309"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:50:18.289105+00
2499	1	DELETE /api/objectives/149	/api/objectives/149	{"params":{"id":"149"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:24.804095+00
2507	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:27.751643+00
2508	1	DELETE /api/plos/197	/api/plos/197	{"params":{"id":"197"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:27.762024+00
2543	1	POST /api/versions/309/knowledge-blocks	/api/versions/309/knowledge-blocks	{"params":{"vId":"309"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:50:38.002568+00
2544	1	POST /api/versions/309/knowledge-blocks	/api/versions/309/knowledge-blocks	{"params":{"vId":"309"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:50:38.012852+00
2545	1	POST /api/versions/309/knowledge-blocks	/api/versions/309/knowledge-blocks	{"params":{"vId":"309"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:50:38.018194+00
2546	1	DELETE /api/knowledge-blocks/1639	/api/knowledge-blocks/1639	{"params":{"id":"1639"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:38.02633+00
2554	1	POST /api/versions/309/courses	/api/versions/309/courses	{"params":{"vId":"309"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:50:41.315921+00
2555	1	PUT /api/version-courses/900	/api/version-courses/900	{"params":{"id":"900"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 09:50:41.321662+00
2556	1	DELETE /api/version-courses/900	/api/version-courses/900	{"params":{"id":"900"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:41.327299+00
2559	1	PUT /api/versions/309/course-pi-map	/api/versions/309/course-pi-map	{"params":{"vId":"309"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 09:50:45.186103+00
2634	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 09:52:34.238128+00
2635	1	DELETE /api/departments/1908	/api/departments/1908	{"params":{"id":"1908"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:34.249419+00
2660	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:55:59.517569+00
2661	1	DELETE /api/programs/390	/api/programs/390	{"params":{"id":"390"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:55:59.705267+00
1054	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:31:16.197285+00
1055	1	DELETE /api/departments/1625	/api/departments/1625	{"params":{"id":"1625"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:31:16.210924+00
1056	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:31:17.69932+00
1057	1	DELETE /api/departments/1627	/api/departments/1627	{"params":{"id":"1627"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:31:17.707988+00
1058	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:32:20.432449+00
1059	1	POST /api/programs/151/versions	/api/programs/151/versions	{"params":{"programId":"151"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:32:20.441828+00
1060	1	DELETE /api/versions/136	/api/versions/136	{"params":{"id":"136"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:20.457907+00
1061	1	DELETE /api/programs/151	/api/programs/151	{"params":{"id":"151"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:20.461769+00
1062	1	PUT /api/versions/29	/api/versions/29	{"params":{"id":"29"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:32:23.832214+00
1063	1	POST /api/versions/29/objectives	/api/versions/29/objectives	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:23.842596+00
1064	1	POST /api/versions/29/plos	/api/versions/29/plos	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:23.853101+00
1065	1	PUT /api/versions/29	/api/versions/29	{"params":{"id":"29"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:32:31.269619+00
1066	1	DELETE /api/objectives/95	/api/objectives/95	{"params":{"id":"95"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:31.279363+00
1067	1	DELETE /api/plos/149	/api/plos/149	{"params":{"id":"149"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:31.295147+00
1068	1	POST /api/versions/29/plos	/api/versions/29/plos	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:31.305712+00
1069	1	POST /api/plos/150/pis	/api/plos/150/pis	{"params":{"ploId":"150"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 08:32:31.347011+00
1070	1	DELETE /api/plos/150	/api/plos/150	{"params":{"id":"150"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:31.357124+00
1071	1	POST /api/versions/29/plos	/api/versions/29/plos	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:36.818211+00
1072	1	DELETE /api/plos/151	/api/plos/151	{"params":{"id":"151"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:36.843089+00
1073	1	POST /api/versions/29/objectives	/api/versions/29/objectives	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:44.729391+00
1074	1	POST /api/versions/29/objectives	/api/versions/29/objectives	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:44.744586+00
1075	1	DELETE /api/objectives/96	/api/objectives/96	{"params":{"id":"96"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:44.754249+00
1076	1	POST /api/versions/29/plos	/api/versions/29/plos	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:49.058273+00
1077	1	POST /api/versions/29/plos	/api/versions/29/plos	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:32:49.074787+00
1078	1	DELETE /api/plos/152	/api/plos/152	{"params":{"id":"152"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:49.084342+00
1079	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:32:54.740374+00
1080	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:32:54.752143+00
1081	1	DELETE /api/programs/152	/api/programs/152	{"params":{"id":"152"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:32:54.782747+00
1082	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:33:01.283702+00
1083	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:33:05.839244+00
1084	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:33:05.915507+00
1085	1	POST /api/users/55/roles	/api/users/55/roles	{"params":{"id":"55"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:33:12.432836+00
1086	1	PUT /api/versions/29/po-plo-map	/api/versions/29/po-plo-map	{"params":{"vId":"29"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 08:33:12.456052+00
1087	1	DELETE /api/users/54	/api/users/54	{"params":{"id":"54"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:33:12.477034+00
1088	1	DELETE /api/users/55	/api/users/55	{"params":{"id":"55"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:33:12.487006+00
1089	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:33:23.028171+00
1090	1	POST /api/users/56/roles	/api/users/56/roles	{"params":{"id":"56"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:33:23.044317+00
1091	1	DELETE /api/users/56	/api/users/56	{"params":{"id":"56"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:33:23.054092+00
1092	1	DELETE /api/departments/1521	/api/departments/1521	{"params":{"id":"1521"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:34:39.178448+00
1093	1	DELETE /api/roles/416	/api/roles/416	{"params":{"id":"416"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:34:43.218196+00
1094	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:34:52.206718+00
1095	1	POST /api/users/57/roles	/api/users/57/roles	{"params":{"id":"57"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:34:52.220478+00
1096	1	DELETE /api/users/57	/api/users/57	{"params":{"id":"57"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:34:52.232868+00
1097	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:35:11.497877+00
1098	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:35:11.759121+00
1099	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:35:14.54892+00
1100	1	POST /api/programs/156/versions	/api/programs/156/versions	{"params":{"programId":"156"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:35:14.557929+00
1101	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:35:21.317622+00
1102	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 08:35:24.53336+00
1103	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 08:35:27.923527+00
1104	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 08:35:29.974087+00
1105	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:36:27.696082+00
1106	1	POST /api/programs/157/versions	/api/programs/157/versions	{"params":{"programId":"157"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:36:27.705728+00
1107	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:36:38.000974+00
1108	1	POST /api/programs/158/versions	/api/programs/158/versions	{"params":{"programId":"158"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:36:38.029505+00
1109	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:37:23.400649+00
1110	1	POST /api/programs/159/versions	/api/programs/159/versions	{"params":{"programId":"159"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:37:23.433476+00
1111	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:38:14.439526+00
1112	1	DELETE /api/programs/160	/api/programs/160	{"params":{"id":"160"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:14.628158+00
1113	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:16.268811+00
1114	1	PUT /api/programs/161	/api/programs/161	{"params":{"id":"161"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:38:17.613704+00
1115	1	DELETE /api/programs/161	/api/programs/161	{"params":{"id":"161"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:17.645319+00
1116	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:19.134762+00
1117	1	DELETE /api/programs/162	/api/programs/162	{"params":{"id":"162"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:19.14933+00
1118	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:20.593351+00
1119	1	POST /api/programs/163/archive	/api/programs/163/archive	{"params":{"id":"163"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:20.601686+00
1120	1	POST /api/programs/163/unarchive	/api/programs/163/unarchive	{"params":{"id":"163"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:21.698653+00
1121	1	DELETE /api/programs/163	/api/programs/163	{"params":{"id":"163"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:21.706603+00
1122	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:23.309749+00
1123	1	POST /api/programs/164/versions	/api/programs/164/versions	{"params":{"programId":"164"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:23.326774+00
1124	1	DELETE /api/versions/141	/api/versions/141	{"params":{"id":"141"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:23.341792+00
1125	1	DELETE /api/programs/164	/api/programs/164	{"params":{"id":"164"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:23.3481+00
1126	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:27.914829+00
1127	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 08:38:28.147808+00
1128	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:32.253205+00
1129	1	POST /api/programs/167/versions	/api/programs/167/versions	{"params":{"programId":"167"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:32.261158+00
1130	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:37.613091+00
1131	1	POST /api/programs/168/archive	/api/programs/168/archive	{"params":{"id":"168"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:37.617637+00
1132	1	POST /api/programs/168/unarchive	/api/programs/168/unarchive	{"params":{"id":"168"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:37.631105+00
1133	1	DELETE /api/programs/168	/api/programs/168	{"params":{"id":"168"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:37.640592+00
1134	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:38.550568+00
1135	1	POST /api/programs/169/versions	/api/programs/169/versions	{"params":{"programId":"169"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:38.564054+00
1136	1	PUT /api/versions/143	/api/versions/143	{"params":{"id":"143"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:38:42.436567+00
1137	1	PUT /api/versions/143	/api/versions/143	{"params":{"id":"143"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:43.276668+00
1138	1	DELETE /api/versions/143	/api/versions/143	{"params":{"id":"143"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:44.210254+00
1139	1	DELETE /api/programs/169	/api/programs/169	{"params":{"id":"169"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:44.215428+00
1140	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:46.196797+00
1141	1	POST /api/programs/170/versions	/api/programs/170/versions	{"params":{"programId":"170"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:46.2053+00
1142	1	PUT /api/versions/144	/api/versions/144	{"params":{"id":"144"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:38:47.153162+00
1143	1	DELETE /api/versions/144	/api/versions/144	{"params":{"id":"144"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:49.713431+00
1144	1	DELETE /api/programs/170	/api/programs/170	{"params":{"id":"170"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:49.717822+00
1145	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:51.723145+00
1146	1	POST /api/programs/171/versions	/api/programs/171/versions	{"params":{"programId":"171"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:51.732212+00
1147	1	DELETE /api/versions/145	/api/versions/145	{"params":{"id":"145"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:53.247927+00
1148	1	DELETE /api/programs/171	/api/programs/171	{"params":{"id":"171"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:53.25306+00
1149	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:38:55.402144+00
1150	1	POST /api/programs/172/versions	/api/programs/172/versions	{"params":{"programId":"172"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:38:55.410477+00
1151	1	POST /api/versions/146/objectives	/api/versions/146/objectives	{"params":{"vId":"146"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:38:56.329071+00
1152	1	DELETE /api/objectives/98	/api/objectives/98	{"params":{"id":"98"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:56.339688+00
1153	1	POST /api/versions/146/objectives	/api/versions/146/objectives	{"params":{"vId":"146"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:38:57.376613+00
1154	1	DELETE /api/versions/146	/api/versions/146	{"params":{"id":"146"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:58.210148+00
1155	1	DELETE /api/programs/172	/api/programs/172	{"params":{"id":"172"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:38:58.217137+00
1156	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:00.480351+00
1157	1	POST /api/programs/173/versions	/api/programs/173/versions	{"params":{"programId":"173"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:00.491584+00
1347	1	DELETE /api/versions/174	/api/versions/174	{"params":{"id":"174"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:05.418702+00
1348	1	DELETE /api/programs/207	/api/programs/207	{"params":{"id":"207"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:05.425264+00
1526	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:47:52.676607+00
1692	1	POST /api/versions/232/courses	/api/versions/232/courses	{"params":{"vId":"232"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:50:33.824154+00
1693	1	PUT /api/version-courses/874	/api/version-courses/874	{"params":{"id":"874"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 08:50:33.828799+00
1694	1	DELETE /api/version-courses/874	/api/version-courses/874	{"params":{"id":"874"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:50:33.834629+00
1697	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:50:38.608224+00
1698	1	POST /api/programs/273/versions	/api/programs/273/versions	{"params":{"programId":"273"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:50:38.617387+00
1783	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:56:28.787454+00
1784	1	POST /api/programs/294/versions	/api/programs/294/versions	{"params":{"programId":"294"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:56:28.794127+00
1919	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:33.296155+00
1920	1	POST /api/programs/320/versions	/api/programs/320/versions	{"params":{"programId":"320"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:33.304523+00
2053	1	POST /api/versions/29/objectives	/api/versions/29/objectives	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:25:50.804592+00
2054	1	DELETE /api/objectives/125	/api/objectives/125	{"params":{"id":"125"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:25:58.621366+00
2055	1	POST /api/versions/29/plos	/api/versions/29/plos	{"params":{"vId":"29"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:25:58.633138+00
2056	1	POST /api/plos/169/pis	/api/plos/169/pis	{"params":{"ploId":"169"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:26:05.146369+00
2057	1	PUT /api/versions/29/po-plo-map	/api/versions/29/po-plo-map	{"params":{"vId":"29"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:26:13.70989+00
2058	1	DELETE /api/pis/305	/api/pis/305	{"params":{"id":"305"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:26:13.732517+00
2059	1	DELETE /api/plos/169	/api/plos/169	{"params":{"id":"169"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:26:13.745348+00
2241	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:36:06.539441+00
2242	1	PUT /api/roles/543	/api/roles/543	{"params":{"id":"543"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:36:06.544339+00
2243	1	DELETE /api/roles/543	/api/roles/543	{"params":{"id":"543"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:06.550459+00
2385	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:47:34.661424+00
2386	1	DELETE /api/courses/662	/api/courses/662	{"params":{"id":"662"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:34.669822+00
2417	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:12.103269+00
2418	1	POST /api/users/110/roles	/api/users/110/roles	{"params":{"id":"110"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:48:12.117958+00
2419	1	DELETE /api/users/110/roles/GIANG_VIEN/5	/api/users/110/roles/GIANG_VIEN/5	{"params":{"userId":"110","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:12.127774+00
2420	1	DELETE /api/users/110	/api/users/110	{"params":{"id":"110"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:12.136489+00
2444	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:49:00.878734+00
2445	1	PUT /api/departments/1878	/api/departments/1878	{"params":{"id":"1878"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:49:00.883566+00
2446	1	DELETE /api/departments/1878	/api/departments/1878	{"params":{"id":"1878"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:49:00.888313+00
2487	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:20.155646+00
2488	1	DELETE /api/objectives/145	/api/objectives/145	{"params":{"id":"145"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:21.760987+00
2500	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:25.488338+00
2501	1	DELETE /api/plos/194	/api/plos/194	{"params":{"id":"194"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:25.501822+00
2509	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:28.729696+00
2510	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:28.742534+00
2511	1	DELETE /api/plos/199	/api/plos/199	{"params":{"id":"199"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:28.75735+00
2512	1	DELETE /api/plos/198	/api/plos/198	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:28.771829+00
2528	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:33.183479+00
2529	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:33.188528+00
2530	1	PUT /api/versions/309/po-plo-map	/api/versions/309/po-plo-map	{"params":{"vId":"309"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:50:33.197105+00
2531	1	DELETE /api/objectives/151	/api/objectives/151	{"params":{"id":"151"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:33.209803+00
2532	1	DELETE /api/plos/204	/api/plos/204	{"params":{"id":"204"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:33.217817+00
2551	1	POST /api/versions/309/courses	/api/versions/309/courses	{"params":{"vId":"309"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:50:40.518091+00
2552	1	POST /api/versions/309/courses	/api/versions/309/courses	{"params":{"vId":"309"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:50:40.52216+00
2553	1	DELETE /api/version-courses/898	/api/version-courses/898	{"params":{"id":"898"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:40.527332+00
2557	1	PUT /api/versions/309/course-plo-map	/api/versions/309/course-plo-map	{"params":{"vId":"309"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:50:42.840942+00
2636	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:52:35.87335+00
2662	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:01.252437+00
1158	1	POST /api/versions/147/objectives	/api/versions/147/objectives	{"params":{"vId":"147"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:39:01.350383+00
1159	1	POST /api/versions/147/objectives	/api/versions/147/objectives	{"params":{"vId":"147"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:39:01.360127+00
1160	1	DELETE /api/versions/147	/api/versions/147	{"params":{"id":"147"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:02.119829+00
1161	1	DELETE /api/programs/173	/api/programs/173	{"params":{"id":"173"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:02.124365+00
1162	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:04.332661+00
1163	1	POST /api/programs/174/versions	/api/programs/174/versions	{"params":{"programId":"174"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:04.34082+00
1164	1	DELETE /api/versions/148	/api/versions/148	{"params":{"id":"148"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:05.966931+00
1165	1	DELETE /api/programs/174	/api/programs/174	{"params":{"id":"174"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:05.972784+00
1166	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:08.167842+00
1167	1	POST /api/programs/175/versions	/api/programs/175/versions	{"params":{"programId":"175"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:08.174952+00
1168	1	DELETE /api/versions/149	/api/versions/149	{"params":{"id":"149"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:09.881849+00
1169	1	DELETE /api/programs/175	/api/programs/175	{"params":{"id":"175"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:09.887119+00
1170	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:12.071109+00
1171	1	POST /api/programs/176/versions	/api/programs/176/versions	{"params":{"programId":"176"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:12.080019+00
1172	1	DELETE /api/versions/150	/api/versions/150	{"params":{"id":"150"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:13.738575+00
1173	1	DELETE /api/programs/176	/api/programs/176	{"params":{"id":"176"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:13.743097+00
1174	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:15.858952+00
1175	1	POST /api/programs/177/versions	/api/programs/177/versions	{"params":{"programId":"177"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:15.868415+00
1176	1	POST /api/versions/151/plos	/api/versions/151/plos	{"params":{"vId":"151"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:39:16.740864+00
1177	1	DELETE /api/versions/151	/api/versions/151	{"params":{"id":"151"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:17.610166+00
1178	1	DELETE /api/programs/177	/api/programs/177	{"params":{"id":"177"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:17.617142+00
1179	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:19.647403+00
1180	1	POST /api/programs/178/versions	/api/programs/178/versions	{"params":{"programId":"178"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:19.655693+00
1181	1	POST /api/versions/152/plos	/api/versions/152/plos	{"params":{"vId":"152"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:39:21.461557+00
1182	1	DELETE /api/versions/152	/api/versions/152	{"params":{"id":"152"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:22.355075+00
1183	1	DELETE /api/programs/178	/api/programs/178	{"params":{"id":"178"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:22.360578+00
1184	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:24.433353+00
1185	1	POST /api/programs/179/versions	/api/programs/179/versions	{"params":{"programId":"179"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:24.441006+00
1186	1	DELETE /api/versions/153	/api/versions/153	{"params":{"id":"153"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:26.20076+00
1187	1	DELETE /api/programs/179	/api/programs/179	{"params":{"id":"179"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:26.20429+00
1188	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:28.302223+00
1189	1	POST /api/programs/180/versions	/api/programs/180/versions	{"params":{"programId":"180"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:28.311051+00
1190	1	DELETE /api/versions/154	/api/versions/154	{"params":{"id":"154"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:30.034255+00
1191	1	DELETE /api/programs/180	/api/programs/180	{"params":{"id":"180"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:30.037714+00
1192	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:32.213714+00
1193	1	POST /api/programs/181/versions	/api/programs/181/versions	{"params":{"programId":"181"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:32.224146+00
1194	1	POST /api/versions/155/objectives	/api/versions/155/objectives	{"params":{"vId":"155"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:39:34.030578+00
1195	1	DELETE /api/versions/155	/api/versions/155	{"params":{"id":"155"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:35.013381+00
1196	1	DELETE /api/programs/181	/api/programs/181	{"params":{"id":"181"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:35.0194+00
1197	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:37.179674+00
1198	1	POST /api/programs/182/versions	/api/programs/182/versions	{"params":{"programId":"182"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:37.187289+00
1199	1	DELETE /api/versions/156	/api/versions/156	{"params":{"id":"156"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:38.891681+00
1200	1	DELETE /api/programs/182	/api/programs/182	{"params":{"id":"182"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:38.896628+00
1201	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:41.045363+00
1202	1	POST /api/programs/183/versions	/api/programs/183/versions	{"params":{"programId":"183"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:41.053766+00
1203	1	DELETE /api/versions/157	/api/versions/157	{"params":{"id":"157"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:42.979196+00
1204	1	DELETE /api/programs/183	/api/programs/183	{"params":{"id":"183"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:42.985065+00
1205	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:45.018797+00
1206	1	POST /api/programs/184/versions	/api/programs/184/versions	{"params":{"programId":"184"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:45.027692+00
1207	1	POST /api/versions/158/knowledge-blocks	/api/versions/158/knowledge-blocks	{"params":{"vId":"158"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:39:46.009073+00
1208	1	POST /api/versions/158/knowledge-blocks	/api/versions/158/knowledge-blocks	{"params":{"vId":"158"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:39:46.863741+00
1209	1	POST /api/versions/158/knowledge-blocks	/api/versions/158/knowledge-blocks	{"params":{"vId":"158"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 08:39:48.546876+00
1221	1	DELETE /api/versions/159	/api/versions/159	{"params":{"id":"159"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:55.317894+00
1222	1	DELETE /api/programs/185	/api/programs/185	{"params":{"id":"185"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:55.321075+00
1232	1	DELETE /api/versions/161	/api/versions/161	{"params":{"id":"161"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:05.05612+00
1233	1	DELETE /api/programs/187	/api/programs/187	{"params":{"id":"187"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:05.060443+00
1236	1	DELETE /api/versions/162	/api/versions/162	{"params":{"id":"162"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:09.715504+00
1237	1	DELETE /api/programs/188	/api/programs/188	{"params":{"id":"188"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:09.71971+00
1240	1	DELETE /api/versions/163	/api/versions/163	{"params":{"id":"163"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:14.427628+00
1241	1	DELETE /api/programs/189	/api/programs/189	{"params":{"id":"189"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:14.432068+00
1351	1	POST /api/versions/175/objectives	/api/versions/175/objectives	{"params":{"vId":"175"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:08.490599+00
1352	1	POST /api/versions/175/objectives	/api/versions/175/objectives	{"params":{"vId":"175"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:08.50279+00
1528	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:47:56.293916+00
1529	1	POST /api/programs/248/versions	/api/programs/248/versions	{"params":{"programId":"248"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:47:56.303248+00
1530	1	PUT /api/versions/208	/api/versions/208	{"params":{"id":"208"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:48:00.285273+00
1705	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:51:12.870998+00
1706	1	POST /api/programs/275/versions	/api/programs/275/versions	{"params":{"programId":"275"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:51:12.879706+00
1785	1	DELETE /api/versions/254	/api/versions/254	{"params":{"id":"254"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:56:32.054854+00
1786	1	DELETE /api/programs/294	/api/programs/294	{"params":{"id":"294"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:56:32.059262+00
1921	1	DELETE /api/versions/271	/api/versions/271	{"params":{"id":"271"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:35.383622+00
1922	1	DELETE /api/programs/320	/api/programs/320	{"params":{"id":"320"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:35.389388+00
2060	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:26:38.59451+00
2061	1	POST /api/programs/336/versions	/api/programs/336/versions	{"params":{"programId":"336"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:26:38.603765+00
2244	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 09:36:13.952678+00
2245	1	DELETE /api/departments/1847	/api/departments/1847	{"params":{"id":"1847"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:13.95898+00
2248	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:36:16.988038+00
2249	1	DELETE /api/departments/1851	/api/departments/1851	{"params":{"id":"1851"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:16.992668+00
2391	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:47:53.989543+00
2392	1	DELETE /api/programs/368	/api/programs/368	{"params":{"id":"368"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:54.003649+00
2399	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:47:58.476618+00
2400	1	POST /api/programs/370/versions	/api/programs/370/versions	{"params":{"programId":"370"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:47:58.483941+00
2401	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:47:58.489748+00
2402	1	DELETE /api/programs/370	/api/programs/370	{"params":{"id":"370"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:58.510764+00
2492	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:23.253033+00
2493	1	DELETE /api/objectives/147	/api/objectives/147	{"params":{"id":"147"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:23.263944+00
2505	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:27.002548+00
2506	1	DELETE /api/plos/196	/api/plos/196	{"params":{"id":"196"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:27.01478+00
2522	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:31.49756+00
2523	1	POST /api/plos/202/pis	/api/plos/202/pis	{"params":{"ploId":"202"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:50:31.522602+00
2524	1	DELETE /api/pis/316	/api/pis/316	{"params":{"id":"316"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:31.53174+00
2525	1	DELETE /api/plos/202	/api/plos/202	{"params":{"id":"202"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:31.539615+00
2534	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:34.807286+00
2535	1	POST /api/versions/309/objectives	/api/versions/309/objectives	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:34.812725+00
2536	1	POST /api/versions/309/plos	/api/versions/309/plos	{"params":{"vId":"309"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:50:34.817253+00
2537	1	PUT /api/versions/309/po-plo-map	/api/versions/309/po-plo-map	{"params":{"vId":"309"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:50:34.836355+00
2538	1	DELETE /api/objectives/152	/api/objectives/152	{"params":{"id":"152"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:34.848903+00
2539	1	DELETE /api/objectives/153	/api/objectives/153	{"params":{"id":"153"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:34.85282+00
2540	1	DELETE /api/plos/205	/api/plos/205	{"params":{"id":"205"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:34.857033+00
2547	1	POST /api/versions/309/courses	/api/versions/309/courses	{"params":{"vId":"309"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:50:38.855814+00
2548	1	DELETE /api/version-courses/896	/api/version-courses/896	{"params":{"id":"896"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:38.862743+00
2558	1	PUT /api/versions/309/course-plo-map	/api/versions/309/course-plo-map	{"params":{"vId":"309"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:50:43.620757+00
2563	1	DELETE /api/versions/309	/api/versions/309	{"params":{"id":"309"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:53.41151+00
2564	1	DELETE /api/programs/382	/api/programs/382	{"params":{"id":"382"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:53.423501+00
1210	1	DELETE /api/versions/158	/api/versions/158	{"params":{"id":"158"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:49.505659+00
1211	1	DELETE /api/programs/184	/api/programs/184	{"params":{"id":"184"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:49.512334+00
1218	1	POST /api/versions/159/courses	/api/versions/159/courses	{"params":{"vId":"159"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:39:54.354716+00
1219	1	POST /api/versions/159/courses	/api/versions/159/courses	{"params":{"vId":"159"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:39:54.359014+00
1220	1	DELETE /api/version-courses/860	/api/version-courses/860	{"params":{"id":"860"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:54.36368+00
1238	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:40:11.832694+00
1239	1	POST /api/programs/189/versions	/api/programs/189/versions	{"params":{"programId":"189"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:40:11.840296+00
1353	1	DELETE /api/versions/175	/api/versions/175	{"params":{"id":"175"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:09.2597+00
1354	1	DELETE /api/programs/208	/api/programs/208	{"params":{"id":"208"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:09.267875+00
1357	1	DELETE /api/versions/176	/api/versions/176	{"params":{"id":"176"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:13.014543+00
1358	1	DELETE /api/programs/209	/api/programs/209	{"params":{"id":"209"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:13.018514+00
1532	1	DELETE /api/versions/208	/api/versions/208	{"params":{"id":"208"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:02.180779+00
1533	1	DELETE /api/programs/248	/api/programs/248	{"params":{"id":"248"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:02.184901+00
1539	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:15.02783+00
1540	1	POST /api/programs/250/versions	/api/programs/250/versions	{"params":{"programId":"250"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:15.03543+00
1541	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:48:15.045607+00
1707	1	DELETE /api/versions/235	/api/versions/235	{"params":{"id":"235"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:15.623404+00
1708	1	DELETE /api/programs/275	/api/programs/275	{"params":{"id":"275"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:15.628974+00
1715	1	DELETE /api/versions/237	/api/versions/237	{"params":{"id":"237"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:29.270725+00
1716	1	DELETE /api/programs/277	/api/programs/277	{"params":{"id":"277"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:29.274334+00
1787	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:03:38.879802+00
1927	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:41.700653+00
1928	1	POST /api/programs/322/versions	/api/programs/322/versions	{"params":{"programId":"322"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:41.708723+00
1942	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:55.117711+00
1943	1	POST /api/programs/325/versions	/api/programs/325/versions	{"params":{"programId":"325"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:55.129878+00
2062	1	DELETE /api/versions/286	/api/versions/286	{"params":{"id":"286"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:26:40.565514+00
2063	1	DELETE /api/programs/336	/api/programs/336	{"params":{"id":"336"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:26:40.571211+00
2246	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:36:15.447564+00
2393	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:47:57.493205+00
2394	1	POST /api/programs/369/versions	/api/programs/369/versions	{"params":{"programId":"369"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:47:57.502263+00
2395	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:47:57.509106+00
2396	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:47:57.518566+00
2397	1	DELETE /api/approval/rejected/program_version/303	/api/approval/rejected/program_version/303	{"params":{"entityType":"program_version","entityId":"303"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:57.530051+00
2398	1	DELETE /api/programs/369	/api/programs/369	{"params":{"id":"369"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:47:57.535725+00
2403	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:48:01.169261+00
2404	1	POST /api/programs/371/versions	/api/programs/371/versions	{"params":{"programId":"371"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:48:01.177721+00
2405	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:48:01.182357+00
2406	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:48:01.195023+00
2407	1	DELETE /api/versions/305	/api/versions/305	{"params":{"id":"305"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:01.202884+00
2408	1	DELETE /api/programs/371	/api/programs/371	{"params":{"id":"371"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:01.207146+00
2409	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:06.036822+00
2410	1	DELETE /api/users/107	/api/users/107	{"params":{"id":"107"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:06.052135+00
2423	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:18.096575+00
2514	1	POST /api/plos/200/pis	/api/plos/200/pis	{"params":{"ploId":"200"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:50:29.654137+00
2515	1	DELETE /api/pis/314	/api/pis/314	{"params":{"id":"314"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:29.671156+00
2516	1	DELETE /api/plos/200	/api/plos/200	{"params":{"id":"200"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:50:29.679347+00
2533	1	PUT /api/versions/309/po-plo-map	/api/versions/309/po-plo-map	{"params":{"vId":"309"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:50:33.969501+00
2565	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:51:00.423808+00
2566	1	DELETE /api/courses/664	/api/courses/664	{"params":{"id":"664"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:01.549644+00
2637	1	DELETE /api/departments/1910	/api/departments/1910	{"params":{"id":"1910"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:35.883783+00
2663	1	PUT /api/programs/391	/api/programs/391	{"params":{"id":"391"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:56:02.558849+00
2664	1	DELETE /api/programs/391	/api/programs/391	{"params":{"id":"391"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:02.635164+00
1212	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:51.567816+00
1213	1	POST /api/programs/185/versions	/api/programs/185/versions	{"params":{"programId":"185"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:51.576422+00
1234	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:40:07.129254+00
1235	1	POST /api/programs/188/versions	/api/programs/188/versions	{"params":{"programId":"188"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:40:07.137603+00
1359	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:15.078959+00
1360	1	POST /api/programs/210/versions	/api/programs/210/versions	{"params":{"programId":"210"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:15.089207+00
1361	1	DELETE /api/versions/177	/api/versions/177	{"params":{"id":"177"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:16.682435+00
1362	1	DELETE /api/programs/210	/api/programs/210	{"params":{"id":"210"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:16.686232+00
1370	1	DELETE /api/versions/179	/api/versions/179	{"params":{"id":"179"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:24.540912+00
1371	1	DELETE /api/programs/212	/api/programs/212	{"params":{"id":"212"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:24.544959+00
1377	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:32.043097+00
1378	1	POST /api/programs/214/versions	/api/programs/214/versions	{"params":{"programId":"214"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:32.050469+00
1534	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:04.422389+00
1535	1	POST /api/programs/249/versions	/api/programs/249/versions	{"params":{"programId":"249"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:04.432139+00
1543	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:18.510882+00
1544	1	POST /api/programs/251/versions	/api/programs/251/versions	{"params":{"programId":"251"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:18.51965+00
1545	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:48:18.526779+00
1546	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:48:18.536211+00
1547	1	DELETE /api/approval/rejected/program_version/211	/api/approval/rejected/program_version/211	{"params":{"entityType":"program_version","entityId":"211"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:18.545924+00
1548	1	DELETE /api/programs/251	/api/programs/251	{"params":{"id":"251"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:18.552466+00
1549	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:19.008183+00
1550	1	POST /api/programs/252/versions	/api/programs/252/versions	{"params":{"programId":"252"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:19.02497+00
1551	1	POST /api/versions/212/objectives	/api/versions/212/objectives	{"params":{"vId":"212"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:48:19.055214+00
1552	1	DELETE /api/objectives/110	/api/objectives/110	{"params":{"id":"110"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:19.08489+00
1553	1	DELETE /api/versions/212	/api/versions/212	{"params":{"id":"212"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:19.096599+00
1554	1	DELETE /api/programs/252	/api/programs/252	{"params":{"id":"252"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:19.105508+00
1709	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:51:17.773384+00
1710	1	POST /api/programs/276/versions	/api/programs/276/versions	{"params":{"programId":"276"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:51:17.780634+00
1711	1	DELETE /api/versions/236	/api/versions/236	{"params":{"id":"236"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:20.361932+00
1712	1	DELETE /api/programs/276	/api/programs/276	{"params":{"id":"276"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:20.366871+00
1788	1	DELETE /api/users/83	/api/users/83	{"params":{"id":"83"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:03:46.992295+00
1789	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:03:47.005095+00
1929	1	POST /api/versions/273/plos	/api/versions/273/plos	{"params":{"vId":"273"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:21:42.750243+00
1930	1	DELETE /api/plos/167	/api/plos/167	{"params":{"id":"167"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:42.759584+00
1938	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:50.775072+00
1939	1	POST /api/programs/324/versions	/api/programs/324/versions	{"params":{"programId":"324"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:50.783046+00
2064	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:26:55.696323+00
2247	1	DELETE /api/departments/1849	/api/departments/1849	{"params":{"id":"1849"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:15.459432+00
2421	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:16.07175+00
2422	1	DELETE /api/users/112	/api/users/112	{"params":{"id":"112"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:16.078802+00
2427	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:22.070316+00
2428	1	PUT /api/users/116/toggle-active	/api/users/116/toggle-active	{"params":{"id":"116"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:22.080022+00
2429	1	DELETE /api/users/116	/api/users/116	{"params":{"id":"116"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:22.09453+00
2567	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:51:02.881958+00
2568	1	PUT /api/courses/665	/api/courses/665	{"params":{"id":"665"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:51:02.886148+00
2569	1	DELETE /api/courses/665	/api/courses/665	{"params":{"id":"665"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:02.890726+00
2586	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:51:33.044628+00
2587	1	POST /api/programs/385/versions	/api/programs/385/versions	{"params":{"programId":"385"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:51:33.051895+00
2588	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:51:33.056966+00
2589	1	DELETE /api/programs/385	/api/programs/385	{"params":{"id":"385"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:33.082589+00
2598	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:51:42.16692+00
1214	1	POST /api/versions/159/courses	/api/versions/159/courses	{"params":{"vId":"159"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:39:52.459911+00
1215	1	DELETE /api/version-courses/858	/api/version-courses/858	{"params":{"id":"858"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:52.468479+00
1225	1	POST /api/versions/160/courses	/api/versions/160/courses	{"params":{"vId":"160"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:39:58.377768+00
1226	1	PUT /api/version-courses/862	/api/version-courses/862	{"params":{"id":"862"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 08:39:58.38401+00
1227	1	DELETE /api/version-courses/862	/api/version-courses/862	{"params":{"id":"862"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:58.389098+00
1230	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:40:03.103469+00
1231	1	POST /api/programs/187/versions	/api/programs/187/versions	{"params":{"programId":"187"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:40:03.11358+00
1244	1	DELETE /api/versions/164	/api/versions/164	{"params":{"id":"164"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:23.195545+00
1245	1	DELETE /api/programs/190	/api/programs/190	{"params":{"id":"190"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:23.200441+00
1363	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:18.704194+00
1364	1	POST /api/programs/211/versions	/api/programs/211/versions	{"params":{"programId":"211"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:18.712977+00
1365	1	DELETE /api/versions/178	/api/versions/178	{"params":{"id":"178"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:20.316114+00
1366	1	DELETE /api/programs/211	/api/programs/211	{"params":{"id":"211"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:44:20.321318+00
1372	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:26.867292+00
1373	1	POST /api/programs/213/versions	/api/programs/213/versions	{"params":{"programId":"213"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:26.872984+00
1536	1	PUT /api/versions/209	/api/versions/209	{"params":{"id":"209"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:48:05.412721+00
1542	1	DELETE /api/programs/250	/api/programs/250	{"params":{"id":"250"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:15.062718+00
1559	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:22.247623+00
1560	1	POST /api/programs/254/versions	/api/programs/254/versions	{"params":{"programId":"254"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:22.255851+00
1561	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:48:22.263053+00
1562	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 08:48:22.272883+00
1563	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:48:28.498897+00
1564	1	DELETE /api/users/71	/api/users/71	{"params":{"id":"71"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:28.513988+00
1576	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:39.372887+00
1577	1	POST /api/programs/255/versions	/api/programs/255/versions	{"params":{"programId":"255"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:39.379477+00
1580	1	DELETE /api/versions/215	/api/versions/215	{"params":{"id":"215"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:44.940143+00
1581	1	DELETE /api/programs/255	/api/programs/255	{"params":{"id":"255"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:44.945091+00
1587	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:52.794726+00
1588	1	POST /api/programs/257/versions	/api/programs/257/versions	{"params":{"programId":"257"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:52.804405+00
1596	1	DELETE /api/versions/218	/api/versions/218	{"params":{"id":"218"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:59.473293+00
1597	1	DELETE /api/programs/258	/api/programs/258	{"params":{"id":"258"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:59.477262+00
1604	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:05.589013+00
1605	1	POST /api/programs/260/versions	/api/programs/260/versions	{"params":{"programId":"260"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:05.597228+00
1608	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:09.505133+00
1609	1	POST /api/programs/261/versions	/api/programs/261/versions	{"params":{"programId":"261"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:09.511643+00
1713	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:51:22.499539+00
1714	1	POST /api/programs/277/versions	/api/programs/277/versions	{"params":{"programId":"277"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:51:22.508189+00
1790	1	POST /api/programs/295/versions	/api/programs/295/versions	{"params":{"programId":"295"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:03:47.046281+00
1791	1	POST /api/versions/255/objectives	/api/versions/255/objectives	{"params":{"vId":"255"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:03:47.078482+00
1792	1	DELETE /api/versions/255	/api/versions/255	{"params":{"id":"255"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:03:47.091773+00
1793	1	DELETE /api/programs/295	/api/programs/295	{"params":{"id":"295"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:03:47.10057+00
1931	1	DELETE /api/versions/273	/api/versions/273	{"params":{"id":"273"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:44.644485+00
1932	1	DELETE /api/programs/322	/api/programs/322	{"params":{"id":"322"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:44.649848+00
1935	1	POST /api/versions/274/plos	/api/versions/274/plos	{"params":{"vId":"274"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:21:47.74602+00
1944	1	DELETE /api/versions/276	/api/versions/276	{"params":{"id":"276"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:57.00614+00
1945	1	DELETE /api/programs/325	/api/programs/325	{"params":{"id":"325"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:57.009775+00
2065	1	POST /api/programs/337/versions	/api/programs/337/versions	{"params":{"programId":"337"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:27:02.138671+00
2066	1	POST /api/versions/287/objectives	/api/versions/287/objectives	{"params":{"vId":"287"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:27:10.327778+00
2067	1	DELETE /api/versions/287	/api/versions/287	{"params":{"id":"287"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:27:10.35299+00
2068	1	DELETE /api/programs/337	/api/programs/337	{"params":{"id":"337"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:27:10.362976+00
2250	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:36:38.081601+00
1216	1	POST /api/versions/159/courses	/api/versions/159/courses	{"params":{"vId":"159"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:39:53.305414+00
1217	1	DELETE /api/version-courses/859	/api/version-courses/859	{"params":{"id":"859"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:39:53.31378+00
1242	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:40:16.599589+00
1243	1	POST /api/programs/190/versions	/api/programs/190/versions	{"params":{"programId":"190"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:40:16.607858+00
1247	1	DELETE /api/courses/646	/api/courses/646	{"params":{"id":"646"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:44.348433+00
1367	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:44:22.565542+00
1368	1	POST /api/programs/212/versions	/api/programs/212/versions	{"params":{"programId":"212"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:44:22.574344+00
1405	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:45:01.151466+00
1406	1	POST /api/programs/220/versions	/api/programs/220/versions	{"params":{"programId":"220"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:45:01.162221+00
1418	1	POST /api/versions/188/courses	/api/versions/188/courses	{"params":{"vId":"188"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 08:45:08.485968+00
1419	1	PUT /api/version-courses/867	/api/version-courses/867	{"params":{"id":"867"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 08:45:08.493604+00
1420	1	DELETE /api/version-courses/867	/api/version-courses/867	{"params":{"id":"867"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:45:08.499602+00
1423	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:45:13.740621+00
1424	1	POST /api/programs/222/versions	/api/programs/222/versions	{"params":{"programId":"222"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:45:13.748787+00
1537	1	DELETE /api/versions/209	/api/versions/209	{"params":{"id":"209"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:08.429252+00
1555	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:48:19.455341+00
1556	1	POST /api/programs/253/versions	/api/programs/253/versions	{"params":{"programId":"253"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:19.463351+00
1557	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 08:48:19.468369+00
1558	1	DELETE /api/programs/253	/api/programs/253	{"params":{"id":"253"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:19.487048+00
1568	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:48:32.464524+00
1569	1	POST /api/users/73/roles	/api/users/73/roles	{"params":{"id":"73"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 08:48:32.489401+00
1570	1	DELETE /api/users/73	/api/users/73	{"params":{"id":"73"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:32.49848+00
1579	1	PUT /api/versions/215	/api/versions/215	{"params":{"id":"215"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:48:44.072419+00
1598	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:49:01.575506+00
1599	1	POST /api/programs/259/versions	/api/programs/259/versions	{"params":{"programId":"259"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:49:01.582582+00
1717	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:51:41.612444+00
1718	1	POST /api/programs/278/versions	/api/programs/278/versions	{"params":{"programId":"278"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:51:41.62097+00
1723	1	DELETE /api/versions/239	/api/versions/239	{"params":{"id":"239"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:52.118737+00
1724	1	DELETE /api/programs/279	/api/programs/279	{"params":{"id":"279"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:52.122407+00
1794	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:03.451519+00
1933	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:21:46.837256+00
1934	1	POST /api/programs/323/versions	/api/programs/323/versions	{"params":{"programId":"323"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:21:46.845474+00
2069	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:27:53.643014+00
2070	1	POST /api/programs/338/versions	/api/programs/338/versions	{"params":{"programId":"338"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:27:53.651743+00
2251	1	POST /api/programs/355/versions	/api/programs/355/versions	{"params":{"programId":"355"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:36:38.088982+00
2252	1	DELETE /api/versions/298	/api/versions/298	{"params":{"id":"298"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:38.096809+00
2253	1	DELETE /api/programs/355	/api/programs/355	{"params":{"id":"355"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:38.108802+00
2425	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:20.107037+00
2426	1	DELETE /api/users/115	/api/users/115	{"params":{"id":"115"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:20.117867+00
2430	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:48:24.08579+00
2431	1	DELETE /api/users/117	/api/users/117	{"params":{"id":"117"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:48:24.09511+00
2570	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:51:08.771516+00
2638	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:52:37.435758+00
2639	1	DELETE /api/departments/1912	/api/departments/1912	{"params":{"id":"1912"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:37.444402+00
2665	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:04.149405+00
2666	1	DELETE /api/programs/392	/api/programs/392	{"params":{"id":"392"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:04.160168+00
2685	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:22.71834+00
2686	1	POST /api/programs/399/versions	/api/programs/399/versions	{"params":{"programId":"399"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:56:22.729929+00
2692	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:32.89756+00
2693	1	PUT /api/objectives/155	/api/objectives/155	{"params":{"id":"155"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:56:32.906114+00
2694	1	DELETE /api/objectives/155	/api/objectives/155	{"params":{"id":"155"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:32.914501+00
1223	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 08:39:57.381505+00
1224	1	POST /api/programs/186/versions	/api/programs/186/versions	{"params":{"programId":"186"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 08:39:57.38851+00
1228	1	DELETE /api/versions/160	/api/versions/160	{"params":{"id":"160"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:01.028686+00
1229	1	DELETE /api/programs/186	/api/programs/186	{"params":{"id":"186"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:40:01.033892+00
1246	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 08:40:44.307851+00
1369	1	POST /api/versions/179/plos	/api/versions/179/plos	{"params":{"vId":"179"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 08:44:23.584424+00
1538	1	DELETE /api/programs/249	/api/programs/249	{"params":{"id":"249"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:08.434432+00
1565	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 08:48:30.514787+00
1566	1	PUT /api/users/72	/api/users/72	{"params":{"id":"72"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 08:48:30.524985+00
1567	1	DELETE /api/users/72	/api/users/72	{"params":{"id":"72"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:48:30.53993+00
1578	1	PUT /api/versions/215	/api/versions/215	{"params":{"id":"215"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:48:43.160086+00
1584	1	PUT /api/versions/216	/api/versions/216	{"params":{"id":"216"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 08:48:47.944841+00
1719	1	DELETE /api/versions/238	/api/versions/238	{"params":{"id":"238"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:43.566969+00
1720	1	DELETE /api/programs/278	/api/programs/278	{"params":{"id":"278"},"bodyKeys":[]}	172.18.0.1	2026-04-04 08:51:43.572238+00
1795	1	POST /api/programs/296/versions	/api/programs/296/versions	{"params":{"programId":"296"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:03.493822+00
1796	1	PUT /api/versions/256	/api/versions/256	{"params":{"id":"256"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:03.524714+00
1797	1	DELETE /api/versions/256	/api/versions/256	{"params":{"id":"256"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:03.53828+00
1798	1	DELETE /api/programs/296	/api/programs/296	{"params":{"id":"296"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:03.55194+00
1799	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:03.562593+00
1800	1	POST /api/programs/297/versions	/api/programs/297/versions	{"params":{"programId":"297"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:03.594736+00
1801	1	POST /api/versions/257/objectives	/api/versions/257/objectives	{"params":{"vId":"257"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:04:03.627495+00
1802	1	POST /api/versions/257/objectives	/api/versions/257/objectives	{"params":{"vId":"257"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:04:03.637397+00
1803	1	DELETE /api/versions/257	/api/versions/257	{"params":{"id":"257"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:03.646634+00
1804	1	DELETE /api/programs/297	/api/programs/297	{"params":{"id":"297"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:03.655261+00
1805	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:03.668965+00
1806	1	POST /api/programs/298/versions	/api/programs/298/versions	{"params":{"programId":"298"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:04:03.699707+00
1807	1	POST /api/versions/258/courses	/api/versions/258/courses	{"params":{"vId":"258"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:04:03.756737+00
1808	1	POST /api/versions/258/courses	/api/versions/258/courses	{"params":{"vId":"258"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:04:03.767236+00
1809	1	DELETE /api/versions/258	/api/versions/258	{"params":{"id":"258"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:03.777438+00
1810	1	DELETE /api/programs/298	/api/programs/298	{"params":{"id":"298"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:04:03.791386+00
1811	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:04:13.492242+00
1940	1	DELETE /api/versions/275	/api/versions/275	{"params":{"id":"275"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:52.648328+00
1941	1	DELETE /api/programs/324	/api/programs/324	{"params":{"id":"324"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:21:52.653631+00
2071	1	DELETE /api/versions/288	/api/versions/288	{"params":{"id":"288"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:27:56.422569+00
2072	1	DELETE /api/programs/338	/api/programs/338	{"params":{"id":"338"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:27:56.427716+00
2254	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:36:55.693848+00
2255	1	DELETE /api/programs/356	/api/programs/356	{"params":{"id":"356"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:36:56.828112+00
2434	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:48:45.124728+00
2571	1	DELETE /api/courses/666	/api/courses/666	{"params":{"id":"666"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:51:08.814799+00
2631	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:52:33.382865+00
2632	1	PUT /api/departments/1907	/api/departments/1907	{"params":{"id":"1907"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:52:33.387381+00
2633	1	DELETE /api/departments/1907	/api/departments/1907	{"params":{"id":"1907"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:33.391844+00
2643	1	DELETE /api/programs/387	/api/programs/387	{"params":{"id":"387"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:52:57.99913+00
2667	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:56:05.585284+00
2668	1	POST /api/programs/393/archive	/api/programs/393/archive	{"params":{"id":"393"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:05.597124+00
2669	1	POST /api/programs/393/unarchive	/api/programs/393/unarchive	{"params":{"id":"393"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:06.718579+00
2670	1	DELETE /api/programs/393	/api/programs/393	{"params":{"id":"393"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:06.723556+00
2687	1	PUT /api/versions/317	/api/versions/317	{"params":{"id":"317"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:56:26.571994+00
2690	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:30.44712+00
2691	1	DELETE /api/objectives/154	/api/objectives/154	{"params":{"id":"154"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:32.063559+00
2699	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:35.587458+00
2700	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:35.598476+00
2701	1	DELETE /api/objectives/159	/api/objectives/159	{"params":{"id":"159"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:35.603701+00
2707	1	DELETE /api/plos/207	/api/plos/207	{"params":{"id":"207"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:37.451714+00
2716	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:41.095725+00
2717	1	POST /api/plos/212/pis	/api/plos/212/pis	{"params":{"ploId":"212"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:56:41.107773+00
2718	1	DELETE /api/pis/318	/api/pis/318	{"params":{"id":"318"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:41.120234+00
2719	1	DELETE /api/plos/212	/api/plos/212	{"params":{"id":"212"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:41.124022+00
2737	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:46.335818+00
2738	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:46.342281+00
2739	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:46.350132+00
2740	1	PUT /api/versions/317/po-plo-map	/api/versions/317/po-plo-map	{"params":{"vId":"317"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:56:46.360949+00
2741	1	DELETE /api/objectives/161	/api/objectives/161	{"params":{"id":"161"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:46.369136+00
2742	1	DELETE /api/objectives/162	/api/objectives/162	{"params":{"id":"162"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:46.372814+00
2743	1	DELETE /api/plos/217	/api/plos/217	{"params":{"id":"217"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:46.376593+00
2746	1	POST /api/versions/317/knowledge-blocks	/api/versions/317/knowledge-blocks	{"params":{"vId":"317"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:56:49.831666+00
2747	1	POST /api/versions/317/knowledge-blocks	/api/versions/317/knowledge-blocks	{"params":{"vId":"317"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:56:49.837911+00
2748	1	POST /api/versions/317/knowledge-blocks	/api/versions/317/knowledge-blocks	{"params":{"vId":"317"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 09:56:49.844428+00
2749	1	DELETE /api/knowledge-blocks/1684	/api/knowledge-blocks/1684	{"params":{"id":"1684"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:49.856532+00
2757	1	POST /api/versions/317/courses	/api/versions/317/courses	{"params":{"vId":"317"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:56:53.405023+00
2758	1	PUT /api/version-courses/906	/api/version-courses/906	{"params":{"id":"906"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 09:56:53.41147+00
2759	1	DELETE /api/version-courses/906	/api/version-courses/906	{"params":{"id":"906"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:53.41774+00
2762	1	PUT /api/versions/317/course-pi-map	/api/versions/317/course-pi-map	{"params":{"vId":"317"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 09:56:57.469169+00
2766	1	DELETE /api/versions/317	/api/versions/317	{"params":{"id":"317"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:05.808631+00
2767	1	DELETE /api/programs/399	/api/programs/399	{"params":{"id":"399"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:05.813322+00
2774	1	DELETE /api/courses/676	/api/courses/676	{"params":{"id":"676"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:20.361964+00
2777	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:57:24.540659+00
2778	1	DELETE /api/courses/679	/api/courses/679	{"params":{"id":"679"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:24.545743+00
2783	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:57:44.296654+00
2784	1	POST /api/programs/401/versions	/api/programs/401/versions	{"params":{"programId":"401"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:57:44.304941+00
2785	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:57:44.310336+00
2786	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:57:44.322169+00
2787	1	DELETE /api/approval/rejected/program_version/319	/api/approval/rejected/program_version/319	{"params":{"entityType":"program_version","entityId":"319"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:44.330686+00
2788	1	DELETE /api/programs/401	/api/programs/401	{"params":{"id":"401"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:44.337388+00
2811	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:58:02.615105+00
2812	1	DELETE /api/users/134	/api/users/134	{"params":{"id":"134"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:02.622943+00
2817	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:58:08.662065+00
2818	1	PUT /api/users/138/toggle-active	/api/users/138/toggle-active	{"params":{"id":"138"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:08.674808+00
2819	1	DELETE /api/users/138	/api/users/138	{"params":{"id":"138"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:08.687062+00
2834	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:58:48.387607+00
2835	1	PUT /api/departments/1936	/api/departments/1936	{"params":{"id":"1936"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:58:48.393466+00
2836	1	DELETE /api/departments/1936	/api/departments/1936	{"params":{"id":"1936"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:48.398547+00
2837	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 09:58:49.392297+00
2838	1	DELETE /api/departments/1937	/api/departments/1937	{"params":{"id":"1937"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:49.396685+00
2849	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:59:49.053793+00
2850	1	PUT /api/programs/406	/api/programs/406	{"params":{"id":"406"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:59:50.32341+00
2851	1	DELETE /api/programs/406	/api/programs/406	{"params":{"id":"406"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:50.414248+00
2864	1	DELETE /api/programs/411	/api/programs/411	{"params":{"id":"411"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:00.902706+00
2865	1	DELETE /api/programs/410	/api/programs/410	{"params":{"id":"410"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:00.91269+00
2874	1	PUT /api/versions/325	/api/versions/325	{"params":{"id":"325"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:00:14.587133+00
2884	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:22.712783+00
2885	1	DELETE /api/objectives/166	/api/objectives/166	{"params":{"id":"166"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:22.719601+00
2897	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:27.145742+00
2898	1	DELETE /api/plos/221	/api/plos/221	{"params":{"id":"221"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:27.154317+00
2708	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:38.387661+00
2709	1	DELETE /api/plos/208	/api/plos/208	{"params":{"id":"208"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:38.398484+00
2729	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:43.756708+00
2730	1	DELETE /api/plos/215	/api/plos/215	{"params":{"id":"215"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:43.781772+00
2744	1	POST /api/versions/317/knowledge-blocks	/api/versions/317/knowledge-blocks	{"params":{"vId":"317"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:56:47.193907+00
2750	1	POST /api/versions/317/courses	/api/versions/317/courses	{"params":{"vId":"317"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:56:50.70153+00
2751	1	DELETE /api/version-courses/902	/api/version-courses/902	{"params":{"id":"902"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:50.708973+00
2768	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:57:13.071596+00
2769	1	DELETE /api/courses/674	/api/courses/674	{"params":{"id":"674"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:14.19088+00
2773	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:57:20.3249+00
2815	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:58:06.654387+00
2816	1	DELETE /api/users/137	/api/users/137	{"params":{"id":"137"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:06.664531+00
2852	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:59:51.906351+00
2853	1	DELETE /api/programs/407	/api/programs/407	{"params":{"id":"407"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:51.920354+00
2862	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:00:00.877533+00
2863	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:00:00.895229+00
2876	1	PUT /api/versions/325	/api/versions/325	{"params":{"id":"325"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:00:16.345706+00
2886	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:23.571788+00
2887	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:23.582868+00
2888	1	DELETE /api/objectives/168	/api/objectives/168	{"params":{"id":"168"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:23.588518+00
2889	1	DELETE /api/objectives/167	/api/objectives/167	{"params":{"id":"167"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:23.596831+00
2903	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:29.068206+00
2904	1	POST /api/plos/224/pis	/api/plos/224/pis	{"params":{"ploId":"224"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:00:29.08066+00
2905	1	DELETE /api/pis/322	/api/pis/322	{"params":{"id":"322"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:29.09332+00
2906	1	DELETE /api/plos/224	/api/plos/224	{"params":{"id":"224"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:29.098585+00
2944	1	POST /api/versions/325/courses	/api/versions/325/courses	{"params":{"vId":"325"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:00:41.550657+00
2945	1	PUT /api/version-courses/912	/api/version-courses/912	{"params":{"id":"912"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 10:00:41.557097+00
2946	1	DELETE /api/version-courses/912	/api/version-courses/912	{"params":{"id":"912"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:41.563066+00
2960	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:01:08.390094+00
2976	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:01:33.832533+00
2977	1	POST /api/programs/417/versions	/api/programs/417/versions	{"params":{"programId":"417"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:01:33.840397+00
2978	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:01:33.846184+00
2979	1	DELETE /api/programs/417	/api/programs/417	{"params":{"id":"417"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:33.870486+00
2986	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:41.718073+00
2987	1	DELETE /api/users/140	/api/users/140	{"params":{"id":"140"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:41.729072+00
2994	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:47.949125+00
2995	1	POST /api/users/143/roles	/api/users/143/roles	{"params":{"id":"143"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:01:47.960939+00
2996	1	DELETE /api/users/143/roles/GIANG_VIEN/5	/api/users/143/roles/GIANG_VIEN/5	{"params":{"userId":"143","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:47.974383+00
2997	1	DELETE /api/users/143	/api/users/143	{"params":{"id":"143"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:47.984159+00
2998	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:51.839994+00
2999	1	DELETE /api/users/145	/api/users/145	{"params":{"id":"145"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:51.845912+00
3001	1	DELETE /api/users/146	/api/users/146	{"params":{"id":"146"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:54.030136+00
3004	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:58.067514+00
3005	1	PUT /api/users/149/toggle-active	/api/users/149/toggle-active	{"params":{"id":"149"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:58.075038+00
3006	1	DELETE /api/users/149	/api/users/149	{"params":{"id":"149"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:58.083004+00
3010	1	DELETE /api/roles/586	/api/roles/586	{"params":{"id":"586"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:09.943624+00
3011	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:02:19.761504+00
3012	1	DELETE /api/roles/588	/api/roles/588	{"params":{"id":"588"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:19.777071+00
3013	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 10:02:24.974074+00
3014	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:02:28.734929+00
3015	1	DELETE /api/roles/590	/api/roles/590	{"params":{"id":"590"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:28.740433+00
3016	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:02:30.434941+00
3017	1	PUT /api/roles/591	/api/roles/591	{"params":{"id":"591"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:02:30.439644+00
2710	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:39.212004+00
2711	1	DELETE /api/plos/209	/api/plos/209	{"params":{"id":"209"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:39.219493+00
2725	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:42.781708+00
2726	1	POST /api/plos/214/pis	/api/plos/214/pis	{"params":{"ploId":"214"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:56:42.793813+00
2727	1	DELETE /api/pis/320	/api/pis/320	{"params":{"id":"320"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:42.806907+00
2728	1	DELETE /api/plos/214	/api/plos/214	{"params":{"id":"214"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:42.814833+00
2731	1	POST /api/versions/317/objectives	/api/versions/317/objectives	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:44.606334+00
2732	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:44.611442+00
2733	1	PUT /api/versions/317/po-plo-map	/api/versions/317/po-plo-map	{"params":{"vId":"317"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:56:44.62079+00
2734	1	DELETE /api/objectives/160	/api/objectives/160	{"params":{"id":"160"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:44.630944+00
2735	1	DELETE /api/plos/216	/api/plos/216	{"params":{"id":"216"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:44.635185+00
2745	1	POST /api/versions/317/knowledge-blocks	/api/versions/317/knowledge-blocks	{"params":{"vId":"317"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 09:56:48.0309+00
2754	1	POST /api/versions/317/courses	/api/versions/317/courses	{"params":{"vId":"317"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:56:52.512855+00
2755	1	POST /api/versions/317/courses	/api/versions/317/courses	{"params":{"vId":"317"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:56:52.52157+00
2756	1	DELETE /api/version-courses/904	/api/version-courses/904	{"params":{"id":"904"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:52.526398+00
2770	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:57:15.598172+00
2771	1	PUT /api/courses/675	/api/courses/675	{"params":{"id":"675"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:57:15.603358+00
2772	1	DELETE /api/courses/675	/api/courses/675	{"params":{"id":"675"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:15.608864+00
2804	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:57:56.764425+00
2805	1	POST /api/users/131/roles	/api/users/131/roles	{"params":{"id":"131"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:57:56.782391+00
2807	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:57:58.688511+00
2808	1	POST /api/users/132/roles	/api/users/132/roles	{"params":{"id":"132"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 09:57:58.698212+00
2809	1	DELETE /api/users/132/roles/GIANG_VIEN/5	/api/users/132/roles/GIANG_VIEN/5	{"params":{"userId":"132","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:58.706392+00
2810	1	DELETE /api/users/132	/api/users/132	{"params":{"id":"132"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:58.722091+00
2824	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:58:32.044949+00
2829	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:58:43.777758+00
2830	1	PUT /api/roles/579	/api/roles/579	{"params":{"id":"579"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 09:58:43.782413+00
2831	1	DELETE /api/roles/579	/api/roles/579	{"params":{"id":"579"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:43.788083+00
2854	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:59:53.407234+00
2855	1	POST /api/programs/408/archive	/api/programs/408/archive	{"params":{"id":"408"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:53.423356+00
2856	1	POST /api/programs/408/unarchive	/api/programs/408/unarchive	{"params":{"id":"408"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:54.543655+00
2857	1	DELETE /api/programs/408	/api/programs/408	{"params":{"id":"408"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:54.548837+00
2877	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:18.350458+00
2878	1	DELETE /api/objectives/163	/api/objectives/163	{"params":{"id":"163"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:19.97523+00
2882	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:21.737442+00
2883	1	DELETE /api/objectives/165	/api/objectives/165	{"params":{"id":"165"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:21.749922+00
2895	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:26.197965+00
2896	1	DELETE /api/plos/220	/api/plos/220	{"params":{"id":"220"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:26.212551+00
2912	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:30.783699+00
2913	1	POST /api/plos/226/pis	/api/plos/226/pis	{"params":{"ploId":"226"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:00:30.794452+00
2914	1	DELETE /api/pis/324	/api/pis/324	{"params":{"id":"324"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:30.808892+00
2915	1	DELETE /api/plos/226	/api/plos/226	{"params":{"id":"226"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:30.817495+00
2931	1	POST /api/versions/325/knowledge-blocks	/api/versions/325/knowledge-blocks	{"params":{"vId":"325"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:00:35.231108+00
2939	1	POST /api/versions/325/courses	/api/versions/325/courses	{"params":{"vId":"325"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:00:39.709137+00
2940	1	DELETE /api/version-courses/909	/api/version-courses/909	{"params":{"id":"909"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:39.718896+00
2949	1	PUT /api/versions/325/course-pi-map	/api/versions/325/course-pi-map	{"params":{"vId":"325"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 10:00:45.592933+00
2961	1	DELETE /api/courses/682	/api/courses/682	{"params":{"id":"682"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:08.421194+00
2964	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:01:12.63063+00
2965	1	DELETE /api/courses/685	/api/courses/685	{"params":{"id":"685"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:12.635713+00
2980	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:01:36.719726+00
2981	1	POST /api/programs/418/versions	/api/programs/418/versions	{"params":{"programId":"418"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:01:36.727609+00
2982	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:01:36.733322+00
2712	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:40.222721+00
2713	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:40.233777+00
2714	1	DELETE /api/plos/211	/api/plos/211	{"params":{"id":"211"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:40.240245+00
2720	1	POST /api/versions/317/plos	/api/versions/317/plos	{"params":{"vId":"317"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 09:56:41.919992+00
2721	1	POST /api/plos/213/pis	/api/plos/213/pis	{"params":{"ploId":"213"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 09:56:41.930615+00
2722	1	PUT /api/pis/319	/api/pis/319	{"params":{"id":"319"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 09:56:41.939738+00
2723	1	DELETE /api/pis/319	/api/pis/319	{"params":{"id":"319"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:41.948805+00
2724	1	DELETE /api/plos/213	/api/plos/213	{"params":{"id":"213"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:41.953013+00
2760	1	PUT /api/versions/317/course-plo-map	/api/versions/317/course-plo-map	{"params":{"vId":"317"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:56:55.112164+00
2775	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 09:57:21.76392+00
2776	1	DELETE /api/courses/678	/api/courses/678	{"params":{"id":"678"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:21.7718+00
2801	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:57:54.716192+00
2802	1	PUT /api/users/130	/api/users/130	{"params":{"id":"130"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 09:57:54.72644+00
2803	1	DELETE /api/users/130	/api/users/130	{"params":{"id":"130"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:54.740888+00
2814	1	DELETE /api/users/135	/api/users/135	{"params":{"id":"135"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:04.712038+00
2820	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:58:10.621274+00
2821	1	DELETE /api/users/139	/api/users/139	{"params":{"id":"139"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:10.636923+00
2827	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:58:41.812662+00
2828	1	DELETE /api/roles/578	/api/roles/578	{"params":{"id":"578"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:41.817967+00
2832	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:58:47.346705+00
2833	1	DELETE /api/departments/1935	/api/departments/1935	{"params":{"id":"1935"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:47.35211+00
2840	1	DELETE /api/departments/1939	/api/departments/1939	{"params":{"id":"1939"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:51.338422+00
2843	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:59:15.163717+00
2844	1	POST /api/programs/404/versions	/api/programs/404/versions	{"params":{"programId":"404"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:59:15.173522+00
2845	1	DELETE /api/versions/322	/api/versions/322	{"params":{"id":"322"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:15.188802+00
2846	1	DELETE /api/programs/404	/api/programs/404	{"params":{"id":"404"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:15.192291+00
2858	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:59:55.981374+00
2859	1	POST /api/programs/409/versions	/api/programs/409/versions	{"params":{"programId":"409"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:59:56.001434+00
2860	1	DELETE /api/versions/323	/api/versions/323	{"params":{"id":"323"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:56.014798+00
2861	1	DELETE /api/programs/409	/api/programs/409	{"params":{"id":"409"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:56.0204+00
2866	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:00:03.834071+00
2867	1	POST /api/programs/412/versions	/api/programs/412/versions	{"params":{"programId":"412"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:00:03.839874+00
2879	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:20.881115+00
2880	1	PUT /api/objectives/164	/api/objectives/164	{"params":{"id":"164"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:00:20.892852+00
2881	1	DELETE /api/objectives/164	/api/objectives/164	{"params":{"id":"164"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:20.904868+00
2902	1	DELETE /api/plos/222	/api/plos/222	{"params":{"id":"222"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:28.137921+00
2918	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:32.601123+00
2919	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:32.60656+00
2920	1	PUT /api/versions/325/po-plo-map	/api/versions/325/po-plo-map	{"params":{"vId":"325"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:00:32.616298+00
2921	1	DELETE /api/objectives/169	/api/objectives/169	{"params":{"id":"169"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:32.626071+00
2922	1	DELETE /api/plos/228	/api/plos/228	{"params":{"id":"228"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:32.629803+00
2947	1	PUT /api/versions/325/course-plo-map	/api/versions/325/course-plo-map	{"params":{"vId":"325"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:00:43.146477+00
2950	1	POST /api/versions/325/courses	/api/versions/325/courses	{"params":{"vId":"325"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:00:47.36255+00
2951	1	PUT /api/versions/325/course-relations	/api/versions/325/course-relations	{"params":{"vId":"325"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 10:00:47.368253+00
2952	1	DELETE /api/version-courses/913	/api/version-courses/913	{"params":{"id":"913"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:47.373602+00
2962	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:01:09.832915+00
2963	1	DELETE /api/courses/684	/api/courses/684	{"params":{"id":"684"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:09.842014+00
2970	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:01:32.757053+00
2971	1	POST /api/programs/416/versions	/api/programs/416/versions	{"params":{"programId":"416"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:01:32.764323+00
2972	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:01:32.770641+00
2973	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:01:32.782711+00
2983	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:01:36.745385+00
2715	1	DELETE /api/plos/210	/api/plos/210	{"params":{"id":"210"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:40.249606+00
2736	1	PUT /api/versions/317/po-plo-map	/api/versions/317/po-plo-map	{"params":{"vId":"317"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:56:45.403164+00
2779	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:57:40.903924+00
2780	1	POST /api/programs/400/versions	/api/programs/400/versions	{"params":{"programId":"400"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:57:40.912175+00
2781	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:57:40.92984+00
2782	1	DELETE /api/programs/400	/api/programs/400	{"params":{"id":"400"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:40.943915+00
2789	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:57:45.254316+00
2790	1	POST /api/programs/402/versions	/api/programs/402/versions	{"params":{"programId":"402"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:57:45.261919+00
2791	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:57:45.26812+00
2792	1	DELETE /api/programs/402	/api/programs/402	{"params":{"id":"402"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:45.285343+00
2822	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 09:58:21.3585+00
2823	1	DELETE /api/roles/574	/api/roles/574	{"params":{"id":"574"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:21.363768+00
2825	1	DELETE /api/roles/576	/api/roles/576	{"params":{"id":"576"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:32.06986+00
2826	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 09:58:37.737831+00
2839	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:58:51.32412+00
2841	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 09:58:53.107225+00
2842	1	DELETE /api/departments/1941	/api/departments/1941	{"params":{"id":"1941"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:58:53.116079+00
2868	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:00:09.679249+00
2869	1	POST /api/programs/413/archive	/api/programs/413/archive	{"params":{"id":"413"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:09.685246+00
2870	1	POST /api/programs/413/unarchive	/api/programs/413/unarchive	{"params":{"id":"413"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:09.703877+00
2871	1	DELETE /api/programs/413	/api/programs/413	{"params":{"id":"413"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:09.715608+00
2890	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:24.437426+00
2891	1	DELETE /api/plos/218	/api/plos/218	{"params":{"id":"218"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:24.448882+00
2899	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:28.111264+00
2900	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:28.122768+00
2901	1	DELETE /api/plos/223	/api/plos/223	{"params":{"id":"223"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:28.128263+00
2916	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:31.743895+00
2917	1	DELETE /api/plos/227	/api/plos/227	{"params":{"id":"227"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:31.769021+00
2923	1	PUT /api/versions/325/po-plo-map	/api/versions/325/po-plo-map	{"params":{"vId":"325"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:00:33.428825+00
2932	1	POST /api/versions/325/knowledge-blocks	/api/versions/325/knowledge-blocks	{"params":{"vId":"325"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:00:36.130754+00
2933	1	POST /api/versions/325/knowledge-blocks	/api/versions/325/knowledge-blocks	{"params":{"vId":"325"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:00:37.849748+00
2934	1	POST /api/versions/325/knowledge-blocks	/api/versions/325/knowledge-blocks	{"params":{"vId":"325"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:00:37.856929+00
2935	1	POST /api/versions/325/knowledge-blocks	/api/versions/325/knowledge-blocks	{"params":{"vId":"325"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:00:37.863168+00
2936	1	DELETE /api/knowledge-blocks/1729	/api/knowledge-blocks/1729	{"params":{"id":"1729"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:37.874192+00
2941	1	POST /api/versions/325/courses	/api/versions/325/courses	{"params":{"vId":"325"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:00:40.615179+00
2942	1	POST /api/versions/325/courses	/api/versions/325/courses	{"params":{"vId":"325"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:00:40.621268+00
2943	1	DELETE /api/version-courses/910	/api/version-courses/910	{"params":{"id":"910"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:40.628555+00
2955	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:01:01.032057+00
2956	1	DELETE /api/courses/680	/api/courses/680	{"params":{"id":"680"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:02.149586+00
2966	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:01:29.105321+00
2967	1	POST /api/programs/415/versions	/api/programs/415/versions	{"params":{"programId":"415"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:01:29.114945+00
2968	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:01:29.131631+00
2969	1	DELETE /api/programs/415	/api/programs/415	{"params":{"id":"415"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:29.15058+00
2984	1	DELETE /api/versions/329	/api/versions/329	{"params":{"id":"329"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:36.754046+00
2985	1	DELETE /api/programs/418	/api/programs/418	{"params":{"id":"418"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:36.757775+00
2991	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:45.78911+00
2992	1	POST /api/users/142/roles	/api/users/142/roles	{"params":{"id":"142"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:01:45.808401+00
2993	1	DELETE /api/users/142	/api/users/142	{"params":{"id":"142"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:45.834729+00
3002	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:55.999036+00
3003	1	DELETE /api/users/148	/api/users/148	{"params":{"id":"148"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:56.012136+00
3007	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:02:00.019112+00
3008	1	DELETE /api/users/150	/api/users/150	{"params":{"id":"150"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:00.028752+00
2752	1	POST /api/versions/317/courses	/api/versions/317/courses	{"params":{"vId":"317"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:56:51.537179+00
2753	1	DELETE /api/version-courses/903	/api/version-courses/903	{"params":{"id":"903"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:51.544666+00
2761	1	PUT /api/versions/317/course-plo-map	/api/versions/317/course-plo-map	{"params":{"vId":"317"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 09:56:55.90296+00
2763	1	POST /api/versions/317/courses	/api/versions/317/courses	{"params":{"vId":"317"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 09:56:59.258707+00
2764	1	PUT /api/versions/317/course-relations	/api/versions/317/course-relations	{"params":{"vId":"317"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 09:56:59.264883+00
2765	1	DELETE /api/version-courses/907	/api/version-courses/907	{"params":{"id":"907"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:56:59.269696+00
2793	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 09:57:47.945949+00
2794	1	POST /api/programs/403/versions	/api/programs/403/versions	{"params":{"programId":"403"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 09:57:47.953628+00
2795	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 09:57:47.958339+00
2796	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 09:57:47.97171+00
2797	1	DELETE /api/versions/321	/api/versions/321	{"params":{"id":"321"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:47.981555+00
2798	1	DELETE /api/programs/403	/api/programs/403	{"params":{"id":"403"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:47.984805+00
2799	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:57:52.694842+00
2800	1	DELETE /api/users/129	/api/users/129	{"params":{"id":"129"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:52.706705+00
2806	1	DELETE /api/users/131	/api/users/131	{"params":{"id":"131"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:57:56.790654+00
2813	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 09:58:04.626334+00
2847	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 09:59:47.439477+00
2848	1	DELETE /api/programs/405	/api/programs/405	{"params":{"id":"405"},"bodyKeys":[]}	172.18.0.1	2026-04-04 09:59:47.627567+00
2872	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:00:10.664945+00
2873	1	POST /api/programs/414/versions	/api/programs/414/versions	{"params":{"programId":"414"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:00:10.675587+00
2875	1	PUT /api/versions/325	/api/versions/325	{"params":{"id":"325"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:00:15.406779+00
2892	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:25.237924+00
2893	1	PUT /api/plos/219	/api/plos/219	{"params":{"id":"219"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:00:25.251927+00
2894	1	DELETE /api/plos/219	/api/plos/219	{"params":{"id":"219"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:25.262657+00
2907	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:29.917298+00
2908	1	POST /api/plos/225/pis	/api/plos/225/pis	{"params":{"ploId":"225"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:00:29.929391+00
2909	1	PUT /api/pis/323	/api/pis/323	{"params":{"id":"323"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:00:29.942277+00
2910	1	DELETE /api/pis/323	/api/pis/323	{"params":{"id":"323"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:29.954673+00
2911	1	DELETE /api/plos/225	/api/plos/225	{"params":{"id":"225"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:29.958598+00
2924	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:34.270211+00
2925	1	POST /api/versions/325/objectives	/api/versions/325/objectives	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:34.275605+00
2926	1	POST /api/versions/325/plos	/api/versions/325/plos	{"params":{"vId":"325"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:00:34.281619+00
2927	1	PUT /api/versions/325/po-plo-map	/api/versions/325/po-plo-map	{"params":{"vId":"325"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:00:34.295846+00
2928	1	DELETE /api/objectives/170	/api/objectives/170	{"params":{"id":"170"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:34.303847+00
2929	1	DELETE /api/objectives/171	/api/objectives/171	{"params":{"id":"171"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:34.307554+00
2930	1	DELETE /api/plos/229	/api/plos/229	{"params":{"id":"229"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:34.311604+00
2937	1	POST /api/versions/325/courses	/api/versions/325/courses	{"params":{"vId":"325"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:00:38.85579+00
2938	1	DELETE /api/version-courses/908	/api/version-courses/908	{"params":{"id":"908"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:38.861121+00
2948	1	PUT /api/versions/325/course-plo-map	/api/versions/325/course-plo-map	{"params":{"vId":"325"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:00:43.944668+00
2953	1	DELETE /api/versions/325	/api/versions/325	{"params":{"id":"325"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:53.936309+00
2954	1	DELETE /api/programs/414	/api/programs/414	{"params":{"id":"414"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:00:53.940034+00
2957	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:01:03.504626+00
2958	1	PUT /api/courses/681	/api/courses/681	{"params":{"id":"681"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:01:03.510302+00
2959	1	DELETE /api/courses/681	/api/courses/681	{"params":{"id":"681"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:03.515404+00
2974	1	DELETE /api/approval/rejected/program_version/327	/api/approval/rejected/program_version/327	{"params":{"entityType":"program_version","entityId":"327"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:32.795758+00
2975	1	DELETE /api/programs/416	/api/programs/416	{"params":{"id":"416"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:32.80287+00
2988	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:43.709712+00
2989	1	PUT /api/users/141	/api/users/141	{"params":{"id":"141"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 10:01:43.717721+00
2990	1	DELETE /api/users/141	/api/users/141	{"params":{"id":"141"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:01:43.727519+00
3000	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:01:53.937789+00
3009	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:02:09.938008+00
3018	1	DELETE /api/roles/591	/api/roles/591	{"params":{"id":"591"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:30.443896+00
4670	1	DELETE /api/programs/496	/api/programs/496	{"params":{"id":"496"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.902328+00
4671	1	DELETE /api/programs/494	/api/programs/494	{"params":{"id":"494"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.912809+00
4672	1	DELETE /api/programs/504	/api/programs/504	{"params":{"id":"504"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.921948+00
4673	1	DELETE /api/programs/495	/api/programs/495	{"params":{"id":"495"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.930566+00
4674	1	DELETE /api/programs/500	/api/programs/500	{"params":{"id":"500"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.938107+00
4675	1	DELETE /api/versions/140	/api/versions/140	{"params":{"id":"140"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.962869+00
4676	1	DELETE /api/programs/159	/api/programs/159	{"params":{"id":"159"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:23.966167+00
4677	1	POST /api/programs/488/archive	/api/programs/488/archive	{"params":{"id":"488"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:32.355006+00
4678	1	POST /api/programs/516/archive	/api/programs/516/archive	{"params":{"id":"516"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:32.358621+00
4679	1	POST /api/programs/539/archive	/api/programs/539/archive	{"params":{"id":"539"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:32.361382+00
3019	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:02:33.375292+00
3020	1	DELETE /api/departments/1964	/api/departments/1964	{"params":{"id":"1964"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:33.382241+00
3027	1	DELETE /api/departments/1968	/api/departments/1968	{"params":{"id":"1968"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:36.23949+00
3021	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:02:34.114986+00
3022	1	PUT /api/departments/1965	/api/departments/1965	{"params":{"id":"1965"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:02:34.119263+00
3023	1	DELETE /api/departments/1965	/api/departments/1965	{"params":{"id":"1965"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:34.123551+00
3024	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 10:02:34.833046+00
3025	1	DELETE /api/departments/1966	/api/departments/1966	{"params":{"id":"1966"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:34.838983+00
3026	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:02:36.226702+00
3028	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:02:37.545295+00
3029	1	DELETE /api/departments/1970	/api/departments/1970	{"params":{"id":"1970"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:37.552018+00
3030	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:02:57.027351+00
3031	1	POST /api/programs/419/versions	/api/programs/419/versions	{"params":{"programId":"419"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:02:57.034284+00
3032	1	DELETE /api/versions/330	/api/versions/330	{"params":{"id":"330"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:57.041679+00
3033	1	DELETE /api/programs/419	/api/programs/419	{"params":{"id":"419"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:02:57.045514+00
3034	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:03:35.751509+00
3035	1	DELETE /api/programs/420	/api/programs/420	{"params":{"id":"420"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:35.944389+00
3036	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:37.308692+00
3037	1	PUT /api/programs/421	/api/programs/421	{"params":{"id":"421"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:03:38.641503+00
3038	1	DELETE /api/programs/421	/api/programs/421	{"params":{"id":"421"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:38.685134+00
3039	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:40.013132+00
3040	1	DELETE /api/programs/422	/api/programs/422	{"params":{"id":"422"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:40.02688+00
3041	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:41.37879+00
3042	1	POST /api/programs/423/archive	/api/programs/423/archive	{"params":{"id":"423"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:41.389012+00
3043	1	POST /api/programs/423/unarchive	/api/programs/423/unarchive	{"params":{"id":"423"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:42.538281+00
3044	1	DELETE /api/programs/423	/api/programs/423	{"params":{"id":"423"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:42.543066+00
3045	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:43.780108+00
3046	1	POST /api/programs/424/versions	/api/programs/424/versions	{"params":{"programId":"424"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:03:43.794406+00
3047	1	DELETE /api/versions/331	/api/versions/331	{"params":{"id":"331"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:43.807659+00
3048	1	DELETE /api/programs/424	/api/programs/424	{"params":{"id":"424"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:43.811+00
3049	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:48.212998+00
3050	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:48.225371+00
3051	1	DELETE /api/programs/426	/api/programs/426	{"params":{"id":"426"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:48.228594+00
3052	1	DELETE /api/programs/425	/api/programs/425	{"params":{"id":"425"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:48.238104+00
3053	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:50.845869+00
3054	1	POST /api/programs/427/versions	/api/programs/427/versions	{"params":{"programId":"427"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:03:50.853511+00
3055	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:56.305343+00
3056	1	POST /api/programs/428/archive	/api/programs/428/archive	{"params":{"id":"428"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:56.310985+00
3057	1	POST /api/programs/428/unarchive	/api/programs/428/unarchive	{"params":{"id":"428"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:56.322975+00
3058	1	DELETE /api/programs/428	/api/programs/428	{"params":{"id":"428"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:03:56.334191+00
3059	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:03:57.148634+00
3060	1	POST /api/programs/429/versions	/api/programs/429/versions	{"params":{"programId":"429"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:03:57.159775+00
3061	1	PUT /api/versions/333	/api/versions/333	{"params":{"id":"333"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:04:00.790261+00
3062	1	PUT /api/versions/333	/api/versions/333	{"params":{"id":"333"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:04:01.492721+00
3063	1	PUT /api/versions/333	/api/versions/333	{"params":{"id":"333"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:04:02.273087+00
3064	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:03.980488+00
3065	1	DELETE /api/objectives/172	/api/objectives/172	{"params":{"id":"172"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:05.596136+00
3066	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:06.308874+00
3067	1	PUT /api/objectives/173	/api/objectives/173	{"params":{"id":"173"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:04:06.31891+00
3068	1	DELETE /api/objectives/173	/api/objectives/173	{"params":{"id":"173"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:06.334049+00
3069	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:06.993529+00
3070	1	DELETE /api/objectives/174	/api/objectives/174	{"params":{"id":"174"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:07.002337+00
3071	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:07.674742+00
3072	1	DELETE /api/objectives/175	/api/objectives/175	{"params":{"id":"175"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:07.681604+00
3073	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:08.430912+00
3074	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:08.441808+00
3075	1	DELETE /api/objectives/177	/api/objectives/177	{"params":{"id":"177"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:08.447486+00
3076	1	DELETE /api/objectives/176	/api/objectives/176	{"params":{"id":"176"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:08.455834+00
3086	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:11.889018+00
3087	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:11.900041+00
3088	1	DELETE /api/plos/235	/api/plos/235	{"params":{"id":"235"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:11.913609+00
3089	1	DELETE /api/plos/234	/api/plos/234	{"params":{"id":"234"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:11.921444+00
3105	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:15.640438+00
3106	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:15.646452+00
3107	1	PUT /api/versions/333/po-plo-map	/api/versions/333/po-plo-map	{"params":{"vId":"333"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:04:15.665129+00
3108	1	DELETE /api/objectives/178	/api/objectives/178	{"params":{"id":"178"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:15.672678+00
3109	1	DELETE /api/plos/240	/api/plos/240	{"params":{"id":"240"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:15.6763+00
3120	1	POST /api/versions/333/knowledge-blocks	/api/versions/333/knowledge-blocks	{"params":{"vId":"333"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:04:19.952735+00
3121	1	POST /api/versions/333/knowledge-blocks	/api/versions/333/knowledge-blocks	{"params":{"vId":"333"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:04:19.959235+00
3122	1	POST /api/versions/333/knowledge-blocks	/api/versions/333/knowledge-blocks	{"params":{"vId":"333"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:04:19.965589+00
3123	1	DELETE /api/knowledge-blocks/1774	/api/knowledge-blocks/1774	{"params":{"id":"1774"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:19.977366+00
3131	1	POST /api/versions/333/courses	/api/versions/333/courses	{"params":{"vId":"333"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:04:22.779395+00
3132	1	PUT /api/version-courses/918	/api/version-courses/918	{"params":{"id":"918"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 10:04:22.785498+00
3133	1	DELETE /api/version-courses/918	/api/version-courses/918	{"params":{"id":"918"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:22.791631+00
3136	1	PUT /api/versions/333/course-pi-map	/api/versions/333/course-pi-map	{"params":{"vId":"333"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 10:04:26.358322+00
3153	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:05:07.987192+00
3154	1	POST /api/programs/430/versions	/api/programs/430/versions	{"params":{"programId":"430"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:05:07.994844+00
3155	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:05:08.003549+00
3156	1	DELETE /api/programs/430	/api/programs/430	{"params":{"id":"430"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:08.01578+00
3157	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:05:11.358053+00
3158	1	POST /api/programs/431/versions	/api/programs/431/versions	{"params":{"programId":"431"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:05:11.365022+00
3159	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:05:11.36992+00
3160	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:05:11.383684+00
3161	1	DELETE /api/approval/rejected/program_version/335	/api/approval/rejected/program_version/335	{"params":{"entityType":"program_version","entityId":"335"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:11.391805+00
3162	1	DELETE /api/programs/431	/api/programs/431	{"params":{"id":"431"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:11.396952+00
3191	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:35.509913+00
3192	1	PUT /api/users/160/toggle-active	/api/users/160/toggle-active	{"params":{"id":"160"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:35.520467+00
3193	1	DELETE /api/users/160	/api/users/160	{"params":{"id":"160"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:35.535039+00
3211	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 10:06:14.519049+00
3212	1	DELETE /api/departments/1995	/api/departments/1995	{"params":{"id":"1995"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:14.524965+00
3217	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:06:38.940791+00
3218	1	POST /api/programs/434/versions	/api/programs/434/versions	{"params":{"programId":"434"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:06:38.948354+00
3219	1	DELETE /api/versions/338	/api/versions/338	{"params":{"id":"338"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:38.954239+00
3220	1	DELETE /api/programs/434	/api/programs/434	{"params":{"id":"434"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:38.957606+00
3077	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:09.128458+00
3078	1	DELETE /api/plos/230	/api/plos/230	{"params":{"id":"230"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:09.138504+00
3090	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:12.695413+00
3091	1	POST /api/plos/236/pis	/api/plos/236/pis	{"params":{"ploId":"236"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:04:12.707581+00
3092	1	DELETE /api/pis/326	/api/pis/326	{"params":{"id":"326"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:12.720493+00
3093	1	DELETE /api/plos/236	/api/plos/236	{"params":{"id":"236"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:12.724303+00
3110	1	PUT /api/versions/333/po-plo-map	/api/versions/333/po-plo-map	{"params":{"vId":"333"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:04:16.417162+00
3124	1	POST /api/versions/333/courses	/api/versions/333/courses	{"params":{"vId":"333"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:04:20.667532+00
3125	1	DELETE /api/version-courses/914	/api/version-courses/914	{"params":{"id":"914"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:20.67544+00
3135	1	PUT /api/versions/333/course-plo-map	/api/versions/333/course-plo-map	{"params":{"vId":"333"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:04:24.93516+00
3140	1	DELETE /api/versions/333	/api/versions/333	{"params":{"id":"333"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:33.888707+00
3141	1	DELETE /api/programs/429	/api/programs/429	{"params":{"id":"429"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:33.892467+00
3142	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:04:40.656467+00
3143	1	DELETE /api/courses/686	/api/courses/686	{"params":{"id":"686"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:41.773465+00
3148	1	DELETE /api/courses/688	/api/courses/688	{"params":{"id":"688"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:47.985435+00
3151	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:04:52.251755+00
3152	1	DELETE /api/courses/691	/api/courses/691	{"params":{"id":"691"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:52.256937+00
3167	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:05:14.938593+00
3168	1	POST /api/programs/433/versions	/api/programs/433/versions	{"params":{"programId":"433"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:05:14.946126+00
3169	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:05:14.952273+00
3170	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:05:14.964468+00
3171	1	DELETE /api/versions/337	/api/versions/337	{"params":{"id":"337"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:14.97166+00
3172	1	DELETE /api/programs/433	/api/programs/433	{"params":{"id":"433"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:14.97451+00
3181	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:25.6179+00
3182	1	POST /api/users/154/roles	/api/users/154/roles	{"params":{"id":"154"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:05:25.63136+00
3183	1	DELETE /api/users/154/roles/GIANG_VIEN/5	/api/users/154/roles/GIANG_VIEN/5	{"params":{"userId":"154","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:25.642552+00
3184	1	DELETE /api/users/154	/api/users/154	{"params":{"id":"154"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:25.651611+00
3188	1	DELETE /api/users/157	/api/users/157	{"params":{"id":"157"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:31.525728+00
3079	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:09.807741+00
3080	1	PUT /api/plos/231	/api/plos/231	{"params":{"id":"231"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:04:09.818902+00
3081	1	DELETE /api/plos/231	/api/plos/231	{"params":{"id":"231"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:09.832577+00
3099	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:14.19717+00
3100	1	POST /api/plos/238/pis	/api/plos/238/pis	{"params":{"ploId":"238"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:04:14.206347+00
3101	1	DELETE /api/pis/328	/api/pis/328	{"params":{"id":"328"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:14.215637+00
3102	1	DELETE /api/plos/238	/api/plos/238	{"params":{"id":"238"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:14.223885+00
3118	1	POST /api/versions/333/knowledge-blocks	/api/versions/333/knowledge-blocks	{"params":{"vId":"333"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:04:17.850592+00
3126	1	POST /api/versions/333/courses	/api/versions/333/courses	{"params":{"vId":"333"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:04:21.383372+00
3127	1	DELETE /api/version-courses/915	/api/version-courses/915	{"params":{"id":"915"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:21.391199+00
3144	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:04:43.172546+00
3145	1	PUT /api/courses/687	/api/courses/687	{"params":{"id":"687"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:04:43.177691+00
3146	1	DELETE /api/courses/687	/api/courses/687	{"params":{"id":"687"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:43.183125+00
3082	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:10.505556+00
3083	1	DELETE /api/plos/232	/api/plos/232	{"params":{"id":"232"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:10.517766+00
3128	1	POST /api/versions/333/courses	/api/versions/333/courses	{"params":{"vId":"333"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:04:22.082207+00
3129	1	POST /api/versions/333/courses	/api/versions/333/courses	{"params":{"vId":"333"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:04:22.088234+00
3130	1	DELETE /api/version-courses/916	/api/version-courses/916	{"params":{"id":"916"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:22.094252+00
3084	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:11.173729+00
3085	1	DELETE /api/plos/233	/api/plos/233	{"params":{"id":"233"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:11.182434+00
3103	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:14.945625+00
3104	1	DELETE /api/plos/239	/api/plos/239	{"params":{"id":"239"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:14.962436+00
3119	1	POST /api/versions/333/knowledge-blocks	/api/versions/333/knowledge-blocks	{"params":{"vId":"333"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:04:18.542772+00
3134	1	PUT /api/versions/333/course-plo-map	/api/versions/333/course-plo-map	{"params":{"vId":"333"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:04:24.2937+00
3137	1	POST /api/versions/333/courses	/api/versions/333/courses	{"params":{"vId":"333"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:04:27.712359+00
3138	1	PUT /api/versions/333/course-relations	/api/versions/333/course-relations	{"params":{"vId":"333"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 10:04:27.719543+00
3139	1	DELETE /api/version-courses/919	/api/version-courses/919	{"params":{"id":"919"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:27.725621+00
3147	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:04:47.952848+00
3094	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:13.480686+00
3095	1	POST /api/plos/237/pis	/api/plos/237/pis	{"params":{"ploId":"237"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:04:13.490828+00
3096	1	PUT /api/pis/327	/api/pis/327	{"params":{"id":"327"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:04:13.506062+00
3097	1	DELETE /api/pis/327	/api/pis/327	{"params":{"id":"327"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:13.517347+00
3098	1	DELETE /api/plos/237	/api/plos/237	{"params":{"id":"237"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:13.523111+00
3111	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:17.047397+00
3112	1	POST /api/versions/333/objectives	/api/versions/333/objectives	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:17.052063+00
3113	1	POST /api/versions/333/plos	/api/versions/333/plos	{"params":{"vId":"333"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:04:17.057313+00
3114	1	PUT /api/versions/333/po-plo-map	/api/versions/333/po-plo-map	{"params":{"vId":"333"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:04:17.066719+00
3115	1	DELETE /api/objectives/179	/api/objectives/179	{"params":{"id":"179"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:17.074935+00
3116	1	DELETE /api/objectives/180	/api/objectives/180	{"params":{"id":"180"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:17.078411+00
3117	1	DELETE /api/plos/241	/api/plos/241	{"params":{"id":"241"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:17.08184+00
3149	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:04:49.391834+00
3150	1	DELETE /api/courses/690	/api/courses/690	{"params":{"id":"690"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:04:49.399921+00
3163	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:05:12.220734+00
3164	1	POST /api/programs/432/versions	/api/programs/432/versions	{"params":{"programId":"432"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:05:12.228493+00
3165	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:05:12.237611+00
3166	1	DELETE /api/programs/432	/api/programs/432	{"params":{"id":"432"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:12.257847+00
3173	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:19.710108+00
3174	1	DELETE /api/users/151	/api/users/151	{"params":{"id":"151"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:19.723481+00
3175	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:21.703691+00
3176	1	PUT /api/users/152	/api/users/152	{"params":{"id":"152"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 10:05:21.711709+00
3177	1	DELETE /api/users/152	/api/users/152	{"params":{"id":"152"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:21.720528+00
3178	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:23.655445+00
3179	1	POST /api/users/153/roles	/api/users/153/roles	{"params":{"id":"153"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:05:23.669238+00
3180	1	DELETE /api/users/153	/api/users/153	{"params":{"id":"153"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:23.679206+00
3185	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:29.510559+00
3186	1	DELETE /api/users/156	/api/users/156	{"params":{"id":"156"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:29.519122+00
3187	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:31.442182+00
3189	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:33.496673+00
3190	1	DELETE /api/users/159	/api/users/159	{"params":{"id":"159"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:33.510245+00
3194	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:05:37.494409+00
3195	1	DELETE /api/users/161	/api/users/161	{"params":{"id":"161"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:37.50646+00
3196	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:05:47.925682+00
3197	1	DELETE /api/roles/598	/api/roles/598	{"params":{"id":"598"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:47.930023+00
3198	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:05:58.192497+00
3199	1	DELETE /api/roles/600	/api/roles/600	{"params":{"id":"600"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:05:58.21717+00
3200	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 10:06:03.883354+00
3201	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:06:07.892703+00
3202	1	DELETE /api/roles/602	/api/roles/602	{"params":{"id":"602"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:07.898304+00
3203	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:06:09.735406+00
3204	1	PUT /api/roles/603	/api/roles/603	{"params":{"id":"603"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:06:09.738818+00
3205	1	DELETE /api/roles/603	/api/roles/603	{"params":{"id":"603"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:09.74222+00
3206	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:06:12.873816+00
3207	1	DELETE /api/departments/1993	/api/departments/1993	{"params":{"id":"1993"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:12.878855+00
3208	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:06:13.704538+00
3209	1	PUT /api/departments/1994	/api/departments/1994	{"params":{"id":"1994"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:06:13.708757+00
3210	1	DELETE /api/departments/1994	/api/departments/1994	{"params":{"id":"1994"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:13.712701+00
3213	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:06:16.061056+00
3214	1	DELETE /api/departments/1997	/api/departments/1997	{"params":{"id":"1997"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:16.074037+00
3215	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:06:17.753806+00
3216	1	DELETE /api/departments/1999	/api/departments/1999	{"params":{"id":"1999"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:06:17.760355+00
3221	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:07:07.788047+00
3222	1	DELETE /api/programs/435	/api/programs/435	{"params":{"id":"435"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:07.975837+00
3223	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:09.424293+00
3224	1	PUT /api/programs/436	/api/programs/436	{"params":{"id":"436"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:07:10.791466+00
3225	1	DELETE /api/programs/436	/api/programs/436	{"params":{"id":"436"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:10.877714+00
3226	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:12.408521+00
3227	1	DELETE /api/programs/437	/api/programs/437	{"params":{"id":"437"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:12.422821+00
3228	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:13.840308+00
3229	1	POST /api/programs/438/archive	/api/programs/438/archive	{"params":{"id":"438"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:13.851545+00
3230	1	POST /api/programs/438/unarchive	/api/programs/438/unarchive	{"params":{"id":"438"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:14.978054+00
3231	1	DELETE /api/programs/438	/api/programs/438	{"params":{"id":"438"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:14.983492+00
3232	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:16.428681+00
3233	1	POST /api/programs/439/versions	/api/programs/439/versions	{"params":{"programId":"439"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:07:16.449367+00
3234	1	DELETE /api/versions/339	/api/versions/339	{"params":{"id":"339"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:16.462383+00
3235	1	DELETE /api/programs/439	/api/programs/439	{"params":{"id":"439"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:16.465515+00
3236	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:21.065671+00
3237	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:21.080382+00
3238	1	DELETE /api/programs/441	/api/programs/441	{"params":{"id":"441"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:21.090804+00
3239	1	DELETE /api/programs/440	/api/programs/440	{"params":{"id":"440"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:21.099782+00
3240	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:23.890017+00
3241	1	POST /api/programs/442/versions	/api/programs/442/versions	{"params":{"programId":"442"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:07:23.897352+00
3242	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:29.720125+00
3243	1	POST /api/programs/443/archive	/api/programs/443/archive	{"params":{"id":"443"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:29.725568+00
3244	1	POST /api/programs/443/unarchive	/api/programs/443/unarchive	{"params":{"id":"443"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:29.744832+00
3245	1	DELETE /api/programs/443	/api/programs/443	{"params":{"id":"443"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:29.755187+00
3246	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:07:30.65504+00
3247	1	POST /api/programs/444/versions	/api/programs/444/versions	{"params":{"programId":"444"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:07:30.665548+00
3248	1	PUT /api/versions/341	/api/versions/341	{"params":{"id":"341"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:07:34.509598+00
3249	1	PUT /api/versions/341	/api/versions/341	{"params":{"id":"341"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:07:35.33317+00
3250	1	PUT /api/versions/341	/api/versions/341	{"params":{"id":"341"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:07:36.241678+00
3251	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:38.039997+00
3252	1	DELETE /api/objectives/181	/api/objectives/181	{"params":{"id":"181"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:39.653226+00
3253	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:40.478781+00
3254	1	PUT /api/objectives/182	/api/objectives/182	{"params":{"id":"182"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:07:40.491131+00
3255	1	DELETE /api/objectives/182	/api/objectives/182	{"params":{"id":"182"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:40.503539+00
3256	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:41.319633+00
3257	1	DELETE /api/objectives/183	/api/objectives/183	{"params":{"id":"183"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:41.330207+00
3258	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:42.241593+00
3259	1	DELETE /api/objectives/184	/api/objectives/184	{"params":{"id":"184"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:42.248304+00
3260	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:43.082245+00
3261	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:43.093002+00
3262	1	DELETE /api/objectives/186	/api/objectives/186	{"params":{"id":"186"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:43.09887+00
3263	1	DELETE /api/objectives/185	/api/objectives/185	{"params":{"id":"185"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:43.108225+00
3264	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:43.953999+00
3265	1	DELETE /api/plos/242	/api/plos/242	{"params":{"id":"242"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:43.966174+00
3266	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:44.801991+00
3267	1	PUT /api/plos/243	/api/plos/243	{"params":{"id":"243"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:07:44.810876+00
3268	1	DELETE /api/plos/243	/api/plos/243	{"params":{"id":"243"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:44.820807+00
3269	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:45.69625+00
3270	1	DELETE /api/plos/244	/api/plos/244	{"params":{"id":"244"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:45.706808+00
3271	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:46.533786+00
3272	1	DELETE /api/plos/245	/api/plos/245	{"params":{"id":"245"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:46.541695+00
3273	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:47.36584+00
3274	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:47.376422+00
3275	1	DELETE /api/plos/247	/api/plos/247	{"params":{"id":"247"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:47.383698+00
3276	1	DELETE /api/plos/246	/api/plos/246	{"params":{"id":"246"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:47.392877+00
3277	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:48.212307+00
3278	1	POST /api/plos/248/pis	/api/plos/248/pis	{"params":{"ploId":"248"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:07:48.223623+00
3279	1	DELETE /api/pis/330	/api/pis/330	{"params":{"id":"330"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:48.237324+00
3280	1	DELETE /api/plos/248	/api/plos/248	{"params":{"id":"248"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:48.241294+00
3281	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:49.084007+00
3282	1	POST /api/plos/249/pis	/api/plos/249/pis	{"params":{"ploId":"249"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:07:49.095763+00
3283	1	PUT /api/pis/331	/api/pis/331	{"params":{"id":"331"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:07:49.109138+00
3284	1	DELETE /api/pis/331	/api/pis/331	{"params":{"id":"331"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:49.118155+00
3285	1	DELETE /api/plos/249	/api/plos/249	{"params":{"id":"249"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:49.122288+00
3298	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:53.366523+00
3299	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:53.371965+00
3300	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:53.377347+00
3301	1	PUT /api/versions/341/po-plo-map	/api/versions/341/po-plo-map	{"params":{"vId":"341"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:07:53.392097+00
3302	1	DELETE /api/objectives/188	/api/objectives/188	{"params":{"id":"188"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:53.39987+00
3303	1	DELETE /api/objectives/189	/api/objectives/189	{"params":{"id":"189"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:53.40344+00
3304	1	DELETE /api/plos/253	/api/plos/253	{"params":{"id":"253"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:53.407299+00
3307	1	POST /api/versions/341/knowledge-blocks	/api/versions/341/knowledge-blocks	{"params":{"vId":"341"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:07:56.749756+00
3308	1	POST /api/versions/341/knowledge-blocks	/api/versions/341/knowledge-blocks	{"params":{"vId":"341"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:07:56.756358+00
3309	1	POST /api/versions/341/knowledge-blocks	/api/versions/341/knowledge-blocks	{"params":{"vId":"341"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:07:56.762204+00
3310	1	DELETE /api/knowledge-blocks/1819	/api/knowledge-blocks/1819	{"params":{"id":"1819"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:56.767016+00
3286	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:49.931677+00
3287	1	POST /api/plos/250/pis	/api/plos/250/pis	{"params":{"ploId":"250"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:07:49.942365+00
3288	1	DELETE /api/pis/332	/api/pis/332	{"params":{"id":"332"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:49.95675+00
3289	1	DELETE /api/plos/250	/api/plos/250	{"params":{"id":"250"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:49.964809+00
3306	1	POST /api/versions/341/knowledge-blocks	/api/versions/341/knowledge-blocks	{"params":{"vId":"341"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:07:55.170679+00
3318	1	POST /api/versions/341/courses	/api/versions/341/courses	{"params":{"vId":"341"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:08:00.212614+00
3319	1	PUT /api/version-courses/924	/api/version-courses/924	{"params":{"id":"924"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 10:08:00.218566+00
3320	1	DELETE /api/version-courses/924	/api/version-courses/924	{"params":{"id":"924"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:00.224571+00
3290	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:50.793792+00
3291	1	DELETE /api/plos/251	/api/plos/251	{"params":{"id":"251"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:50.818712+00
3321	1	PUT /api/versions/341/course-plo-map	/api/versions/341/course-plo-map	{"params":{"vId":"341"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:08:01.85711+00
3292	1	POST /api/versions/341/objectives	/api/versions/341/objectives	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:51.743087+00
3293	1	POST /api/versions/341/plos	/api/versions/341/plos	{"params":{"vId":"341"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:07:51.749686+00
3294	1	PUT /api/versions/341/po-plo-map	/api/versions/341/po-plo-map	{"params":{"vId":"341"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:07:51.760404+00
3295	1	DELETE /api/objectives/187	/api/objectives/187	{"params":{"id":"187"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:51.767922+00
3296	1	DELETE /api/plos/252	/api/plos/252	{"params":{"id":"252"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:51.771848+00
3315	1	POST /api/versions/341/courses	/api/versions/341/courses	{"params":{"vId":"341"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:07:59.299638+00
3316	1	POST /api/versions/341/courses	/api/versions/341/courses	{"params":{"vId":"341"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:07:59.305054+00
3317	1	DELETE /api/version-courses/922	/api/version-courses/922	{"params":{"id":"922"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:59.311066+00
3297	1	PUT /api/versions/341/po-plo-map	/api/versions/341/po-plo-map	{"params":{"vId":"341"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:07:52.54137+00
3311	1	POST /api/versions/341/courses	/api/versions/341/courses	{"params":{"vId":"341"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:07:57.627803+00
3312	1	DELETE /api/version-courses/920	/api/version-courses/920	{"params":{"id":"920"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:57.636182+00
3305	1	POST /api/versions/341/knowledge-blocks	/api/versions/341/knowledge-blocks	{"params":{"vId":"341"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:07:54.266846+00
3313	1	POST /api/versions/341/courses	/api/versions/341/courses	{"params":{"vId":"341"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:07:58.523308+00
3314	1	DELETE /api/version-courses/921	/api/version-courses/921	{"params":{"id":"921"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:07:58.529616+00
3322	1	PUT /api/versions/341/course-plo-map	/api/versions/341/course-plo-map	{"params":{"vId":"341"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:08:02.638139+00
3323	1	PUT /api/versions/341/course-pi-map	/api/versions/341/course-pi-map	{"params":{"vId":"341"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 10:08:04.207541+00
3324	1	POST /api/versions/341/courses	/api/versions/341/courses	{"params":{"vId":"341"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:08:05.803474+00
3325	1	PUT /api/versions/341/course-relations	/api/versions/341/course-relations	{"params":{"vId":"341"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 10:08:05.809633+00
3326	1	DELETE /api/version-courses/925	/api/version-courses/925	{"params":{"id":"925"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:05.814411+00
3327	1	DELETE /api/versions/341	/api/versions/341	{"params":{"id":"341"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:12.361468+00
3328	1	DELETE /api/programs/444	/api/programs/444	{"params":{"id":"444"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:12.366188+00
3329	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:08:19.65701+00
3330	1	DELETE /api/courses/692	/api/courses/692	{"params":{"id":"692"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:20.750707+00
3331	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:08:22.216343+00
3332	1	PUT /api/courses/693	/api/courses/693	{"params":{"id":"693"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:08:22.226399+00
3333	1	DELETE /api/courses/693	/api/courses/693	{"params":{"id":"693"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:22.23065+00
3334	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:08:26.943308+00
3335	1	DELETE /api/courses/694	/api/courses/694	{"params":{"id":"694"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:26.978125+00
3336	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:08:28.436679+00
3337	1	DELETE /api/courses/696	/api/courses/696	{"params":{"id":"696"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:28.442116+00
3338	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:08:31.208223+00
3339	1	DELETE /api/courses/697	/api/courses/697	{"params":{"id":"697"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:31.213239+00
3340	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:08:46.880364+00
3341	1	POST /api/programs/445/versions	/api/programs/445/versions	{"params":{"programId":"445"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:08:46.888477+00
3342	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:08:46.905481+00
3343	1	DELETE /api/programs/445	/api/programs/445	{"params":{"id":"445"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:46.918553+00
3344	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:08:50.345448+00
3345	1	POST /api/programs/446/versions	/api/programs/446/versions	{"params":{"programId":"446"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:08:50.353199+00
3346	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:08:50.359149+00
3347	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:08:50.371294+00
3348	1	DELETE /api/approval/rejected/program_version/343	/api/approval/rejected/program_version/343	{"params":{"entityType":"program_version","entityId":"343"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:50.383868+00
3349	1	DELETE /api/programs/446	/api/programs/446	{"params":{"id":"446"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:50.390765+00
3350	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:08:51.414713+00
3351	1	POST /api/programs/447/versions	/api/programs/447/versions	{"params":{"programId":"447"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:08:51.422012+00
3352	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:08:51.428256+00
3353	1	DELETE /api/programs/447	/api/programs/447	{"params":{"id":"447"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:51.455022+00
3354	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:08:54.459094+00
3355	1	POST /api/programs/448/versions	/api/programs/448/versions	{"params":{"programId":"448"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:08:54.46559+00
3356	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:08:54.471388+00
3357	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:08:54.485347+00
3358	1	DELETE /api/versions/345	/api/versions/345	{"params":{"id":"345"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:54.497906+00
3359	1	DELETE /api/programs/448	/api/programs/448	{"params":{"id":"448"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:54.50235+00
3360	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:08:59.26875+00
3361	1	DELETE /api/users/162	/api/users/162	{"params":{"id":"162"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:08:59.28107+00
3362	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:01.221577+00
3363	1	PUT /api/users/163	/api/users/163	{"params":{"id":"163"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 10:09:01.229379+00
3364	1	DELETE /api/users/163	/api/users/163	{"params":{"id":"163"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:01.238126+00
3365	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:03.212064+00
3366	1	POST /api/users/164/roles	/api/users/164/roles	{"params":{"id":"164"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:09:03.229303+00
3367	1	DELETE /api/users/164	/api/users/164	{"params":{"id":"164"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:03.240592+00
3368	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:05.202539+00
3369	1	POST /api/users/165/roles	/api/users/165/roles	{"params":{"id":"165"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:09:05.215968+00
3370	1	DELETE /api/users/165/roles/GIANG_VIEN/5	/api/users/165/roles/GIANG_VIEN/5	{"params":{"userId":"165","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:05.228157+00
3371	1	DELETE /api/users/165	/api/users/165	{"params":{"id":"165"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:05.237054+00
3372	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:09.134546+00
3373	1	DELETE /api/users/167	/api/users/167	{"params":{"id":"167"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:09.142457+00
3374	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:11.101153+00
3386	1	DELETE /api/roles/612	/api/roles/612	{"params":{"id":"612"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:38.108544+00
3387	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 10:09:43.934187+00
3390	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:09:50.200646+00
3391	1	PUT /api/roles/615	/api/roles/615	{"params":{"id":"615"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:09:50.205133+00
3392	1	DELETE /api/roles/615	/api/roles/615	{"params":{"id":"615"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:50.208395+00
3419	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:54.179389+00
3420	1	POST /api/programs/454/versions	/api/programs/454/versions	{"params":{"programId":"454"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:10:54.19106+00
3421	1	DELETE /api/versions/347	/api/versions/347	{"params":{"id":"347"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:54.204516+00
3422	1	DELETE /api/programs/454	/api/programs/454	{"params":{"id":"454"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:54.208095+00
3427	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:11:01.930712+00
3428	1	POST /api/programs/457/versions	/api/programs/457/versions	{"params":{"programId":"457"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:11:01.93795+00
3375	1	DELETE /api/users/168	/api/users/168	{"params":{"id":"168"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:11.186046+00
3376	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:13.217312+00
3377	1	DELETE /api/users/170	/api/users/170	{"params":{"id":"170"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:13.23108+00
3378	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:15.19781+00
3379	1	PUT /api/users/171/toggle-active	/api/users/171/toggle-active	{"params":{"id":"171"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:15.205299+00
3380	1	DELETE /api/users/171	/api/users/171	{"params":{"id":"171"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:15.213946+00
3383	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:09:27.569532+00
3384	1	DELETE /api/roles/610	/api/roles/610	{"params":{"id":"610"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:27.575842+00
3388	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:09:48.135274+00
3389	1	DELETE /api/roles/614	/api/roles/614	{"params":{"id":"614"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:48.139948+00
3393	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:09:53.642458+00
3394	1	DELETE /api/departments/2022	/api/departments/2022	{"params":{"id":"2022"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:53.654378+00
3401	1	DELETE /api/departments/2026	/api/departments/2026	{"params":{"id":"2026"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:57.0843+00
3410	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:47.382204+00
3411	1	PUT /api/programs/451	/api/programs/451	{"params":{"id":"451"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:10:48.763134+00
3412	1	DELETE /api/programs/451	/api/programs/451	{"params":{"id":"451"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:48.849088+00
3381	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:09:17.073407+00
3382	1	DELETE /api/users/172	/api/users/172	{"params":{"id":"172"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:17.081668+00
3385	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:09:38.08813+00
3395	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:09:54.492722+00
3396	1	PUT /api/departments/2023	/api/departments/2023	{"params":{"id":"2023"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:09:54.498362+00
3397	1	DELETE /api/departments/2023	/api/departments/2023	{"params":{"id":"2023"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:54.50332+00
3402	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:09:58.834299+00
3403	1	DELETE /api/departments/2028	/api/departments/2028	{"params":{"id":"2028"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:58.838928+00
3404	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:20.255239+00
3405	1	POST /api/programs/449/versions	/api/programs/449/versions	{"params":{"programId":"449"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:10:20.263349+00
3406	1	DELETE /api/versions/346	/api/versions/346	{"params":{"id":"346"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:20.269716+00
3407	1	DELETE /api/programs/449	/api/programs/449	{"params":{"id":"449"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:20.273055+00
3408	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:10:45.779648+00
3409	1	DELETE /api/programs/450	/api/programs/450	{"params":{"id":"450"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:45.967157+00
3398	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 10:09:55.363002+00
3399	1	DELETE /api/departments/2024	/api/departments/2024	{"params":{"id":"2024"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:09:55.368754+00
3400	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:09:57.07195+00
3413	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:50.262363+00
3414	1	DELETE /api/programs/452	/api/programs/452	{"params":{"id":"452"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:50.275499+00
3415	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:51.645476+00
3416	1	POST /api/programs/453/archive	/api/programs/453/archive	{"params":{"id":"453"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:51.658253+00
3417	1	POST /api/programs/453/unarchive	/api/programs/453/unarchive	{"params":{"id":"453"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:52.784256+00
3418	1	DELETE /api/programs/453	/api/programs/453	{"params":{"id":"453"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:52.788909+00
3423	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:58.999974+00
3424	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:10:59.025344+00
3425	1	DELETE /api/programs/456	/api/programs/456	{"params":{"id":"456"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:59.030698+00
3426	1	DELETE /api/programs/455	/api/programs/455	{"params":{"id":"455"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:10:59.048118+00
3429	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:11:07.90206+00
3430	1	POST /api/programs/458/archive	/api/programs/458/archive	{"params":{"id":"458"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:07.906882+00
3431	1	POST /api/programs/458/unarchive	/api/programs/458/unarchive	{"params":{"id":"458"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:07.91886+00
3432	1	DELETE /api/programs/458	/api/programs/458	{"params":{"id":"458"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:07.93101+00
3433	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:11:08.899672+00
3434	1	POST /api/programs/459/versions	/api/programs/459/versions	{"params":{"programId":"459"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:11:08.909942+00
3435	1	PUT /api/versions/349	/api/versions/349	{"params":{"id":"349"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:11:12.836869+00
3436	1	PUT /api/versions/349	/api/versions/349	{"params":{"id":"349"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:11:13.786136+00
3437	1	PUT /api/versions/349	/api/versions/349	{"params":{"id":"349"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:11:14.611286+00
3438	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:16.485017+00
3439	1	DELETE /api/objectives/190	/api/objectives/190	{"params":{"id":"190"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:18.090333+00
3440	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:18.998102+00
3441	1	PUT /api/objectives/191	/api/objectives/191	{"params":{"id":"191"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:11:19.010324+00
3442	1	DELETE /api/objectives/191	/api/objectives/191	{"params":{"id":"191"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:19.023012+00
3443	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:19.987771+00
3444	1	DELETE /api/objectives/192	/api/objectives/192	{"params":{"id":"192"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:19.998036+00
3445	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:20.843835+00
3446	1	DELETE /api/objectives/193	/api/objectives/193	{"params":{"id":"193"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:20.848942+00
3447	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:21.801284+00
3448	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:21.809505+00
3449	1	DELETE /api/objectives/195	/api/objectives/195	{"params":{"id":"195"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:21.814271+00
3450	1	DELETE /api/objectives/194	/api/objectives/194	{"params":{"id":"194"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:21.82685+00
3451	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:22.737422+00
3452	1	DELETE /api/plos/254	/api/plos/254	{"params":{"id":"254"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:22.751361+00
3453	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:23.601896+00
3454	1	PUT /api/plos/255	/api/plos/255	{"params":{"id":"255"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:11:23.612741+00
3455	1	DELETE /api/plos/255	/api/plos/255	{"params":{"id":"255"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:23.627404+00
3456	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:24.535971+00
3457	1	DELETE /api/plos/256	/api/plos/256	{"params":{"id":"256"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:24.549817+00
3458	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:25.425791+00
3459	1	DELETE /api/plos/257	/api/plos/257	{"params":{"id":"257"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:25.434052+00
3460	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:26.307073+00
3461	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:26.315019+00
3462	1	DELETE /api/plos/259	/api/plos/259	{"params":{"id":"259"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:26.320498+00
3463	1	DELETE /api/plos/258	/api/plos/258	{"params":{"id":"258"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:26.331822+00
3464	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:27.158449+00
3465	1	POST /api/plos/260/pis	/api/plos/260/pis	{"params":{"ploId":"260"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:11:27.167948+00
3466	1	DELETE /api/pis/334	/api/pis/334	{"params":{"id":"334"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:27.183818+00
3467	1	DELETE /api/plos/260	/api/plos/260	{"params":{"id":"260"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:27.188981+00
3468	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:28.004403+00
3469	1	POST /api/plos/261/pis	/api/plos/261/pis	{"params":{"ploId":"261"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:11:28.017483+00
3470	1	PUT /api/pis/335	/api/pis/335	{"params":{"id":"335"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:11:28.02908+00
3471	1	DELETE /api/pis/335	/api/pis/335	{"params":{"id":"335"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:28.03782+00
3472	1	DELETE /api/plos/261	/api/plos/261	{"params":{"id":"261"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:28.041657+00
3485	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:32.441634+00
3486	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:32.447915+00
3487	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:32.45422+00
3488	1	PUT /api/versions/349/po-plo-map	/api/versions/349/po-plo-map	{"params":{"vId":"349"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:11:32.467766+00
3489	1	DELETE /api/objectives/197	/api/objectives/197	{"params":{"id":"197"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:32.475839+00
3490	1	DELETE /api/objectives/198	/api/objectives/198	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:32.480083+00
3491	1	DELETE /api/plos/265	/api/plos/265	{"params":{"id":"265"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:32.484098+00
3511	1	POST /api/versions/349/courses	/api/versions/349/courses	{"params":{"vId":"349"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:11:44.614927+00
3512	1	PUT /api/versions/349/course-relations	/api/versions/349/course-relations	{"params":{"vId":"349"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 10:11:44.621244+00
3513	1	DELETE /api/version-courses/931	/api/version-courses/931	{"params":{"id":"931"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:44.626727+00
3473	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:28.982149+00
3474	1	POST /api/plos/262/pis	/api/plos/262/pis	{"params":{"ploId":"262"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:11:28.99282+00
3475	1	DELETE /api/pis/336	/api/pis/336	{"params":{"id":"336"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:29.007382+00
3476	1	DELETE /api/plos/262	/api/plos/262	{"params":{"id":"262"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:29.01588+00
3492	1	POST /api/versions/349/knowledge-blocks	/api/versions/349/knowledge-blocks	{"params":{"vId":"349"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:11:33.236515+00
3502	1	POST /api/versions/349/courses	/api/versions/349/courses	{"params":{"vId":"349"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:11:38.357666+00
3503	1	POST /api/versions/349/courses	/api/versions/349/courses	{"params":{"vId":"349"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:11:38.362217+00
3504	1	DELETE /api/version-courses/928	/api/version-courses/928	{"params":{"id":"928"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:38.367349+00
3575	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:13:25.970758+00
3576	1	DELETE /api/roles/626	/api/roles/626	{"params":{"id":"626"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:25.975763+00
3477	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:29.846923+00
3478	1	DELETE /api/plos/263	/api/plos/263	{"params":{"id":"263"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:29.872046+00
3493	1	POST /api/versions/349/knowledge-blocks	/api/versions/349/knowledge-blocks	{"params":{"vId":"349"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:11:34.152248+00
3500	1	POST /api/versions/349/courses	/api/versions/349/courses	{"params":{"vId":"349"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:11:37.548503+00
3501	1	DELETE /api/version-courses/927	/api/version-courses/927	{"params":{"id":"927"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:37.556538+00
3509	1	PUT /api/versions/349/course-plo-map	/api/versions/349/course-plo-map	{"params":{"vId":"349"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:11:41.512353+00
3547	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:37.563012+00
3548	1	DELETE /api/users/173	/api/users/173	{"params":{"id":"173"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:37.576969+00
3555	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:43.5586+00
3556	1	POST /api/users/176/roles	/api/users/176/roles	{"params":{"id":"176"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:12:43.571554+00
3557	1	DELETE /api/users/176/roles/GIANG_VIEN/5	/api/users/176/roles/GIANG_VIEN/5	{"params":{"userId":"176","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:43.583671+00
3558	1	DELETE /api/users/176	/api/users/176	{"params":{"id":"176"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:43.593416+00
3479	1	POST /api/versions/349/objectives	/api/versions/349/objectives	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:30.692199+00
3480	1	POST /api/versions/349/plos	/api/versions/349/plos	{"params":{"vId":"349"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:11:30.698173+00
3481	1	PUT /api/versions/349/po-plo-map	/api/versions/349/po-plo-map	{"params":{"vId":"349"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:11:30.708218+00
3482	1	DELETE /api/objectives/196	/api/objectives/196	{"params":{"id":"196"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:30.717232+00
3483	1	DELETE /api/plos/264	/api/plos/264	{"params":{"id":"264"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:30.721376+00
3510	1	PUT /api/versions/349/course-pi-map	/api/versions/349/course-pi-map	{"params":{"vId":"349"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 10:11:43.049318+00
3514	1	DELETE /api/versions/349	/api/versions/349	{"params":{"id":"349"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:51.059322+00
3515	1	DELETE /api/programs/459	/api/programs/459	{"params":{"id":"459"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:51.063587+00
3518	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:12:00.740222+00
3519	1	PUT /api/courses/699	/api/courses/699	{"params":{"id":"699"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:12:00.745547+00
3520	1	DELETE /api/courses/699	/api/courses/699	{"params":{"id":"699"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:00.75049+00
3549	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:39.626845+00
3550	1	PUT /api/users/174	/api/users/174	{"params":{"id":"174"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 10:12:39.63752+00
3551	1	DELETE /api/users/174	/api/users/174	{"params":{"id":"174"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:39.651723+00
3484	1	PUT /api/versions/349/po-plo-map	/api/versions/349/po-plo-map	{"params":{"vId":"349"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:11:31.599833+00
3494	1	POST /api/versions/349/knowledge-blocks	/api/versions/349/knowledge-blocks	{"params":{"vId":"349"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:11:35.773812+00
3495	1	POST /api/versions/349/knowledge-blocks	/api/versions/349/knowledge-blocks	{"params":{"vId":"349"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:11:35.780786+00
3496	1	POST /api/versions/349/knowledge-blocks	/api/versions/349/knowledge-blocks	{"params":{"vId":"349"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:11:35.786405+00
3497	1	DELETE /api/knowledge-blocks/1864	/api/knowledge-blocks/1864	{"params":{"id":"1864"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:35.791638+00
3505	1	POST /api/versions/349/courses	/api/versions/349/courses	{"params":{"vId":"349"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:11:39.14777+00
3506	1	PUT /api/version-courses/930	/api/version-courses/930	{"params":{"id":"930"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 10:11:39.153712+00
3507	1	DELETE /api/version-courses/930	/api/version-courses/930	{"params":{"id":"930"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:39.159176+00
3516	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:11:58.234624+00
3517	1	DELETE /api/courses/698	/api/courses/698	{"params":{"id":"698"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:59.360995+00
3522	1	DELETE /api/courses/700	/api/courses/700	{"params":{"id":"700"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:05.519558+00
3525	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:12:09.825385+00
3526	1	DELETE /api/courses/703	/api/courses/703	{"params":{"id":"703"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:09.831897+00
3531	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:12:29.207889+00
3532	1	POST /api/programs/461/versions	/api/programs/461/versions	{"params":{"programId":"461"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:12:29.215782+00
3533	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:12:29.221771+00
3534	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:12:29.233331+00
3535	1	DELETE /api/approval/rejected/program_version/351	/api/approval/rejected/program_version/351	{"params":{"entityType":"program_version","entityId":"351"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:29.242549+00
3536	1	DELETE /api/programs/461	/api/programs/461	{"params":{"id":"461"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:29.24838+00
3541	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:12:32.773176+00
3542	1	POST /api/programs/463/versions	/api/programs/463/versions	{"params":{"programId":"463"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:12:32.779967+00
3543	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:12:32.784989+00
3544	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:12:32.799037+00
3545	1	DELETE /api/versions/353	/api/versions/353	{"params":{"id":"353"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:32.807458+00
3546	1	DELETE /api/programs/463	/api/programs/463	{"params":{"id":"463"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:32.810479+00
3561	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:49.423226+00
3498	1	POST /api/versions/349/courses	/api/versions/349/courses	{"params":{"vId":"349"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:11:36.692349+00
3499	1	DELETE /api/version-courses/926	/api/version-courses/926	{"params":{"id":"926"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:11:36.69948+00
3508	1	PUT /api/versions/349/course-plo-map	/api/versions/349/course-plo-map	{"params":{"vId":"349"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:11:40.728825+00
3521	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:12:05.484296+00
3523	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:12:06.89361+00
3524	1	DELETE /api/courses/702	/api/courses/702	{"params":{"id":"702"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:06.902043+00
3527	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:12:26.030716+00
3528	1	POST /api/programs/460/versions	/api/programs/460/versions	{"params":{"programId":"460"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:12:26.039408+00
3529	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:12:26.055952+00
3530	1	DELETE /api/programs/460	/api/programs/460	{"params":{"id":"460"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:26.070849+00
3537	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:12:30.057253+00
3538	1	POST /api/programs/462/versions	/api/programs/462/versions	{"params":{"programId":"462"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:12:30.064168+00
3539	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:12:30.069771+00
3540	1	DELETE /api/programs/462	/api/programs/462	{"params":{"id":"462"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:30.087745+00
3552	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:41.593545+00
3553	1	POST /api/users/175/roles	/api/users/175/roles	{"params":{"id":"175"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:12:41.610546+00
3554	1	DELETE /api/users/175	/api/users/175	{"params":{"id":"175"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:41.6195+00
3559	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:47.459226+00
3560	1	DELETE /api/users/178	/api/users/178	{"params":{"id":"178"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:47.467677+00
3562	1	DELETE /api/users/179	/api/users/179	{"params":{"id":"179"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:49.509705+00
3563	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:51.433617+00
3564	1	DELETE /api/users/181	/api/users/181	{"params":{"id":"181"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:51.448427+00
3565	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:53.39581+00
3566	1	PUT /api/users/182/toggle-active	/api/users/182/toggle-active	{"params":{"id":"182"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:53.407503+00
3567	1	DELETE /api/users/182	/api/users/182	{"params":{"id":"182"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:53.419848+00
3568	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:12:55.375845+00
3569	1	DELETE /api/users/183	/api/users/183	{"params":{"id":"183"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:12:55.384021+00
3570	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:13:05.845712+00
3571	1	DELETE /api/roles/622	/api/roles/622	{"params":{"id":"622"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:05.851523+00
3572	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:13:16.37681+00
3573	1	DELETE /api/roles/624	/api/roles/624	{"params":{"id":"624"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:16.401437+00
3574	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 10:13:21.977056+00
3577	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:13:27.862113+00
3578	1	PUT /api/roles/627	/api/roles/627	{"params":{"id":"627"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:13:27.867223+00
3579	1	DELETE /api/roles/627	/api/roles/627	{"params":{"id":"627"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:27.871872+00
3580	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:13:31.039915+00
3581	1	DELETE /api/departments/2051	/api/departments/2051	{"params":{"id":"2051"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:31.045416+00
3582	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:13:31.883583+00
3583	1	PUT /api/departments/2052	/api/departments/2052	{"params":{"id":"2052"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:13:31.888928+00
3584	1	DELETE /api/departments/2052	/api/departments/2052	{"params":{"id":"2052"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:31.894069+00
3585	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 10:13:32.737553+00
3586	1	DELETE /api/departments/2053	/api/departments/2053	{"params":{"id":"2053"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:32.743285+00
3587	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:13:34.295755+00
3588	1	DELETE /api/departments/2055	/api/departments/2055	{"params":{"id":"2055"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:34.30892+00
3589	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:13:36.099165+00
3590	1	DELETE /api/departments/2057	/api/departments/2057	{"params":{"id":"2057"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:36.104729+00
3591	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:13:57.58343+00
3592	1	POST /api/programs/464/versions	/api/programs/464/versions	{"params":{"programId":"464"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:13:57.592173+00
3593	1	DELETE /api/versions/354	/api/versions/354	{"params":{"id":"354"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:57.608058+00
3594	1	DELETE /api/programs/464	/api/programs/464	{"params":{"id":"464"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:13:57.612067+00
3595	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:15:01.532121+00
3596	1	DELETE /api/programs/465	/api/programs/465	{"params":{"id":"465"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:01.620363+00
3597	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:03.154212+00
3835	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:12.470988+00
3598	1	PUT /api/programs/466	/api/programs/466	{"params":{"id":"466"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-04 10:15:04.520152+00
3599	1	DELETE /api/programs/466	/api/programs/466	{"params":{"id":"466"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:04.610621+00
3600	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:06.050416+00
3601	1	DELETE /api/programs/467	/api/programs/467	{"params":{"id":"467"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:06.064563+00
3602	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:07.558185+00
3603	1	POST /api/programs/468/archive	/api/programs/468/archive	{"params":{"id":"468"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:07.570579+00
3604	1	POST /api/programs/468/unarchive	/api/programs/468/unarchive	{"params":{"id":"468"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:08.668008+00
3605	1	DELETE /api/programs/468	/api/programs/468	{"params":{"id":"468"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:08.672696+00
3606	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:10.052947+00
3607	1	POST /api/programs/469/versions	/api/programs/469/versions	{"params":{"programId":"469"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:15:10.068883+00
3608	1	DELETE /api/versions/355	/api/versions/355	{"params":{"id":"355"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:10.082383+00
3609	1	DELETE /api/programs/469	/api/programs/469	{"params":{"id":"469"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:10.086163+00
3610	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:14.657452+00
3611	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:14.673902+00
3612	1	DELETE /api/programs/471	/api/programs/471	{"params":{"id":"471"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:14.682693+00
3613	1	DELETE /api/programs/470	/api/programs/470	{"params":{"id":"470"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:14.692611+00
3614	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:17.628294+00
3615	1	POST /api/programs/472/versions	/api/programs/472/versions	{"params":{"programId":"472"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:15:17.637182+00
3616	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:22.132642+00
3617	1	DELETE /api/programs/473	/api/programs/473	{"params":{"id":"473"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:23.207607+00
3618	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:25.997127+00
3619	1	POST /api/programs/474/archive	/api/programs/474/archive	{"params":{"id":"474"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:26.000773+00
3620	1	POST /api/programs/474/unarchive	/api/programs/474/unarchive	{"params":{"id":"474"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:26.009625+00
3621	1	DELETE /api/programs/474	/api/programs/474	{"params":{"id":"474"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:26.019039+00
3622	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:15:26.849466+00
3623	1	POST /api/programs/475/versions	/api/programs/475/versions	{"params":{"programId":"475"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:15:26.859338+00
3624	1	PUT /api/versions/357	/api/versions/357	{"params":{"id":"357"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:15:30.633614+00
3625	1	PUT /api/versions/357	/api/versions/357	{"params":{"id":"357"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:15:31.575359+00
3626	1	PUT /api/versions/357	/api/versions/357	{"params":{"id":"357"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:15:32.411617+00
3627	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:34.251394+00
3628	1	DELETE /api/objectives/199	/api/objectives/199	{"params":{"id":"199"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:35.868716+00
3629	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:36.695462+00
3630	1	PUT /api/objectives/200	/api/objectives/200	{"params":{"id":"200"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:15:36.706051+00
3631	1	DELETE /api/objectives/200	/api/objectives/200	{"params":{"id":"200"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:36.719733+00
3632	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:37.625218+00
3633	1	DELETE /api/objectives/201	/api/objectives/201	{"params":{"id":"201"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:37.636483+00
3634	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:38.46333+00
3635	1	DELETE /api/objectives/202	/api/objectives/202	{"params":{"id":"202"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:38.469316+00
3636	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:39.363397+00
3637	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:39.373599+00
3638	1	DELETE /api/objectives/204	/api/objectives/204	{"params":{"id":"204"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:39.379709+00
3639	1	DELETE /api/objectives/203	/api/objectives/203	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:39.38835+00
3640	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:40.212022+00
3641	1	DELETE /api/plos/266	/api/plos/266	{"params":{"id":"266"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:40.224789+00
3642	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:41.080629+00
3643	1	PUT /api/plos/267	/api/plos/267	{"params":{"id":"267"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:15:41.091877+00
3644	1	DELETE /api/plos/267	/api/plos/267	{"params":{"id":"267"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:41.105169+00
3645	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:42.021818+00
3646	1	DELETE /api/plos/268	/api/plos/268	{"params":{"id":"268"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:42.03471+00
3647	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:42.958119+00
3648	1	DELETE /api/plos/269	/api/plos/269	{"params":{"id":"269"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:42.965726+00
4144	1	DELETE /api/pis/347	/api/pis/347	{"params":{"id":"347"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:42.860113+00
3649	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:43.794255+00
3650	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:43.804568+00
3651	1	DELETE /api/plos/271	/api/plos/271	{"params":{"id":"271"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:43.812398+00
3652	1	DELETE /api/plos/270	/api/plos/270	{"params":{"id":"270"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:43.826711+00
3687	1	POST /api/versions/357/courses	/api/versions/357/courses	{"params":{"vId":"357"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:15:53.842279+00
3688	1	DELETE /api/version-courses/932	/api/version-courses/932	{"params":{"id":"932"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:53.847647+00
3714	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:16:27.156617+00
3715	1	DELETE /api/courses/709	/api/courses/709	{"params":{"id":"709"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:27.163427+00
3720	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:16:46.464909+00
3721	1	POST /api/programs/477/versions	/api/programs/477/versions	{"params":{"programId":"477"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:16:46.473115+00
3722	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:16:46.478536+00
3723	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:16:46.490376+00
3724	1	DELETE /api/approval/rejected/program_version/359	/api/approval/rejected/program_version/359	{"params":{"entityType":"program_version","entityId":"359"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:46.49897+00
3725	1	DELETE /api/programs/477	/api/programs/477	{"params":{"id":"477"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:46.504903+00
3730	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:16:50.491688+00
3731	1	POST /api/programs/479/versions	/api/programs/479/versions	{"params":{"programId":"479"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:16:50.498972+00
3732	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:16:50.504131+00
3733	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-04 10:16:50.517413+00
3734	1	DELETE /api/versions/361	/api/versions/361	{"params":{"id":"361"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:50.525261+00
3735	1	DELETE /api/programs/479	/api/programs/479	{"params":{"id":"479"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:50.528133+00
3741	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:16:59.338109+00
3742	1	POST /api/users/186/roles	/api/users/186/roles	{"params":{"id":"186"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:16:59.363103+00
3743	1	DELETE /api/users/186	/api/users/186	{"params":{"id":"186"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:59.372001+00
3653	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:44.62606+00
3654	1	POST /api/plos/272/pis	/api/plos/272/pis	{"params":{"ploId":"272"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:15:44.638888+00
3655	1	DELETE /api/pis/338	/api/pis/338	{"params":{"id":"338"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:44.65123+00
3656	1	DELETE /api/plos/272	/api/plos/272	{"params":{"id":"272"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:44.655994+00
3673	1	PUT /api/versions/357/po-plo-map	/api/versions/357/po-plo-map	{"params":{"vId":"357"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:15:48.89675+00
3698	1	PUT /api/versions/357/course-plo-map	/api/versions/357/course-plo-map	{"params":{"vId":"357"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:15:58.769127+00
3700	1	POST /api/versions/357/courses	/api/versions/357/courses	{"params":{"vId":"357"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:16:02.062597+00
3701	1	PUT /api/versions/357/course-relations	/api/versions/357/course-relations	{"params":{"vId":"357"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-04 10:16:02.068801+00
3702	1	DELETE /api/version-courses/937	/api/version-courses/937	{"params":{"id":"937"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:02.075437+00
3707	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:16:18.354563+00
3708	1	PUT /api/courses/705	/api/courses/705	{"params":{"id":"705"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:16:18.358983+00
3709	1	DELETE /api/courses/705	/api/courses/705	{"params":{"id":"705"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:18.363018+00
3738	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:16:57.321559+00
3739	1	PUT /api/users/185	/api/users/185	{"params":{"id":"185"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-04 10:16:57.329868+00
3740	1	DELETE /api/users/185	/api/users/185	{"params":{"id":"185"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:57.337989+00
3657	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:45.492207+00
3658	1	POST /api/plos/273/pis	/api/plos/273/pis	{"params":{"ploId":"273"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:15:45.504086+00
3659	1	PUT /api/pis/339	/api/pis/339	{"params":{"id":"339"},"bodyKeys":["description"]}	172.18.0.1	2026-04-04 10:15:45.517341+00
3660	1	DELETE /api/pis/339	/api/pis/339	{"params":{"id":"339"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:45.527275+00
3661	1	DELETE /api/plos/273	/api/plos/273	{"params":{"id":"273"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:45.530921+00
3681	1	POST /api/versions/357/knowledge-blocks	/api/versions/357/knowledge-blocks	{"params":{"vId":"357"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:15:50.611284+00
3744	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:17:01.275049+00
3745	1	POST /api/users/187/roles	/api/users/187/roles	{"params":{"id":"187"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-04 10:17:01.285371+00
3746	1	DELETE /api/users/187/roles/GIANG_VIEN/5	/api/users/187/roles/GIANG_VIEN/5	{"params":{"userId":"187","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:01.293049+00
3747	1	DELETE /api/users/187	/api/users/187	{"params":{"id":"187"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:01.302207+00
3662	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:46.342327+00
3663	1	POST /api/plos/274/pis	/api/plos/274/pis	{"params":{"ploId":"274"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-04 10:15:46.352618+00
3664	1	DELETE /api/pis/340	/api/pis/340	{"params":{"id":"340"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:46.36738+00
3665	1	DELETE /api/plos/274	/api/plos/274	{"params":{"id":"274"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:46.378508+00
3674	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:49.745925+00
3675	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:49.75179+00
3676	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:49.757386+00
3677	1	PUT /api/versions/357/po-plo-map	/api/versions/357/po-plo-map	{"params":{"vId":"357"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:15:49.771585+00
3678	1	DELETE /api/objectives/206	/api/objectives/206	{"params":{"id":"206"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:49.778994+00
3679	1	DELETE /api/objectives/207	/api/objectives/207	{"params":{"id":"207"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:49.782303+00
3680	1	DELETE /api/plos/277	/api/plos/277	{"params":{"id":"277"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:49.785941+00
3689	1	POST /api/versions/357/courses	/api/versions/357/courses	{"params":{"vId":"357"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:15:54.705717+00
3690	1	DELETE /api/version-courses/933	/api/version-courses/933	{"params":{"id":"933"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:54.712583+00
3697	1	PUT /api/versions/357/course-plo-map	/api/versions/357/course-plo-map	{"params":{"vId":"357"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:15:57.984581+00
3705	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:16:15.892884+00
3706	1	DELETE /api/courses/704	/api/courses/704	{"params":{"id":"704"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:17.01146+00
3710	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:16:22.950169+00
3666	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:47.191935+00
3667	1	DELETE /api/plos/275	/api/plos/275	{"params":{"id":"275"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:47.208795+00
3682	1	POST /api/versions/357/knowledge-blocks	/api/versions/357/knowledge-blocks	{"params":{"vId":"357"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:15:51.411509+00
3691	1	POST /api/versions/357/courses	/api/versions/357/courses	{"params":{"vId":"357"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:15:55.515263+00
3692	1	POST /api/versions/357/courses	/api/versions/357/courses	{"params":{"vId":"357"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:15:55.520909+00
3693	1	DELETE /api/version-courses/934	/api/version-courses/934	{"params":{"id":"934"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:55.527515+00
3699	1	PUT /api/versions/357/course-pi-map	/api/versions/357/course-pi-map	{"params":{"vId":"357"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-04 10:16:00.336825+00
3703	1	DELETE /api/versions/357	/api/versions/357	{"params":{"id":"357"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:08.582893+00
3704	1	DELETE /api/programs/475	/api/programs/475	{"params":{"id":"475"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:08.587556+00
3716	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:16:43.209925+00
3717	1	POST /api/programs/476/versions	/api/programs/476/versions	{"params":{"programId":"476"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:16:43.216932+00
3718	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:16:43.225408+00
3719	1	DELETE /api/programs/476	/api/programs/476	{"params":{"id":"476"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:43.237107+00
3726	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:16:47.390827+00
3727	1	POST /api/programs/478/versions	/api/programs/478/versions	{"params":{"programId":"478"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:16:47.398192+00
3728	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-04 10:16:47.40456+00
3729	1	DELETE /api/programs/478	/api/programs/478	{"params":{"id":"478"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:47.422764+00
3668	1	POST /api/versions/357/objectives	/api/versions/357/objectives	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:48.009726+00
3669	1	POST /api/versions/357/plos	/api/versions/357/plos	{"params":{"vId":"357"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-04 10:15:48.015482+00
3670	1	PUT /api/versions/357/po-plo-map	/api/versions/357/po-plo-map	{"params":{"vId":"357"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-04 10:15:48.026326+00
3671	1	DELETE /api/objectives/205	/api/objectives/205	{"params":{"id":"205"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:48.034126+00
3672	1	DELETE /api/plos/276	/api/plos/276	{"params":{"id":"276"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:48.037839+00
3683	1	POST /api/versions/357/knowledge-blocks	/api/versions/357/knowledge-blocks	{"params":{"vId":"357"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-04 10:15:53.011034+00
3684	1	POST /api/versions/357/knowledge-blocks	/api/versions/357/knowledge-blocks	{"params":{"vId":"357"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:15:53.017683+00
3685	1	POST /api/versions/357/knowledge-blocks	/api/versions/357/knowledge-blocks	{"params":{"vId":"357"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-04 10:15:53.023528+00
3686	1	DELETE /api/knowledge-blocks/1909	/api/knowledge-blocks/1909	{"params":{"id":"1909"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:53.02913+00
3694	1	POST /api/versions/357/courses	/api/versions/357/courses	{"params":{"vId":"357"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-04 10:15:56.426598+00
3695	1	PUT /api/version-courses/936	/api/version-courses/936	{"params":{"id":"936"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-04 10:15:56.432998+00
3696	1	DELETE /api/version-courses/936	/api/version-courses/936	{"params":{"id":"936"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:15:56.439574+00
3711	1	DELETE /api/courses/706	/api/courses/706	{"params":{"id":"706"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:22.978284+00
3712	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-04 10:16:24.350782+00
3713	1	DELETE /api/courses/708	/api/courses/708	{"params":{"id":"708"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:24.360119+00
3736	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:16:55.250882+00
3737	1	DELETE /api/users/184	/api/users/184	{"params":{"id":"184"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:16:55.263636+00
3748	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:17:05.240715+00
3749	1	DELETE /api/users/189	/api/users/189	{"params":{"id":"189"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:05.250053+00
3750	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:17:07.218858+00
3751	1	DELETE /api/users/190	/api/users/190	{"params":{"id":"190"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:07.311349+00
3752	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:17:09.266856+00
3753	1	DELETE /api/users/192	/api/users/192	{"params":{"id":"192"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:09.279983+00
3754	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:17:11.231482+00
3755	1	PUT /api/users/193/toggle-active	/api/users/193/toggle-active	{"params":{"id":"193"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:11.241723+00
3756	1	DELETE /api/users/193	/api/users/193	{"params":{"id":"193"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:11.256639+00
3757	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-04 10:17:13.183602+00
3758	1	DELETE /api/users/194	/api/users/194	{"params":{"id":"194"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:13.195168+00
3759	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:17:23.710047+00
3760	1	DELETE /api/roles/634	/api/roles/634	{"params":{"id":"634"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:23.714755+00
3761	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:17:34.240651+00
3762	1	DELETE /api/roles/636	/api/roles/636	{"params":{"id":"636"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:34.265275+00
3763	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-04 10:17:39.871884+00
3764	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:17:43.939809+00
3765	1	DELETE /api/roles/638	/api/roles/638	{"params":{"id":"638"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:43.945202+00
3766	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-04 10:17:45.78153+00
3767	1	PUT /api/roles/639	/api/roles/639	{"params":{"id":"639"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:17:45.786675+00
3768	1	DELETE /api/roles/639	/api/roles/639	{"params":{"id":"639"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:45.791334+00
3769	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:17:49.058355+00
3770	1	DELETE /api/departments/2080	/api/departments/2080	{"params":{"id":"2080"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:49.064432+00
3771	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:17:49.914155+00
3772	1	PUT /api/departments/2081	/api/departments/2081	{"params":{"id":"2081"},"bodyKeys":["name"]}	172.18.0.1	2026-04-04 10:17:49.918938+00
3773	1	DELETE /api/departments/2081	/api/departments/2081	{"params":{"id":"2081"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:49.923655+00
3774	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-04 10:17:50.741714+00
3775	1	DELETE /api/departments/2082	/api/departments/2082	{"params":{"id":"2082"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:50.747651+00
3776	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:17:52.362849+00
3777	1	DELETE /api/departments/2084	/api/departments/2084	{"params":{"id":"2084"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:52.37496+00
3778	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-04 10:17:54.094154+00
3779	1	DELETE /api/departments/2086	/api/departments/2086	{"params":{"id":"2086"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:17:54.104539+00
3780	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-04 10:18:15.743348+00
3781	1	POST /api/programs/480/versions	/api/programs/480/versions	{"params":{"programId":"480"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-04 10:18:15.751352+00
3782	1	DELETE /api/versions/362	/api/versions/362	{"params":{"id":"362"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:18:15.761053+00
3783	1	DELETE /api/programs/480	/api/programs/480	{"params":{"id":"480"},"bodyKeys":[]}	172.18.0.1	2026-04-04 10:18:15.768613+00
3784	1	PUT /api/versions/29/course-plo-map	/api/versions/29/course-plo-map	{"params":{"vId":"29"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 04:46:43.06236+00
3785	1	PUT /api/versions/29/course-plo-map	/api/versions/29/course-plo-map	{"params":{"vId":"29"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 04:46:49.966608+00
3786	1	POST /api/versions/29/assignments	/api/versions/29/assignments	{"params":{"vId":"29"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-04-05 04:47:59.245726+00
3787	7	POST /api/my-assignments/5/create-syllabus	/api/my-assignments/5/create-syllabus	{"params":{"assignmentId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-05 04:48:49.681816+00
3788	7	POST /api/syllabi/15/import-pdf	/api/syllabi/15/import-pdf	{"params":{"id":"15"},"bodyKeys":[]}	172.18.0.1	2026-04-05 04:48:59.85461+00
3789	7	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["content"]}	172.18.0.1	2026-04-05 04:48:59.864694+00
3790	7	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["content"]}	172.18.0.1	2026-04-05 04:49:03.60404+00
3791	7	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 04:49:08.808463+00
3792	7	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 04:49:08.815574+00
3793	7	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 04:49:08.824717+00
3794	7	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 04:49:08.829952+00
3795	7	PUT /api/syllabi/15/clo-plo-map	/api/syllabi/15/clo-plo-map	{"params":{"sId":"15"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 04:49:08.837935+00
3796	7	PUT /api/syllabi/15/clo-plo-map	/api/syllabi/15/clo-plo-map	{"params":{"sId":"15"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 04:49:12.08661+00
3797	7	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["content"]}	172.18.0.1	2026-04-05 04:49:13.597712+00
3798	7	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["content"]}	172.18.0.1	2026-04-05 04:49:16.763146+00
3799	7	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["content"]}	172.18.0.1	2026-04-05 04:49:19.075992+00
3800	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-05 05:03:46.889697+00
3801	1	DELETE /api/programs/481	/api/programs/481	{"params":{"id":"481"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:46.947793+00
3802	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:03:48.381908+00
3803	1	PUT /api/programs/482	/api/programs/482	{"params":{"id":"482"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-05 05:03:49.686408+00
3804	1	DELETE /api/programs/482	/api/programs/482	{"params":{"id":"482"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:49.7172+00
3805	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:03:51.223754+00
3806	1	DELETE /api/programs/483	/api/programs/483	{"params":{"id":"483"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:51.237187+00
3807	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:03:52.699025+00
3808	1	POST /api/programs/484/archive	/api/programs/484/archive	{"params":{"id":"484"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:52.711063+00
3809	1	POST /api/programs/484/unarchive	/api/programs/484/unarchive	{"params":{"id":"484"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:53.860949+00
3810	1	DELETE /api/programs/484	/api/programs/484	{"params":{"id":"484"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:53.865768+00
3811	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:03:55.309297+00
3812	1	POST /api/programs/485/versions	/api/programs/485/versions	{"params":{"programId":"485"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:03:55.334133+00
3813	1	DELETE /api/versions/363	/api/versions/363	{"params":{"id":"363"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:55.348142+00
3814	1	DELETE /api/programs/485	/api/programs/485	{"params":{"id":"485"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:03:55.352576+00
3815	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:00.039226+00
3816	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:00.056147+00
3817	1	DELETE /api/programs/487	/api/programs/487	{"params":{"id":"487"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:00.063583+00
3818	1	DELETE /api/programs/486	/api/programs/486	{"params":{"id":"486"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:00.073139+00
3819	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:01.507213+00
3820	1	POST /api/programs/488/versions	/api/programs/488/versions	{"params":{"programId":"488"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:04:01.513182+00
3821	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:04:01.519329+00
3822	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:04:01.530235+00
3823	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:04:01.535317+00
3824	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:04:01.539877+00
3825	1	POST /api/programs/488/archive	/api/programs/488/archive	{"params":{"id":"488"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:01.560091+00
3826	1	POST /api/programs/488/unarchive	/api/programs/488/unarchive	{"params":{"id":"488"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:01.56322+00
3827	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:02.974727+00
3828	1	POST /api/programs/489/versions	/api/programs/489/versions	{"params":{"programId":"489"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:04:02.985063+00
3829	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:07.509735+00
3830	1	DELETE /api/programs/490	/api/programs/490	{"params":{"id":"490"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:08.638814+00
3831	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:04:11.559205+00
3832	1	POST /api/programs/491/archive	/api/programs/491/archive	{"params":{"id":"491"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:11.563332+00
3833	1	POST /api/programs/491/unarchive	/api/programs/491/unarchive	{"params":{"id":"491"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:11.575026+00
3834	1	DELETE /api/programs/491	/api/programs/491	{"params":{"id":"491"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:11.588549+00
3836	1	POST /api/programs/492/versions	/api/programs/492/versions	{"params":{"programId":"492"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:04:12.478474+00
3837	1	PUT /api/versions/366	/api/versions/366	{"params":{"id":"366"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:04:16.399045+00
3838	1	PUT /api/versions/366	/api/versions/366	{"params":{"id":"366"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:04:17.308833+00
3839	1	PUT /api/versions/366	/api/versions/366	{"params":{"id":"366"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:04:18.245458+00
3847	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:24.326771+00
3848	1	DELETE /api/objectives/211	/api/objectives/211	{"params":{"id":"211"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:24.33327+00
3855	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:27.105154+00
3856	1	PUT /api/plos/279	/api/plos/279	{"params":{"id":"279"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:04:27.116518+00
3857	1	DELETE /api/plos/279	/api/plos/279	{"params":{"id":"279"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:27.130097+00
3858	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:27.966331+00
3859	1	DELETE /api/plos/280	/api/plos/280	{"params":{"id":"280"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:27.978608+00
3870	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:31.522276+00
3871	1	POST /api/plos/285/pis	/api/plos/285/pis	{"params":{"ploId":"285"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:04:31.533797+00
3872	1	PUT /api/pis/343	/api/pis/343	{"params":{"id":"343"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:04:31.547799+00
3873	1	DELETE /api/pis/343	/api/pis/343	{"params":{"id":"343"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:31.557297+00
3874	1	DELETE /api/plos/285	/api/plos/285	{"params":{"id":"285"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:31.561089+00
3875	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:32.489303+00
3876	1	POST /api/plos/286/pis	/api/plos/286/pis	{"params":{"ploId":"286"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:04:32.50062+00
3877	1	DELETE /api/pis/344	/api/pis/344	{"params":{"id":"344"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:32.514543+00
3878	1	DELETE /api/plos/286	/api/plos/286	{"params":{"id":"286"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:32.523731+00
3886	1	PUT /api/versions/366/po-plo-map	/api/versions/366/po-plo-map	{"params":{"vId":"366"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:04:35.148436+00
3887	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:35.952364+00
3888	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:35.95707+00
3889	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:35.961323+00
3890	1	PUT /api/versions/366/po-plo-map	/api/versions/366/po-plo-map	{"params":{"vId":"366"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:04:35.969597+00
3894	1	POST /api/versions/366/knowledge-blocks	/api/versions/366/knowledge-blocks	{"params":{"vId":"366"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:04:36.800303+00
3900	1	POST /api/versions/366/courses	/api/versions/366/courses	{"params":{"vId":"366"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:04:40.308842+00
3901	1	DELETE /api/version-courses/938	/api/version-courses/938	{"params":{"id":"938"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:40.31648+00
3907	1	POST /api/versions/366/courses	/api/versions/366/courses	{"params":{"vId":"366"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:04:42.840474+00
3908	1	PUT /api/version-courses/942	/api/version-courses/942	{"params":{"id":"942"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-05 05:04:42.847477+00
3909	1	DELETE /api/version-courses/942	/api/version-courses/942	{"params":{"id":"942"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:42.85435+00
3910	1	PUT /api/versions/366/course-plo-map	/api/versions/366/course-plo-map	{"params":{"vId":"366"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:04:44.597752+00
3912	1	PUT /api/versions/366/course-pi-map	/api/versions/366/course-pi-map	{"params":{"vId":"366"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-05 05:04:46.971651+00
3920	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:05:04.994397+00
3921	1	PUT /api/courses/711	/api/courses/711	{"params":{"id":"711"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:05:05.000582+00
3922	1	DELETE /api/courses/711	/api/courses/711	{"params":{"id":"711"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:05.006268+00
3923	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:05:09.641486+00
3929	1	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["course_description"]}	172.18.0.1	2026-04-05 05:05:19.64523+00
3932	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:21.329709+00
3933	1	PUT /api/clos/14	/api/clos/14	{"params":{"id":"14"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:05:21.333329+00
3934	1	DELETE /api/clos/14	/api/clos/14	{"params":{"id":"14"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:21.335885+00
3937	1	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:24.128645+00
3940	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:25.944095+00
3941	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:25.948815+00
3942	1	DELETE /api/clos/17	/api/clos/17	{"params":{"id":"17"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:25.952243+00
3943	1	DELETE /api/clos/18	/api/clos/18	{"params":{"id":"18"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:25.95536+00
3944	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:27.11583+00
3945	1	DELETE /api/clos/19	/api/clos/19	{"params":{"id":"19"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:27.11878+00
3840	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:20.101059+00
3841	1	DELETE /api/objectives/208	/api/objectives/208	{"params":{"id":"208"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:21.748637+00
3842	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:22.526083+00
3843	1	PUT /api/objectives/209	/api/objectives/209	{"params":{"id":"209"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:04:22.536955+00
3844	1	DELETE /api/objectives/209	/api/objectives/209	{"params":{"id":"209"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:22.544858+00
3849	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:25.241134+00
3850	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:25.252606+00
3851	1	DELETE /api/objectives/213	/api/objectives/213	{"params":{"id":"213"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:25.258322+00
3852	1	DELETE /api/objectives/212	/api/objectives/212	{"params":{"id":"212"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:25.266033+00
3853	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:26.173308+00
3854	1	DELETE /api/plos/278	/api/plos/278	{"params":{"id":"278"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:26.186186+00
3862	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:29.632169+00
3863	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:29.64218+00
3864	1	DELETE /api/plos/283	/api/plos/283	{"params":{"id":"283"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:29.64822+00
3865	1	DELETE /api/plos/282	/api/plos/282	{"params":{"id":"282"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:29.656967+00
3866	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:30.557992+00
3867	1	POST /api/plos/284/pis	/api/plos/284/pis	{"params":{"ploId":"284"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:04:30.570493+00
3868	1	DELETE /api/pis/342	/api/pis/342	{"params":{"id":"342"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:30.583144+00
3869	1	DELETE /api/plos/284	/api/plos/284	{"params":{"id":"284"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:30.588068+00
3879	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:33.39839+00
3880	1	DELETE /api/plos/287	/api/plos/287	{"params":{"id":"287"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:33.41762+00
3891	1	DELETE /api/objectives/215	/api/objectives/215	{"params":{"id":"215"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:35.978095+00
3892	1	DELETE /api/objectives/216	/api/objectives/216	{"params":{"id":"216"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:35.984349+00
3893	1	DELETE /api/plos/289	/api/plos/289	{"params":{"id":"289"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:35.989785+00
3895	1	POST /api/versions/366/knowledge-blocks	/api/versions/366/knowledge-blocks	{"params":{"vId":"366"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:04:37.761808+00
3896	1	POST /api/versions/366/knowledge-blocks	/api/versions/366/knowledge-blocks	{"params":{"vId":"366"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:04:39.46998+00
3897	1	POST /api/versions/366/knowledge-blocks	/api/versions/366/knowledge-blocks	{"params":{"vId":"366"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-05 05:04:39.477388+00
3898	1	POST /api/versions/366/knowledge-blocks	/api/versions/366/knowledge-blocks	{"params":{"vId":"366"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-05 05:04:39.484188+00
3899	1	DELETE /api/knowledge-blocks/1959	/api/knowledge-blocks/1959	{"params":{"id":"1959"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:39.494213+00
3904	1	POST /api/versions/366/courses	/api/versions/366/courses	{"params":{"vId":"366"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:04:42.006259+00
3905	1	POST /api/versions/366/courses	/api/versions/366/courses	{"params":{"vId":"366"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:04:42.011012+00
3906	1	DELETE /api/version-courses/940	/api/version-courses/940	{"params":{"id":"940"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:42.016257+00
3913	1	POST /api/versions/366/courses	/api/versions/366/courses	{"params":{"vId":"366"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:04:48.680331+00
3914	1	PUT /api/versions/366/course-relations	/api/versions/366/course-relations	{"params":{"vId":"366"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-05 05:04:48.68659+00
3915	1	DELETE /api/version-courses/943	/api/version-courses/943	{"params":{"id":"943"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:48.692381+00
3916	1	DELETE /api/versions/366	/api/versions/366	{"params":{"id":"366"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:55.314509+00
3917	1	DELETE /api/programs/492	/api/programs/492	{"params":{"id":"492"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:55.319329+00
3924	1	DELETE /api/courses/712	/api/courses/712	{"params":{"id":"712"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:09.687437+00
3952	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:05:29.849804+00
3953	1	POST /api/programs/494/versions	/api/programs/494/versions	{"params":{"programId":"494"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:05:29.85737+00
3954	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:05:29.863244+00
3845	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:23.369487+00
3846	1	DELETE /api/objectives/210	/api/objectives/210	{"params":{"id":"210"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:23.380902+00
3860	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:28.799912+00
3861	1	DELETE /api/plos/281	/api/plos/281	{"params":{"id":"281"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:28.807728+00
3881	1	POST /api/versions/366/objectives	/api/versions/366/objectives	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:34.24527+00
3882	1	POST /api/versions/366/plos	/api/versions/366/plos	{"params":{"vId":"366"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:04:34.25378+00
3883	1	PUT /api/versions/366/po-plo-map	/api/versions/366/po-plo-map	{"params":{"vId":"366"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:04:34.270616+00
3884	1	DELETE /api/objectives/214	/api/objectives/214	{"params":{"id":"214"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:34.278343+00
3885	1	DELETE /api/plos/288	/api/plos/288	{"params":{"id":"288"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:34.283079+00
3902	1	POST /api/versions/366/courses	/api/versions/366/courses	{"params":{"vId":"366"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:04:41.160691+00
3903	1	DELETE /api/version-courses/939	/api/version-courses/939	{"params":{"id":"939"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:04:41.167757+00
3911	1	PUT /api/versions/366/course-plo-map	/api/versions/366/course-plo-map	{"params":{"vId":"366"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:04:45.35631+00
3918	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:05:02.439177+00
3919	1	DELETE /api/courses/710	/api/courses/710	{"params":{"id":"710"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:03.58743+00
3925	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:05:11.075203+00
3926	1	DELETE /api/courses/714	/api/courses/714	{"params":{"id":"714"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:11.083547+00
3927	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:05:13.87801+00
3928	1	DELETE /api/courses/715	/api/courses/715	{"params":{"id":"715"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:13.883445+00
3930	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:20.471055+00
3931	1	DELETE /api/clos/13	/api/clos/13	{"params":{"id":"13"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:20.476506+00
3935	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:22.361084+00
3936	1	DELETE /api/clos/15	/api/clos/15	{"params":{"id":"15"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:22.36649+00
3938	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:25.027186+00
3939	1	DELETE /api/clos/16	/api/clos/16	{"params":{"id":"16"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:25.031109+00
3946	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:05:27.962995+00
3947	1	DELETE /api/clos/20	/api/clos/20	{"params":{"id":"20"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:27.966785+00
3948	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:05:28.918701+00
3949	1	POST /api/programs/493/versions	/api/programs/493/versions	{"params":{"programId":"493"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:05:28.927395+00
3950	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:05:28.943893+00
3951	1	DELETE /api/programs/493	/api/programs/493	{"params":{"id":"493"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:05:28.956331+00
3955	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:05:42.187343+00
3956	1	POST /api/programs/495/versions	/api/programs/495/versions	{"params":{"programId":"495"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:05:42.195621+00
3957	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:05:42.200756+00
3958	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:05:42.213275+00
3959	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:05:54.419272+00
3960	1	POST /api/programs/496/versions	/api/programs/496/versions	{"params":{"programId":"496"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:05:54.427342+00
3961	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:05:54.432839+00
3962	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:05:54.445061+00
3963	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:05:54.449553+00
3964	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:06:06.760808+00
3965	1	POST /api/programs/497/versions	/api/programs/497/versions	{"params":{"programId":"497"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:06:06.770312+00
3966	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:06.776563+00
3967	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:06:06.787097+00
3968	1	DELETE /api/approval/rejected/program_version/371	/api/approval/rejected/program_version/371	{"params":{"entityType":"program_version","entityId":"371"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:06.801804+00
3969	1	DELETE /api/programs/497	/api/programs/497	{"params":{"id":"497"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:06.808359+00
3970	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:06:07.698297+00
3971	1	POST /api/programs/498/versions	/api/programs/498/versions	{"params":{"programId":"498"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:06:07.708764+00
3972	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:07.71499+00
3973	1	DELETE /api/programs/498	/api/programs/498	{"params":{"id":"498"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:07.739624+00
3974	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:06:10.516447+00
4145	1	DELETE /api/plos/297	/api/plos/297	{"params":{"id":"297"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:42.864133+00
3975	1	POST /api/programs/499/versions	/api/programs/499/versions	{"params":{"programId":"499"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:06:10.524763+00
3976	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:10.530413+00
3977	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:06:10.541773+00
3978	1	DELETE /api/versions/373	/api/versions/373	{"params":{"id":"373"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:10.554052+00
3979	1	DELETE /api/programs/499	/api/programs/499	{"params":{"id":"499"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:10.557688+00
3980	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:06:11.546244+00
3981	1	POST /api/programs/500/versions	/api/programs/500/versions	{"params":{"programId":"500"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:06:11.552649+00
3982	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:11.557356+00
3983	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:06:23.778627+00
3984	1	POST /api/programs/501/versions	/api/programs/501/versions	{"params":{"programId":"501"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:06:23.785159+00
3985	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:23.789681+00
3986	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:06:23.793626+00
3987	1	DELETE /api/approval/rejected/program_version/375	/api/approval/rejected/program_version/375	{"params":{"entityType":"program_version","entityId":"375"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:23.807271+00
3988	1	DELETE /api/programs/501	/api/programs/501	{"params":{"id":"501"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:23.817181+00
3989	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:06:24.848469+00
3990	1	POST /api/programs/502/versions	/api/programs/502/versions	{"params":{"programId":"502"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:06:24.857376+00
3991	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:24.864209+00
3992	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:06:24.874647+00
3993	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:06:24.882634+00
3994	1	DELETE /api/programs/502	/api/programs/502	{"params":{"id":"502"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:24.899172+00
3995	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:28.767056+00
3996	1	DELETE /api/users/195	/api/users/195	{"params":{"id":"195"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:28.779439+00
3997	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:30.784021+00
3998	1	PUT /api/users/196	/api/users/196	{"params":{"id":"196"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-05 05:06:30.79461+00
3999	1	DELETE /api/users/196	/api/users/196	{"params":{"id":"196"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:30.809229+00
4000	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:32.899714+00
4001	1	POST /api/users/197/roles	/api/users/197/roles	{"params":{"id":"197"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-05 05:06:32.925419+00
4002	1	DELETE /api/users/197	/api/users/197	{"params":{"id":"197"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:32.939121+00
4003	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:34.983059+00
4004	1	POST /api/users/198/roles	/api/users/198/roles	{"params":{"id":"198"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-05 05:06:34.997079+00
4005	1	DELETE /api/users/198/roles/GIANG_VIEN/5	/api/users/198/roles/GIANG_VIEN/5	{"params":{"userId":"198","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:35.007687+00
4006	1	DELETE /api/users/198	/api/users/198	{"params":{"id":"198"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:35.017824+00
4007	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:39.038393+00
4008	1	DELETE /api/users/200	/api/users/200	{"params":{"id":"200"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:39.046457+00
4009	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:41.149392+00
4010	1	DELETE /api/users/201	/api/users/201	{"params":{"id":"201"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:41.235665+00
4011	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:43.241536+00
4012	1	DELETE /api/users/203	/api/users/203	{"params":{"id":"203"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:43.255543+00
4013	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:45.237201+00
4014	1	PUT /api/users/204/toggle-active	/api/users/204/toggle-active	{"params":{"id":"204"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:45.247955+00
4015	1	DELETE /api/users/204	/api/users/204	{"params":{"id":"204"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:45.262866+00
4016	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:06:47.273958+00
4017	1	DELETE /api/users/205	/api/users/205	{"params":{"id":"205"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:47.282276+00
4018	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:06:58.131455+00
4019	1	DELETE /api/roles/658	/api/roles/658	{"params":{"id":"658"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:06:58.137781+00
4020	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:07:08.887763+00
4021	1	DELETE /api/roles/660	/api/roles/660	{"params":{"id":"660"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:08.912889+00
4022	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-05 05:07:14.837589+00
4023	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:07:19.04802+00
4024	1	DELETE /api/roles/662	/api/roles/662	{"params":{"id":"662"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:19.053445+00
4025	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:07:20.933413+00
4026	1	PUT /api/roles/663	/api/roles/663	{"params":{"id":"663"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:07:20.938397+00
4027	1	DELETE /api/roles/663	/api/roles/663	{"params":{"id":"663"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:20.942282+00
4028	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:07:24.190388+00
4029	1	DELETE /api/departments/2153	/api/departments/2153	{"params":{"id":"2153"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:24.197086+00
4030	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:07:25.027302+00
4031	1	PUT /api/departments/2154	/api/departments/2154	{"params":{"id":"2154"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:07:25.031864+00
4032	1	DELETE /api/departments/2154	/api/departments/2154	{"params":{"id":"2154"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:25.035852+00
4035	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:07:27.529457+00
4033	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-05 05:07:25.858864+00
4034	1	DELETE /api/departments/2155	/api/departments/2155	{"params":{"id":"2155"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:25.864343+00
4036	1	DELETE /api/departments/2157	/api/departments/2157	{"params":{"id":"2157"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:27.540954+00
4037	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:07:29.306189+00
4038	1	DELETE /api/departments/2159	/api/departments/2159	{"params":{"id":"2159"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:29.31325+00
4039	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:07:49.873512+00
4040	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:08:18.61219+00
4041	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:08:35.31221+00
4042	1	POST /api/programs/503/versions	/api/programs/503/versions	{"params":{"programId":"503"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:08:35.32176+00
4043	1	DELETE /api/versions/377	/api/versions/377	{"params":{"id":"377"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:08:35.337141+00
4044	1	DELETE /api/programs/503	/api/programs/503	{"params":{"id":"503"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:08:35.341269+00
4045	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:08:44.575679+00
4046	1	POST /api/programs/504/versions	/api/programs/504/versions	{"params":{"programId":"504"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:08:44.585813+00
4047	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:08:44.591568+00
4048	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:10:16.825468+00
4049	1	POST /api/programs/505/versions	/api/programs/505/versions	{"params":{"programId":"505"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:10:16.834727+00
4050	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:10:16.842715+00
4051	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:10:17.196963+00
4052	1	DELETE /api/programs/505	/api/programs/505	{"params":{"id":"505"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:10:17.417054+00
4053	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:10:18.339339+00
4054	1	POST /api/programs/506/versions	/api/programs/506/versions	{"params":{"programId":"506"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:10:18.350928+00
4055	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:10:18.356684+00
4056	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:10:18.364986+00
4057	5	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:10:18.70243+00
4058	1	DELETE /api/programs/506	/api/programs/506	{"params":{"id":"506"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:10:18.957245+00
4059	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:10:19.956889+00
4060	1	POST /api/programs/507/versions	/api/programs/507/versions	{"params":{"programId":"507"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:10:19.963278+00
4061	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:10:19.967235+00
4062	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:10:19.971961+00
4063	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:10:19.979157+00
4064	6	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:10:20.220568+00
4065	1	POST /api/programs/507/archive	/api/programs/507/archive	{"params":{"id":"507"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:10:20.462132+00
4066	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:10:21.464984+00
4067	1	POST /api/programs/508/versions	/api/programs/508/versions	{"params":{"programId":"508"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:10:21.472241+00
4068	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:10:21.479163+00
4069	1	DELETE /api/programs/508	/api/programs/508	{"params":{"id":"508"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:10:22.114584+00
4070	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:10:24.886318+00
4071	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-05 05:11:01.556216+00
4072	1	DELETE /api/programs/509	/api/programs/509	{"params":{"id":"509"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:01.679493+00
4073	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:03.240147+00
4074	1	PUT /api/programs/510	/api/programs/510	{"params":{"id":"510"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-05 05:11:04.638298+00
4075	1	DELETE /api/programs/510	/api/programs/510	{"params":{"id":"510"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:04.727979+00
4076	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:06.126529+00
4077	1	DELETE /api/programs/511	/api/programs/511	{"params":{"id":"511"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:06.138337+00
4078	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:07.417797+00
4079	1	POST /api/programs/512/archive	/api/programs/512/archive	{"params":{"id":"512"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:07.430169+00
4080	1	POST /api/programs/512/unarchive	/api/programs/512/unarchive	{"params":{"id":"512"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:08.579752+00
4081	1	DELETE /api/programs/512	/api/programs/512	{"params":{"id":"512"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:08.584611+00
4082	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:09.902539+00
4083	1	POST /api/programs/513/versions	/api/programs/513/versions	{"params":{"programId":"513"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:11:09.91911+00
4084	1	DELETE /api/versions/383	/api/versions/383	{"params":{"id":"383"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:09.932771+00
4085	1	DELETE /api/programs/513	/api/programs/513	{"params":{"id":"513"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:09.93591+00
4086	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:14.46774+00
4087	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:14.485499+00
4098	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:17.237045+00
4099	1	POST /api/programs/517/versions	/api/programs/517/versions	{"params":{"programId":"517"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:11:17.24591+00
4088	1	DELETE /api/programs/515	/api/programs/515	{"params":{"id":"515"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:14.492909+00
4089	1	DELETE /api/programs/514	/api/programs/514	{"params":{"id":"514"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:14.502963+00
4090	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:15.874254+00
4091	1	POST /api/programs/516/versions	/api/programs/516/versions	{"params":{"programId":"516"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:11:15.882706+00
4092	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:11:15.888847+00
4093	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:11:15.89923+00
4094	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:11:15.903402+00
4095	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:11:15.907787+00
4096	1	POST /api/programs/516/archive	/api/programs/516/archive	{"params":{"id":"516"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:15.926177+00
4097	1	POST /api/programs/516/unarchive	/api/programs/516/unarchive	{"params":{"id":"516"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:15.929195+00
4100	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:21.58075+00
4101	1	DELETE /api/programs/518	/api/programs/518	{"params":{"id":"518"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:22.698928+00
4102	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:25.412084+00
4103	1	POST /api/programs/519/archive	/api/programs/519/archive	{"params":{"id":"519"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:25.417351+00
4104	1	POST /api/programs/519/unarchive	/api/programs/519/unarchive	{"params":{"id":"519"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:25.429069+00
4105	1	DELETE /api/programs/519	/api/programs/519	{"params":{"id":"519"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:25.439856+00
4106	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:11:26.137884+00
4107	1	POST /api/programs/520/versions	/api/programs/520/versions	{"params":{"programId":"520"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:11:26.150379+00
4108	1	PUT /api/versions/386	/api/versions/386	{"params":{"id":"386"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:11:29.804312+00
4109	1	PUT /api/versions/386	/api/versions/386	{"params":{"id":"386"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:11:30.482111+00
4110	1	PUT /api/versions/386	/api/versions/386	{"params":{"id":"386"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:11:31.199208+00
4111	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:32.905102+00
4112	1	DELETE /api/objectives/217	/api/objectives/217	{"params":{"id":"217"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:34.518508+00
4113	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:35.21633+00
4114	1	PUT /api/objectives/218	/api/objectives/218	{"params":{"id":"218"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:11:35.226652+00
4115	1	DELETE /api/objectives/218	/api/objectives/218	{"params":{"id":"218"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:35.241647+00
4116	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:35.967741+00
4117	1	DELETE /api/objectives/219	/api/objectives/219	{"params":{"id":"219"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:35.976709+00
4118	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:36.761065+00
4119	1	DELETE /api/objectives/220	/api/objectives/220	{"params":{"id":"220"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:36.767788+00
4120	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:37.451398+00
4121	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:37.460104+00
4122	1	DELETE /api/objectives/222	/api/objectives/222	{"params":{"id":"222"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:37.464434+00
4123	1	DELETE /api/objectives/221	/api/objectives/221	{"params":{"id":"221"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:37.476635+00
4124	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:38.150744+00
4125	1	DELETE /api/plos/290	/api/plos/290	{"params":{"id":"290"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:38.160676+00
4126	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:39.041596+00
4127	1	PUT /api/plos/291	/api/plos/291	{"params":{"id":"291"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:11:39.053738+00
4128	1	DELETE /api/plos/291	/api/plos/291	{"params":{"id":"291"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:39.06655+00
4129	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:39.839253+00
4130	1	DELETE /api/plos/292	/api/plos/292	{"params":{"id":"292"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:39.851881+00
4131	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:40.515871+00
4132	1	DELETE /api/plos/293	/api/plos/293	{"params":{"id":"293"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:40.523569+00
4133	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:41.196393+00
4134	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:41.207044+00
4135	1	DELETE /api/plos/295	/api/plos/295	{"params":{"id":"295"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:41.221445+00
4136	1	DELETE /api/plos/294	/api/plos/294	{"params":{"id":"294"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:41.229494+00
4137	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:42.021712+00
4138	1	POST /api/plos/296/pis	/api/plos/296/pis	{"params":{"ploId":"296"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:11:42.033686+00
4139	1	DELETE /api/pis/346	/api/pis/346	{"params":{"id":"346"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:42.047031+00
4140	1	DELETE /api/plos/296	/api/plos/296	{"params":{"id":"296"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:42.051661+00
4141	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:42.826168+00
4142	1	POST /api/plos/297/pis	/api/plos/297/pis	{"params":{"ploId":"297"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:11:42.838351+00
4143	1	PUT /api/pis/347	/api/pis/347	{"params":{"id":"347"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:11:42.851262+00
4146	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:43.630952+00
4147	1	POST /api/plos/298/pis	/api/plos/298/pis	{"params":{"ploId":"298"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:11:43.645085+00
4148	1	DELETE /api/pis/348	/api/pis/348	{"params":{"id":"348"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:43.655894+00
4149	1	DELETE /api/plos/298	/api/plos/298	{"params":{"id":"298"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:43.663173+00
4165	1	POST /api/versions/386/knowledge-blocks	/api/versions/386/knowledge-blocks	{"params":{"vId":"386"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:11:47.252406+00
4173	1	POST /api/versions/386/courses	/api/versions/386/courses	{"params":{"vId":"386"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:11:50.955009+00
4174	1	DELETE /api/version-courses/945	/api/version-courses/945	{"params":{"id":"945"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:50.961937+00
4183	1	PUT /api/versions/386/course-pi-map	/api/versions/386/course-pi-map	{"params":{"vId":"386"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-05 05:11:55.991001+00
4187	1	DELETE /api/versions/386	/api/versions/386	{"params":{"id":"386"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:03.617787+00
4188	1	DELETE /api/programs/520	/api/programs/520	{"params":{"id":"520"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:03.622583+00
4150	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:44.32967+00
4151	1	DELETE /api/plos/299	/api/plos/299	{"params":{"id":"299"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:44.3547+00
4166	1	POST /api/versions/386/knowledge-blocks	/api/versions/386/knowledge-blocks	{"params":{"vId":"386"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:11:47.950083+00
4178	1	POST /api/versions/386/courses	/api/versions/386/courses	{"params":{"vId":"386"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:11:52.372828+00
4179	1	PUT /api/version-courses/948	/api/version-courses/948	{"params":{"id":"948"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-05 05:11:52.378452+00
4180	1	DELETE /api/version-courses/948	/api/version-courses/948	{"params":{"id":"948"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:52.383377+00
4184	1	POST /api/versions/386/courses	/api/versions/386/courses	{"params":{"vId":"386"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:11:57.339763+00
4185	1	PUT /api/versions/386/course-relations	/api/versions/386/course-relations	{"params":{"vId":"386"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-05 05:11:57.345986+00
4186	1	DELETE /api/version-courses/949	/api/version-courses/949	{"params":{"id":"949"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:57.350702+00
4152	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:45.138869+00
4153	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:45.146617+00
4154	1	PUT /api/versions/386/po-plo-map	/api/versions/386/po-plo-map	{"params":{"vId":"386"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:11:45.162346+00
4155	1	DELETE /api/objectives/223	/api/objectives/223	{"params":{"id":"223"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:45.169571+00
4156	1	DELETE /api/plos/300	/api/plos/300	{"params":{"id":"300"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:45.174875+00
4182	1	PUT /api/versions/386/course-plo-map	/api/versions/386/course-plo-map	{"params":{"vId":"386"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:11:54.620062+00
4157	1	PUT /api/versions/386/po-plo-map	/api/versions/386/po-plo-map	{"params":{"vId":"386"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:11:45.823435+00
4167	1	POST /api/versions/386/knowledge-blocks	/api/versions/386/knowledge-blocks	{"params":{"vId":"386"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:11:49.565293+00
4168	1	POST /api/versions/386/knowledge-blocks	/api/versions/386/knowledge-blocks	{"params":{"vId":"386"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-05 05:11:49.572537+00
4169	1	POST /api/versions/386/knowledge-blocks	/api/versions/386/knowledge-blocks	{"params":{"vId":"386"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-05 05:11:49.579055+00
4170	1	DELETE /api/knowledge-blocks/2064	/api/knowledge-blocks/2064	{"params":{"id":"2064"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:49.59041+00
4189	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:12:10.193939+00
4158	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:46.517408+00
4159	1	POST /api/versions/386/objectives	/api/versions/386/objectives	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:46.523251+00
4160	1	POST /api/versions/386/plos	/api/versions/386/plos	{"params":{"vId":"386"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:11:46.529735+00
4161	1	PUT /api/versions/386/po-plo-map	/api/versions/386/po-plo-map	{"params":{"vId":"386"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:11:46.543268+00
4162	1	DELETE /api/objectives/224	/api/objectives/224	{"params":{"id":"224"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:46.551043+00
4163	1	DELETE /api/objectives/225	/api/objectives/225	{"params":{"id":"225"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:46.554701+00
4164	1	DELETE /api/plos/301	/api/plos/301	{"params":{"id":"301"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:46.558595+00
4171	1	POST /api/versions/386/courses	/api/versions/386/courses	{"params":{"vId":"386"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:11:50.249349+00
4172	1	DELETE /api/version-courses/944	/api/version-courses/944	{"params":{"id":"944"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:50.254549+00
4181	1	PUT /api/versions/386/course-plo-map	/api/versions/386/course-plo-map	{"params":{"vId":"386"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:11:53.881474+00
4175	1	POST /api/versions/386/courses	/api/versions/386/courses	{"params":{"vId":"386"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:11:51.672066+00
4176	1	POST /api/versions/386/courses	/api/versions/386/courses	{"params":{"vId":"386"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:11:51.677855+00
4177	1	DELETE /api/version-courses/946	/api/version-courses/946	{"params":{"id":"946"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:11:51.684691+00
4190	1	DELETE /api/courses/716	/api/courses/716	{"params":{"id":"716"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:11.312299+00
4191	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:12:12.537079+00
4192	1	PUT /api/courses/717	/api/courses/717	{"params":{"id":"717"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:12:12.542008+00
4193	1	DELETE /api/courses/717	/api/courses/717	{"params":{"id":"717"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:12.546223+00
4194	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:12:16.995123+00
4195	1	DELETE /api/courses/718	/api/courses/718	{"params":{"id":"718"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:17.027301+00
4196	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:12:18.29951+00
4197	1	DELETE /api/courses/720	/api/courses/720	{"params":{"id":"720"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:18.307456+00
4198	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:12:20.993477+00
4199	1	DELETE /api/courses/721	/api/courses/721	{"params":{"id":"721"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:21.000753+00
4200	1	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["course_description"]}	172.18.0.1	2026-04-05 05:12:26.389881+00
4201	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:27.096112+00
4202	1	DELETE /api/clos/21	/api/clos/21	{"params":{"id":"21"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:27.101942+00
4203	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:27.950558+00
4204	1	PUT /api/clos/22	/api/clos/22	{"params":{"id":"22"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:12:27.955088+00
4205	1	DELETE /api/clos/22	/api/clos/22	{"params":{"id":"22"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:27.958267+00
4206	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:28.75228+00
4207	1	DELETE /api/clos/23	/api/clos/23	{"params":{"id":"23"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:28.757433+00
4208	1	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:30.30609+00
4209	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:30.994689+00
4210	1	DELETE /api/clos/24	/api/clos/24	{"params":{"id":"24"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:30.999431+00
4211	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:31.705705+00
4212	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:31.709552+00
4213	1	DELETE /api/clos/25	/api/clos/25	{"params":{"id":"25"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:31.713103+00
4214	1	DELETE /api/clos/26	/api/clos/26	{"params":{"id":"26"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:31.715932+00
4215	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:32.589268+00
4216	1	DELETE /api/clos/27	/api/clos/27	{"params":{"id":"27"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:32.593263+00
4217	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:12:33.345786+00
4218	1	DELETE /api/clos/28	/api/clos/28	{"params":{"id":"28"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:33.35042+00
4219	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:34.201739+00
4220	1	POST /api/programs/521/versions	/api/programs/521/versions	{"params":{"programId":"521"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:34.208069+00
4221	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:34.216324+00
4222	1	DELETE /api/programs/521	/api/programs/521	{"params":{"id":"521"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:34.227909+00
4223	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:34.948464+00
4224	1	POST /api/programs/522/versions	/api/programs/522/versions	{"params":{"programId":"522"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:34.953638+00
4225	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:34.957892+00
4226	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:12:35.152853+00
4227	1	DELETE /api/programs/522	/api/programs/522	{"params":{"id":"522"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:35.450643+00
4228	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:36.190214+00
4229	1	POST /api/programs/523/versions	/api/programs/523/versions	{"params":{"programId":"523"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:36.1976+00
4230	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:36.203187+00
4231	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:12:36.208361+00
4232	5	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:12:36.402144+00
4233	1	DELETE /api/programs/523	/api/programs/523	{"params":{"id":"523"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:36.681383+00
4234	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:37.312334+00
4235	1	POST /api/programs/524/versions	/api/programs/524/versions	{"params":{"programId":"524"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:37.318901+00
4236	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:37.325908+00
4237	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:12:37.333359+00
4238	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:12:37.337892+00
4239	6	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:12:37.638057+00
4267	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:44.40871+00
4268	1	POST /api/programs/530/versions	/api/programs/530/versions	{"params":{"programId":"530"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:44.414564+00
4269	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:44.418924+00
4270	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:12:44.422941+00
4271	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:44.431236+00
4272	1	DELETE /api/programs/530	/api/programs/530	{"params":{"id":"530"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:44.445377+00
4275	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:12:49.819488+00
4276	1	PUT /api/users/207	/api/users/207	{"params":{"id":"207"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-05 05:12:49.830832+00
4277	1	DELETE /api/users/207	/api/users/207	{"params":{"id":"207"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:49.844204+00
4240	1	POST /api/programs/524/archive	/api/programs/524/archive	{"params":{"id":"524"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:37.832629+00
4257	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:42.516865+00
4258	1	POST /api/programs/528/versions	/api/programs/528/versions	{"params":{"programId":"528"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:42.521586+00
4259	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:42.525619+00
4241	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:38.477501+00
4242	1	POST /api/programs/525/versions	/api/programs/525/versions	{"params":{"programId":"525"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:38.483958+00
4243	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:38.488206+00
4244	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:12:38.497699+00
4245	1	DELETE /api/approval/rejected/program_version/391	/api/approval/rejected/program_version/391	{"params":{"entityType":"program_version","entityId":"391"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:38.508965+00
4246	1	DELETE /api/programs/525	/api/programs/525	{"params":{"id":"525"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:38.515079+00
4299	1	DELETE /api/roles/672	/api/roles/672	{"params":{"id":"672"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:25.158875+00
4303	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:13:36.31518+00
4304	1	PUT /api/roles/675	/api/roles/675	{"params":{"id":"675"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:13:36.320272+00
4305	1	DELETE /api/roles/675	/api/roles/675	{"params":{"id":"675"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:36.325133+00
4247	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:39.264856+00
4248	1	POST /api/programs/526/versions	/api/programs/526/versions	{"params":{"programId":"526"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:39.269951+00
4249	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:39.274074+00
4250	1	DELETE /api/programs/526	/api/programs/526	{"params":{"id":"526"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:39.290278+00
4296	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:13:14.882186+00
4297	1	DELETE /api/roles/670	/api/roles/670	{"params":{"id":"670"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:14.887006+00
4300	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-05 05:13:30.596298+00
4308	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:13:40.250348+00
4309	1	PUT /api/departments/2183	/api/departments/2183	{"params":{"id":"2183"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:13:40.255392+00
4310	1	DELETE /api/departments/2183	/api/departments/2183	{"params":{"id":"2183"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:40.259629+00
4314	1	DELETE /api/departments/2186	/api/departments/2186	{"params":{"id":"2186"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:42.502179+00
4251	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:41.756632+00
4252	1	POST /api/programs/527/versions	/api/programs/527/versions	{"params":{"programId":"527"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:41.763528+00
4253	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:41.76816+00
4254	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:12:41.776152+00
4255	1	DELETE /api/versions/393	/api/versions/393	{"params":{"id":"393"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:41.78374+00
4256	1	DELETE /api/programs/527	/api/programs/527	{"params":{"id":"527"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:41.78673+00
4260	1	DELETE /api/programs/528	/api/programs/528	{"params":{"id":"528"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:43.003323+00
4278	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:12:51.733592+00
4279	1	POST /api/users/208/roles	/api/users/208/roles	{"params":{"id":"208"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-05 05:12:51.751053+00
4281	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:12:53.568527+00
4282	1	POST /api/users/209/roles	/api/users/209/roles	{"params":{"id":"209"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-05 05:12:53.581819+00
4283	1	DELETE /api/users/209/roles/GIANG_VIEN/5	/api/users/209/roles/GIANG_VIEN/5	{"params":{"userId":"209","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:53.593523+00
4284	1	DELETE /api/users/209	/api/users/209	{"params":{"id":"209"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:53.603797+00
4288	1	DELETE /api/users/212	/api/users/212	{"params":{"id":"212"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:59.251781+00
4294	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:13:04.71806+00
4295	1	DELETE /api/users/216	/api/users/216	{"params":{"id":"216"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:04.730016+00
4261	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:12:43.646095+00
4262	1	POST /api/programs/529/versions	/api/programs/529/versions	{"params":{"programId":"529"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:12:43.6516+00
4263	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:12:43.656281+00
4264	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:12:43.661292+00
4265	1	DELETE /api/approval/rejected/program_version/395	/api/approval/rejected/program_version/395	{"params":{"entityType":"program_version","entityId":"395"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:43.671021+00
4266	1	DELETE /api/programs/529	/api/programs/529	{"params":{"id":"529"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:43.67816+00
4273	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:12:47.970596+00
4274	1	DELETE /api/users/206	/api/users/206	{"params":{"id":"206"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:47.981942+00
4280	1	DELETE /api/users/208	/api/users/208	{"params":{"id":"208"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:51.759579+00
4285	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:12:57.207647+00
4286	1	DELETE /api/users/211	/api/users/211	{"params":{"id":"211"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:12:57.21457+00
4287	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:12:59.166331+00
4289	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:13:01.090397+00
4290	1	DELETE /api/users/214	/api/users/214	{"params":{"id":"214"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:01.103256+00
4291	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:13:02.894149+00
4292	1	PUT /api/users/215/toggle-active	/api/users/215/toggle-active	{"params":{"id":"215"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:02.902798+00
4293	1	DELETE /api/users/215	/api/users/215	{"params":{"id":"215"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:02.911809+00
4298	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:13:25.133676+00
4301	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:13:34.41989+00
4302	1	DELETE /api/roles/674	/api/roles/674	{"params":{"id":"674"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:34.426826+00
4306	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:13:39.45554+00
4307	1	DELETE /api/departments/2182	/api/departments/2182	{"params":{"id":"2182"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:39.462628+00
4311	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-05 05:13:40.983788+00
4312	1	DELETE /api/departments/2184	/api/departments/2184	{"params":{"id":"2184"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:40.990025+00
4313	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:13:42.488181+00
4315	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:13:44.188329+00
4316	1	DELETE /api/departments/2188	/api/departments/2188	{"params":{"id":"2188"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:13:44.193548+00
4317	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:14:03.149552+00
4318	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:14:20.648093+00
4319	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:14:39.872292+00
4320	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:15:01.536327+00
4321	1	POST /api/programs/531/versions	/api/programs/531/versions	{"params":{"programId":"531"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:15:01.545564+00
4322	1	DELETE /api/versions/397	/api/versions/397	{"params":{"id":"397"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:15:01.561688+00
4323	1	DELETE /api/programs/531	/api/programs/531	{"params":{"id":"531"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:15:01.566828+00
4324	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-05 05:16:08.357394+00
4325	1	DELETE /api/programs/532	/api/programs/532	{"params":{"id":"532"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:08.475288+00
4326	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:09.865788+00
4327	1	PUT /api/programs/533	/api/programs/533	{"params":{"id":"533"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-04-05 05:16:11.28832+00
4328	1	DELETE /api/programs/533	/api/programs/533	{"params":{"id":"533"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:11.375751+00
4329	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:12.825296+00
4330	1	DELETE /api/programs/534	/api/programs/534	{"params":{"id":"534"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:12.839878+00
4331	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:14.232253+00
4332	1	POST /api/programs/535/archive	/api/programs/535/archive	{"params":{"id":"535"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:14.244458+00
4333	1	POST /api/programs/535/unarchive	/api/programs/535/unarchive	{"params":{"id":"535"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:15.323093+00
4334	1	DELETE /api/programs/535	/api/programs/535	{"params":{"id":"535"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:15.326344+00
4335	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:16.694692+00
4336	1	POST /api/programs/536/versions	/api/programs/536/versions	{"params":{"programId":"536"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:16:16.710668+00
4337	1	DELETE /api/versions/398	/api/versions/398	{"params":{"id":"398"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:16.726887+00
4338	1	DELETE /api/programs/536	/api/programs/536	{"params":{"id":"536"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:16.734269+00
4339	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:21.11273+00
4340	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:21.129458+00
4341	1	DELETE /api/programs/538	/api/programs/538	{"params":{"id":"538"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:21.137738+00
4556	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:18:43.711868+00
4342	1	DELETE /api/programs/537	/api/programs/537	{"params":{"id":"537"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:21.147557+00
4343	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:22.424798+00
4344	1	POST /api/programs/539/versions	/api/programs/539/versions	{"params":{"programId":"539"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:16:22.433071+00
4345	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:16:22.437766+00
4346	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:16:22.441852+00
4347	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:16:22.450302+00
4348	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:16:22.45439+00
4349	1	POST /api/programs/539/archive	/api/programs/539/archive	{"params":{"id":"539"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:22.472975+00
4350	1	POST /api/programs/539/unarchive	/api/programs/539/unarchive	{"params":{"id":"539"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:22.47586+00
4351	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:23.805865+00
4352	1	POST /api/programs/540/versions	/api/programs/540/versions	{"params":{"programId":"540"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:16:23.815144+00
4353	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:28.267265+00
4354	1	DELETE /api/programs/541	/api/programs/541	{"params":{"id":"541"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:29.392044+00
4355	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:31.935875+00
4356	1	POST /api/programs/542/archive	/api/programs/542/archive	{"params":{"id":"542"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:31.941622+00
4357	1	POST /api/programs/542/unarchive	/api/programs/542/unarchive	{"params":{"id":"542"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:31.952562+00
4358	1	DELETE /api/programs/542	/api/programs/542	{"params":{"id":"542"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:31.962971+00
4359	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:16:32.840223+00
4360	1	POST /api/programs/543/versions	/api/programs/543/versions	{"params":{"programId":"543"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:16:32.847696+00
4361	1	PUT /api/versions/401	/api/versions/401	{"params":{"id":"401"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:16:36.537436+00
4362	1	PUT /api/versions/401	/api/versions/401	{"params":{"id":"401"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:16:37.365124+00
4363	1	PUT /api/versions/401	/api/versions/401	{"params":{"id":"401"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:16:38.147965+00
4364	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:39.887406+00
4365	1	DELETE /api/objectives/226	/api/objectives/226	{"params":{"id":"226"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:41.49027+00
4366	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:42.345154+00
4367	1	PUT /api/objectives/227	/api/objectives/227	{"params":{"id":"227"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:16:42.358053+00
4368	1	DELETE /api/objectives/227	/api/objectives/227	{"params":{"id":"227"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:42.369797+00
4369	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:43.199205+00
4370	1	DELETE /api/objectives/228	/api/objectives/228	{"params":{"id":"228"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:43.210618+00
4371	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:43.934505+00
4372	1	DELETE /api/objectives/229	/api/objectives/229	{"params":{"id":"229"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:43.940698+00
4373	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:44.68427+00
4374	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:44.69613+00
4375	1	DELETE /api/objectives/231	/api/objectives/231	{"params":{"id":"231"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:44.701283+00
4376	1	DELETE /api/objectives/230	/api/objectives/230	{"params":{"id":"230"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:44.709268+00
4377	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:45.515913+00
4378	1	DELETE /api/plos/302	/api/plos/302	{"params":{"id":"302"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:45.529279+00
4379	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:46.282181+00
4380	1	PUT /api/plos/303	/api/plos/303	{"params":{"id":"303"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:16:46.293866+00
4381	1	DELETE /api/plos/303	/api/plos/303	{"params":{"id":"303"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:46.307155+00
4382	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:47.144032+00
4383	1	DELETE /api/plos/304	/api/plos/304	{"params":{"id":"304"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:47.156007+00
4384	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:47.978721+00
4385	1	DELETE /api/plos/305	/api/plos/305	{"params":{"id":"305"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:47.984701+00
4386	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:48.731859+00
4387	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:48.744176+00
4388	1	DELETE /api/plos/307	/api/plos/307	{"params":{"id":"307"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:48.749504+00
4389	1	DELETE /api/plos/306	/api/plos/306	{"params":{"id":"306"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:48.759098+00
4390	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:49.549347+00
4391	1	POST /api/plos/308/pis	/api/plos/308/pis	{"params":{"ploId":"308"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:16:49.562284+00
4392	1	DELETE /api/pis/350	/api/pis/350	{"params":{"id":"350"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:49.573479+00
4393	1	DELETE /api/plos/308	/api/plos/308	{"params":{"id":"308"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:49.577998+00
4394	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:50.35193+00
4395	1	POST /api/plos/309/pis	/api/plos/309/pis	{"params":{"ploId":"309"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:16:50.363193+00
4396	1	PUT /api/pis/351	/api/pis/351	{"params":{"id":"351"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:16:50.376438+00
4397	1	DELETE /api/pis/351	/api/pis/351	{"params":{"id":"351"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:50.38545+00
4398	1	DELETE /api/plos/309	/api/plos/309	{"params":{"id":"309"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:50.389168+00
4399	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:51.185375+00
4400	1	POST /api/plos/310/pis	/api/plos/310/pis	{"params":{"ploId":"310"},"bodyKeys":["pi_code","description"]}	172.18.0.1	2026-04-05 05:16:51.193837+00
4401	1	DELETE /api/pis/352	/api/pis/352	{"params":{"id":"352"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:51.20227+00
4402	1	DELETE /api/plos/310	/api/plos/310	{"params":{"id":"310"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:51.213612+00
4403	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:51.931001+00
4404	1	DELETE /api/plos/311	/api/plos/311	{"params":{"id":"311"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:51.955649+00
4434	1	PUT /api/versions/401/course-plo-map	/api/versions/401/course-plo-map	{"params":{"vId":"401"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:17:02.136854+00
4437	1	POST /api/versions/401/courses	/api/versions/401/courses	{"params":{"vId":"401"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:17:05.376623+00
4438	1	PUT /api/versions/401/course-relations	/api/versions/401/course-relations	{"params":{"vId":"401"},"bodyKeys":["version_course_id","prerequisite_course_ids","corequisite_course_ids"]}	172.18.0.1	2026-04-05 05:17:05.383173+00
4439	1	DELETE /api/version-courses/955	/api/version-courses/955	{"params":{"id":"955"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:05.389175+00
4454	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:34.729585+00
4455	1	DELETE /api/clos/29	/api/clos/29	{"params":{"id":"29"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:34.734171+00
4464	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:39.287947+00
4465	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:39.292186+00
4466	1	DELETE /api/clos/33	/api/clos/33	{"params":{"id":"33"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:39.294975+00
4467	1	DELETE /api/clos/34	/api/clos/34	{"params":{"id":"34"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:39.297937+00
4476	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:42.577504+00
4477	1	POST /api/programs/545/versions	/api/programs/545/versions	{"params":{"programId":"545"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:42.585808+00
4478	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:42.59164+00
4487	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:45.203607+00
4488	1	POST /api/programs/547/versions	/api/programs/547/versions	{"params":{"programId":"547"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:45.209348+00
4489	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:45.213544+00
4490	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:17:45.217908+00
4491	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:17:45.228712+00
4514	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:51.815252+00
4515	1	POST /api/programs/552/versions	/api/programs/552/versions	{"params":{"programId":"552"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:51.822905+00
4516	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:51.828188+00
4517	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:17:51.833207+00
4520	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:52.519521+00
4521	1	POST /api/programs/553/versions	/api/programs/553/versions	{"params":{"programId":"553"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:52.525735+00
4522	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:52.529837+00
4523	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:17:52.533696+00
4524	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:52.544742+00
4525	1	DELETE /api/programs/553	/api/programs/553	{"params":{"id":"553"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:52.557149+00
4405	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:52.768782+00
4406	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:52.774542+00
4407	1	PUT /api/versions/401/po-plo-map	/api/versions/401/po-plo-map	{"params":{"vId":"401"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:16:52.784987+00
4408	1	DELETE /api/objectives/232	/api/objectives/232	{"params":{"id":"232"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:52.793347+00
4409	1	DELETE /api/plos/312	/api/plos/312	{"params":{"id":"312"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:52.797686+00
4431	1	POST /api/versions/401/courses	/api/versions/401/courses	{"params":{"vId":"401"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:17:00.5708+00
4432	1	PUT /api/version-courses/954	/api/version-courses/954	{"params":{"id":"954"},"bodyKeys":["semester"]}	172.18.0.1	2026-04-05 05:17:00.577239+00
4433	1	DELETE /api/version-courses/954	/api/version-courses/954	{"params":{"id":"954"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:00.583575+00
4436	1	PUT /api/versions/401/course-pi-map	/api/versions/401/course-pi-map	{"params":{"vId":"401"},"bodyKeys":["pi_mappings"]}	172.18.0.1	2026-04-05 05:17:04.055455+00
4410	1	PUT /api/versions/401/po-plo-map	/api/versions/401/po-plo-map	{"params":{"vId":"401"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:16:53.582677+00
4420	1	POST /api/versions/401/knowledge-blocks	/api/versions/401/knowledge-blocks	{"params":{"vId":"401"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:16:57.419407+00
4421	1	POST /api/versions/401/knowledge-blocks	/api/versions/401/knowledge-blocks	{"params":{"vId":"401"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-05 05:16:57.425644+00
4422	1	POST /api/versions/401/knowledge-blocks	/api/versions/401/knowledge-blocks	{"params":{"vId":"401"},"bodyKeys":["name","type","parent_id"]}	172.18.0.1	2026-04-05 05:16:57.430534+00
4423	1	DELETE /api/knowledge-blocks/2144	/api/knowledge-blocks/2144	{"params":{"id":"2144"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:57.43504+00
4435	1	PUT /api/versions/401/course-plo-map	/api/versions/401/course-plo-map	{"params":{"vId":"401"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:17:02.754773+00
4448	1	DELETE /api/courses/724	/api/courses/724	{"params":{"id":"724"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:25.102942+00
4462	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:38.50723+00
4463	1	DELETE /api/clos/32	/api/clos/32	{"params":{"id":"32"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:38.512207+00
4479	4	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:17:42.829201+00
4486	1	DELETE /api/programs/546	/api/programs/546	{"params":{"id":"546"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:44.49366+00
4411	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:54.368919+00
4412	1	POST /api/versions/401/objectives	/api/versions/401/objectives	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:54.374939+00
4413	1	POST /api/versions/401/plos	/api/versions/401/plos	{"params":{"vId":"401"},"bodyKeys":["code","description"]}	172.18.0.1	2026-04-05 05:16:54.380816+00
4414	1	PUT /api/versions/401/po-plo-map	/api/versions/401/po-plo-map	{"params":{"vId":"401"},"bodyKeys":["mappings"]}	172.18.0.1	2026-04-05 05:16:54.394487+00
4415	1	DELETE /api/objectives/233	/api/objectives/233	{"params":{"id":"233"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:54.40178+00
4416	1	DELETE /api/objectives/234	/api/objectives/234	{"params":{"id":"234"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:54.405407+00
4417	1	DELETE /api/plos/313	/api/plos/313	{"params":{"id":"313"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:54.409227+00
4424	1	POST /api/versions/401/courses	/api/versions/401/courses	{"params":{"vId":"401"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:16:58.272753+00
4425	1	DELETE /api/version-courses/950	/api/version-courses/950	{"params":{"id":"950"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:58.279728+00
4440	1	DELETE /api/versions/401	/api/versions/401	{"params":{"id":"401"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:11.48132+00
4441	1	DELETE /api/programs/543	/api/programs/543	{"params":{"id":"543"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:11.486504+00
4451	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:17:28.880363+00
4452	1	DELETE /api/courses/727	/api/courses/727	{"params":{"id":"727"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:28.886028+00
4456	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:35.510015+00
4457	1	PUT /api/clos/30	/api/clos/30	{"params":{"id":"30"},"bodyKeys":["description"]}	172.18.0.1	2026-04-05 05:17:35.51466+00
4458	1	DELETE /api/clos/30	/api/clos/30	{"params":{"id":"30"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:35.517738+00
4470	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:40.858346+00
4471	1	DELETE /api/clos/36	/api/clos/36	{"params":{"id":"36"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:40.862029+00
4485	5	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:17:44.156351+00
4500	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:47.432975+00
4501	1	POST /api/programs/549/versions	/api/programs/549/versions	{"params":{"programId":"549"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:47.440721+00
4502	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:47.445533+00
4503	1	DELETE /api/programs/549	/api/programs/549	{"params":{"id":"549"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:47.463577+00
4528	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:17:57.940498+00
4529	1	PUT /api/users/218	/api/users/218	{"params":{"id":"218"},"bodyKeys":["display_name"]}	172.18.0.1	2026-04-05 05:17:57.950775+00
4530	1	DELETE /api/users/218	/api/users/218	{"params":{"id":"218"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:57.965708+00
4418	1	POST /api/versions/401/knowledge-blocks	/api/versions/401/knowledge-blocks	{"params":{"vId":"401"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:16:55.201701+00
4426	1	POST /api/versions/401/courses	/api/versions/401/courses	{"params":{"vId":"401"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:16:59.026121+00
4427	1	DELETE /api/version-courses/951	/api/version-courses/951	{"params":{"id":"951"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:59.032163+00
4444	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:17:20.76069+00
4445	1	PUT /api/courses/723	/api/courses/723	{"params":{"id":"723"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:17:20.767089+00
4446	1	DELETE /api/courses/723	/api/courses/723	{"params":{"id":"723"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:20.773214+00
4459	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:36.181458+00
4460	1	DELETE /api/clos/31	/api/clos/31	{"params":{"id":"31"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:36.184597+00
4472	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:41.757907+00
4473	1	POST /api/programs/544/versions	/api/programs/544/versions	{"params":{"programId":"544"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:41.766501+00
4474	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:41.775591+00
4475	1	DELETE /api/programs/544	/api/programs/544	{"params":{"id":"544"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:41.786848+00
4492	6	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:17:45.559259+00
4504	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:49.916728+00
4505	1	POST /api/programs/550/versions	/api/programs/550/versions	{"params":{"programId":"550"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:49.924068+00
4506	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:49.92979+00
4507	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:17:49.942704+00
4508	1	DELETE /api/versions/408	/api/versions/408	{"params":{"id":"408"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:49.950291+00
4509	1	DELETE /api/programs/550	/api/programs/550	{"params":{"id":"550"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:49.953551+00
4513	1	DELETE /api/programs/551	/api/programs/551	{"params":{"id":"551"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:51.133561+00
4526	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:17:56.117131+00
4527	1	DELETE /api/users/217	/api/users/217	{"params":{"id":"217"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:56.126633+00
4533	1	DELETE /api/users/219	/api/users/219	{"params":{"id":"219"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:59.818781+00
4547	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:18:12.766942+00
4548	1	DELETE /api/users/227	/api/users/227	{"params":{"id":"227"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:12.777513+00
4419	1	POST /api/versions/401/knowledge-blocks	/api/versions/401/knowledge-blocks	{"params":{"vId":"401"},"bodyKeys":["name","type"]}	172.18.0.1	2026-04-05 05:16:55.952058+00
4428	1	POST /api/versions/401/courses	/api/versions/401/courses	{"params":{"vId":"401"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:16:59.809412+00
4429	1	POST /api/versions/401/courses	/api/versions/401/courses	{"params":{"vId":"401"},"bodyKeys":["course_id","semester"]}	172.18.0.1	2026-04-05 05:16:59.814547+00
4430	1	DELETE /api/version-courses/952	/api/version-courses/952	{"params":{"id":"952"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:16:59.820081+00
4442	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:17:18.299748+00
4443	1	DELETE /api/courses/722	/api/courses/722	{"params":{"id":"722"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:19.415755+00
4447	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:17:25.06924+00
4449	1	POST /api/courses	/api/courses	{"params":{},"bodyKeys":["code","name","credits","department_id"]}	172.18.0.1	2026-04-05 05:17:26.369736+00
4450	1	DELETE /api/courses/726	/api/courses/726	{"params":{"id":"726"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:26.377724+00
4453	1	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":["course_description"]}	172.18.0.1	2026-04-05 05:17:34.067486+00
4461	1	PUT /api/syllabi/15	/api/syllabi/15	{"params":{"id":"15"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:37.717296+00
4468	1	POST /api/syllabi/15/clos	/api/syllabi/15/clos	{"params":{"sId":"15"},"bodyKeys":["code","description","level"]}	172.18.0.1	2026-04-05 05:17:40.215782+00
4469	1	DELETE /api/clos/35	/api/clos/35	{"params":{"id":"35"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:40.220369+00
4480	1	DELETE /api/programs/545	/api/programs/545	{"params":{"id":"545"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:43.065245+00
4481	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:43.819825+00
4482	1	POST /api/programs/546/versions	/api/programs/546/versions	{"params":{"programId":"546"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:43.82587+00
4483	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:43.831332+00
4484	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-04-05 05:17:43.835833+00
4493	1	POST /api/programs/547/archive	/api/programs/547/archive	{"params":{"id":"547"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:45.890591+00
4494	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:46.585621+00
4495	1	POST /api/programs/548/versions	/api/programs/548/versions	{"params":{"programId":"548"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:46.593752+00
4496	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:46.599491+00
4497	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-04-05 05:17:46.611129+00
4498	1	DELETE /api/approval/rejected/program_version/406	/api/approval/rejected/program_version/406	{"params":{"entityType":"program_version","entityId":"406"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:46.62009+00
4499	1	DELETE /api/programs/548	/api/programs/548	{"params":{"id":"548"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:46.625446+00
4510	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:17:50.665047+00
4511	1	POST /api/programs/551/versions	/api/programs/551/versions	{"params":{"programId":"551"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:17:50.671812+00
4512	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-04-05 05:17:50.676026+00
4518	1	DELETE /api/approval/rejected/program_version/410	/api/approval/rejected/program_version/410	{"params":{"entityType":"program_version","entityId":"410"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:51.840779+00
4519	1	DELETE /api/programs/552	/api/programs/552	{"params":{"id":"552"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:17:51.847482+00
4531	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:17:59.792606+00
4532	1	POST /api/users/219/roles	/api/users/219/roles	{"params":{"id":"219"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-05 05:17:59.809658+00
4534	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:18:01.655282+00
4535	1	POST /api/users/220/roles	/api/users/220/roles	{"params":{"id":"220"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-04-05 05:18:01.667485+00
4536	1	DELETE /api/users/220/roles/GIANG_VIEN/5	/api/users/220/roles/GIANG_VIEN/5	{"params":{"userId":"220","roleCode":"GIANG_VIEN","deptId":"5"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:01.679937+00
4537	1	DELETE /api/users/220	/api/users/220	{"params":{"id":"220"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:01.688151+00
4538	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:18:05.224645+00
4539	1	DELETE /api/users/222	/api/users/222	{"params":{"id":"222"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:05.233039+00
4540	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:18:07.169292+00
4541	1	DELETE /api/users/223	/api/users/223	{"params":{"id":"223"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:07.252258+00
4542	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:18:09.076697+00
4543	1	DELETE /api/users/225	/api/users/225	{"params":{"id":"225"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:09.090566+00
4544	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["username","password","display_name"]}	172.18.0.1	2026-04-05 05:18:10.911993+00
4545	1	PUT /api/users/226/toggle-active	/api/users/226/toggle-active	{"params":{"id":"226"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:10.919584+00
4546	1	DELETE /api/users/226	/api/users/226	{"params":{"id":"226"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:10.927884+00
4549	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:18:23.005024+00
4550	1	DELETE /api/roles/682	/api/roles/682	{"params":{"id":"682"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:23.010114+00
4551	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:18:32.810381+00
4552	1	DELETE /api/roles/684	/api/roles/684	{"params":{"id":"684"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:32.835502+00
4553	1	POST /api/users/1/roles	/api/users/1/roles	{"params":{"id":"1"},"bodyKeys":["role_code"]}	172.18.0.1	2026-04-05 05:18:38.073599+00
4554	1	POST /api/roles	/api/roles	{"params":{},"bodyKeys":["code","name","level"]}	172.18.0.1	2026-04-05 05:18:41.872276+00
4555	1	DELETE /api/roles/686	/api/roles/686	{"params":{"id":"686"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:41.877835+00
4557	1	PUT /api/roles/687	/api/roles/687	{"params":{"id":"687"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:18:43.716858+00
4558	1	DELETE /api/roles/687	/api/roles/687	{"params":{"id":"687"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:43.721376+00
4564	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type","parent_id"]}	172.18.0.1	2026-04-05 05:18:48.134034+00
4565	1	DELETE /api/departments/2213	/api/departments/2213	{"params":{"id":"2213"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:48.139365+00
4559	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:18:46.676404+00
4560	1	DELETE /api/departments/2211	/api/departments/2211	{"params":{"id":"2211"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:46.683011+00
4566	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:18:49.468689+00
4561	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:18:47.343387+00
4562	1	PUT /api/departments/2212	/api/departments/2212	{"params":{"id":"2212"},"bodyKeys":["name"]}	172.18.0.1	2026-04-05 05:18:47.348263+00
4563	1	DELETE /api/departments/2212	/api/departments/2212	{"params":{"id":"2212"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:47.352717+00
4567	1	DELETE /api/departments/2215	/api/departments/2215	{"params":{"id":"2215"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:49.480194+00
4568	1	POST /api/departments	/api/departments	{"params":{},"bodyKeys":["code","name","type"]}	172.18.0.1	2026-04-05 05:18:50.828067+00
4569	1	DELETE /api/departments/2217	/api/departments/2217	{"params":{"id":"2217"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:18:50.83441+00
4570	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:19:10.055862+00
4571	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:19:27.292356+00
4572	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:19:46.718424+00
4573	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["code","name","name_en","department_id","degree"]}	172.18.0.1	2026-04-05 05:20:08.357366+00
4574	1	POST /api/programs/554/versions	/api/programs/554/versions	{"params":{"programId":"554"},"bodyKeys":["academic_year"]}	172.18.0.1	2026-04-05 05:20:08.366165+00
4575	1	DELETE /api/versions/412	/api/versions/412	{"params":{"id":"412"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:20:08.375106+00
4576	1	DELETE /api/programs/554	/api/programs/554	{"params":{"id":"554"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:20:08.38271+00
4577	1	DELETE /api/programs/302	/api/programs/302	{"params":{"id":"302"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.421835+00
4578	1	DELETE /api/programs/299	/api/programs/299	{"params":{"id":"299"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.429534+00
4579	1	DELETE /api/versions/356	/api/versions/356	{"params":{"id":"356"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.446839+00
4580	1	DELETE /api/programs/472	/api/programs/472	{"params":{"id":"472"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.450127+00
4581	1	DELETE /api/versions/170	/api/versions/170	{"params":{"id":"170"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.456281+00
4582	1	DELETE /api/programs/202	/api/programs/202	{"params":{"id":"202"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.459238+00
4583	1	DELETE /api/versions/292	/api/versions/292	{"params":{"id":"292"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.464966+00
4584	1	DELETE /api/programs/348	/api/programs/348	{"params":{"id":"348"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.467294+00
4585	1	DELETE /api/versions/324	/api/versions/324	{"params":{"id":"324"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.47436+00
4586	1	DELETE /api/programs/412	/api/programs/412	{"params":{"id":"412"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.476676+00
4587	1	DELETE /api/versions/31	/api/versions/31	{"params":{"id":"31"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.482322+00
4588	1	DELETE /api/programs/17	/api/programs/17	{"params":{"id":"17"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.484731+00
4589	1	DELETE /api/versions/75	/api/versions/75	{"params":{"id":"75"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.490867+00
4590	1	DELETE /api/programs/82	/api/programs/82	{"params":{"id":"82"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.49355+00
4591	1	DELETE /api/versions/365	/api/versions/365	{"params":{"id":"365"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.498841+00
4592	1	DELETE /api/programs/489	/api/programs/489	{"params":{"id":"489"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.501163+00
4593	1	DELETE /api/versions/137	/api/versions/137	{"params":{"id":"137"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.506022+00
4594	1	DELETE /api/programs/156	/api/programs/156	{"params":{"id":"156"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.508243+00
4595	1	DELETE /api/versions/138	/api/versions/138	{"params":{"id":"138"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.51328+00
4596	1	DELETE /api/programs/157	/api/programs/157	{"params":{"id":"157"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.516181+00
4597	1	DELETE /api/versions/60	/api/versions/60	{"params":{"id":"60"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.520895+00
4598	1	DELETE /api/programs/53	/api/programs/53	{"params":{"id":"53"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.523143+00
4599	1	DELETE /api/versions/142	/api/versions/142	{"params":{"id":"142"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.528074+00
4600	1	DELETE /api/programs/167	/api/programs/167	{"params":{"id":"167"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.530393+00
4601	1	DELETE /api/versions/199	/api/versions/199	{"params":{"id":"199"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.535209+00
4602	1	DELETE /api/programs/238	/api/programs/238	{"params":{"id":"238"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.547908+00
4603	1	DELETE /api/versions/332	/api/versions/332	{"params":{"id":"332"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.552947+00
4604	1	DELETE /api/programs/427	/api/programs/427	{"params":{"id":"427"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.55533+00
4605	1	DELETE /api/versions/300	/api/versions/300	{"params":{"id":"300"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.56094+00
4606	1	DELETE /api/programs/365	/api/programs/365	{"params":{"id":"365"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.564096+00
4607	1	DELETE /api/versions/64	/api/versions/64	{"params":{"id":"64"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.56939+00
4608	1	DELETE /api/programs/64	/api/programs/64	{"params":{"id":"64"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.571763+00
4609	1	DELETE /api/versions/108	/api/versions/108	{"params":{"id":"108"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.576598+00
4610	1	DELETE /api/programs/122	/api/programs/122	{"params":{"id":"122"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.578912+00
4611	1	DELETE /api/versions/267	/api/versions/267	{"params":{"id":"267"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.583298+00
4612	1	DELETE /api/programs/315	/api/programs/315	{"params":{"id":"315"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.586006+00
4613	1	DELETE /api/versions/340	/api/versions/340	{"params":{"id":"340"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.59693+00
4614	1	DELETE /api/programs/442	/api/programs/442	{"params":{"id":"442"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.599641+00
4615	1	DELETE /api/versions/308	/api/versions/308	{"params":{"id":"308"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.604792+00
4616	1	DELETE /api/programs/380	/api/programs/380	{"params":{"id":"380"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.607317+00
4617	1	DELETE /api/versions/385	/api/versions/385	{"params":{"id":"385"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.612661+00
4618	1	DELETE /api/programs/517	/api/programs/517	{"params":{"id":"517"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.615236+00
4619	1	DELETE /api/versions/348	/api/versions/348	{"params":{"id":"348"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.621181+00
4620	1	DELETE /api/programs/457	/api/programs/457	{"params":{"id":"457"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.623776+00
4621	1	DELETE /api/versions/316	/api/versions/316	{"params":{"id":"316"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.629373+00
4630	1	DELETE /api/programs/113	/api/programs/113	{"params":{"id":"113"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.665211+00
4631	1	DELETE /api/versions/89	/api/versions/89	{"params":{"id":"89"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.670262+00
4657	1	DELETE /api/programs/158	/api/programs/158	{"params":{"id":"158"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.781479+00
4622	1	DELETE /api/programs/397	/api/programs/397	{"params":{"id":"397"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.632068+00
4623	1	DELETE /api/versions/400	/api/versions/400	{"params":{"id":"400"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.637544+00
4624	1	DELETE /api/programs/540	/api/programs/540	{"params":{"id":"540"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.641372+00
4625	1	DELETE /api/versions/135	/api/versions/135	{"params":{"id":"135"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.646783+00
4626	1	DELETE /api/programs/150	/api/programs/150	{"params":{"id":"150"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.649289+00
4627	1	DELETE /api/versions/168	/api/versions/168	{"params":{"id":"168"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.654483+00
4628	1	DELETE /api/programs/194	/api/programs/194	{"params":{"id":"194"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.657565+00
4629	1	DELETE /api/versions/105	/api/versions/105	{"params":{"id":"105"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.662807+00
4632	1	DELETE /api/programs/97	/api/programs/97	{"params":{"id":"97"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.672599+00
4633	1	DELETE /api/versions/214	/api/versions/214	{"params":{"id":"214"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.67769+00
4634	1	DELETE /api/programs/254	/api/programs/254	{"params":{"id":"254"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.68033+00
4635	1	DELETE /api/versions/57	/api/versions/57	{"params":{"id":"57"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.687475+00
4636	1	DELETE /api/programs/44	/api/programs/44	{"params":{"id":"44"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.689927+00
4637	1	DELETE /api/programs/120	/api/programs/120	{"params":{"id":"120"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.694577+00
4638	1	DELETE /api/programs/79	/api/programs/79	{"params":{"id":"79"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.698843+00
4639	1	DELETE /api/programs/62	/api/programs/62	{"params":{"id":"62"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.702859+00
4640	1	DELETE /api/programs/165	/api/programs/165	{"params":{"id":"165"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.707337+00
4641	1	DELETE /api/programs/234	/api/programs/234	{"params":{"id":"234"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.711455+00
4642	1	DELETE /api/programs/154	/api/programs/154	{"params":{"id":"154"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.715613+00
4643	1	DELETE /api/programs/51	/api/programs/51	{"params":{"id":"51"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.719593+00
4644	1	DELETE /api/programs/15	/api/programs/15	{"params":{"id":"15"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.723733+00
4645	1	DELETE /api/programs/200	/api/programs/200	{"params":{"id":"200"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.728214+00
4646	1	DELETE /api/programs/236	/api/programs/236	{"params":{"id":"236"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.732407+00
4647	1	DELETE /api/programs/16	/api/programs/16	{"params":{"id":"16"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.736899+00
4648	1	DELETE /api/programs/121	/api/programs/121	{"params":{"id":"121"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.741235+00
4649	1	DELETE /api/programs/63	/api/programs/63	{"params":{"id":"63"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.745366+00
4650	1	DELETE /api/programs/155	/api/programs/155	{"params":{"id":"155"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.750206+00
4651	1	DELETE /api/programs/80	/api/programs/80	{"params":{"id":"80"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.75517+00
4652	1	DELETE /api/programs/166	/api/programs/166	{"params":{"id":"166"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.75961+00
4653	1	DELETE /api/programs/52	/api/programs/52	{"params":{"id":"52"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.763585+00
4654	1	DELETE /api/programs/201	/api/programs/201	{"params":{"id":"201"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.768303+00
4655	1	DELETE /api/programs/153	/api/programs/153	{"params":{"id":"153"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.773528+00
4656	1	DELETE /api/versions/139	/api/versions/139	{"params":{"id":"139"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:41:46.778088+00
4658	1	DELETE /api/users/12	/api/users/12	{"params":{"id":"12"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.042322+00
4659	1	DELETE /api/users/13	/api/users/13	{"params":{"id":"13"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.046343+00
4660	1	DELETE /api/users/24	/api/users/24	{"params":{"id":"24"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.04972+00
4661	1	DELETE /api/users/35	/api/users/35	{"params":{"id":"35"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.053148+00
4662	1	DELETE /api/users/46	/api/users/46	{"params":{"id":"46"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.056347+00
4663	1	DELETE /api/users/53	/api/users/53	{"params":{"id":"53"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.05954+00
4664	1	DELETE /api/users/59	/api/users/59	{"params":{"id":"59"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.067679+00
4665	1	DELETE /api/users/65	/api/users/65	{"params":{"id":"65"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.071325+00
4666	1	DELETE /api/users/76	/api/users/76	{"params":{"id":"76"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.074656+00
4667	1	DELETE /api/departments/1796	/api/departments/1796	{"params":{"id":"1796"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.082831+00
4668	1	DELETE /api/departments/1652	/api/departments/1652	{"params":{"id":"1652"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.087285+00
4669	1	DELETE /api/roles/470	/api/roles/470	{"params":{"id":"470"},"bodyKeys":[]}	172.18.0.1	2026-04-05 05:42:01.094212+00
\.


--
-- Data for Name: clo_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.clo_plo_map (clo_id, plo_id, contribution_level) FROM stdin;
5	6	3
6	6	3
7	6	3
8	1	3
9	140	3
10	140	3
11	140	3
12	135	3
\.


--
-- Data for Name: course_clos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_clos (id, version_course_id, code, description) FROM stdin;
5	1	CLO1	Giải thích các khái niệm cơ bản về TTNT và cách TTNT hoạt động.
6	1	CLO2	Sử dụng các công cụ TTNT hiệu quả và có trách nhiệm.
7	1	CLO3	Áp dụng TTNT để phát triển các giải pháp một cách sáng tạo
8	1	CLO4	Thể hiện thái độ chuyên cần và tích cực trong học tập để tự điều chỉnh và phát triển năng lực học tập suốt đời
9	783	CLO1	Giải thích các khái niệm cơ bản về TTNT và cách TTNT hoạt động.
10	783	CLO2	Sử dụng các công cụ TTNT hiệu quả và có trách nhiệm.
11	783	CLO3	Áp dụng TTNT để phát triển các giải pháp một cách sáng tạo
12	783	CLO4	Thể hiện thái độ chuyên cần và tích cực trong học tập để tự điều chỉnh và phát triển năng lực học tập suốt đời
\.


--
-- Data for Name: course_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_plo_map (version_id, course_id, plo_id, contribution_level) FROM stdin;
1	5	1	2
1	5	3	3
1	6	1	3
1	6	3	2
1	8	4	3
1	8	2	2
1	7	2	2
1	7	3	3
1	9	1	1
1	9	2	2
1	10	2	3
1	10	5	2
1	10	6	1
1	11	2	2
1	11	3	3
1	11	6	2
1	12	1	2
1	12	6	3
1	15	2	3
1	15	5	2
1	15	6	2
1	16	5	3
1	16	6	2
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.courses (id, code, name, credits, credits_theory, credits_practice, credits_project, credits_internship, department_id, description) FROM stdin;
1	IT001	Nhập môn lập trình	3	2	1	0	0	5	Giới thiệu tư duy lập trình, cú pháp C/C++, cấu trúc điều khiển, hàm, mảng
2	IT002	Cấu trúc dữ liệu và giải thuật	3	2	1	0	0	5	Danh sách liên kết, ngăn xếp, hàng đợi, cây, đồ thị, sắp xếp, tìm kiếm
3	IT003	Cơ sở dữ liệu	3	2	1	0	0	5	Mô hình quan hệ, SQL, chuẩn hóa, transaction, thiết kế CSDL
4	IT004	Lập trình hướng đối tượng	3	2	1	0	0	5	OOP với Java: class, kế thừa, đa hình, interface, design pattern cơ bản
5	IT005	Mạng máy tính	3	2	1	0	0	5	Mô hình OSI/TCP-IP, định tuyến, giao thức mạng, bảo mật mạng cơ bản
6	IT006	Công nghệ phần mềm	3	2	1	0	0	5	Quy trình SDLC, Agile/Scrum, UML, kiểm thử phần mềm, quản lý dự án
7	IT007	Phát triển ứng dụng Web	3	1	2	0	0	5	HTML/CSS/JS, React/Vue, Node.js, REST API, triển khai ứng dụng web
8	IT008	Trí tuệ nhân tạo	3	2	1	0	0	5	Tìm kiếm, học máy, mạng nơ-ron, xử lý ngôn ngữ tự nhiên, ứng dụng AI
9	IT009	Đồ án chuyên ngành	3	0	0	3	0	5	Thực hiện dự án CNTT theo nhóm, áp dụng quy trình phát triển phần mềm
10	IT010	Thực tập doanh nghiệp	3	0	0	0	3	5	Thực tập tại doanh nghiệp CNTT, báo cáo kết quả thực tập
11	GE001	Triết học Mác - Lênin	3	3	0	0	0	5	Các nguyên lý cơ bản của chủ nghĩa Mác-Lênin về triết học
12	GE002	Tiếng Anh 1	3	2	1	0	0	5	Ngữ pháp, từ vựng, kỹ năng nghe-nói-đọc-viết trình độ A2-B1
13	GE003	Toán cao cấp	3	3	0	0	0	5	Đại số tuyến tính, giải tích, xác suất thống kê ứng dụng trong CNTT
14	GE004	Vật lý đại cương	3	2	1	0	0	5	Cơ học, điện từ, quang học — nền tảng cho kỹ thuật phần cứng
15	IT011	An toàn thông tin	3	2	1	0	0	5	Mã hóa, xác thực, bảo mật hệ thống, tấn công và phòng thủ mạng
16	IT012	Điện toán đám mây	3	1	2	0	0	5	AWS/Azure/GCP, container, microservices, CI/CD, serverless
34	CHN108	Tiếng Trung – Nghe 2	3	3	0	0	0	4	Nội dung luyện tập gồm nghe những câu văn, đoạn đối thoại dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc.
45	CHN119	Tiếng Trung – Đọc 3	3	3	0	0	0	4	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, các điểm ngữ pháp ở mức độ trung cấp, các mẫu câu thường gặp thông qua nội dung các bài khóa xoay quanh các chủ đề như văn hóa, xã hội, kinh tế,... Mỗi bài học đều có bài khóa, từ vựng, điểm ngữ pháp cũng như phần luyện tập. Những bài tập này cũng được nâng lên một tầm cao mới, từ việc đọc đúng âm, rõ nghĩa, hiểu nội dung chính đến khả năng phân tích, đánh giá và đưa ra luận điểm cá nhân.
61	CHN144	Kỹ năng dịch viết tiếng Trung	3	3	0	0	0	4	Học phần giới thiệu môn học, phương pháp học môn phiên dịch viết tiếng Trung. Sau đó, giới thiệu tổng quan về các chủ đề đọc hiểu cùng các mẫu câu thông dụng theo các bài giảng. Thực hành dịch văn bản trong các tình huống cụ thể, dịch văn bản trong các sự kiện ở một số lĩnh vực (văn hóa, giáo dục, thương mại, du lịch…)
67	PHT304	Bóng chuyền 1	2	0	0	0	0	12	Học phần trang bị cho sinh viên những kiến thức cơ bản về lịch sử hình thành và phát triển môn Bóng chuyền, tổ chức quản lý môn thể thao này trong nước và quốc tế, hệ thống luật thi đấu và các kỹ thuật chính như chuyền bóng, đệm bóng và phát bóng. Đồng thời, sinh viên được rèn luyện kỹ năng thực hành thông qua các bài tập đệm bóng thấp tay, chuyền bóng cao tay và phát bóng, góp phần nâng cao thể lực, kỹ thuật cá nhân và khả năng phối hợp trong thi đấu.
17	POS104	Triết học Mác - Lênin	3	3	0	0	0	13	Triết học Mác – Lê nin là học phần bắt buộc trong khối kiến thức cơ bản nhằm trang bị các kiến thức cơ bản về triết học học Mác – Lênin, học phần được cấu trúc gồm: (i) Trình bày những nét khái quát về triết học, triết học Mác – Lênin trong đời sống xã hội; (ii) Trình bày những nội dung cơ bản của chủ nghĩa duy vật biện chứng như: vật chất và ý thức; phép biện chứng duy vật; lý luận nhận thức của chủ nghĩa duy vật biện chứng; (iii) Trình bày những nội dung cơ bản của chủ nghĩa duy vật lịch sử, gồm vấn đề hình thái kinh tế - xã hội; giai cấp và dân tộc; nhà nước và cách mạng xã hội; ý thức xã hội; triết học về con người, quần chúng nhân dân.
18	POS105	Kinh tế chính trị Mác - Lênin	2	2	0	0	0	13	Nội dung học phần gồm 6 bài trong đó:Bài 1: Bàn về đối tượng, phương pháp nghiên cứu và chức năng của Kinh tế chính trị Mác – Lênin. Từ bài 2 đến bài 6 trình bày nội dung cốt lõi của kinh tế chính trị Mác – Lênin theo mục tiêu môn học. Cụ thể các vấn đề như: Hàng hóa, thị trường và vai trò của các chủ thể trong nền kinh tế thị trường; Giá trị thặng dư và quan hệ lợi ích trong nền kinh tế thị trường; Cạnh tranh và độc quyền trong nền kinh tế thị trường; Kinh tế thị trường định hướng XHCN ở Việt Nam; Cách mạng công nghiệp và hội nhập kinh tế quốc tế trong phát triển của Việt Nam
19	POS106	Chủ nghĩa xã hội khoa học	2	2	0	0	0	13	Chủ nghĩa xã hội khoa học là học phần bắt buộc trong khối kiến thức cơ bản, cung cấp những hiểu biết nền tảng về quá trình hình thành và phát triển của CNXHKH. Học phần gồm 7 bài, tập trung vào các nội dung chính: (1) sự ra đời và các giai đoạn phát triển của Chủ nghĩa xã hội khoa học; (2) sứ mệnh lịch sử của giai cấp công nhân, đặc biệt trong bối cảnh Việt Nam; (3) khái niệm chủ nghĩa xã hội và thời kỳ quá độ; (4) những vấn đề quy luật trong cách mạng xã hội chủ nghĩa như dân chủ, nhà nước pháp quyền; (5) cơ cấu xã hội - giai cấp và liên minh giai cấp trong thời kỳ quá độ; (6) vấn đề dân tộc, tôn giáo và mối quan hệ giữa chúng trong chủ nghĩa xã hội; (7) vai trò, chức năng của gia đình và định hướng xây dựng gia đình trong thời kỳ quá độ lên chủ nghĩa xã hội tại Việt Nam.
20	POS107	Lịch sử Đảng Cộng sản Việt Nam	2	2	0	0	0	13	Nội dung học phần gồm 5 bài: (1) trình bày đối tượng, chức năng, nhiệm vụ, phương pháp nghiên cứu, học tập môn Lịch sử Đảng; (2) Đảng cộng sản Việt Nam ra đời và lãnh đạo cách mạng giải phóng dân tộc (1930-1945); (3) trình bày về quá trình lãnh đạo của Đảng trong hai cuộc kháng chiến chống ngoại xâm chống Pháp và chống Mỹ (1945-1975); (4) trình bày những nội dung cơ bản về quá trình phát triển đường lối và lãnh đạo của Đảng trong quá trình đưa cả nước quá độ lên chủ nghĩa xã hội và tiến hành công cuộc đổi mới (1975 đến nay); (5) tổng kết những thắng lợi vĩ đại của dân tộc dưới sự lãnh đạo của Đảng và những bài học kinh nghiệm của Đảng trong quá trình lãnh đạo cách mạng.
21	POS103	Tư tưởng Hồ Chí Minh	2	2	0	0	0	13	Tư tưởng Hồ Chí Minh là học phần cơ sở bắt buộc trong chương trình đào tạo Đại học của tất cả các chuyên ngành; với cấu trúc nội dung bao gồm 6 bài: (1) Khái niệm, đối tượng, phương pháp nghiên cứu và ý nghĩa học tập môn Tư tưởng Hồ Chí Minh; (2) Cơ sở, quá trình hình thành và phát triển tư tưởng Hồ Chí Minh; (3) Tư tưởng Hồ Chí Minh về độc lập dân tộc và chủ nghĩa xã hội; (4) Tư tưởng Hồ Chí Minh về Đảng Cộng sản Việt Nam và Nhà nước của nhân dân, do nhân dân, vì nhân dân; (5) Tư tưởng Hồ Chí Minh về đại đoàn kết toàn dân tộc và đoàn kết quốc tế; (6) Tư tưởng Hồ Chí Minh về văn hóa, đạo đức và con người
22	ENC120	Anh ngữ 1	3	3	0	0	0	6	Nội dung học phần Anh Ngữ 1 được thiết kế giảng dạy với 6 đơn vị bài học, bao gồm kiến thức ngôn ngữ về từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc trong cuộc sống, trải nghiệm cá nhân, quản lý thời gian, du lịch thế giới, cảnh quan, thời trang,  tương đương trình độ Bậc 2 theo khung NLNNVN.
23	ENC121	Anh ngữ 2	3	3	0	0	0	6	Nội dung học phần Anh Ngữ 2 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần trang bị kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc như âm nhạc, cuộc sống, các mối quan hệ, du lịch, môi trường, tương đương trình độ trung cấp B1.
24	ENC122	Anh ngữ 3	3	3	0	0	0	6	Nội dung học phần Anh Ngữ 3 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần cung cấp kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc trong cuộc sống như giao tiếp, trao đổi thông tin, thói quen, thực phẩm, du lịch, tương đương trình độ trung cấp B1+
25	ENC123	Anh ngữ 4	3	3	0	0	0	6	Nội dung học phần Anh Ngữ 4 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần trang bị kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề trong cuộc sống thường ngày, nêu cách suy nghĩ, giải quyết vấn đề, tương đương trình độ trung cấp B1+
578	AIT129	Trí tuệ nhân tạo ứng dụng	3	3	0	0	0	5	Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn
27	ENS192	Phát triển bền vững	3	3	0	0	0	11	Học phần Phát triển bền vững cung cấp nền tảng kiến thức về khái niệm, nguyên tắc và thực tiễn nhằm đạt được sự cân bằng giữa các mục tiêu kinh tế, xã hội và môi trường. Nội dung học phần bao gồm: tổng quan về phát triển bền vững, lịch sử hình thành và các thách thức hiện tại; vai trò của tài nguyên môi trường, chiến lược khai thác và bảo vệ tài nguyên bền vững; mối quan hệ giữa kinh tế xanh, kinh tế tuần hoàn và bảo vệ môi trường; yếu tố xã hội như giáo dục, y tế, bình đẳng và cộng đồng trong phát triển bền vững; cùng với các công cụ quản trị và chính sách quốc gia, quốc tế nhằm thúc đẩy mục tiêu này.  Qua đó, học phần trang bị cho sinh viên khả năng phân tích vấn đề, đề xuất giải pháp và ứng dụng tư duy hệ thống vào thực tế, đặc biệt trong việc giải quyết các thách thức phát triển bền vững như quản lý và bảo vệ tài nguyên, giảm thiểu tác động tiêu cực đến môi trường, thúc đẩy kinh tế xanh và phát triển xã hội bền vững.
28	LAW158	Luật và Khởi nghiệp	3	3	0	0	0	8	Học phần cung cấp những kiến thức cơ bản về Nhà nước, Pháp luật và Khởi nghiệp, giúp sinh viên áp dụng vào thực tiễn, đặc biệt trong bối cảnh khởi nghiệp kinh doanh. Nội dung gồm hai phần chính:(1) Những vấn đề cơ bản về Nhà nước và Pháp luật, giúp sinh viên hiểu về bộ máy Nhà nước, hệ thống pháp luật Việt Nam và các ngành luật quan trọng;(2) Tổng quan về Khởi nghiệp, trang bị kiến thức về ý tưởng kinh doanh, nghiên cứu thị trường, lập kế hoạch kinh doanh, tài chính, nhân sự và quản lý rủi ro. Học phần hướng đến việc nâng cao nhận thức, khả năng phân tích và lập kế hoạch, đồng thời khuyến khích tinh thần chủ động, trách nhiệm, tuân thủ pháp luật và đạo đức kinh doanh.
29	SKL115	Tư duy thiết kế dự án	3	3	0	0	0	10	Học phần "Tư duy thiết kế dự án" cung cấp kiến thức và kỹ năng thiết yếu để phát hiện và giải quyết vấn đề thông qua quy trình tư duy thiết kế. Nội dung học phần xoay quanh quy trình gồm 7 bước chính: (1) Phát hiện vấn đề; (2) Khảo sát thực trạng vấn đề; (3) Khảo sát nhu cầu giải quyết vấn đề của các bên liên quan; (4) Khảo sát và đánh giá các giải pháp hiện có; (5) Phân tích cấu trúc nguyên nhân vấn đề; (6) Thiết lập điều kiện tiên quyết và (7) Sáng tạo và đề xuất giải pháp. Với định hướng thực tiễn và bền vững, học phần không chỉ hỗ trợ phát triển các kỹ năng cá nhân mà còn góp phần giải quyết các vấn đề xã hội theo các mục tiêu phát triển bền vững của Liên Hợp Quốc (SDGs).
30	MAN116	Quản trị học	3	3	0	0	0	7	Quản trị học là học phần cung cấp kiến thức cơ bản về công tác quản trị một tổ chức. Học phần này trang bị cho người học những nội dung về khái niệm, vai trò của công tác quản trị trong một tổ chức, phân loại môi trường và cách thức quản trị sự bất trắc môi trường, các chức năng của quản trị (Hoạch định, tổ chức, điều khiển, kiểm soát). Ngoài ra, học phần còn đề cập đến các vấn đề liên quan tác động đến hiệu quả quản trị tổ chức như thông tin quản lý, văn hóa tổ chức, kỹ năng ra quyết định của nhà quản trị.
31	ENG183	Dẫn luận ngôn ngữ	3	3	0	0	0	9	Học phần gồm 05 đơn vị bài học cung cấp cho sinh viên:- Kiến thức cơ bản về ngôn ngữ và ngôn ngữ học: đặc trưng, chức năng, hệ thống, cấu trúc, loại hình ngôn ngữ; các  bình diện sử dụng ngôn ngữ: cú pháp, từ vựng, ngữ nghĩa…- Môn học còn cung cấp những kiến thức cơ bản của tiếng Việt, giúp người học phát triển các kỹ năng sử dụng từ, viết câu; có khả năng phát hiện và sửa chữa các lỗi sử dụng tiếng Việt, các hình thức và cách diễn đạt ngôn ngữ.
32	SLK122	Kỹ năng phát triển bản thân	3	3	0	0	0	14	Học phần trang bị cho sinh viên các kiến thức và kỹ năng cần thiết để phát triển bản thân và sự nghiệp trong tương lai thông qua các kỹ năng như kỹ năng tìm kiếm nguồn lực hỗ trợ phát triển bản thân, xây dựng tác phong làm việc, kỹ năng tìm việc. Học phần gồm 5 bài học về hiểu bản thân, các nguồn lực và phát triển bản thân, kỹ năng tìm kiếm và khai thác nguồn lực, tác phong làm việc chuyên nghiệp, và dự án phát triển bản thân. Thông qua các bài học lý thuyết và thực hành, sinh viên sẽ có thể: (1) Hiểu rõ bản thân và chủ động tìm kiếm các nguồn lực phù hợp để phát triển bản thân; (2) Xây dựng phong cách làm việc chuyên nghiệp và áp dụng tác phong đó vào học tập và công việc (3) Lập kế hoạch và xây dựng được dự án phát triển bản thân.
33	CHN107	Tiếng Trung – Nghe 1	3	3	0	0	0	4	Nội dung luyện tập gồm nghe và đọc hệ thống phiên âm, nghe những câu văn dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc
35	CHN109	Tiếng Trung – Nghe 3	3	3	0	0	0	4	Nội dung luyện tập gồm nghe những đoạn văn, bài hội thoại dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc.
36	CHN110	Tiếng Trung – Nghe 4	3	3	0	0	0	4	Nội dung luyện tập gồm nghe những đoạn văn dài, đoạn hội thoại dài dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc
37	CHN111	Tiếng Trung – Nghe 5	3	3	0	0	0	4	Nội dung luyện tập gồm nghe những đoạn văn dài, đoạn hội thoại dài dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên có khả năng phân tích thông tin trong các tình huống giao tiếp phức tạp
38	CHN112	Tiếng Trung – Nói 1	3	3	0	0	0	4	Học phần Tiếng Trung Nói 1 gồm 12 bài học và 3 bài ôn tập, tập trung vào việc giới thiệu hệ thống phiên âm, thanh điệu và ngữ âm cơ bản trong tiếng Trung. Sinh viên được học cách viết phiên âm, luyện đọc và sử dụng các mẫu câu cơ bản trong các chủ đề giao tiếp hàng ngày như giới thiệu bản thân, chào hỏi, hỏi thăm sức khỏe, số lượng, tiền tệ, nơi chốn. Học phần giúp sinh viên xây dựng khả năng phản xạ giao tiếp, luyện tập các đoạn hội thoại ngắn và làm quen với cách diễn đạt của người bản địa. Ngoài ra, các bài tập thực hành như đóng vai, luyện tập theo cặp và nhóm được lồng ghép để tăng sự hứng thú và hiệu quả học tập
39	CHN113	Tiếng Trung – Nói 2	3	3	0	0	0	4	Học phần Tiếng Trung Nói 2 gồm 12 bài học và 3 bài ôn tập, tiếp tục củng cố kỹ năng nói thông qua các chủ đề quen thuộc trong cuộc sống hàng ngày như mua sắm, gọi món ăn, giới thiệu quê hương, gọi điện thoại và tìm bạn học ngoại ngữ. Sinh viên được học cách nắm bắt ý chính của bài khóa, luyện tập các đoạn hội thoại ngắn và áp dụng từ vựng, ngữ pháp đã học vào giao tiếp. Học phần chú trọng vào việc thực hành nghe – nói, giúp sinh viên phản xạ nhanh hơn và giao tiếp tự tin hơn trong các tình huống thường gặp. Các hoạt động nhóm và bài tập thực hành giúp sinh viên nâng cao khả năng giao tiếp và phát triển kỹ năng làm việc nhóm.
40	CHN114	Tiếng Trung – Nói 3	3	3	0	0	0	4	Học phần Tiếng Trung Nói 3 gồm 12 bài học và 3 bài ôn tập, xoay quanh các chủ đề giao tiếp thực tiễn như đi tàu xe, gửi bưu phẩm, khám bệnh, và các vấn đề sinh hoạt thường ngày. Sinh viên được học các mẫu câu mới, tích lũy vốn từ vựng và luyện tập các đoạn hội thoại phù hợp với văn phong của người bản địa. Học phần giúp sinh viên rèn luyện kỹ năng phản xạ, thực hành xây dựng và trình bày các đoạn hội thoại ngắn, cũng như bày tỏ quan điểm cá nhân trong các tình huống cụ thể. Các bài tập nhóm, đóng vai và thuyết trình được lồng ghép để tăng cường khả năng giao tiếp hiệu quả
41	CHN115	Tiếng Trung – Nói 4	3	3	0	0	0	4	Học phần Tiếng Trung Nói 4 gồm 12 bài học và 3 bài ôn tập, bao gồm các chủ đề đa dạng về cuộc sống, xã hội, gia đình và học tập. Sinh viên sẽ được học cách xây dựng bài nói theo từng chủ đề, vận dụng từ vựng và ngữ pháp đã học để thảo luận, tranh luận và giải quyết vấn đề. Học phần tập trung vào việc phát triển khả năng tư duy logic, diễn đạt ý tưởng rõ ràng và tự nhiên. Thông qua các bài tập nhóm, thuyết trình và tranh luận, sinh viên sẽ cải thiện khả năng giao tiếp, trình bày và phản biện trong các ngữ cảnh cụ thể.
42	CHN116	Tiếng Trung – Nói 5	3	3	0	0	0	4	Học phần Tiếng Trung Nói 5 tập trung phát triển kỹ năng giao tiếp nâng cao bằng tiếng Trung trong các tình huống thực tế và chuyên môn. Nội dung học phần bao gồm việc củng cố và mở rộng vốn từ vựng, cấu trúc ngữ pháp, cùng cách diễn đạt phong phú trong các chủ đề nâng cao. Sinh viên sẽ được thực hành các kỹ năng như thuyết trình, tranh luận, và xử lý tình huống giao tiếp trong các bối cảnh học tập, công việc và đời sống hàng ngày. Ngoài ra, học phần tích hợp các bài tập nhóm, bài nói cá nhân để rèn luyện tư duy phản biện, khả năng làm việc nhóm và sự tự tin trong giao tiếp. Đặc biệt, sinh viên sẽ có cơ hội trải nghiệm thực tế nghề nghiệp thông qua các hoạt động với sự tham gia của doanh nghiệp hoặc chuyên gia trong ngành, giúp làm quen với môi trường làm việc thực tế và phát triển kỹ năng chuyên môn cơ bản. Học phần không chỉ giúp sinh viên thành thạo hơn trong kỹ năng nói tiếng Trung mà còn trang bị hành trang cần thiết để đáp ứng các yêu cầu công việc trong tương lai.
43	CHN117	Tiếng Trung – Đọc 1	3	3	0	0	0	4	Nội dung môn học chủ yếu gồm có bài khóa, từ vựng, điểm ngữ pháp và phần luyện tập. Bài khóa có nội dung đa dạng, ngắn và dễ hiểu, giúp sinh viên làm quen với văn phong của tiếng Trung, từ đó mở rộng vốn từ vựng và ngữ pháp. Phần luyện tập có nội dung xoay quanh chủ đề của bài khóa, giúp sinh viên ghi chép, đánh dấu các thông tin có được từ bài khóa.
44	CHN118	Tiếng Trung – Đọc 2	3	3	0	0	0	4	Nội dung môn học tập trung chủ yếu vào vốn từ vựng, ngữ pháp cơ bản và kỹ năng đọc hiểu của sinh viên ở mức độ sơ cấp bằng việc mở rộng thêm vốn từ vựng, tìm hiểu sâu hơn về các điểm ngữ pháp sau mỗi bài khóa. Phần luyện tập sau mỗi bài khóa trang bị thêm cho sinh viên những kiến thức về văn hóa, xã hội thông qua việc đọc hiểu và trả lời các câu hỏi xoay quanh các mẫu hội thoại, các văn bản có nội dung gần gũi với đời sống thường ngày.
46	CHN120	Tiếng Trung – Đọc 4	3	3	0	0	0	4	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, các điểm ngữ pháp ở mức độ trung và cao cấp, các cấu trúc ngữ pháp phức tạp thông qua nội dung các bài khóa xoay quanh các chủ đề như văn hóa, xã hội, kinh tế,... Mỗi bài học đều có bài khóa, từ vựng, điểm ngữ pháp cũng như phần luyện tập. Những bài tập này cũng được nâng lên mức tương đối khó, nhằm phát triển khả năng phân tích, đánh giá và đưa ra luận điểm cá nhân.
47	CHN121	Tiếng Trung – Đọc 5	3	3	0	0	0	4	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, bao gồm cả những từ vựng chuyên ngành, thành ngữ, tục ngữ, các phép tu từ,… thông qua các bài khóa có nội dung liên quan đến các chủ đề kinh tế, văn hóa và xã hội. Sau mỗi bài khóa, học phần còn cung cấp thêm nhiều điểm ngữ pháp cao cấp, các cấu trúc câu phức tạp cũng như bài tập minh họa để ví dụ, từ đó làm rõ các kiến thức đang học cũng như áp dụng các kiến thức đã học vào các bài tập thực tế.
48	CHN122	Tiếng Trung – Viết 1	3	3	0	0	0	4	Học phần cung cấp cho sinh viên kiến thức cơ bản về quy tắc viết chữ Hán ( quy tắc bút thuận), cung cấp kiến thức về lịch sử hình thành và phát triển của chữ Hán, cách viết chữ Hán, các bộ, các tự dạng chữ Hán ở mức độ nhập môn.Kết thúc học phần sinh viên có thể thực hành viết chữ Hán giản thể và nhận biết chữ Hán phồn thể ở mức độ sơ cấp; Sinh viên có thể viết các mẫu câu đa dạng theo những chủ đề quen thuộc như giới thiệu bản thân, gia đình, sở thích…
49	CHN123	Tiếng Trung – Viết 2	3	3	0	0	0	4	Môn học thông qua các bài viết giúp sinh viên: Biết phân biệt và viết đúng dấu câu trong tiếng Hán; Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên có thể soạn thảo các mẫu thư tín xã giao, các đơn từ trong hành chính…; Sinh viên làm quen và phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc quan sát sự việc hoặc hình ảnh.
50	CHN124	Tiếng Trung – Viết 3	3	3	0	0	0	4	Môn học thông qua các bài viết giúp sinh viên: Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên có thể soạn thảo các mẫu thư tín xã giao, các đơn từ trong hành chính…; Sinh viên làm quen và phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc quan sát sự việc hoặc hình ảnh
51	CHN125	Tiếng Trung – Viết 4	3	3	0	0	0	4	Môn học thông qua các bài viết giúp sinh viên: Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên làm quen và phát triển kỹ năng viết độc lập, sáng tạo và logic theo chủ đề.
52	CHN126	Tiếng Trung – Viết 5	3	3	0	0	0	4	Môn học thông qua các bài viết giúp sinh viên: Phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc thuật lại, lên kế hoạch và viết báo cáo tổng kết
53	CHN134	Lý thuyết tiếng Trung Quốc	3	3	0	0	0	4	Môn học cung cấp kiến thức nền tảng về ngữ âm, văn tự, từ vựng và ngữ pháp tiếng Hán hiện đại, giúp sinh viên nhận biết cấu trúc, chức năng của các thành phần ngôn ngữ, phân tích mối quan hệ giữa hình - âm - nghĩa của chữ Hán . Sinh viên được rèn luyện khả năng tư duy phản biện, phân tích và đánh giá các vấn đề ngôn ngữ để áp dụng chính xác vào thực tiễn giao tiếp và học thuật. Thông qua các bài giảng lý thuyết, bài tập thực hành và thảo luận, sinh viên sẽ nắm vững hệ thống kiến thức về tiếng Hán hiện đại, từ đó áp dụng hiệu quả vào học tập và công việc.
54	SOS118	Văn hoá, xã hội Trung Quốc	3	3	0	0	0	4	Học phần Văn hóa – Xã hội Trung Quốc (SOS118) trang bị cho sinh viên kiến thức tổng quan về địa lý, lịch sử, văn hóa, phong tục, ẩm thực, nghệ thuật và tư tưởng truyền thống Trung Quốc. Môn học giúp sinh viên phát triển tư duy phân tích, tổng hợp, rèn luyện kỹ năng làm việc nhóm, và ý thức trách nhiệm xã hội trong bối cảnh toàn cầu hóa.Sinh viên sẽ biết cách khai thác tài liệu, cập nhật kiến thức chuyên ngành và vận dụng tiếng Trung để giải quyết các vấn đề thực tiễn liên quan đến văn hóa - xã hội.
55	CHN5002	Thực tế trải nghiệm văn hóa và ngôn ngữ Trung Quốc	3	0	0	0	3	4	-Học phần này thông qua nhiều hoạt động trải nghiệm phong phú, giúp sinh viên khám phá văn hóa Trung Quốc. Đầu tiên, sinh viên sẽ được giới thiệu tổng quan về văn hóa, ngôn ngữ vàhướng dẫn phương pháp nghiên cứu thực địa, kỹ năng viết báo cáo,làm việc nhóm. Sau đó, học phần đi sâu vào giao tiếp liên văn hóa và so sánh sự khác biệt giữa văn hóa Việt Nam và Trung Quốc.Các buổi trải nghiệm thực tế bao gồm tham quan không gian văn hóa người Hoa,tham gia các sự kiện văn hóa TrungHoahoặc workshop giao tiếp với người bản ngữ để nâng cao kỹ năng nghe-nói và hiểu biết xã hội.Mỗi chuyến đi đều có nhiệm vụ cụ thể như phỏng vấn, ghi chép, chụp ảnh tư liệu, thử nghiệm ẩm thực, hoặc quan sát nghi lễ truyền thống.-Cuối cùng, sinh viên sẽ làm việc nhóm để xây dựng và thuyết trình một dự án về văn hóa TrungHoa, từ phân tích dữ liệu đến thiết kế sản phẩm như slide, video hoặc brochure.
56	CHN546	Thực tập tốt nghiệp ngành Ngôn ngữ Trung Quốc (*)	3	0	0	0	3	4	Học phần “Thực tập tốt nghiệp ngành Ngôn ngữ Trung Quốc” nhằm trang bị cho sinh viên kiến thức và kỹ năng để áp dụng vào thực tiễn công việc. Trong học phần này, sinh viên sẽ được hướng dẫn lựa chọn doanh nghiệp phù hợp để thực tập, lập kế hoạch thực tập, xác định đề tài và viết đề cương chi tiết. Quá trình thực tập bao gồm việc sinh viên tham gia trực tiếp vào các hoạt động tại đơn vị thực tập, thực hiện các nhiệm vụ được giao, thu thập và phân tích dữ liệu thực tế. Sinh viên sẽ hoàn thiện báo cáo thực tập, bao gồm các tài liệu liên quan như nhật ký thực tập, nhận xét từ giảng viên hướng dẫn và đơn vị thực tập. Học phần kết thúc bằng buổi bảo vệ báo cáo trước hội đồng, đánh giá toàn diện khả năng áp dụng kiến thức, kỹ năng giải quyết vấn đề, và năng lực phản biện của sinh viên.Học phần đặc biệt chú trọng tích hợp công cụ trí tuệ nhân tạo (AI) trong các hoạt động như phân tích dữ liệu, dịch thuật, lập kế hoạch và viết báo cáo, nhằm nâng cao hiệu quả và tính chuyên nghiệp. Đồng thời, năng lực giải quyết vấn đề được phát triển qua các nhiệm vụ thực tiễn, từ việc xác định vấn đề, đề xuất giải pháp đến triển khai và đánh giá hiệu quả thực hiện.
57	CHN135	Thư tín thương mại tiếng Trung	3	3	0	0	0	4	Nội dung môn học xoay quanh các chủ đề về thư tín thương mại, văn phòng như: cách viết thư mời, thư giới thiệu, thư cảm ơn, thư xin lỗi, thư thiết lập mối quan hệ thương mại, thư hỏi giá, báo giá, thư thương lượng định giá,... Môn học trang bị cho người học khối kiến thức và vốn từ vựng, thuật ngữ nhất định về thư tín thương mại, văn phòng, giúp sinh viên nhận biết và biết cách viết các loại thư này.
58	CHN128	Tiếng Trung Thương mại	3	3	0	0	0	4	Học phần Tiếng Trung thương mại là một môn học trang bị cho người học những kiến thức và kỹ năng giao tiếp tiếng Trung chuyên ngành, phục vụ công việc trong môi trường kinh doanh, thương mại.Thông qua các hoạt động xử lý tình huống thực tế và đóng vai, sinh viên được rèn luyện năng lực sử dụng tiếng Trung trong môi trường thương mại. Học phần cũng góp phần hình thành tư duy ngôn ngữ chuyên ngành, hỗ trợ sinh viên định hướng nghề nghiệp trong các lĩnh vực như phiên dịch thương mại, quan hệ khách hàng, xuất nhập khẩu, và hợp tác quốc tế.
59	CHN137	Tiếng Trung hành chính – văn phòng	3	3	0	0	0	4	Học phần xoay quanh các vấn đề thường gặp khi làm việc trong môi trường công ty/công sở như: tổ chức cuộc họp, mua văn phòng phẩm, giới thiệu về cơ cấu tổ chức của một công ty, cách trình bày ý kiến cá nhân, báo cáo công việc, giải quyết nghỉ việc, quảng cáo tuyên truyền, tuyển dụng, tập huấn,…Mỗi bài đều được thiết kế gồm các phần: từ mới, bài khóa, điểm ngữ pháp cần lưu ý và bài tập. Bài khóa chủ yếu xuất hiện những mẫu câu cơ bản thường được dùng trong giao tiếp hành chính - văn phòng. Bài tập giao tiếp bám sát nội dung kiến thức trong từng bài giúp sinh viên rèn luyện khả năng phản xạ trong các tình huống cụ thể.Môn học này là cơ hội để sinh viên tiếp cận và làm quen với các nghiệp vụ cụ thể trong văn phòng, là nền tảng tốt cho các hoạt động nghề nghiệp sau này liên quan đến ngôn ngữ và văn hóa Trung Quốc.
60	CHN139	Kỹ năng dịch nói tiếng Trung	3	3	0	0	0	4	Học phần cung cấp kiến thức và kỹ năng cần thiết để thực hiện các nhiệm vụ dịch nói Trung-Việt và Việt-Trung trong các tình huống giao tiếp thực tế. Học phần tập trung vào phát triển năng lực nghe hiểu, phân tích, và diễn đạt chính xác thông điệp giữa hai ngôn ngữ, đồng thời rèn luyện khả năng xử lý thông tin nhanh chóng và linh hoạt. Sinh viên sẽ được trang bị các kỹ năng thực hành dịch nói qua các bài tập câu thoại, bài diễn văn ngắn, và tình huống giả định đơn giản.
62	AIT1021	Ứng dụng AI trong dịch thuật tiếng Trung	3	3	0	0	0	4	Học phần “Ứng dụng AI trong dịch thuật tiếng Trung” giới thiệu tổng quan về các công nghệ trí tuệ nhân tạo đang được sử dụng trong lĩnh vực dịch thuật. Sinh viên sẽ được hướng dẫn cách sử dụng, phân tích đầu ra của các công cụ dịch máy, và kết hợp giữa bản dịch tự động với hiệu chỉnh thủ công nhằm nâng cao chất lượng bản dịch tiếng Trung. Ngoài ra, học phần cũng giúp người học nhận diện các lỗi thường gặp trong dịch máy, từ đó hình thành năng lực lựa chọn công cụ phù hợp với từng ngữ cảnh dịch cụ thể.
615	CHN1003	Thiết kế giáo án và thực hành giảng dạy tiếng Trung	3	3	0	0	0	4	Học phần này cung cấp cho sinh viên những kiến thức và kỹ năng cơ bản để thiết kế giáo án giảng dạy tiếng Trung. Nội dung gồm các bước và nguyên tắc thiết kế giáo án, lựa chọn và sử dụng tài liệu giảng dạy, thiết kế hoạt động học tập và kiểm tra đánh giá. Bên cạnh đó, Sinh viên sẽ được thực hành xây dựng giáo án và giảng dạy thử trong các tình huống lớp học cụ thể.
64	CHN1004	Kỹ năng giảng dạy tiếng Trung	3	3	0	0	0	4	Học phần “Kỹ năng giảng dạy tiếng Trung” nhằm trang bị cho sinh viên những kiến thức và kỹ năng sư phạm thiết yếu trong việc tổ chức giảng dạy bốn kỹ năng ngôn ngữ cơ bản: nghe, nói, đọc, viết trong lớp học tiếng Trung. Sinh viên sẽ được tìm hiểu về mục tiêu giảng dạy của từng kỹ năng, cách chọn lựa phương pháp phù hợp và thiết kế các hoạt động giảng dạy cụ thể.Học phần kết hợp chặt chẽ giữa lý thuyết và thực hành, giúp sinh viên phát triển các kỹ năng chuyên môn như xây dựng giáo án kỹ năng, lựa chọn và khai thác ngữ liệu, thiết kế bài tập, tổ chức hoạt động giao tiếp, và ứng dụng các phần mềm, công cụ số vào quá trình dạy học. Trong suốt học phần, sinh viên sẽ tham gia các hoạt động mô phỏng giảng dạy, phân tích tình huống sư phạm, thảo luận nhóm và nhận phản hồi từ giảng viên nhằm nâng cao khả năng giảng dạy thực tiễn. Những trải nghiệm này không chỉ giúp sinh viên củng cố kiến thức, phát triển năng lực sư phạm, mà còn là bước chuẩn bị vững chắc cho công việc giảng dạy tiếng Trung trong tương lai.
65	AIT1022	Ứng dụng AI trong giảng dạy tiếng Trung	3	3	0	0	0	4	Học phần này giới thiệu một cách hệ thống các lý thuyết và ứng dụng thực tiễn của công nghệ trí tuệ nhân tạo (AI) trong giảng dạy tiếng Trung. Nội dung tập trung vào việc ứng dụng AI trong các khía cạnh như: luyện phát âm, phân tích và sửa lỗi ngữ pháp, chấm và sửa bài văn viết, thiết kế lộ trình học tập cá nhân hóa và phát triển tài nguyên dạy học thông minh. Kết thúc học phần, sinh viên sẽ có năng lực phân tích, lựa chọn và ứng dụng hiệu quả các công cụ AI để đổi mới phương pháp giảng dạy, đồng thời hình thành tư duy phản biện về những cơ hội và thách thức mà AI mang lại cho lĩnh vực giảng dạy tiếng Trung Quốc
66	CHN4005	Khóa luận tốt nghiệp Ngôn  ngữ Trung Quốc (*)	9	0	0	9	0	4	Học phần này trang bị cho sinh viên các kiến thức và các kỹ năng, phương pháp nghiên cứu khoa học, vận dụng các kiến thức chuyên ngành ngôn ngữ Trung Quốc đã học để hoàn thành đề tài nghiên cứu đã chọn.
68	PHT305	Bóng chuyền 1	2	0	0	0	0	12	Cung cấp kiến thức cơ bản và chuyên sâu về bóng chuyền, bao gồm luật chơi, kỹ thuật cơ bản, dinh dưỡng thể thao và phòng tránh chấn thương. Rèn luyện và hoàn thiện kỹ thuật chuyền, đệm, phát bóng; nâng cao kỹ năng xử lý tình huống và phát triển kỹ năng cá nhân trong thi đấu
69	PHT306	Bóng chuyền 1	1	0	0	0	0	12	Học phần Bóng chuyền 3 gồm lý thuyết và thực hành, giúp sinh viên nâng cao kỹ thuật và chiến thuật thi đấu. Phần lý thuyết trang bị kiến thức về luật, tổ chức thi đấu và chiến thuật từ cơ bản đến nâng cao. Phần thực hành tập trung rèn luyện kỹ thuật chuyền đệm, đập bóng, chắn bóng, phòng thủ và phối hợp thi đấu hiệu quả
70	PHT307	Bóng rổ 1	2	0	0	0	0	12	Học phần "Bóng rổ 1" trang bị cho sinh viên những kiến thức cơ bản về môn bóng rổ, bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu khái quát về lịch sử hình thành và phát triển của bóng rổ, các kỹ thuật cơ bản, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, các kỹ thuật chuyền bắt bóng cơ bản trong bóng rổ, kỹ thuật ném rổ, kỹ thuật dẫn bóng, phối hợp bước dân di chuyển thường sử dụng trong môn này. Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng rổ.
71	PHT308	Bóng rổ 2	2	0	0	0	0	12	Học phần được xây dựng nhằm nâng cao kỹ năng thực hành, tư duy chiến thuật và thể lực chuyên môn cho sinh viên, dựa trên nền tảng kiến thức từ học phần Bóng rổ 1. Củng cố và phát triển các kỹ thuật cá nhân, giúp sinh viên nắm vững và vận dụng các chiến thuật thi đấu cơ bản (phối hợp nhóm, tấn công-phòng ngự cá nhân/khu vực), hiểu rõ mối liên hệ giữa kỹ thuật, chiến thuật và thể lực, đồng thời áp dụng kiến thức vào tập luyện, thi đấu thực tế để nâng cao sức khỏe, ý thức kỷ luật và tinh thần đồng đội.
72	PHT309	Bóng rổ 3	1	0	0	0	0	12	Học phần được thiết kế nhằm hoàn thiện các kỹ thuật và kỹ năng bóng rổ nâng cao cho sinh viên, phục vụ cho việc tập luyện và thi đấu. Bên cạnh đó, học phần còn hướng đến việc tạo hứng thú, nâng cao sức khỏe thể chất và tinh thần, đồng thời củng cố kiến thức về vệ sinh và phòng tránh chấn thương trong thể thao
73	PHT310	Thể hình - Thẩm mỹ 1	2	0	0	0	0	12	Học phần Thể hình – Thẩm mỹ 1 cung cấp kiến thức lý thuyết và thực hành cơ bản về Gym – Fitness, giúp sinh viên hiểu về lịch sử, nguyên lý phát triển cơ bắp, phân loại nhóm cơ, kỹ thuật tập luyện và dinh dưỡng phù hợp. Phần thực hành rèn luyện thể lực và kỹ năng sử dụng máy móc, tập đúng kỹ thuật với 6 nhóm cơ chính. Qua học phần, sinh viên nâng cao thể lực, cải thiện vóc dáng và có khả năng tự xây dựng chương trình tập luyện phù hợp với mục tiêu cá nhân
74	PHT311	Thể hình - Thẩm mỹ 2	2	0	0	0	0	12	Học phần Thể hình – Thẩm mỹ 2 giúp sinh viên ôn tập kiến thức về dinh dưỡng, chỉ số BMI – TDEE, nguyên lý phát triển cơ bắp, luật thi đấu và an toàn tập luyện. Phần thực hành tập trung vào nâng cao thể lực, sử dụng thành thạo thiết bị, hoàn thiện kỹ thuật và xây dựng kế hoạch tập luyện cá nhân, từ đó hình thành ý thức tự giác và lan tỏa tinh thần thể thao tích cực.
75	PHT312	Thể hình - Thẩm mỹ 3	1	0	0	0	0	12	Học phần Thể hình – Thẩm mỹ 3 trang bị cho sinh viên kỹ thuật và phương pháp tập luyện nâng cao, bao gồm các phương pháp huấn luyện lặp lại, vòng tròn và các bài tập chuyên sâu tác động hiệu quả lên từng nhóm cơ, tối ưu hóa sự phát triển cơ bắp. Trang bị kiến thức về dinh dưỡng hồi phục và cách tự thiết kế thực đơn ăn uống phù hợp
76	PHT313	Vovinam 1	2	0	0	0	0	12	Học phần Vovinam 1 trang bị cho sinh viên những kiến thức cơ bản và nền tảng về môn võ Vovinam – Việt Võ Đạo. Giới thiệu khái quát về lịch sử hình thành và phát triển của Vovinam, trình bày các nguyên lý, khái niệm và giá trị võ đạo như lối nghiêm lễ, khái niệm “Vovinam là gì”, Mười điều tâm niệm, điều sơ khởi về kỷ luật, quan niệm dụng võ, hệ thống cấp đai, màu đai. Hướng dẫn và rèn luyện các kỹ thuật cơ bản như tấn, gạt, đấm, chém, chỏ, gối và các đòn đá, giúp hình thành kỹ năng thực chiến bước đầu
77	PHT314	Vovinam 2	2	0	0	0	0	12	Học phần Vovinam 2 trang bị sinh viên kiến thức hoàn thiện hơn về môn võ Vovinam.  Hiểu được luật thi đấu, danh dự người võ sĩ, cách rèn luyện tinh thần, khái niệm võ thuật – võ đạo, mục đích tôn chỉ người học võ, cách huấn luyện người học về võ lực – võ thuật – võ đạo, khả năng phối hợp cưng nhu, tác phong người học cần tránh những điều xấu và làm những điều tốt nào, cũng như đi sâu vào môn võ Vovinam khả năng phân tích chiến lược, bài quyền để hiểu hơn về môn võ này. Rèn luyện khả năng di chuyển và phối hợp động tác liên hoàn, thông qua tập luyện các động tác chiến lược từ 1 -5 và bài “Nhập môn quyền”.
79	PHT316	Bóng đá 1	2	0	0	0	0	12	Học phần "Bóng đá 1" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu khái quát về lịch sử hình thành và phát triển của bóng đá, các kỹ thuật cơ bản, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, tâng bóng, kéo bóng, kỹ thuật đá bóng bằng các phần khác nhau của bàn chân (lòng bàn chân, mu trong, mu giữa), kỹ thuật nhận bóng bằng gan bàn chân, dẫn bóng và đánh đầu bằng trán giữa. Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá .
81	PHT318	Bóng đá 3	1	0	0	0	0	12	Học phần "Bóng đá 3" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu về đội hình chiến thuật, chiến thuật  cơ bản (Chiến thuật tấn công và phòng ngự 3x2, chiến thuật tấn công và phòng ngự với quả phạt góc), phát triển thể lực (sức bền tốc độ). Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá .
82	NDF108	Quốc phòng, an ninh 1	0	0	0	0	0	13	Học phần gồm 11 chủ đề trong đó giới thiệu về đối tượng và phương pháp nghiên cứu bộ môn quốc phòng – an ninh nói chung; trình bày quan điểm Chủ nghĩa Mác –Lênin, tư tưởng Hồ Chí Minh về chiến tranh, quân đội và bảo vệ Tổ quốc XHCN; xây dựng lực lượng vũ trang nhân dân; xây dựng và bảo vệ chủ quyền biển, đảo, biên giới quốc gia trong tình hình mới; xây dựng lực lượng dân quân tự vệ, lực lượng dự bị động viên và động viên quốc phòng; xây dựng phong trào toàn dân bảo vệ an ninh Tổ quốc; những vấn đề cơ bản về bảo vệ an ninh quốc gia và bảo đảm trật tự an toàn xã hội; về kết hợp phát triển kinh tế với tăng cường quốc phòng an ninh, đối ngoại và một số nôi dung về lịch sử nghệ thuật quân sự Việt Nam.
78	PHT315	Vovinam 3	1	0	0	0	0	12	Học phần Vovinam 3 trang bị cho sinh viên các kỹ thuật nâng cao, bao gồm khả năng phản xạ, né đỡ đòn và phản đòn hiệu quả. Sinh viên sẽ được huấn luyện các chiến lược tự vệ từ cấp độ 6 đến 10, cùng với các kỹ thuật khóa gỡ trong các tình huống tấn công như ôm, nắm tóc và bóp cổ, giúp nâng cao kỹ năng tự vệ trong thực tiễn
80	PHT317	Bóng đá 2	2	0	0	0	0	12	Học phần "Bóng đá 2" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu về chiến thuật bóng đá , các chấn thương và phương pháp điều trị chấn thương trong tập luyện và thi đấu, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, kỹ thuật đá bóng bằng mũi bàn chân, các chiến thuật  cơ bản ( Chiến thuật tấn công và phòng ngự 2x1, chiến thuật tấn công và phòng ngự với quả đá biên), phát triển thể lực ( sức mạnh – tốc độ). Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá
83	NDF109	Quốc phòng, an ninh 2	0	0	0	0	0	13	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Nội dung của học phần gồm: Đấu tranh phòng chống chiến lược “Diễn biến hòa bình” bạo loạn lật đổ của các thế lực thù địch; một số vấn đề về dân tộc, tôn giáo; bảo vệ môi trường; an toàn giao thông; bảo vệ danh dự, nhân phẩm con người; an toàn thông tin; phòng ngừa, ứng phó với các mối đe dọa an ninh phi truyền thống.
84	NDF210	Quốc phòng, an ninh 3	0	0	0	0	0	13	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Nội dung của học phần gồm 9 chủ đề: chế độ sinh hoạt, học tập, công tác trong ngày, trong tuần; các chế độ nền nếp chính quy, bố trí trật tự nội vụ trong doanh trại; hiểu biết chung về các quân, binh chủng trong quân đội nhân dân Việt Nam; điều lệnh đội ngũ từng người có súng; điều lệnh đội ngũ đơn vị; hiểu biết chung về bản đồ địa hình quân sự; phòng tránh địch tiến công hỏa lực bằng vũ khí công nghệ cao; ba môn quân sự phối hợp, phòng cháy chữa cháy và cứu hộ cứu nạn.
85	NDF211	Quốc phòng, an ninh 4	0	0	0	0	0	13	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Học phần trang bị những kiến thức cơ bản về kỹ thuật chiến đấu bộ binh và chiến thuật, gồm 5 chủ đề: kỹ thuật bắn súng tiểu liên AK; tính năng, cấu tạo và cách sử dụng một số loại lựu đạn thường dùng; từng người trong chiến đấu tiến công; từng người trong chiến đấu phòng ngự và từng người làm nhiệm vụ canh gác, cảnh giới.
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.departments (id, parent_id, code, name, type, created_at) FROM stdin;
1	\N	HUTECH	Trường Đại học Công nghệ TP.HCM	ROOT	2026-03-25 09:16:56.878689+00
2	1	BGH	Ban Giám Hiệu	PHONG	2026-03-25 09:16:56.881487+00
3	1	PDT	Phòng Đào tạo	PHONG	2026-03-25 09:16:56.882609+00
4	1	K.TQH	Khoa Trung Quốc học	KHOA	2026-03-25 09:16:56.883438+00
5	1	K.CNTT	Khoa CNTT	KHOA	2026-03-25 09:16:56.884207+00
6	1	K.TA	Khoa Tiếng Anh	KHOA	2026-03-25 09:16:56.885036+00
7	1	K.QTKD	Khoa QTKD	KHOA	2026-03-25 09:16:56.886048+00
8	1	K.LUAT	Khoa Luật	KHOA	2026-03-25 09:16:56.886819+00
9	1	K.NBH	Khoa Nhật Bản học	KHOA	2026-03-25 09:16:56.887563+00
10	1	VJIT	Viện CNTT Việt-Nhật	VIEN	2026-03-25 09:16:56.888228+00
11	1	V.KHUD	Viện Khoa học ứng dụng	VIEN	2026-03-25 09:16:56.888943+00
12	1	TT.GDTC	TT Giáo dục Thể chất	TRUNG_TAM	2026-03-25 09:16:56.889591+00
13	1	TT.GDCT-QP	TT Giáo dục CT-QP	TRUNG_TAM	2026-03-25 09:16:56.890319+00
14	1	TT.TH-NN-KN	TT Tin học-NN-KN	TRUNG_TAM	2026-03-25 09:16:56.89095+00
15	5	N.CNPM	Ngành Công nghệ phần mềm	BO_MON	2026-03-25 09:16:56.891551+00
16	5	N.HTTT	Ngành Hệ thống thông tin	BO_MON	2026-03-25 09:16:56.892137+00
17	5	N.KTPM	Ngành Kỹ thuật phần mềm	BO_MON	2026-03-25 09:16:56.892764+00
18	5	N.TTNT	Ngành Trí tuệ nhân tạo	BO_MON	2026-03-25 09:16:56.893387+00
19	7	N.TMDT	Ngành Thương mại điện tử	BO_MON	2026-03-25 09:16:56.894017+00
20	7	N.QTKD-TH	Ngành Quản trị kinh doanh tổng hợp	BO_MON	2026-03-25 09:16:56.894619+00
21	6	N.TACN	Ngành Tiếng Anh chuyên ngành	BO_MON	2026-03-25 09:16:56.89522+00
22	6	N.TATM	Ngành Tiếng Anh thương mại	BO_MON	2026-03-25 09:16:56.895821+00
947	4	N.NNTQ	Ngành Ngôn Ngữ Trung Quốc	BO_MON	2026-03-26 16:48:29.808872+00
\.


--
-- Data for Name: knowledge_blocks; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.knowledge_blocks (id, version_id, name, parent_id, total_credits, required_credits, elective_credits, sort_order, level) FROM stdin;
57	1	Kiến thức giáo dục đại cương	\N	0	0	0	1	1
58	1	Kiến thức giáo dục chuyên nghiệp	\N	0	0	0	2	1
59	1	Kiến thức bắt buộc	58	0	0	0	3	2
60	1	Kiến thức tự chọn	58	0	0	0	4	2
61	1	Kiến thức không tích lũy	\N	0	0	0	5	1
182	29	Kiến thức giáo dục đại cương	\N	44	0	0	1	1
183	29	Kiến thức giáo dục chuyên nghiệp	\N	81	0	0	2	1
184	29	Kiến thức bắt buộc	183	72	0	0	3	2
185	29	Kiến thức tự chọn	183	9	0	0	4	2
186	29	Nhóm 1:Tiếng Trung thương mại	185	0	0	0	5	3
187	29	Nhóm 2:Biên phiên dịch tiếng Trung	185	0	0	0	6	3
188	29	Nhóm 3:Phương pháp giảng dạy tiếng Trung	185	0	0	0	7	3
189	29	Nhóm 4:Khóa luận tốt nghiệp	185	0	0	0	8	3
190	29	Kiến thức không tích lũy	\N	0	0	0	9	1
191	29	Giáo dục thể chất (tự chọn 1 trong 5 nhóm)	190	5	0	0	10	2
192	29	Nhóm 1	191	0	0	0	11	3
193	29	Nhóm 2	191	0	0	0	12	3
194	29	Nhóm 3	191	0	0	0	13	3
195	29	Nhóm 4	191	0	0	0	14	3
196	29	Nhóm 5	191	0	0	0	15	3
197	29	Chương trình Giáo dục quốc phòng và an ninh (theo quy định của Bộ GD&ĐT)	190	0	0	0	16	2
172	27	Kiến thức giáo dục đại cương	\N	0	0	0	1	1
173	27	Kiến thức giáo dục chuyên nghiệp	\N	0	0	0	2	1
174	27	Kiến thức bắt buộc	173	0	0	0	3	2
175	27	Kiến thức tự chọn	173	0	0	0	4	2
176	27	Kiến thức không tích lũy	\N	0	0	0	5	1
2030	381	Kiến thức giáo dục đại cương	\N	0	0	0	1	1
2031	381	Kiến thức giáo dục chuyên nghiệp	\N	0	0	0	2	1
2032	381	Kiến thức bắt buộc	2031	0	0	0	3	2
2033	381	Kiến thức tự chọn	2031	0	0	0	4	2
2034	381	Kiến thức không tích lũy	\N	0	0	0	5	1
2080	390	Kiến thức giáo dục đại cương	\N	0	0	0	1	1
2081	390	Kiến thức giáo dục chuyên nghiệp	\N	0	0	0	2	1
2082	390	Kiến thức bắt buộc	2081	0	0	0	3	2
2083	390	Kiến thức tự chọn	2081	0	0	0	4	2
2084	390	Kiến thức không tích lũy	\N	0	0	0	5	1
2160	405	Kiến thức giáo dục đại cương	\N	0	0	0	1	1
2161	405	Kiến thức giáo dục chuyên nghiệp	\N	0	0	0	2	1
2162	405	Kiến thức bắt buộc	2161	0	0	0	3	2
2163	405	Kiến thức tự chọn	2161	0	0	0	4	2
2164	405	Kiến thức không tích lũy	\N	0	0	0	5	1
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.permissions (id, code, module, description) FROM stdin;
23	syllabus.approve_tbm	syllabus	Duyệt cấp Trưởng BM
24	syllabus.approve_khoa	syllabus	Duyệt cấp Trưởng Khoa
25	syllabus.approve_pdt	syllabus	Duyệt cấp Phòng ĐT
26	syllabus.approve_bgh	syllabus	Phê duyệt cấp BGH
27	syllabus.assign	syllabus	Phân công GV soạn đề cương
28	courses.view	courses	Xem danh mục học phần
29	courses.create	courses	Tạo học phần mới
30	courses.edit	courses	Chỉnh sửa học phần
1	programs.view_published	programs	Xem CTĐT đã công bố
2	programs.view_draft	programs	Xem CTĐT bản nháp
3	programs.create	programs	Tạo mới CTĐT
4	programs.edit	programs	Chỉnh sửa CTĐT
5	programs.delete_draft	programs	Xóa CTĐT bản nháp
6	programs.submit	programs	Nộp CTĐT để phê duyệt
7	programs.approve_khoa	programs	Duyệt CTĐT cấp Khoa
8	programs.approve_pdt	programs	Duyệt CTĐT cấp Phòng ĐT
9	programs.approve_bgh	programs	Phê duyệt CTĐT cấp BGH
10	programs.export	programs	Xuất báo cáo CTĐT
11	programs.import_word	programs	Import CTĐT từ Word
12	programs.manage_all	programs	Quản lý CTĐT toàn trường
13	programs.create_version	programs	Tạo phiên bản CTĐT mới
19	syllabus.view	syllabus	Xem đề cương đã công bố
20	syllabus.create	syllabus	Tạo đề cương
21	syllabus.edit	syllabus	Chỉnh sửa đề cương
22	syllabus.submit	syllabus	Nộp đề cương để phê duyệt
\.


--
-- Data for Name: plo_pis; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.plo_pis (id, plo_id, pi_code, description) FROM stdin;
1	1	PI1.1	Giải các bài toán tối ưu và xác suất thống kê trong CNTT
2	1	PI1.2	Áp dụng cấu trúc dữ liệu và giải thuật phù hợp cho bài toán
3	2	PI2.1	Phân tích yêu cầu chức năng và phi chức năng của hệ thống
4	2	PI2.2	Thiết kế kiến trúc hệ thống theo mô hình phân lớp
5	3	PI3.1	Viết mã nguồn sạch, có cấu trúc theo chuẩn coding convention
6	4	PI4.1	Thiết kế lược đồ CSDL chuẩn hóa đến 3NF
7	5	PI5.1	Trình bày ý tưởng kỹ thuật rõ ràng trước nhóm và khách hàng
8	6	PI6.1	Đánh giá ưu nhược điểm của công nghệ mới so với giải pháp hiện tại
273	135	PI.1.1	Nhận biếtcác vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc.
274	135	PI.1.2	Xây dựng phương án để giải quyết các vấn đề về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc.
275	135	PI.1.3	Kết hợp các kiến thức cơ bản, kiến thức chuyên ngành để đóng góp hữu hiệu vào sự phát triển bền vững của xã hội, cộng đồng.
276	136	PI.2.1	Nhận biếtcác thành phần cấu tạo nên ngôn ngữ Trung Quốc.
277	136	PI.2.2	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc.
278	136	PI.2.3	Sử dụng thành thạo4 kỹ năng tiếng Trungtương đương bậc 5 theo Khung năng lực ngoại ngữ Việt Nam.
279	137	PI.3.1	Sử dụng ngoại ngữ 2 tiếng Anh để nâng cao cơ hội việc làm và hiểu biết thêm về các nền văn hóa khác.
280	138	PI.4.1	Áp dụng thành thạo tiếng Trung vào công việc.
281	138	PI.4.2	Nhận biết chữ Hán phồn thểvà thành thạo chữ Hán giản thểtrong côngviệc.
282	138	PI.4.3	Khai thác thông tin và cập nhật kiến thức chuyên ngành thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c)phương pháp giảng dạy, hoặc (d)khóa luận tốt nghiệp.
283	139	PI.5.1	Phân tích thông tin, đưa ra luận điểm có căn cứ.
284	139	PI.5.2	Hệ thống lại vấn đề, đưa ra kết luận về cách thức vận hành của vấn đề hệ thống.
285	139	PI.5.3	Lập kế hoạch, thực hiện và đánh giá công việc chuyên môn.
286	140	PI.6.1	Sử dụng tốt các chiến lược giao tiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.
287	140	PI.6.2	Áp dụng thành thạo kỹ năng giao tiếp ứng xử cần thiết để thực hiện các nhiệm vụ phức tạp.
288	140	PI.6.3	Sử dụng Word, Excel, Powerpoint ….soạn thảo, trình bày các loại văn bản  trong học tập, nghiên cứu và công việc có hiệu quả.
289	140	PI.6.4	Sử dụng có hiệu quả các phần mềm chuyên dụng để phục vụ học tập và công việc chuyên môn liên quan đến tiếng Trung.
290	141	PI.7.1	Đưa ra các nhận định cá nhân trong điều kiện làm việc thay đổi
291	141	PI.7.2	Xác định được đầy đủ mục tiêu của nhóm, vai trò, trách nhiệm của các thành viên
292	141	PI.7.3	Tham gia hoạch định, lên chương trình và phối hợp trong thực hiện hoạt động nhóm đạt được mục tiêu đã đềra.
293	141	PI.7.4	Nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.
257	123	PI1.1	Giải các bài toán tối ưu và xác suất thống kê trong CNTT
258	123	PI1.2	Áp dụng cấu trúc dữ liệu và giải thuật phù hợp cho bài toán
259	124	PI2.1	Phân tích yêu cầu chức năng và phi chức năng của hệ thống
260	124	PI2.2	Thiết kế kiến trúc hệ thống theo mô hình phân lớp
261	125	PI3.1	Viết mã nguồn sạch, có cấu trúc theo chuẩn coding convention
262	126	PI4.1	Thiết kế lược đồ CSDL chuẩn hóa đến 3NF
263	127	PI5.1	Trình bày ý tưởng kỹ thuật rõ ràng trước nhóm và khách hàng
264	128	PI6.1	Đánh giá ưu nhược điểm của công nghệ mới so với giải pháp hiện tại
\.


--
-- Data for Name: po_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.po_plo_map (version_id, po_id, plo_id) FROM stdin;
1	1	1
1	1	2
1	1	3
1	1	4
1	2	2
1	2	3
1	2	6
1	3	5
1	3	6
\.


--
-- Data for Name: program_versions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.program_versions (id, program_id, academic_year, version_name, status, is_locked, copied_from_id, completion_pct, total_credits, training_duration, change_type, effective_date, change_summary, grading_scale, graduation_requirements, job_positions, further_education, reference_programs, training_process, admission_targets, admission_criteria, created_at, updated_at, is_rejected, rejection_reason, general_objective) FROM stdin;
1	1	2025-2026	CTĐT CNTT 2025-2026	published	t	\N	0	130	4 năm	\N	\N	\N	Thang điểm 10 quy đổi sang thang 4 và xếp loại A/B/C/D/F	Hoàn thành tối thiểu 130 TC, đạt chuẩn ngoại ngữ, không nợ học phí	Lập trình viên, Kỹ sư phần mềm, Quản trị mạng, Chuyên viên CNTT, Tư vấn giải pháp CNTT	Thạc sĩ CNTT, Thạc sĩ Khoa học máy tính, MBA chuyên ngành CNTT	\N	Đào tạo theo hệ thống tín chỉ, kết hợp lý thuyết và thực hành	\N	\N	2026-03-25 09:16:57.047572+00	2026-03-26 18:53:09.444671+00	f	\N	Đào tạo kỹ sư CNTT có năng lực chuyên môn, tư duy sáng tạo, đạo đức nghề nghiệp, đáp ứng nhu cầu xã hội và hội nhập quốc tế.
29	9	2024-2025	\N	draft	f	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-27 07:25:01.204831+00	2026-04-04 08:32:31.228039+00	f	\N	Đào tạo cử nhân ngành Ngôn ngữ Trung Quốc có phẩm chất chính trị, đạo đức, có kiến thức toàn diện về văn hóa, khoa học xã hội và tự nhiên; có năng lực sử dụng tiếng Trung ở trình độ cao để giao tiếp hiệu quả trong các bối cảnh khác nhau; có kiến thức chuyên ngành và kỹ năng mềm đáp ứng nhu cầu phát triển kinh tế - xã hội và hội nhập quốc tế.
405	547	2083-2084	\N	published	t	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-05 05:17:45.206812+00	2026-04-05 05:17:45.516978+00	f	\N	\N
390	524	2083-2084	\N	published	t	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-05 05:12:37.315319+00	2026-04-05 05:12:37.636238+00	f	\N	\N
27	1	2026-2027	\N	draft	f	1	0	130	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-27 03:01:01.407388+00	2026-03-27 07:50:09.66705+00	f	\N	\N
381	507	2083-2084	\N	published	t	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-05 05:10:19.959825+00	2026-04-05 05:10:20.178245+00	f	\N	\N
\.


--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.programs (id, department_id, name, name_en, code, degree, total_credits, institution, degree_name, training_mode, notes, created_at, archived_at) FROM stdin;
547	5	Approve BGH Test	AB EN	AB_1775366265158	Dai hoc	\N	\N	\N	\N	\N	2026-04-05 05:17:45.162113+00	2026-04-05 05:17:45.847305+00
9	947	Ngôn ngữ Trung Quốc	Chinese Language	7220204	Cử nhân Ngôn ngữ Trung Quốc	125	Trường Đại học Công nghệ TP.HCM	\N	Chính quy	\N	2026-03-27 07:25:01.204831+00	\N
1	15	Công nghệ thông tin	Information Technology	7480201	Đại học	130	Trường Đại học Công nghệ TP.HCM	Cử nhân Công nghệ thông tin	Chính quy	\N	2026-03-25 09:16:57.046839+00	2026-04-04 04:54:05.149209+00
507	5	Approve BGH Test	AB EN	AB_1775365819953	Dai hoc	\N	\N	\N	\N	\N	2026-04-05 05:10:19.955649+00	2026-04-05 05:10:20.420577+00
524	5	Approve BGH Test	AB EN	AB_1775365957308	Dai hoc	\N	\N	\N	\N	\N	2026-04-05 05:12:37.311237+00	2026-04-05 05:12:37.830501+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	28
1	2
1	1
1	20
1	21
1	22
1	19
2	28
2	13
2	5
2	4
2	6
2	2
2	1
2	23
2	27
2	19
3	28
3	7
3	3
3	5
3	4
3	10
3	11
3	6
3	2
3	1
3	24
3	27
3	20
3	21
3	22
3	19
4	29
4	30
4	28
4	8
4	3
4	13
4	5
4	4
4	10
4	11
4	12
4	2
4	1
4	25
4	27
4	20
4	21
4	19
5	28
5	9
5	10
5	2
5	1
5	26
5	27
5	19
6	29
6	30
6	28
6	9
6	7
6	8
6	3
6	13
6	5
6	4
6	10
6	11
6	12
6	6
6	2
6	1
6	26
6	24
6	25
6	23
6	27
6	20
6	21
6	22
6	19
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.roles (id, code, name, level, is_system) FROM stdin;
1	GIANG_VIEN	Giảng viên	1	t
2	TRUONG_NGANH	Trưởng ngành / Trưởng BM	2	t
3	LANH_DAO_KHOA	Lãnh đạo Khoa/Viện/TT	3	t
4	PHONG_DAO_TAO	Phòng Đào tạo	4	t
5	BAN_GIAM_HIEU	Ban Giám Hiệu	5	t
6	ADMIN	Quản trị hệ thống	99	t
\.


--
-- Data for Name: syllabus_assignments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.syllabus_assignments (id, version_id, course_id, assigned_to, assigned_by, assigner_role_level, deadline, notes, created_at, updated_at) FROM stdin;
1	1	11	2	1	99	2026-03-31	\N	2026-03-25 16:01:29.092888+00	2026-03-25 16:01:29.092888+00
5	29	578	7	1	99	\N	\N	2026-04-05 04:47:59.200302+00	2026-04-05 04:47:59.200302+00
\.


--
-- Data for Name: teaching_plan; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.teaching_plan (id, version_course_id, total_hours, hours_theory, hours_practice, hours_project, hours_internship, software, managing_dept, batch, notes) FROM stdin;
1	5	45	30	15	0	0	\N	K.CNTT	A	\N
2	6	45	30	15	0	0	\N	K.CNTT	A	\N
3	8	45	30	15	0	0	MySQL Workbench	K.CNTT	B	\N
4	7	45	30	15	0	0	IntelliJ IDEA	K.CNTT	A	\N
5	9	45	30	15	0	0	Cisco Packet Tracer	K.CNTT	B	\N
6	10	45	30	15	0	0	Jira, Draw.io	K.CNTT	A	\N
7	11	45	15	30	0	0	VS Code, Node.js	K.CNTT	B	\N
8	12	45	30	15	0	0	Python, Jupyter	K.CNTT	A	\N
9	15	90	0	0	90	0	\N	K.CNTT	A	\N
10	16	135	0	0	0	135	\N	K.CNTT	B	\N
563	779	45	45	0	0	0	\N	K.TA	B	\N
564	790	45	45	0	0	0	\N	K.TQH	A	\N
565	795	45	45	0	0	0	\N	K.TQH	A	\N
566	800	45	45	0	0	0	\N	K.TQH	B	\N
567	805	45	45	0	0	0	\N	K.TQH	B	\N
568	783	45	45	0	0	0	\N	K.CNTT	A	\N
569	839	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
570	840	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
571	780	45	45	0	0	0	\N	K.TA	B	\N
572	786	45	45	0	0	0	\N	VJIT	B	\N
573	791	45	45	0	0	0	\N	K.TQH	A	\N
574	796	45	45	0	0	0	\N	K.TQH	A	\N
575	801	45	45	0	0	0	\N	K.TQH	B	\N
576	806	45	45	0	0	0	\N	K.TQH	B	\N
577	841	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
578	842	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
579	824	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
580	827	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
581	830	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
582	833	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
583	836	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
584	781	45	45	0	0	0	\N	K.TA	B	\N
585	792	45	45	0	0	0	\N	K.TQH	A	\N
586	797	45	45	0	0	0	\N	K.TQH	A	\N
587	802	45	45	0	0	0	\N	K.TQH	B	\N
588	807	45	45	0	0	0	\N	K.TQH	B	\N
589	774	45	45	0	0	0	\N	TT.GDCT-QP	A	\N
590	825	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
591	828	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
592	831	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
593	834	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
594	837	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
595	782	45	45	0	0	0	\N	K.TA	B	\N
596	784	45	45	0	0	0	\N	V.KHUD	A	\N
597	793	45	45	0	0	0	\N	K.TQH	A	\N
598	798	45	45	0	0	0	\N	K.TQH	A	\N
599	803	45	45	0	0	0	\N	K.TQH	B	\N
600	808	45	45	0	0	0	\N	K.TQH	B	\N
601	826	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
602	829	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
603	832	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
604	835	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
605	838	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
606	777	30	30	0	0	0	\N	TT.GDCT-QP	A	\N
607	775	30	30	0	0	0	\N	TT.GDCT-QP	B	\N
608	788	45	45	0	0	0	\N	K.NBH	A	\N
609	794	45	45	0	0	0	\N	K.TQH	A	\N
610	799	45	45	0	0	0	\N	K.TQH	A	\N
611	804	45	45	0	0	0	\N	K.TQH	B	\N
612	809	45	45	0	0	0	\N	K.TQH	B	\N
613	810	45	45	0	0	0	\N	K.TQH	B	\N
614	778	30	30	0	0	0	\N	TT.GDCT-QP	B	\N
615	776	30	30	0	0	0	\N	TT.GDCT-QP	A	\N
616	812	135	0	0	0	135	\N	K.TQH	B	\N
617	814	45	45	0	0	0	\N	K.TQH	A	\N
618	815	45	45	0	0	0	\N	K.TQH	A	\N
619	816	45	45	0	0	0	\N	K.TQH	B	\N
620	817	45	45	0	0	0	\N	K.TQH	A	\N
621	818	45	45	0	0	0	\N	K.TQH	A	\N
622	819	45	45	0	0	0	\N	K.TQH	B	\N
623	820	45	45	0	0	0	\N	K.TQH	A	\N
624	821	45	45	0	0	0	\N	K.TQH	A	\N
625	822	45	45	0	0	0	\N	K.TQH	B	\N
626	823	405	0	0	405	0	\N	K.TQH	\N	\N
627	787	45	45	0	0	0	\N	K.QTKD	A	\N
628	785	45	45	0	0	0	\N	K.LUAT	A	\N
629	789	45	45	0	0	0	\N	TT.TH-NN-KN	A	\N
630	811	45	45	0	0	0	\N	K.TQH	A	\N
631	813	135	0	0	0	135	\N	K.TQH	B	\N
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.user_roles (id, user_id, role_id, department_id) FROM stdin;
1	1	6	1
7	3	2	15
8	4	3	5
9	5	4	1
10	6	5	1
13	2	1	16
14	7	1	947
15	3	2	947
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.users (id, username, password_hash, display_name, email, is_active, created_at) FROM stdin;
2	giangvien	$2a$10$l49IYdxPJNMHqB2ZB0pR9uOSOhu1uP5is0gDgSZwGX6iBJSRb8GFu	Huy	test@gmail.com	t	2026-03-25 09:27:04.500412+00
3	truongnganh	$2a$10$ZCrQRsyG01wJlJfvasbY6.qA02bJJJ8Yw7RAy5tSACnCBSINAU/iW	Huy	huy@gmail.com	t	2026-03-26 17:40:06.189038+00
4	lanhdaokhoa	$2a$10$TsdQ5SnlnVO0fT5j8sU0RuRpGhhTj6b2pLkzXHysbhGf4HquB.2M.	Huy	huy@gmail.com	t	2026-03-26 17:41:22.870406+00
5	phongdaotao	$2a$10$Hi.6i1q7rDFqd8orqWiIY.ug9e2I0nI3aJmxTVKGw0uMp1aSeF2MW	Huy	huy@gmail.com	t	2026-03-26 17:42:21.089426+00
6	bandamhieu	$2a$10$MhNWu.hpDelGbwrqCYDDPOa8AC45OhRNU//40DaNK0F5B5l3bJDgy	Huy	huy@gmail.com	t	2026-03-26 17:43:00.724948+00
7	giangvien1	$2a$10$MG9C8Mv2ExTsXuFOABrjw.wfENuqA.uaAT3EIjbohQwimD5jekFXC	Huy	huy@gmail.com	t	2026-03-27 02:21:53.460954+00
1	admin	$2a$10$OVg.5/wyksqBP3J8VXT3QubwQtrHXhwlTPjynSMqbg3.4QxyLOzgq	Quản trị viên	\N	t	2026-03-25 09:16:57.043389+00
\.


--
-- Data for Name: version_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_courses (id, version_id, course_id, semester, course_type, prerequisite_course_ids, corequisite_course_ids, elective_group, knowledge_block_id) FROM stdin;
1	1	11	1	required	\N	\N	\N	\N
2	1	12	1	required	\N	\N	\N	\N
3	1	13	1	required	\N	\N	\N	\N
4	1	14	1	required	\N	\N	\N	\N
5	1	1	1	required	\N	\N	\N	\N
6	1	2	2	required	\N	\N	\N	\N
7	1	4	2	required	\N	\N	\N	\N
8	1	3	3	required	\N	\N	\N	\N
9	1	5	3	required	\N	\N	\N	\N
10	1	6	4	required	\N	\N	\N	\N
11	1	7	4	required	\N	\N	\N	\N
12	1	8	5	required	\N	\N	\N	\N
13	1	15	5	elective	\N	\N	An toàn & Đám mây	\N
14	1	16	5	elective	\N	\N	An toàn & Đám mây	\N
15	1	9	6	required	\N	\N	\N	\N
16	1	10	7	required	\N	\N	\N	\N
569	1	62	1	required	\N	\N	\N	\N
740	27	11	1	required	\N	\N	\N	\N
741	27	12	1	required	\N	\N	\N	\N
742	27	13	1	required	\N	\N	\N	\N
743	27	14	1	required	\N	\N	\N	\N
744	27	1	1	required	\N	\N	\N	\N
745	27	2	2	required	\N	\N	\N	\N
746	27	4	2	required	\N	\N	\N	\N
747	27	3	3	required	\N	\N	\N	\N
748	27	5	3	required	\N	\N	\N	\N
749	27	6	4	required	\N	\N	\N	\N
750	27	7	4	required	\N	\N	\N	\N
751	27	8	5	required	\N	\N	\N	\N
752	27	15	5	elective	\N	\N	\N	\N
753	27	16	5	elective	\N	\N	\N	\N
754	27	9	6	required	\N	\N	\N	\N
755	27	10	7	required	\N	\N	\N	\N
756	27	62	1	required	\N	\N	\N	\N
774	29	17	3	required	\N	\N	\N	182
775	29	18	5	required	\N	\N	\N	182
776	29	19	6	required	\N	\N	\N	182
777	29	20	5	required	\N	\N	\N	182
778	29	21	6	required	\N	\N	\N	182
779	29	22	1	required	\N	\N	\N	182
780	29	23	2	required	{779}	\N	\N	182
781	29	24	3	required	{780}	\N	\N	182
782	29	25	4	required	{781}	\N	\N	182
783	29	578	1	required	\N	\N	\N	182
784	29	27	4	required	\N	\N	\N	182
785	29	28	7	required	\N	\N	\N	182
786	29	29	2	required	\N	\N	\N	182
787	29	30	7	required	\N	\N	\N	182
788	29	31	5	required	\N	\N	\N	182
789	29	32	7	required	\N	\N	\N	182
790	29	33	1	required	\N	\N	\N	184
791	29	34	2	required	\N	\N	\N	184
792	29	35	3	required	\N	\N	\N	184
793	29	36	4	required	\N	\N	\N	184
794	29	37	5	required	\N	\N	\N	184
795	29	38	1	required	\N	\N	\N	184
796	29	39	2	required	\N	\N	\N	184
797	29	40	3	required	\N	\N	\N	184
798	29	41	4	required	\N	\N	\N	184
799	29	42	5	required	\N	\N	\N	184
800	29	43	1	required	\N	\N	\N	184
801	29	44	2	required	\N	\N	\N	184
802	29	45	3	required	\N	\N	\N	184
803	29	46	4	required	\N	\N	\N	184
804	29	47	5	required	\N	\N	\N	184
805	29	48	1	required	\N	\N	\N	184
806	29	49	2	required	\N	\N	\N	184
807	29	50	3	required	\N	\N	\N	184
808	29	51	4	required	\N	\N	\N	184
809	29	52	5	required	\N	\N	\N	184
810	29	53	6	required	\N	\N	\N	184
811	29	54	7	required	\N	\N	\N	184
812	29	55	6	required	\N	\N	\N	184
813	29	56	7	required	\N	\N	\N	184
814	29	57	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại	186
815	29	58	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại	186
816	29	59	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại	186
817	29	60	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung	187
818	29	61	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung	187
819	29	62	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung	187
820	29	615	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung	188
821	29	64	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung	188
822	29	65	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung	188
823	29	66	6	elective	\N	\N	Nhóm 4:Khóa luận tốt nghiệp	189
824	29	67	2	non_accumulative	\N	\N	Nhóm 1	192
825	29	68	3	non_accumulative	\N	\N	Nhóm 1	192
826	29	69	4	non_accumulative	\N	\N	Nhóm 1	192
827	29	70	2	non_accumulative	\N	\N	Nhóm 2	193
828	29	71	3	non_accumulative	\N	\N	Nhóm 2	193
829	29	72	4	non_accumulative	\N	\N	Nhóm 2	193
830	29	73	2	non_accumulative	\N	\N	Nhóm 3	194
831	29	74	3	non_accumulative	\N	\N	Nhóm 3	194
832	29	75	4	non_accumulative	\N	\N	Nhóm 3	194
833	29	76	2	non_accumulative	\N	\N	Nhóm 4	195
834	29	77	3	non_accumulative	\N	\N	Nhóm 4	195
835	29	78	4	non_accumulative	\N	\N	Nhóm 4	195
836	29	79	2	non_accumulative	\N	\N	Nhóm 5	196
837	29	80	3	non_accumulative	\N	\N	Nhóm 5	196
838	29	81	4	non_accumulative	\N	\N	Nhóm 5	196
839	29	82	1	non_accumulative	\N	\N	\N	197
840	29	83	1	non_accumulative	\N	\N	\N	197
841	29	84	2	non_accumulative	\N	\N	\N	197
842	29	85	2	non_accumulative	\N	\N	\N	197
\.


--
-- Data for Name: version_objectives; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_objectives (id, version_id, code, description) FROM stdin;
1	1	PO1	Vận dụng kiến thức nền tảng CNTT để phân tích, thiết kế và phát triển phần mềm
2	1	PO2	Áp dụng quy trình phát triển phần mềm chuyên nghiệp và công nghệ hiện đại
3	1	PO3	Có năng lực làm việc nhóm, giao tiếp hiệu quả và phát triển nghề nghiệp liên tục
66	27	PO1	Vận dụng kiến thức nền tảng CNTT để phân tích, thiết kế và phát triển phần mềm
67	27	PO2	Áp dụng quy trình phát triển phần mềm chuyên nghiệp và công nghệ hiện đại
68	27	PO3	Có năng lực làm việc nhóm, giao tiếp hiệu quả và phát triển nghề nghiệp liên tục
72	29	PO1	Ứng dụng kiến thức: Vận dụng kiến thức vềvăn hóa, xãhội, chính trị, luật pháp, ngôn ngữ, vàcông nghệthông tin vào thực tiễn công việc vàcuộc sống. Cókhảnăng tựnghiên cứu, cập nhật kiến thức mới.
73	29	PO2	Năng lực tiếng Trung: Sửdụng thành thạo 4 kỹnăng Nghe, Nói,Đọc, Viết tiếng Trungởtrìnhđộcao.
74	29	PO3	Kỹnăng chuyên ngành: Vận dụng kiến thức vàkỹnăng chuyên ngành (biên phiên dịch/ thương mại/phương pháp giảng dạy/ Khoáluận tốt nghiệp)đểgiải quyết các vấnđềthực tiễn trong công việc.
75	29	PO4	Kỹnăng mềm vàtháiđộ: Làm việcđộc lập, làm việc nhóm, giao tiếp hiệu quả, cótrách nhiệm, sáng tạo, chủđộng thích nghi với môi trường làm việc, tuân thủchuẩn mựcđạođức nghềnghiệp.
97	29	PO_DUP_TEST	Duplicate PO
\.


--
-- Data for Name: version_pi_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_pi_courses (id, version_id, pi_id, course_id, contribution_level) FROM stdin;
1	1	2	5	2
2	1	5	5	3
3	1	1	6	2
4	1	2	6	3
5	1	6	8	3
6	1	3	8	2
7	1	4	7	2
8	1	5	7	3
9	1	3	10	3
10	1	4	10	2
11	1	7	10	2
12	1	4	11	2
13	1	5	11	3
14	1	8	11	2
15	1	2	12	2
16	1	8	12	3
\.


--
-- Data for Name: version_plos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_plos (id, version_id, code, bloom_level, description) FROM stdin;
1	1	PLO1	3	Áp dụng kiến thức toán học, khoa học tự nhiên và CNTT vào giải quyết bài toán thực tế
2	1	PLO2	4	Phân tích yêu cầu, thiết kế kiến trúc và triển khai hệ thống phần mềm
3	1	PLO3	3	Lập trình thành thạo ít nhất 2 ngôn ngữ lập trình hiện đại
4	1	PLO4	4	Thiết kế và quản trị cơ sở dữ liệu quan hệ và NoSQL
5	1	PLO5	2	Làm việc nhóm hiệu quả, giao tiếp chuyên nghiệp bằng tiếng Việt và tiếng Anh
6	1	PLO6	5	Nghiên cứu, đánh giá và ứng dụng công nghệ mới vào dự án thực tế
135	29	PLO1	3	Vận dụng kiến thức cơ bản về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc để đóng góp tích cực vào sự phát triển bền vững của xã hội, cộng đồng.
136	29	PLO2	5	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc đồng thời sử dụng thành thạo 4 kỹ năng tiếng Trung.
137	29	PLO3	3	Sử dụng ngoại ngữ 2 tiếng Anh trong các tình huống quen thuộc để nâng cao cơ hội việc làm và hiểu biết thêm về các nền văn hóa khác.
138	29	PLO4	5	Áp dụng thành thạo tiếng Trung vào công việc, nhận biết chữ Hán phồn thể và thành thạo chữ Hán giản thể trong công việc; sử dụng có hiệu quả  kiến thức và kỹ năng chuyên ngành tiếng Trung thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c)phương pháp giảng dạy, hoặc (d)khóaluậntốt nghiệp.
139	29	PLO5	5	Thểhiện kỹnăng nhận thức liên quanđến tưduy phản biện, phân tích, tổng hợp vào công việc.
140	29	PLO6	3	Vận dụng kỹ năng giao tiếp và công nghệ thông tin cần thiết để thực hiện các nhiệm vụ phức tạp trong môi trường làm việc liên ngành, đa văn hóa, đa quốc gia.
141	29	PLO7	4	Làm việc độc lập và làm việc theo nhóm trong điều kiện làm việc thay đổi; nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.
153	29	PLO_DUP_TEST	1	Duplicate PLO
123	27	PLO1	3	Áp dụng kiến thức toán học, khoa học tự nhiên và CNTT vào giải quyết bài toán thực tế
124	27	PLO2	4	Phân tích yêu cầu, thiết kế kiến trúc và triển khai hệ thống phần mềm
125	27	PLO3	3	Lập trình thành thạo ít nhất 2 ngôn ngữ lập trình hiện đại
126	27	PLO4	4	Thiết kế và quản trị cơ sở dữ liệu quan hệ và NoSQL
127	27	PLO5	2	Làm việc nhóm hiệu quả, giao tiếp chuyên nghiệp bằng tiếng Việt và tiếng Anh
128	27	PLO6	5	Nghiên cứu, đánh giá và ứng dụng công nghệ mới vào dự án thực tế
\.


--
-- Data for Name: version_syllabi; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_syllabi (id, version_id, course_id, author_id, status, content, is_rejected, rejection_reason, created_at, updated_at) FROM stdin;
1	1	11	2	draft	{"textbooks": ["Khoa Công nghệ Thông tin. Tài liệu học tập học phần \\"TRÍ TUỆ NHÂN TẠO ỨNG DỤNG\\". HUTECH"], "references": ["Thông tư quy định Khung năng lực số (Số 02 /2025/TT-BGDĐT)", "Tài liệu về Prompt Engineering, RAG, Multimodal AI.", "AI Competency Framework for Students (2024). UNESCO."], "prerequisites": "", "course_outline": [{"clos": ["CLO1", "CLO4"], "hours": 5, "title": "GIỚI THIỆU VỂ TRÍ TUỆ NHÂN TẠO", "lesson": 1, "topics": ["1.1. Định nghĩa TTNT", "1.2. Sự phát triển của TTNT và ứng dụng trong cuộc sống", "1.3. Các loại TTNT", "1.4. Ứng dụng TTNT trong các ngành nghề"], "teaching_methods": "Giảng dạy tích cực về TTNT từ khái niệm đến các ứng dụng thực tế. Thảo luận và bài tập: \\"Trình bày ứng dụng của TTNT đến các lĩnh vực như Kinh tế, KHXH, Sức khỏe, Kỹ thuật, Ngoại ngữ\\". Làm việc nhóm và trình bày tổng quan các ứng dụng (tại lớp). Tìm hiểu ứng dụng cụ thể (về nhà)."}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 10, "title": "TRÍ TUỆ NHÂN TẠO VÀ DỮ LIỆU", "lesson": 2, "topics": ["2.1. Vai trò của TTNT và dữ liệu lớn", "2.2. Cách TTNT học từ dữ liệu", "2.3. Tổ chức và quản lý dữ liệu", "2.4. Phân tích dữ liệu cơ bản"], "teaching_methods": "Giảng dạy tích cực về chiếc lược khai thác dữ liệu số hiện nay. Thảo luận và bài tập: \\"Phân tích một bộ dữ liệu thực tế liên quan đến các nhóm ngành học\\". Khảo sát các nguồn dữ liệu (tại lớp). Thực hiện phân tích và trình bày trực quan kết quả qua biểu đồ, kết hợp giải thích ý nghĩa thực tế (về nhà)."}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 5, "title": "VAI TRÒ CỦA TRÍ TUỆ NHÂN TẠO TRONG THỰC TẾ", "lesson": 3, "topics": ["3.1. TTNT trong lĩnh vực Kinh tế", "3.2. TTNT trong lĩnh vực Khoa học xã hội", "3.3. TTNT trong lĩnh vực Y tế", "3.4. TTNT trong lĩnh vực Kỹ thuật", "3.5. TTNT trong lĩnh vực Ngoại ngữ"], "teaching_methods": "Giảng dạy tích cực về vai trò TTNT trong các lĩnh vực. Thảo luận: \\"Khảo sát các công cụ TTNT liên quan đến nhóm ngành học\\". SV chọn hướng ứng dụng TTNT phù hợp với nhóm ngành học tương ứng. Trình bày kết quả khảo sát và lựa chọn các công cụ TTNT phù hợp. (tại lớp)"}, {"clos": ["CLO2", "CLO4"], "hours": 10, "title": "SỬ DỤNG CÔNG CỤ TRÍ TUỆ NHÂN TẠO", "lesson": 4, "topics": ["4.1. Google AutoML", "4.2. Microsoft AI Builder", "4.3. IBM Watson", "4.4. TTNT trong sáng tạo nội dung"], "teaching_methods": "Giảng dạy tích cực về cách sử dụng các công cụ TTNT phổ biến. Bài tập: \\"Sử dụng công cụ TTNT vào Học tập\\". SV tạo ra một sản phẩm cá nhân như bài viết, hình ảnh minh họa, hoặc báo cáo dữ liệu bằng công cụ TTNT. (về nhà)"}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 5, "title": "TRÍ TUỆ NHÂN TẠO - ĐẠO ĐỨC VÀ THÁCH THỨC", "lesson": 5, "topics": ["5.1. Tương lai của TTNT", "5.2. Đạo đức khi sử dụng TTNT", "5.3. TTNT và quyền riêng tư", "5.4. Quy định và chính sách TTNT trên thế giới"], "teaching_methods": "Giảng dạy tích cực về đạo đức TTNT và những thách thức đối với xã hội hiện nay. Thảo luận: \\"Sử dụng TTNT có trách nhiệm\\" liên quan đến các ngành học. SV làm việc nhóm và trình bày các vấn đề liên quan. (tại lớp)"}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 10, "title": "DỰ ÁN TỔNG HỢP", "lesson": 6, "topics": ["6.1. Xác định vấn đề", "6.2. Thiết kế giải pháp", "6.3. Triển khai hệ thống", "6.4. Đánh giá và hoàn thiện"], "teaching_methods": "SV chọn một lĩnh vực và tìm cách ứng dụng TTNT và lĩnh vực đó. SV có thể phân tích dữ liệu bằng TTNT, xây dựng chatbot, sử dụng AutoML. Viết báo cáo và trình bày trước lớp."}], "_schema_version": 2, "learning_methods": [{"method": "Giảng dạy tích cực", "objective": "Lấy người học làm trung tâm, khuyến khích sự tham gia chủ động, tư duy phản biện và áp dụng kiến thức vào thực tiễn."}, {"method": "Thảo luận", "objective": "Thông qua việc hỏi đáp giữa giảng viên và sinh viên để làm rõ các nội dung kiến thức trong học phần."}, {"method": "Bài tập", "objective": "Giúp sinh viên hiểu rõ và biết vận dụng các nội dung học phần vào các vấn đề thực tiễn."}, {"method": "Tự nghiên cứu", "objective": "Giúp người học tăng cường năng lực tự học, tự nghiên cứu."}], "course_objectives": "Học phần này cung cấp cho sinh viên các kiến thức và kỹ năng cơ bản nhằm khai thác, quản lý và phân tích dữ liệu, ứng dụng trí tuệ nhân tạo (TTNT) để để cá nhân hóa học tập và giải quyết vấn đề thực tiễn. Hoàn thành xong học phần này, sinh viên sẽ có thể: -Có kiến thức cơ bản về TTNT và hiểu biết cách thức hoạt động của TTNT. -Biết cách sử dụng các công cụ TTNT để giải quyết các vấn đề trong thực tiễn một cách phù hợp.", "assessment_methods": [{"clos": ["CLO4"], "weight": 20, "component": "Điểm thành phần", "assessment_tool": "Chuyên cần và hoạt động tích cực"}, {"clos": ["CLO1", "CLO2"], "weight": 20, "component": "Bài tập nhóm", "assessment_tool": "Bài tập nhóm"}, {"clos": ["CLO1", "CLO2"], "weight": 10, "component": "Bài tập cá nhân", "assessment_tool": "Bài tập cá nhân"}, {"clos": ["CLO2", "CLO3"], "weight": 50, "component": "Điểm thi kết thúc HP", "assessment_tool": "Đồ án học phần"}], "course_description": "Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn.", "course_requirements": {"hardware": [], "software": ["Google AutoML", "Microsoft AI Builder", "IBM Watson", "TTNT trong sáng tạo nội dung"], "lab_equipment": [], "classroom_setup": ""}, "language_instruction": "Tiếng Việt"}	t	Yêu cầu chỉnh sửa	2026-03-25 16:01:38.994898+00	2026-03-26 18:26:19.204677+00
13	27	11	2	draft	{"textbooks": ["Khoa Công nghệ Thông tin. Tài liệu học tập học phần \\"TRÍ TUỆ NHÂN TẠO ỨNG DỤNG\\". HUTECH"], "references": ["Thông tư quy định Khung năng lực số (Số 02 /2025/TT-BGDĐT)", "Tài liệu về Prompt Engineering, RAG, Multimodal AI.", "AI Competency Framework for Students (2024). UNESCO."], "prerequisites": "", "course_outline": [{"clos": ["CLO1", "CLO4"], "hours": 5, "title": "GIỚI THIỆU VỂ TRÍ TUỆ NHÂN TẠO", "lesson": 1, "topics": ["1.1. Định nghĩa TTNT", "1.2. Sự phát triển của TTNT và ứng dụng trong cuộc sống", "1.3. Các loại TTNT", "1.4. Ứng dụng TTNT trong các ngành nghề"], "teaching_methods": "Giảng dạy tích cực về TTNT từ khái niệm đến các ứng dụng thực tế. Thảo luận và bài tập: \\"Trình bày ứng dụng của TTNT đến các lĩnh vực như Kinh tế, KHXH, Sức khỏe, Kỹ thuật, Ngoại ngữ\\". Làm việc nhóm và trình bày tổng quan các ứng dụng (tại lớp). Tìm hiểu ứng dụng cụ thể (về nhà)."}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 10, "title": "TRÍ TUỆ NHÂN TẠO VÀ DỮ LIỆU", "lesson": 2, "topics": ["2.1. Vai trò của TTNT và dữ liệu lớn", "2.2. Cách TTNT học từ dữ liệu", "2.3. Tổ chức và quản lý dữ liệu", "2.4. Phân tích dữ liệu cơ bản"], "teaching_methods": "Giảng dạy tích cực về chiếc lược khai thác dữ liệu số hiện nay. Thảo luận và bài tập: \\"Phân tích một bộ dữ liệu thực tế liên quan đến các nhóm ngành học\\". Khảo sát các nguồn dữ liệu (tại lớp). Thực hiện phân tích và trình bày trực quan kết quả qua biểu đồ, kết hợp giải thích ý nghĩa thực tế (về nhà)."}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 5, "title": "VAI TRÒ CỦA TRÍ TUỆ NHÂN TẠO TRONG THỰC TẾ", "lesson": 3, "topics": ["3.1. TTNT trong lĩnh vực Kinh tế", "3.2. TTNT trong lĩnh vực Khoa học xã hội", "3.3. TTNT trong lĩnh vực Y tế", "3.4. TTNT trong lĩnh vực Kỹ thuật", "3.5. TTNT trong lĩnh vực Ngoại ngữ"], "teaching_methods": "Giảng dạy tích cực về vai trò TTNT trong các lĩnh vực. Thảo luận: \\"Khảo sát các công cụ TTNT liên quan đến nhóm ngành học\\". SV chọn hướng ứng dụng TTNT phù hợp với nhóm ngành học tương ứng. Trình bày kết quả khảo sát và lựa chọn các công cụ TTNT phù hợp. (tại lớp)"}, {"clos": ["CLO2", "CLO4"], "hours": 10, "title": "SỬ DỤNG CÔNG CỤ TRÍ TUỆ NHÂN TẠO", "lesson": 4, "topics": ["4.1. Google AutoML", "4.2. Microsoft AI Builder", "4.3. IBM Watson", "4.4. TTNT trong sáng tạo nội dung"], "teaching_methods": "Giảng dạy tích cực về cách sử dụng các công cụ TTNT phổ biến. Bài tập: \\"Sử dụng công cụ TTNT vào Học tập\\". SV tạo ra một sản phẩm cá nhân như bài viết, hình ảnh minh họa, hoặc báo cáo dữ liệu bằng công cụ TTNT. (về nhà)"}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 5, "title": "TRÍ TUỆ NHÂN TẠO - ĐẠO ĐỨC VÀ THÁCH THỨC", "lesson": 5, "topics": ["5.1. Tương lai của TTNT", "5.2. Đạo đức khi sử dụng TTNT", "5.3. TTNT và quyền riêng tư", "5.4. Quy định và chính sách TTNT trên thế giới"], "teaching_methods": "Giảng dạy tích cực về đạo đức TTNT và những thách thức đối với xã hội hiện nay. Thảo luận: \\"Sử dụng TTNT có trách nhiệm\\" liên quan đến các ngành học. SV làm việc nhóm và trình bày các vấn đề liên quan. (tại lớp)"}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 10, "title": "DỰ ÁN TỔNG HỢP", "lesson": 6, "topics": ["6.1. Xác định vấn đề", "6.2. Thiết kế giải pháp", "6.3. Triển khai hệ thống", "6.4. Đánh giá và hoàn thiện"], "teaching_methods": "SV chọn một lĩnh vực và tìm cách ứng dụng TTNT và lĩnh vực đó. SV có thể phân tích dữ liệu bằng TTNT, xây dựng chatbot, sử dụng AutoML. Viết báo cáo và trình bày trước lớp."}], "_schema_version": 2, "learning_methods": [{"method": "Giảng dạy tích cực", "objective": "Lấy người học làm trung tâm, khuyến khích sự tham gia chủ động, tư duy phản biện và áp dụng kiến thức vào thực tiễn."}, {"method": "Thảo luận", "objective": "Thông qua việc hỏi đáp giữa giảng viên và sinh viên để làm rõ các nội dung kiến thức trong học phần."}, {"method": "Bài tập", "objective": "Giúp sinh viên hiểu rõ và biết vận dụng các nội dung học phần vào các vấn đề thực tiễn."}, {"method": "Tự nghiên cứu", "objective": "Giúp người học tăng cường năng lực tự học, tự nghiên cứu."}], "course_objectives": "Học phần này cung cấp cho sinh viên các kiến thức và kỹ năng cơ bản nhằm khai thác, quản lý và phân tích dữ liệu, ứng dụng trí tuệ nhân tạo (TTNT) để để cá nhân hóa học tập và giải quyết vấn đề thực tiễn. Hoàn thành xong học phần này, sinh viên sẽ có thể: -Có kiến thức cơ bản về TTNT và hiểu biết cách thức hoạt động của TTNT. -Biết cách sử dụng các công cụ TTNT để giải quyết các vấn đề trong thực tiễn một cách phù hợp.", "assessment_methods": [{"clos": ["CLO4"], "weight": 20, "component": "Điểm thành phần", "assessment_tool": "Chuyên cần và hoạt động tích cực"}, {"clos": ["CLO1", "CLO2"], "weight": 20, "component": "Bài tập nhóm", "assessment_tool": "Bài tập nhóm"}, {"clos": ["CLO1", "CLO2"], "weight": 10, "component": "Bài tập cá nhân", "assessment_tool": "Bài tập cá nhân"}, {"clos": ["CLO2", "CLO3"], "weight": 50, "component": "Điểm thi kết thúc HP", "assessment_tool": "Đồ án học phần"}], "course_description": "Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn.", "course_requirements": {"hardware": [], "software": ["Google AutoML", "Microsoft AI Builder", "IBM Watson", "TTNT trong sáng tạo nội dung"], "lab_equipment": [], "classroom_setup": ""}, "language_instruction": "Tiếng Việt"}	f	\N	2026-03-27 03:01:01.407388+00	2026-03-27 03:01:01.407388+00
15	29	578	7	draft	{"textbooks": ["Khoa Công nghệ Thông tin. Tài liệu học tập học phần \\"TRÍ TUỆ NHÂN TẠO ỨNG DỤNG\\". HUTECH"], "references": ["Thông tư quy định Khung năng lực số (Số 02 /2025/TT-BGDĐT)", "Tài liệu về Prompt Engineering, RAG, Multimodal AI.", "AI Competency Framework for Students (2024). UNESCO."], "prerequisites": "", "course_outline": [{"clos": ["CLO1", "CLO4"], "hours": 5, "title": "GIỚI THIỆU VỂ TRÍ TUỆ NHÂN TẠO", "lesson": 1, "topics": ["1.1. Định nghĩa TTNT", "1.2. Sự phát triển của TTNT và ứng dụng trong cuộc sống", "1.3. Các loại TTNT", "1.4. Ứng dụng TTNT trong các ngành nghề"], "teaching_methods": "Giảng dạy tích cực về TTNT từ khái niệm đến các ứng dụng thực tế. Thảo luận và bài tập: \\"Trình bày ứng dụng của TTNT đến các lĩnh vực như Kinh tế, KHXH, Sức khỏe, Kỹ thuật, Ngoại ngữ\\". Làm việc nhóm và trình bày tổng quan các ứng dụng (tại lớp). Tìm hiểu ứng dụng cụ thể (về nhà)."}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 10, "title": "TRÍ TUỆ NHÂN TẠO VÀ DỮ LIỆU", "lesson": 2, "topics": ["2.1. Vai trò của TTNT và dữ liệu lớn", "2.2. Cách TTNT học từ dữ liệu", "2.3. Tổ chức và quản lý dữ liệu", "2.4. Phân tích dữ liệu cơ bản"], "teaching_methods": "Giảng dạy tích cực về chiếc lược khai thác dữ liệu số hiện nay. Thảo luận và bài tập: \\"Phân tích một bộ dữ liệu thực tế liên quan đến các nhóm ngành học\\". Khảo sát các nguồn dữ liệu (tại lớp). Thực hiện phân tích và trình bày trực quan kết quả qua biểu đồ, kết hợp giải thích ý nghĩa thực tế (về nhà)."}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 5, "title": "VAI TRÒ CỦA TRÍ TUỆ NHÂN TẠO TRONG THỰC TẾ", "lesson": 3, "topics": ["3.1. TTNT trong lĩnh vực Kinh tế", "3.2. TTNT trong lĩnh vực Khoa học xã hội", "3.3. TTNT trong lĩnh vực Y tế", "3.4. TTNT trong lĩnh vực Kỹ thuật", "3.5. TTNT trong lĩnh vực Ngoại ngữ"], "teaching_methods": "Giảng dạy tích cực về vai trò TTNT trong các lĩnh vực. Thảo luận: \\"Khảo sát các công cụ TTNT liên quan đến nhóm ngành học\\". SV chọn hướng ứng dụng TTNT phù hợp với nhóm ngành học tương ứng. Trình bày kết quả khảo sát và lựa chọn các công cụ TTNT phù hợp. (tại lớp)"}, {"clos": ["CLO2", "CLO4"], "hours": 10, "title": "SỬ DỤNG CÔNG CỤ TRÍ TUỆ NHÂN TẠO", "lesson": 4, "topics": ["4.1. Google AutoML", "4.2. Microsoft AI Builder", "4.3. IBM Watson", "4.4. TTNT trong sáng tạo nội dung"], "teaching_methods": "Giảng dạy tích cực về cách sử dụng các công cụ TTNT phổ biến. Bài tập: \\"Sử dụng công cụ TTNT vào Học tập\\". SV tạo ra một sản phẩm cá nhân như bài viết, hình ảnh minh họa, hoặc báo cáo dữ liệu bằng công cụ TTNT. (về nhà)"}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 5, "title": "TRÍ TUỆ NHÂN TẠO - ĐẠO ĐỨC VÀ THÁCH THỨC", "lesson": 5, "topics": ["5.1. Tương lai của TTNT", "5.2. Đạo đức khi sử dụng TTNT", "5.3. TTNT và quyền riêng tư", "5.4. Quy định và chính sách TTNT trên thế giới"], "teaching_methods": "Giảng dạy tích cực về đạo đức TTNT và những thách thức đối với xã hội hiện nay. Thảo luận: \\"Sử dụng TTNT có trách nhiệm\\" liên quan đến các ngành học. SV làm việc nhóm và trình bày các vấn đề liên quan. (tại lớp)"}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 10, "title": "DỰ ÁN TỔNG HỢP", "lesson": 6, "topics": ["6.1. Xác định vấn đề", "6.2. Thiết kế giải pháp", "6.3. Triển khai hệ thống", "6.4. Đánh giá và hoàn thiện"], "teaching_methods": "SV chọn một lĩnh vực và tìm cách ứng dụng TTNT và lĩnh vực đó. SV có thể phân tích dữ liệu bằng TTNT, xây dựng chatbot, sử dụng AutoML. Viết báo cáo và trình bày trước lớp."}], "_schema_version": 2, "learning_methods": "Giảng dạy tích cực: Lấy người học làm trung tâm, khuyến khích sự tham gia chủ động, tư duy phản biện và áp dụng kiến thức vào thực tiễn.\\nThảo luận: Thông qua việc hỏi đáp giữa giảng viên và sinh viên để làm rõ các nội dung kiến thức trong học phần.\\nBài tập: Giúp sinh viên hiểu rõ và biết vận dụng các nội dung học phần vào các vấn đề thực tiễn.\\nTự nghiên cứu: Giúp người học tăng cường năng lực tự học, tự nghiên cứu.", "course_objectives": "Học phần này cung cấp cho sinh viên các kiến thức và kỹ năng cơ bản nhằm khai thác, quản lý và phân tích dữ liệu, ứng dụng trí tuệ nhân tạo (TTNT) để để cá nhân hóa học tập và giải quyết vấn đề thực tiễn. Hoàn thành xong học phần này, sinh viên sẽ có thể: -Có kiến thức cơ bản về TTNT và hiểu biết cách thức hoạt động của TTNT. -Biết cách sử dụng các công cụ TTNT để giải quyết các vấn đề trong thực tiễn một cách phù hợp.", "assessment_methods": [{"clos": ["CLO4"], "weight": 20, "component": "Điểm thành phần", "assessment_tool": "Chuyên cần và hoạt động tích cực"}, {"clos": ["CLO1", "CLO2"], "weight": 20, "component": "Bài tập nhóm", "assessment_tool": "Bài tập nhóm"}, {"clos": ["CLO1", "CLO2"], "weight": 10, "component": "Bài tập cá nhân", "assessment_tool": "Bài tập cá nhân"}, {"clos": ["CLO2", "CLO3"], "weight": 50, "component": "Điểm thi kết thúc HP", "assessment_tool": "Đồ án học phần"}], "course_description": "Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn.", "course_requirements": {"hardware": [], "software": ["Google Search", "Scholar", "ChatGPT", "Google AutoML", "Microsoft AI Builder", "IBM Watson"], "lab_equipment": [], "classroom_setup": ""}, "language_instruction": "Tiếng Việt"}	f	\N	2026-04-05 04:48:49.638081+00	2026-04-05 05:17:37.675039+00
\.


--
-- Name: approval_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.approval_logs_id_seq', 213, true);


--
-- Name: assessment_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.assessment_plans_id_seq', 240, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 4679, true);


--
-- Name: course_clos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.course_clos_id_seq', 36, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.courses_id_seq', 727, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.departments_id_seq', 2217, true);


--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.knowledge_blocks_id_seq', 2199, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.permissions_id_seq', 2460, true);


--
-- Name: plo_pis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.plo_pis_id_seq', 353, true);


--
-- Name: program_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.program_versions_id_seq', 412, true);


--
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.programs_id_seq', 554, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.roles_id_seq', 687, true);


--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.syllabus_assignments_id_seq', 5, true);


--
-- Name: teaching_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.teaching_plan_id_seq', 631, true);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 78, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.users_id_seq', 227, true);


--
-- Name: version_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_courses_id_seq', 955, true);


--
-- Name: version_objectives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_objectives_id_seq', 234, true);


--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_pi_courses_id_seq', 2194, true);


--
-- Name: version_plos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_plos_id_seq', 313, true);


--
-- Name: version_syllabi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_syllabi_id_seq', 15, true);


--
-- Name: approval_logs approval_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_pkey PRIMARY KEY (id);


--
-- Name: assessment_plans assessment_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clo_plo_map clo_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_pkey PRIMARY KEY (clo_id, plo_id);


--
-- Name: course_clos course_clos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_pkey PRIMARY KEY (id);


--
-- Name: course_plo_map course_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_pkey PRIMARY KEY (course_id, plo_id);


--
-- Name: courses courses_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_code_key UNIQUE (code);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: departments departments_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_code_key UNIQUE (code);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: knowledge_blocks knowledge_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plo_pis plo_pis_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_pkey PRIMARY KEY (id);


--
-- Name: po_plo_map po_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_pkey PRIMARY KEY (po_id, plo_id);


--
-- Name: program_versions program_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_pkey PRIMARY KEY (id);


--
-- Name: program_versions program_versions_program_id_academic_year_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_academic_year_key UNIQUE (program_id, academic_year);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_code_key UNIQUE (code);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: syllabus_assignments syllabus_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_pkey PRIMARY KEY (id);


--
-- Name: syllabus_assignments syllabus_assignments_version_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_version_id_course_id_key UNIQUE (version_id, course_id);


--
-- Name: teaching_plan teaching_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan
    ADD CONSTRAINT teaching_plan_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_department_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_department_id_key UNIQUE (user_id, role_id, department_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: version_courses version_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_pkey PRIMARY KEY (id);


--
-- Name: version_objectives version_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_pkey PRIMARY KEY (id);


--
-- Name: version_pi_courses version_pi_courses_pi_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pi_id_course_id_key UNIQUE (pi_id, course_id);


--
-- Name: version_pi_courses version_pi_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pkey PRIMARY KEY (id);


--
-- Name: version_plos version_plos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_pkey PRIMARY KEY (id);


--
-- Name: version_syllabi version_syllabi_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_pkey PRIMARY KEY (id);


--
-- Name: idx_sa_assigned_to; Type: INDEX; Schema: public; Owner: program
--

CREATE INDEX idx_sa_assigned_to ON public.syllabus_assignments USING btree (assigned_to);


--
-- Name: idx_sa_version; Type: INDEX; Schema: public; Owner: program
--

CREATE INDEX idx_sa_version ON public.syllabus_assignments USING btree (version_id);


--
-- Name: teaching_plan_vc_unique; Type: INDEX; Schema: public; Owner: program
--

CREATE UNIQUE INDEX teaching_plan_vc_unique ON public.teaching_plan USING btree (version_course_id);


--
-- Name: approval_logs approval_logs_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: assessment_plans assessment_plans_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id);


--
-- Name: assessment_plans assessment_plans_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: assessment_plans assessment_plans_sample_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_sample_course_id_fkey FOREIGN KEY (sample_course_id) REFERENCES public.courses(id);


--
-- Name: assessment_plans assessment_plans_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_clo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_clo_id_fkey FOREIGN KEY (clo_id) REFERENCES public.course_clos(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_clos course_clos_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: courses courses_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id);


--
-- Name: knowledge_blocks knowledge_blocks_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_blocks(id) ON DELETE CASCADE;


--
-- Name: knowledge_blocks knowledge_blocks_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: plo_pis plo_pis_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.version_objectives(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: program_versions program_versions_copied_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_copied_from_id_fkey FOREIGN KEY (copied_from_id) REFERENCES public.program_versions(id);


--
-- Name: program_versions program_versions_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.programs(id) ON DELETE CASCADE;


--
-- Name: programs programs_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: syllabus_assignments syllabus_assignments_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: syllabus_assignments syllabus_assignments_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: syllabus_assignments syllabus_assignments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: syllabus_assignments syllabus_assignments_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: teaching_plan teaching_plan_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan
    ADD CONSTRAINT teaching_plan_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_knowledge_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_knowledge_block_id_fkey FOREIGN KEY (knowledge_block_id) REFERENCES public.knowledge_blocks(id) ON DELETE SET NULL;


--
-- Name: version_courses version_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_objectives version_objectives_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_plos version_plos_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_syllabi version_syllabi_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: version_syllabi version_syllabi_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: version_syllabi version_syllabi_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: program
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict aGH4uXWl4GeUpAcFud7oeIkDnt3r0eMjHaXrZ4H3KtQKGjCuU6oYOgqSmEagvUr

