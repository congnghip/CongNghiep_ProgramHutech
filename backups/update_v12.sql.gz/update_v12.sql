--
-- PostgreSQL database dump
--

\restrict a6reIuL5ABTi8mPZJnPo6wcFakhl6uHzSQweWHUqpPXZVSd7shVmx0w5ty0dHk4

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: program
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO program;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: program
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.approval_logs (
    id integer NOT NULL,
    entity_type character varying(30) NOT NULL,
    entity_id integer NOT NULL,
    step character varying(30) NOT NULL,
    action character varying(20) NOT NULL,
    reviewer_id integer,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.approval_logs OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.approval_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_logs_id_seq OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.approval_logs_id_seq OWNED BY public.approval_logs.id;


--
-- Name: assessment_plans; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.assessment_plans (
    id integer NOT NULL,
    version_id integer,
    plo_id integer,
    pi_id integer,
    sample_course_id integer,
    assessment_tool character varying(200),
    criteria character varying(200),
    threshold character varying(200),
    semester character varying(30),
    assessor character varying(200),
    dept_code character varying(20),
    direct_evidence character varying(200),
    expected_result character varying(200),
    contributing_course_codes text
);


ALTER TABLE public.assessment_plans OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.assessment_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assessment_plans_id_seq OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.assessment_plans_id_seq OWNED BY public.assessment_plans.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100),
    target character varying(200),
    details text,
    ip character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clo_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.clo_plo_map (
    clo_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 1
);


ALTER TABLE public.clo_plo_map OWNER TO program;

--
-- Name: course_clos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_clos (
    id integer NOT NULL,
    version_course_id integer,
    code character varying(20),
    description text
);


ALTER TABLE public.course_clos OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.course_clos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_clos_id_seq OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.course_clos_id_seq OWNED BY public.course_clos.id;


--
-- Name: course_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_plo_map (
    version_id integer,
    course_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.course_plo_map OWNER TO program;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(300) NOT NULL,
    credits integer DEFAULT 3,
    credits_theory integer DEFAULT 0,
    credits_practice integer DEFAULT 0,
    credits_project integer DEFAULT 0,
    credits_internship integer DEFAULT 0,
    department_id integer,
    description text
);


ALTER TABLE public.courses OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    parent_id integer,
    code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(20) DEFAULT 'KHOA'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.departments OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: knowledge_blocks; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.knowledge_blocks (
    id integer NOT NULL,
    version_id integer,
    name character varying(200) NOT NULL,
    parent_id integer,
    total_credits integer DEFAULT 0,
    required_credits integer DEFAULT 0,
    elective_credits integer DEFAULT 0,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.knowledge_blocks OWNER TO program;

--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.knowledge_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knowledge_blocks_id_seq OWNER TO program;

--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.knowledge_blocks_id_seq OWNED BY public.knowledge_blocks.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    code character varying(60) NOT NULL,
    module character varying(30) NOT NULL,
    description character varying(200)
);


ALTER TABLE public.permissions OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: plo_pis; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.plo_pis (
    id integer NOT NULL,
    plo_id integer,
    pi_code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.plo_pis OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.plo_pis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plo_pis_id_seq OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.plo_pis_id_seq OWNED BY public.plo_pis.id;


--
-- Name: po_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.po_plo_map (
    version_id integer,
    po_id integer NOT NULL,
    plo_id integer NOT NULL
);


ALTER TABLE public.po_plo_map OWNER TO program;

--
-- Name: program_versions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.program_versions (
    id integer NOT NULL,
    program_id integer,
    academic_year character varying(20) NOT NULL,
    version_name character varying(300),
    status character varying(30) DEFAULT 'draft'::character varying,
    is_locked boolean DEFAULT false,
    copied_from_id integer,
    completion_pct integer DEFAULT 0,
    total_credits integer,
    training_duration character varying(50),
    change_type character varying(50),
    effective_date date,
    change_summary text,
    grading_scale text,
    graduation_requirements text,
    job_positions text,
    further_education text,
    reference_programs text,
    training_process text,
    admission_targets text,
    admission_criteria text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_rejected boolean DEFAULT false,
    rejection_reason text,
    general_objective text
);


ALTER TABLE public.program_versions OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.program_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_versions_id_seq OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.program_versions_id_seq OWNED BY public.program_versions.id;


--
-- Name: programs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.programs (
    id integer NOT NULL,
    department_id integer,
    name character varying(300) NOT NULL,
    name_en character varying(300),
    code character varying(30),
    degree character varying(50) DEFAULT 'Đại học'::character varying,
    total_credits integer,
    institution character varying(300),
    degree_name character varying(300),
    training_mode character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.programs OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.programs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.programs_id_seq OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.programs_id_seq OWNED BY public.programs.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO program;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    is_system boolean DEFAULT true
);


ALTER TABLE public.roles OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: syllabus_assignments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.syllabus_assignments (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    assigned_to integer,
    assigned_by integer,
    assigner_role_level integer DEFAULT 1,
    deadline date,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.syllabus_assignments OWNER TO program;

--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.syllabus_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.syllabus_assignments_id_seq OWNER TO program;

--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.syllabus_assignments_id_seq OWNED BY public.syllabus_assignments.id;


--
-- Name: teaching_plan; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.teaching_plan (
    id integer NOT NULL,
    version_course_id integer,
    total_hours integer DEFAULT 0,
    hours_theory integer DEFAULT 0,
    hours_practice integer DEFAULT 0,
    hours_project integer DEFAULT 0,
    hours_internship integer DEFAULT 0,
    software character varying(500),
    managing_dept character varying(200),
    batch character varying(10),
    notes text
);


ALTER TABLE public.teaching_plan OWNER TO program;

--
-- Name: teaching_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.teaching_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teaching_plan_id_seq OWNER TO program;

--
-- Name: teaching_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.teaching_plan_id_seq OWNED BY public.teaching_plan.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    department_id integer
);


ALTER TABLE public.user_roles OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(200) NOT NULL,
    email character varying(200),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_courses (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    semester integer,
    course_type character varying(20) DEFAULT 'required'::character varying,
    prerequisite_course_ids integer[],
    corequisite_course_ids integer[],
    elective_group character varying(100)
);


ALTER TABLE public.version_courses OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_courses_id_seq OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_courses_id_seq OWNED BY public.version_courses.id;


--
-- Name: version_objectives; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_objectives (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.version_objectives OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_objectives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_objectives_id_seq OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_objectives_id_seq OWNED BY public.version_objectives.id;


--
-- Name: version_pi_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_pi_courses (
    id integer NOT NULL,
    version_id integer,
    pi_id integer,
    course_id integer,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.version_pi_courses OWNER TO program;

--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_pi_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_pi_courses_id_seq OWNER TO program;

--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_pi_courses_id_seq OWNED BY public.version_pi_courses.id;


--
-- Name: version_plos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_plos (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    bloom_level integer DEFAULT 1,
    description text
);


ALTER TABLE public.version_plos OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_plos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_plos_id_seq OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_plos_id_seq OWNED BY public.version_plos.id;


--
-- Name: version_syllabi; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_syllabi (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    author_id integer,
    status character varying(30) DEFAULT 'draft'::character varying,
    content jsonb DEFAULT '{}'::jsonb,
    is_rejected boolean DEFAULT false,
    rejection_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.version_syllabi OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_syllabi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_syllabi_id_seq OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_syllabi_id_seq OWNED BY public.version_syllabi.id;


--
-- Name: approval_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs ALTER COLUMN id SET DEFAULT nextval('public.approval_logs_id_seq'::regclass);


--
-- Name: assessment_plans id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans ALTER COLUMN id SET DEFAULT nextval('public.assessment_plans_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: course_clos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos ALTER COLUMN id SET DEFAULT nextval('public.course_clos_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: knowledge_blocks id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks ALTER COLUMN id SET DEFAULT nextval('public.knowledge_blocks_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: plo_pis id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis ALTER COLUMN id SET DEFAULT nextval('public.plo_pis_id_seq'::regclass);


--
-- Name: program_versions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions ALTER COLUMN id SET DEFAULT nextval('public.program_versions_id_seq'::regclass);


--
-- Name: programs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs ALTER COLUMN id SET DEFAULT nextval('public.programs_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: syllabus_assignments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments ALTER COLUMN id SET DEFAULT nextval('public.syllabus_assignments_id_seq'::regclass);


--
-- Name: teaching_plan id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan ALTER COLUMN id SET DEFAULT nextval('public.teaching_plan_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses ALTER COLUMN id SET DEFAULT nextval('public.version_courses_id_seq'::regclass);


--
-- Name: version_objectives id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives ALTER COLUMN id SET DEFAULT nextval('public.version_objectives_id_seq'::regclass);


--
-- Name: version_pi_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses ALTER COLUMN id SET DEFAULT nextval('public.version_pi_courses_id_seq'::regclass);


--
-- Name: version_plos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos ALTER COLUMN id SET DEFAULT nextval('public.version_plos_id_seq'::regclass);


--
-- Name: version_syllabi id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi ALTER COLUMN id SET DEFAULT nextval('public.version_syllabi_id_seq'::regclass);


--
-- Data for Name: approval_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.approval_logs (id, entity_type, entity_id, step, action, reviewer_id, notes, created_at) FROM stdin;
\.


--
-- Data for Name: assessment_plans; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.assessment_plans (id, version_id, plo_id, pi_id, sample_course_id, assessment_tool, criteria, threshold, semester, assessor, dept_code, direct_evidence, expected_result, contributing_course_codes) FROM stdin;
1	1	1	\N	2	Bài kiểm tra cuối kỳ	Giải đúng bài toán CTDL	≥70% SV đạt từ 5/10	HK2	GV phụ trách	\N	\N	\N	\N
2	1	2	\N	6	Đồ án môn học	Thiết kế đúng quy trình UML	≥70% SV đạt yêu cầu	HK4	GV + Doanh nghiệp	\N	\N	\N	\N
3	1	3	\N	7	Bài tập thực hành	Chạy đúng chức năng web app	≥80% SV hoàn thành	HK4	GV phụ trách	\N	\N	\N	\N
4	1	4	\N	3	Bài kiểm tra cuối kỳ	Thiết kế CSDL chuẩn 3NF	≥70% SV đạt từ 5/10	HK3	GV phụ trách	\N	\N	\N	\N
5	1	5	\N	9	Báo cáo nhóm	Trình bày rõ ràng, logic	≥75% SV đạt	HK6	Hội đồng chấm	\N	\N	\N	\N
6	1	6	\N	8	Tiểu luận	Phân tích công nghệ AI mới	≥70% SV đạt	HK5	GV phụ trách	\N	\N	\N	\N
59	4	21	51	37	Điểm chuyên cần	Nhận biết các vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK1 / năm 3	Trần Phương Anh	\N	Chuyên cần	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,LAW158,MAN116,ENG183,SLK122,CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN120,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211,AIT129
60	4	21	51	37	Điểm chuyên cần	Nhận biết các vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK1 / năm 3	Trần Phương Anh	\N	Chuyên cần	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,LAW158,MAN116,ENG183,SLK122,CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN120,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211,AIT129
61	4	21	52	29	Rubric	Xây dựng phương án để giải quyết các vấn đề về chính trị và pháp luật, khoa học xã hội và nhânvăn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK2 / năm 1	\N	VJIT	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	LAW158,SKL115,ENG183,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318
62	4	21	53	54	Thang điểm bài thi viết	Kết hợp các kiến thức cơ bản, kiến thức chuyên ngành để đóng góp hữu hiệu vào sự phát triển bền vững của xã hội, cộng đồng	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	ENS192,SOS118,CHN5002,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211
63	4	22	54	52	Thang điểm bài thi viết	Nhận biết các thành phần cấu tạo nên ngôn ngữ Trung Quốc	\N	HK1/ năm 3	Khuất Thị Tú Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN117,CHN118,CHN122,CHN123,CHN124,CHN125,CHN126,CHN134
64	4	22	55	37	Thang điểm bài thi viết	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc	\N	HK1/ năm 3	Trần Phương Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN118,CHN119,CHN120,CHN121,CHN134,CHN135,AIT1021,CHN1003,CHN4005
65	4	22	56	47	Thang điểm bài thi viết	Sử dụng thành thạo 4 kỹ năng tiếng Trung	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126
66	4	23	57	25	Thang điểm bài thi viết	Sử dụng ngoại ngữ 2 tiếng Anh trong các tình huống quen thuộc để nâng cao cơ hội việc làm và mở rộng hiểu biết về các nền văn hóa khác.	\N	HK2/ năm 2	\N	K.TA	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	ENC120,ENC121,ENC122,ENC123
67	4	24	58	57	Thang điểm bài thi viết	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Trần Phương Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
68	4	24	58	61	Thang điểm bài thi viết	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Khuất Thị Tú Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
69	4	24	58	64	Rubric	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Lê Quốc Huỳnh	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
70	4	24	59	47	Thang điểm bài thi viết	Nhận biết chữ Hán phồn thể và thành thạo chữ Hán giản thể trong công việc.	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN121,CHN122,CHN123,CHN124,CHN125,CHN126
71	4	24	60	54	Thang điểm bài thi viết	Khai thác thông tin và cập nhật kiến thức chuyên ngành thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c) văn hóa Trung Hoa, hoặc (d) khóa luận tốt nghiệp.	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	SOS118,CHN5002,CHN546,CHN135,CHN128,CHN144,AIT1021,AIT1022,CHN4005
72	4	25	61	53	Thang điểm bài thi viết	Phân tích thông tin, đưa ra luận điểm có căn cứ.	\N	HK2/ năm 3	Sú Xuân Thanh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN119,CHN120,CHN134,CHN137,CHN139,AIT1022,CHN4005,CHN1003
73	4	25	62	47	Thang điểm bài thi viết	Hệ thống lại vấn đề, đưa ra kết luận về cách thức vận hành của vấn đề hệ thống.	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,CHN121
74	4	26	63	27	Rubric	Lập kế hoạch, thực hiện và đánh giá công việc chuyên môn	\N	HK2/ năm 2	\N	K.TA	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	ENS192,LAW158,SOS118,CHN5002,CHN546
75	4	26	64	59	Thang điểm bài thi viết	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Lê Quốc Huỳnh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
76	4	26	64	60	Thang điểm bài thi viết	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Đào Thị Châu Giang	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
77	4	26	64	63	Rubric	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Thái Thị Ngọc Hương	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
78	4	26	65	55	Rubric	Áp dụng thành thạo kỹ năng giao tiếp ứng xử cần thiết để thực hiện các nhiệm vụ phức tạp.	\N	HK2/ năm 3	Ngô Thế Sử	K.TQH	Bài thu hoạch	Tối thiểu 70% người học đáp ứng	SOS118,CHN5002
79	4	26	66	56	Rubric	Ứng dụng công nghệ thông tin để soạn thảo, trình bày các loại văn bản  trong học tập, nghiên cứu và công việc có hiệu quả.	\N	HK1/ năm 4	Đào Thị Châu Giang	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	MAN116,CHN546
80	4	26	67	26	Rubric	Sử dụng có hiệu quả các phần mềm chuyên dụng để phục vụ học tập và công việc chuyên môn liên quan đến tiếng Trung	\N	HK1/ năm1	\N	K.CNTT	Đồ án	Tối thiểu 70% người học đáp ứng	AIT129,SOS118,CHN139,AIT1022,CHN1004,CHN4005
81	4	27	68	\N	Rubric	Đưa ra các nhận định cá nhân trong điều kiện làm việc thay đổi	\N	HK2 / năm 1	\N	VJIT	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	POS103,ENG183,SLK122
82	4	27	69	56	Rubric	Xác định được đầy đủ mục tiêu của nhóm, vai trò, trách nhiệm của các thành viên	\N	HK1/ năm 4	Đào Thị Châu Giang	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN546
83	4	27	70	54	Thang điểm bài thi viết	Tham gia hoạch định, lên chương trình và phối hợp trong thực hiện hoạt động nhóm đạt được mục tiêu đã đề ra.	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	POS104,POS106,POS107,ENS192,SKL115,MAN116,SLK122,SOS118,CHN5002
84	4	27	71	53	Điểm chuyên cần	Nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.	\N	HK2/ năm 3	Sú Xuân Thanh	K.TQH	Chuyên cần	Tối thiểu 70% người học đáp ứng	LAW158,SKL115,MAN116,SLK122,CHN134,SOS118,CHN5002,CHN135,CHN128,CHN137,CHN139,CHN144,AIT1021,CHN1003,CHN1004,AIT1022,CHN4005,NDF108,NDF109,NDF210,NDF211
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.audit_logs (id, user_id, action, target, details, ip, created_at) FROM stdin;
1	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:23:30.661034+00
2	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 09:24:13.773942+00
3	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-25 09:27:04.502129+00
4	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-25 09:27:18.799021+00
5	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:30:47.424145+00
6	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:35:15.254903+00
7	1	DELETE /api/programs/2	/api/programs/2	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:45:40.754262+00
8	1	PUT /api/programs/1	/api/programs/1	{"params":{"id":"1"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-03-25 09:45:53.226523+00
9	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:46:02.928121+00
10	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:47:20.3843+00
11	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 09:48:01.640783+00
12	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 10:45:17.058544+00
13	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:12:35.754412+00
14	1	DELETE /api/programs/3	/api/programs/3	{"params":{"id":"3"},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:25.846238+00
15	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:31.906452+00
16	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:41.139763+00
17	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:40:24.894399+00
18	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 11:40:39.845973+00
19	1	POST /api/versions/1/assignments	/api/versions/1/assignments	{"params":{"vId":"1"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-25 16:01:29.145986+00
20	2	POST /api/my-assignments/1/create-syllabus	/api/my-assignments/1/create-syllabus	{"params":{"assignmentId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:01:39.037698+00
21	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:29:59.750868+00
22	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:29:59.7676+00
23	1	POST /api/versions/4/assignments	/api/versions/4/assignments	{"params":{"vId":"4"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-25 16:34:20.695698+00
24	2	POST /api/my-assignments/2/create-syllabus	/api/my-assignments/2/create-syllabus	{"params":{"assignmentId":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:35:43.326965+00
25	2	POST /api/syllabi/2/import-pdf	/api/syllabi/2/import-pdf	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:35:52.671848+00
26	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:35:52.713731+00
27	2	POST /api/syllabi/2/import-pdf	/api/syllabi/2/import-pdf	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:39:31.010983+00
28	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:31.053356+00
29	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:35.479796+00
30	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.97764+00
31	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.984787+00
32	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.991555+00
33	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:39.002067+00
34	2	PUT /api/syllabi/2/clo-plo-map	/api/syllabi/2/clo-plo-map	{"params":{"sId":"2"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-25 16:39:39.010138+00
35	2	PUT /api/syllabi/2/clo-plo-map	/api/syllabi/2/clo-plo-map	{"params":{"sId":"2"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-25 16:39:49.155541+00
36	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:54.767459+00
37	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:56.988855+00
\.


--
-- Data for Name: clo_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.clo_plo_map (clo_id, plo_id, contribution_level) FROM stdin;
1	26	3
2	26	3
3	26	3
4	21	3
\.


--
-- Data for Name: course_clos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_clos (id, version_course_id, code, description) FROM stdin;
1	164	CLO1	Giải thích các khái niệm cơ bản về TTNT và cách TTNT hoạt động.
2	164	CLO2	Sử dụng các công cụ TTNT hiệu quả và có trách nhiệm.
3	164	CLO3	Áp dụng TTNT để phát triển các giải pháp một cách sáng tạo
4	164	CLO4	Thể hiện thái độ chuyên cần và tích cực trong học tập để tự điều chỉnh và phát triển năng lực học tập suốt đời
\.


--
-- Data for Name: course_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_plo_map (version_id, course_id, plo_id, contribution_level) FROM stdin;
1	5	1	2
1	5	3	3
1	6	1	3
1	6	3	2
1	8	4	3
1	8	2	2
1	7	2	2
1	7	3	3
1	9	1	1
1	9	2	2
1	10	2	3
1	10	5	2
1	10	6	1
1	11	2	2
1	11	3	3
1	11	6	2
1	12	1	2
1	12	6	3
1	15	2	3
1	15	5	2
1	15	6	2
1	16	5	3
1	16	6	2
4	155	21	1
4	155	25	1
4	155	27	1
4	156	21	1
4	156	25	1
4	156	27	1
4	157	21	2
4	157	25	2
4	157	27	2
4	158	21	1
4	158	25	1
4	158	27	1
4	159	21	2
4	159	25	2
4	159	27	2
4	160	23	1
4	161	23	1
4	162	23	2
4	163	23	3
4	164	21	1
4	164	26	3
4	165	21	2
4	165	25	2
4	165	27	2
4	166	21	2
4	166	25	2
4	166	27	2
4	167	21	3
4	167	27	3
4	168	21	2
4	168	26	3
4	168	27	2
4	169	21	1
4	169	27	1
4	170	21	3
4	170	27	3
4	171	21	1
4	171	22	1
4	172	21	1
4	172	22	1
4	173	21	2
4	173	22	2
4	174	21	2
4	174	22	2
4	175	21	3
4	175	22	3
4	176	21	1
4	176	22	1
4	176	24	1
4	177	21	1
4	177	22	1
4	177	24	1
4	178	21	2
4	178	22	2
4	178	24	2
4	179	21	2
4	179	22	2
4	179	24	2
4	180	21	3
4	180	22	3
4	180	24	3
4	181	21	1
4	181	22	1
4	182	21	1
4	182	22	1
4	183	21	2
4	183	22	2
4	183	25	2
4	184	21	2
4	184	22	2
4	184	24	2
4	184	25	2
4	185	21	3
4	185	22	3
4	185	24	3
4	185	25	3
4	186	21	1
4	186	22	1
4	186	24	1
4	187	21	1
4	187	22	1
4	187	24	1
4	188	21	2
4	188	22	2
4	188	24	2
4	189	21	2
4	189	22	2
4	189	24	2
4	190	21	3
4	190	22	3
4	190	24	3
4	191	22	3
4	191	25	3
4	191	26	3
4	191	27	3
4	192	21	3
4	192	24	3
4	192	25	3
4	192	26	3
4	192	27	3
4	193	21	3
4	193	24	3
4	193	25	3
4	193	26	3
4	193	27	3
4	194	21	3
4	194	24	3
4	194	25	3
4	194	26	3
4	194	27	3
4	195	22	3
4	195	24	3
4	195	27	3
4	196	24	3
4	196	26	3
4	196	27	3
4	197	25	3
4	197	26	3
4	197	27	3
4	198	25	3
4	198	26	3
4	198	27	3
4	199	24	3
4	199	27	3
4	200	22	3
4	200	24	3
4	200	27	3
4	201	22	3
4	201	25	3
4	201	26	3
4	201	27	3
4	202	24	3
4	202	26	3
4	202	27	3
4	203	24	3
4	203	25	3
4	203	26	3
4	203	27	3
4	204	22	3
4	204	24	3
4	204	25	3
4	204	26	3
4	204	27	3
4	205	21	1
4	206	21	1
4	207	21	1
4	208	21	1
4	209	21	1
4	210	21	1
4	211	21	1
4	212	21	1
4	213	21	1
4	214	21	1
4	215	21	1
4	216	21	1
4	217	21	1
4	218	21	1
4	219	21	1
4	220	21	1
4	220	27	1
4	221	21	1
4	221	27	1
4	222	21	2
4	222	27	2
4	223	21	2
4	223	27	2
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.courses (id, code, name, credits, credits_theory, credits_practice, credits_project, credits_internship, department_id, description) FROM stdin;
1	IT001	Nhập môn lập trình	3	2	1	0	0	5	Giới thiệu tư duy lập trình, cú pháp C/C++, cấu trúc điều khiển, hàm, mảng
2	IT002	Cấu trúc dữ liệu và giải thuật	3	2	1	0	0	5	Danh sách liên kết, ngăn xếp, hàng đợi, cây, đồ thị, sắp xếp, tìm kiếm
3	IT003	Cơ sở dữ liệu	3	2	1	0	0	5	Mô hình quan hệ, SQL, chuẩn hóa, transaction, thiết kế CSDL
4	IT004	Lập trình hướng đối tượng	3	2	1	0	0	5	OOP với Java: class, kế thừa, đa hình, interface, design pattern cơ bản
5	IT005	Mạng máy tính	3	2	1	0	0	5	Mô hình OSI/TCP-IP, định tuyến, giao thức mạng, bảo mật mạng cơ bản
6	IT006	Công nghệ phần mềm	3	2	1	0	0	5	Quy trình SDLC, Agile/Scrum, UML, kiểm thử phần mềm, quản lý dự án
7	IT007	Phát triển ứng dụng Web	3	1	2	0	0	5	HTML/CSS/JS, React/Vue, Node.js, REST API, triển khai ứng dụng web
8	IT008	Trí tuệ nhân tạo	3	2	1	0	0	5	Tìm kiếm, học máy, mạng nơ-ron, xử lý ngôn ngữ tự nhiên, ứng dụng AI
9	IT009	Đồ án chuyên ngành	3	0	0	3	0	5	Thực hiện dự án CNTT theo nhóm, áp dụng quy trình phát triển phần mềm
10	IT010	Thực tập doanh nghiệp	3	0	0	0	3	5	Thực tập tại doanh nghiệp CNTT, báo cáo kết quả thực tập
11	GE001	Triết học Mác - Lênin	3	3	0	0	0	5	Các nguyên lý cơ bản của chủ nghĩa Mác-Lênin về triết học
12	GE002	Tiếng Anh 1	3	2	1	0	0	5	Ngữ pháp, từ vựng, kỹ năng nghe-nói-đọc-viết trình độ A2-B1
13	GE003	Toán cao cấp	3	3	0	0	0	5	Đại số tuyến tính, giải tích, xác suất thống kê ứng dụng trong CNTT
14	GE004	Vật lý đại cương	3	2	1	0	0	5	Cơ học, điện từ, quang học — nền tảng cho kỹ thuật phần cứng
15	IT011	An toàn thông tin	3	2	1	0	0	5	Mã hóa, xác thực, bảo mật hệ thống, tấn công và phòng thủ mạng
16	IT012	Điện toán đám mây	3	1	2	0	0	5	AWS/Azure/GCP, container, microservices, CI/CD, serverless
22	ENC120	Anh ngữ 1	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 1 được thiết kế giảng dạy với 6 đơn vị bài học, bao gồm kiến thức ngôn ngữ về từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc trong cuộc sống, trải nghiệm cá nhân, quản lý thời gian, du lịch thế giới, cảnh quan, thời trang,  tương đương trình độ Bậc 2 theo khung NLNNVN.
43	CHN117	Tiếng Trung – Đọc 1	3	3	0	0	0	1	Nội dung môn học chủ yếu gồm có bài khóa, từ vựng, điểm ngữ pháp và phần luyện tập. Bài khóa có nội dung đa dạng, ngắn và dễ hiểu, giúp sinh viên làm quen với văn phong của tiếng Trung, từ đó mở rộng vốn từ vựng và ngữ pháp. Phần luyện tập có nội dung xoay quanh chủ đề của bài khóa, giúp sinh viên ghi chép, đánh dấu các thông tin có được từ bài khóa.
49	CHN123	Tiếng Trung – Viết 2	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Biết phân biệt và viết đúng dấu câu trong tiếng Hán; Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên có thể soạn thảo các mẫu thư tín xã giao, các đơn từ trong hành chính…; Sinh viên làm quen và phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc quan sát sự việc hoặc hình ảnh.
19	POS106	Chủ nghĩa xã hội khoa học	2	2	0	0	0	1	Chủ nghĩa xã hội khoa học là học phần bắt buộc trong khối kiến thức cơ bản, cung cấp những hiểu biết nền tảng về quá trình hình thành và phát triển của CNXHKH. Học phần gồm 7 bài, tập trung vào các nội dung chính: (1) sự ra đời và các giai đoạn phát triển của Chủ nghĩa xã hội khoa học; (2) sứ mệnh lịch sử của giai cấp công nhân, đặc biệt trong bối cảnh Việt Nam; (3) khái niệm chủ nghĩa xã hội và thời kỳ quá độ; (4) những vấn đề quy luật trong cách mạng xã hội chủ nghĩa như dân chủ, nhà nước pháp quyền; (5) cơ cấu xã hội - giai cấp và liên minh giai cấp trong thời kỳ quá độ; (6) vấn đề dân tộc, tôn giáo và mối quan hệ giữa chúng trong chủ nghĩa xã hội; (7) vai trò, chức năng của gia đình và định hướng xây dựng gia đình trong thời kỳ quá độ lên chủ nghĩa xã hội tại Việt Nam.
20	POS107	Lịch sử Đảng Cộng sản Việt Nam	2	2	0	0	0	1	Nội dung học phần gồm 5 bài: (1) trình bày đối tượng, chức năng, nhiệm vụ, phương pháp nghiên cứu, học tập môn Lịch sử Đảng; (2) Đảng cộng sản Việt Nam ra đời và lãnh đạo cách mạng giải phóng dân tộc (1930-1945); (3) trình bày về quá trình lãnh đạo của Đảng trong hai cuộc kháng chiến chống ngoại xâm chống Pháp và chống Mỹ (1945-1975); (4) trình bày những nội dung cơ bản về quá trình phát triển đường lối và lãnh đạo của Đảng trong quá trình đưa cả nước quá độ lên chủ nghĩa xã hội và tiến hành công cuộc đổi mới (1975 đến nay); (5) tổng kết những thắng lợi vĩ đại của dân tộc dưới sự lãnh đạo của Đảng và những bài học kinh nghiệm của Đảng trong quá trình lãnh đạo cách mạng.
21	POS103	Tư tưởng Hồ Chí Minh	2	2	0	0	0	1	Tư tưởng Hồ Chí Minh là học phần cơ sở bắt buộc trong chương trình đào tạo Đại học của tất cả các chuyên ngành; với cấu trúc nội dung bao gồm 6 bài: (1) Khái niệm, đối tượng, phương pháp nghiên cứu và ý nghĩa học tập môn Tư tưởng Hồ Chí Minh; (2) Cơ sở, quá trình hình thành và phát triển tư tưởng Hồ Chí Minh; (3) Tư tưởng Hồ Chí Minh về độc lập dân tộc và chủ nghĩa xã hội; (4) Tư tưởng Hồ Chí Minh về Đảng Cộng sản Việt Nam và Nhà nước của nhân dân, do nhân dân, vì nhân dân; (5) Tư tưởng Hồ Chí Minh về đại đoàn kết toàn dân tộc và đoàn kết quốc tế; (6) Tư tưởng Hồ Chí Minh về văn hóa, đạo đức và con người
23	ENC121	Anh ngữ 2	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 2 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần trang bị kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc như âm nhạc, cuộc sống, các mối quan hệ, du lịch, môi trường, tương đương trình độ trung cấp B1.
24	ENC122	Anh ngữ 3	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 3 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần cung cấp kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc trong cuộc sống như giao tiếp, trao đổi thông tin, thói quen, thực phẩm, du lịch, tương đương trình độ trung cấp B1+
25	ENC123	Anh ngữ 4	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 4 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần trang bị kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề trong cuộc sống thường ngày, nêu cách suy nghĩ, giải quyết vấn đề, tương đương trình độ trung cấp B1+
26	AIT129	Trí tuệ nhân tạo ứng dụng	3	3	0	0	0	1	Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn
27	ENS192	Phát triển bền vững	3	3	0	0	0	1	Học phần Phát triển bền vững cung cấp nền tảng kiến thức về khái niệm, nguyên tắc và thực tiễn nhằm đạt được sự cân bằng giữa các mục tiêu kinh tế, xã hội và môi trường. Nội dung học phần bao gồm: tổng quan về phát triển bền vững, lịch sử hình thành và các thách thức hiện tại; vai trò của tài nguyên môi trường, chiến lược khai thác và bảo vệ tài nguyên bền vững; mối quan hệ giữa kinh tế xanh, kinh tế tuần hoàn và bảo vệ môi trường; yếu tố xã hội như giáo dục, y tế, bình đẳng và cộng đồng trong phát triển bền vững; cùng với các công cụ quản trị và chính sách quốc gia, quốc tế nhằm thúc đẩy mục tiêu này.  Qua đó, học phần trang bị cho sinh viên khả năng phân tích vấn đề, đề xuất giải pháp và ứng dụng tư duy hệ thống vào thực tế, đặc biệt trong việc giải quyết các thách thức phát triển bền vững như quản lý và bảo vệ tài nguyên, giảm thiểu tác động tiêu cực đến môi trường, thúc đẩy kinh tế xanh và phát triển xã hội bền vững.
28	LAW158	Luật và Khởi nghiệp	3	3	0	0	0	1	Học phần cung cấp những kiến thức cơ bản về Nhà nước, Pháp luật và Khởi nghiệp, giúp sinh viên áp dụng vào thực tiễn, đặc biệt trong bối cảnh khởi nghiệp kinh doanh. Nội dung gồm hai phần chính:(1) Những vấn đề cơ bản về Nhà nước và Pháp luật, giúp sinh viên hiểu về bộ máy Nhà nước, hệ thống pháp luật Việt Nam và các ngành luật quan trọng;(2) Tổng quan về Khởi nghiệp, trang bị kiến thức về ý tưởng kinh doanh, nghiên cứu thị trường, lập kế hoạch kinh doanh, tài chính, nhân sự và quản lý rủi ro. Học phần hướng đến việc nâng cao nhận thức, khả năng phân tích và lập kế hoạch, đồng thời khuyến khích tinh thần chủ động, trách nhiệm, tuân thủ pháp luật và đạo đức kinh doanh.
29	SKL115	Tư duy thiết kế dự án	3	3	0	0	0	1	Học phần "Tư duy thiết kế dự án" cung cấp kiến thức và kỹ năng thiết yếu để phát hiện và giải quyết vấn đề thông qua quy trình tư duy thiết kế. Nội dung học phần xoay quanh quy trình gồm 7 bước chính: (1) Phát hiện vấn đề; (2) Khảo sát thực trạng vấn đề; (3) Khảo sát nhu cầu giải quyết vấn đề của các bên liên quan; (4) Khảo sát và đánh giá các giải pháp hiện có; (5) Phân tích cấu trúc nguyên nhân vấn đề; (6) Thiết lập điều kiện tiên quyết và (7) Sáng tạo và đề xuất giải pháp. Với định hướng thực tiễn và bền vững, học phần không chỉ hỗ trợ phát triển các kỹ năng cá nhân mà còn góp phần giải quyết các vấn đề xã hội theo các mục tiêu phát triển bền vững của Liên Hợp Quốc (SDGs).
30	MAN116	Quản trị học	3	3	0	0	0	1	Quản trị học là học phần cung cấp kiến thức cơ bản về công tác quản trị một tổ chức. Học phần này trang bị cho người học những nội dung về khái niệm, vai trò của công tác quản trị trong một tổ chức, phân loại môi trường và cách thức quản trị sự bất trắc môi trường, các chức năng của quản trị (Hoạch định, tổ chức, điều khiển, kiểm soát). Ngoài ra, học phần còn đề cập đến các vấn đề liên quan tác động đến hiệu quả quản trị tổ chức như thông tin quản lý, văn hóa tổ chức, kỹ năng ra quyết định của nhà quản trị.
31	ENG183	Dẫn luận ngôn ngữ	3	3	0	0	0	1	Học phần gồm 05 đơn vị bài học cung cấp cho sinh viên:- Kiến thức cơ bản về ngôn ngữ và ngôn ngữ học: đặc trưng, chức năng, hệ thống, cấu trúc, loại hình ngôn ngữ; các  bình diện sử dụng ngôn ngữ: cú pháp, từ vựng, ngữ nghĩa…- Môn học còn cung cấp những kiến thức cơ bản của tiếng Việt, giúp người học phát triển các kỹ năng sử dụng từ, viết câu; có khả năng phát hiện và sửa chữa các lỗi sử dụng tiếng Việt, các hình thức và cách diễn đạt ngôn ngữ.
32	SLK122	Kỹ năng phát triển bản thân	3	3	0	0	0	1	Học phần trang bị cho sinh viên các kiến thức và kỹ năng cần thiết để phát triển bản thân và sự nghiệp trong tương lai thông qua các kỹ năng như kỹ năng tìm kiếm nguồn lực hỗ trợ phát triển bản thân, xây dựng tác phong làm việc, kỹ năng tìm việc. Học phần gồm 5 bài học về hiểu bản thân, các nguồn lực và phát triển bản thân, kỹ năng tìm kiếm và khai thác nguồn lực, tác phong làm việc chuyên nghiệp, và dự án phát triển bản thân. Thông qua các bài học lý thuyết và thực hành, sinh viên sẽ có thể: (1) Hiểu rõ bản thân và chủ động tìm kiếm các nguồn lực phù hợp để phát triển bản thân; (2) Xây dựng phong cách làm việc chuyên nghiệp và áp dụng tác phong đó vào học tập và công việc (3) Lập kế hoạch và xây dựng được dự án phát triển bản thân.
33	CHN107	Tiếng Trung – Nghe 1	3	3	0	0	0	1	Nội dung luyện tập gồm nghe và đọc hệ thống phiên âm, nghe những câu văn dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc
34	CHN108	Tiếng Trung – Nghe 2	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những câu văn, đoạn đối thoại dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc.
35	CHN109	Tiếng Trung – Nghe 3	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những đoạn văn, bài hội thoại dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc.
36	CHN110	Tiếng Trung – Nghe 4	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những đoạn văn dài, đoạn hội thoại dài dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc
37	CHN111	Tiếng Trung – Nghe 5	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những đoạn văn dài, đoạn hội thoại dài dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên có khả năng phân tích thông tin trong các tình huống giao tiếp phức tạp
38	CHN112	Tiếng Trung – Nói 1	3	3	0	0	0	1	Học phần Tiếng Trung Nói 1 gồm 12 bài học và 3 bài ôn tập, tập trung vào việc giới thiệu hệ thống phiên âm, thanh điệu và ngữ âm cơ bản trong tiếng Trung. Sinh viên được học cách viết phiên âm, luyện đọc và sử dụng các mẫu câu cơ bản trong các chủ đề giao tiếp hàng ngày như giới thiệu bản thân, chào hỏi, hỏi thăm sức khỏe, số lượng, tiền tệ, nơi chốn. Học phần giúp sinh viên xây dựng khả năng phản xạ giao tiếp, luyện tập các đoạn hội thoại ngắn và làm quen với cách diễn đạt của người bản địa. Ngoài ra, các bài tập thực hành như đóng vai, luyện tập theo cặp và nhóm được lồng ghép để tăng sự hứng thú và hiệu quả học tập
39	CHN113	Tiếng Trung – Nói 2	3	3	0	0	0	1	Học phần Tiếng Trung Nói 2 gồm 12 bài học và 3 bài ôn tập, tiếp tục củng cố kỹ năng nói thông qua các chủ đề quen thuộc trong cuộc sống hàng ngày như mua sắm, gọi món ăn, giới thiệu quê hương, gọi điện thoại và tìm bạn học ngoại ngữ. Sinh viên được học cách nắm bắt ý chính của bài khóa, luyện tập các đoạn hội thoại ngắn và áp dụng từ vựng, ngữ pháp đã học vào giao tiếp. Học phần chú trọng vào việc thực hành nghe – nói, giúp sinh viên phản xạ nhanh hơn và giao tiếp tự tin hơn trong các tình huống thường gặp. Các hoạt động nhóm và bài tập thực hành giúp sinh viên nâng cao khả năng giao tiếp và phát triển kỹ năng làm việc nhóm.
40	CHN114	Tiếng Trung – Nói 3	3	3	0	0	0	1	Học phần Tiếng Trung Nói 3 gồm 12 bài học và 3 bài ôn tập, xoay quanh các chủ đề giao tiếp thực tiễn như đi tàu xe, gửi bưu phẩm, khám bệnh, và các vấn đề sinh hoạt thường ngày. Sinh viên được học các mẫu câu mới, tích lũy vốn từ vựng và luyện tập các đoạn hội thoại phù hợp với văn phong của người bản địa. Học phần giúp sinh viên rèn luyện kỹ năng phản xạ, thực hành xây dựng và trình bày các đoạn hội thoại ngắn, cũng như bày tỏ quan điểm cá nhân trong các tình huống cụ thể. Các bài tập nhóm, đóng vai và thuyết trình được lồng ghép để tăng cường khả năng giao tiếp hiệu quả
41	CHN115	Tiếng Trung – Nói 4	3	3	0	0	0	1	Học phần Tiếng Trung Nói 4 gồm 12 bài học và 3 bài ôn tập, bao gồm các chủ đề đa dạng về cuộc sống, xã hội, gia đình và học tập. Sinh viên sẽ được học cách xây dựng bài nói theo từng chủ đề, vận dụng từ vựng và ngữ pháp đã học để thảo luận, tranh luận và giải quyết vấn đề. Học phần tập trung vào việc phát triển khả năng tư duy logic, diễn đạt ý tưởng rõ ràng và tự nhiên. Thông qua các bài tập nhóm, thuyết trình và tranh luận, sinh viên sẽ cải thiện khả năng giao tiếp, trình bày và phản biện trong các ngữ cảnh cụ thể.
42	CHN116	Tiếng Trung – Nói 5	3	3	0	0	0	1	Học phần Tiếng Trung Nói 5 tập trung phát triển kỹ năng giao tiếp nâng cao bằng tiếng Trung trong các tình huống thực tế và chuyên môn. Nội dung học phần bao gồm việc củng cố và mở rộng vốn từ vựng, cấu trúc ngữ pháp, cùng cách diễn đạt phong phú trong các chủ đề nâng cao. Sinh viên sẽ được thực hành các kỹ năng như thuyết trình, tranh luận, và xử lý tình huống giao tiếp trong các bối cảnh học tập, công việc và đời sống hàng ngày. Ngoài ra, học phần tích hợp các bài tập nhóm, bài nói cá nhân để rèn luyện tư duy phản biện, khả năng làm việc nhóm và sự tự tin trong giao tiếp. Đặc biệt, sinh viên sẽ có cơ hội trải nghiệm thực tế nghề nghiệp thông qua các hoạt động với sự tham gia của doanh nghiệp hoặc chuyên gia trong ngành, giúp làm quen với môi trường làm việc thực tế và phát triển kỹ năng chuyên môn cơ bản. Học phần không chỉ giúp sinh viên thành thạo hơn trong kỹ năng nói tiếng Trung mà còn trang bị hành trang cần thiết để đáp ứng các yêu cầu công việc trong tương lai.
44	CHN118	Tiếng Trung – Đọc 2	3	3	0	0	0	1	Nội dung môn học tập trung chủ yếu vào vốn từ vựng, ngữ pháp cơ bản và kỹ năng đọc hiểu của sinh viên ở mức độ sơ cấp bằng việc mở rộng thêm vốn từ vựng, tìm hiểu sâu hơn về các điểm ngữ pháp sau mỗi bài khóa. Phần luyện tập sau mỗi bài khóa trang bị thêm cho sinh viên những kiến thức về văn hóa, xã hội thông qua việc đọc hiểu và trả lời các câu hỏi xoay quanh các mẫu hội thoại, các văn bản có nội dung gần gũi với đời sống thường ngày.
45	CHN119	Tiếng Trung – Đọc 3	3	3	0	0	0	1	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, các điểm ngữ pháp ở mức độ trung cấp, các mẫu câu thường gặp thông qua nội dung các bài khóa xoay quanh các chủ đề như văn hóa, xã hội, kinh tế,... Mỗi bài học đều có bài khóa, từ vựng, điểm ngữ pháp cũng như phần luyện tập. Những bài tập này cũng được nâng lên một tầm cao mới, từ việc đọc đúng âm, rõ nghĩa, hiểu nội dung chính đến khả năng phân tích, đánh giá và đưa ra luận điểm cá nhân.
46	CHN120	Tiếng Trung – Đọc 4	3	3	0	0	0	1	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, các điểm ngữ pháp ở mức độ trung và cao cấp, các cấu trúc ngữ pháp phức tạp thông qua nội dung các bài khóa xoay quanh các chủ đề như văn hóa, xã hội, kinh tế,... Mỗi bài học đều có bài khóa, từ vựng, điểm ngữ pháp cũng như phần luyện tập. Những bài tập này cũng được nâng lên mức tương đối khó, nhằm phát triển khả năng phân tích, đánh giá và đưa ra luận điểm cá nhân.
47	CHN121	Tiếng Trung – Đọc 5	3	3	0	0	0	1	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, bao gồm cả những từ vựng chuyên ngành, thành ngữ, tục ngữ, các phép tu từ,… thông qua các bài khóa có nội dung liên quan đến các chủ đề kinh tế, văn hóa và xã hội. Sau mỗi bài khóa, học phần còn cung cấp thêm nhiều điểm ngữ pháp cao cấp, các cấu trúc câu phức tạp cũng như bài tập minh họa để ví dụ, từ đó làm rõ các kiến thức đang học cũng như áp dụng các kiến thức đã học vào các bài tập thực tế.
48	CHN122	Tiếng Trung – Viết 1	3	3	0	0	0	1	Học phần cung cấp cho sinh viên kiến thức cơ bản về quy tắc viết chữ Hán ( quy tắc bút thuận), cung cấp kiến thức về lịch sử hình thành và phát triển của chữ Hán, cách viết chữ Hán, các bộ, các tự dạng chữ Hán ở mức độ nhập môn.Kết thúc học phần sinh viên có thể thực hành viết chữ Hán giản thể và nhận biết chữ Hán phồn thể ở mức độ sơ cấp; Sinh viên có thể viết các mẫu câu đa dạng theo những chủ đề quen thuộc như giới thiệu bản thân, gia đình, sở thích…
50	CHN124	Tiếng Trung – Viết 3	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên có thể soạn thảo các mẫu thư tín xã giao, các đơn từ trong hành chính…; Sinh viên làm quen và phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc quan sát sự việc hoặc hình ảnh
51	CHN125	Tiếng Trung – Viết 4	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên làm quen và phát triển kỹ năng viết độc lập, sáng tạo và logic theo chủ đề.
53	CHN134	Lý thuyết tiếng Trung Quốc	3	3	0	0	0	1	Môn học cung cấp kiến thức nền tảng về ngữ âm, văn tự, từ vựng và ngữ pháp tiếng Hán hiện đại, giúp sinh viên nhận biết cấu trúc, chức năng của các thành phần ngôn ngữ, phân tích mối quan hệ giữa hình - âm - nghĩa của chữ Hán . Sinh viên được rèn luyện khả năng tư duy phản biện, phân tích và đánh giá các vấn đề ngôn ngữ để áp dụng chính xác vào thực tiễn giao tiếp và học thuật. Thông qua các bài giảng lý thuyết, bài tập thực hành và thảo luận, sinh viên sẽ nắm vững hệ thống kiến thức về tiếng Hán hiện đại, từ đó áp dụng hiệu quả vào học tập và công việc.
54	SOS118	Văn hoá, xã hội Trung Quốc	3	3	0	0	0	1	Học phần Văn hóa – Xã hội Trung Quốc (SOS118) trang bị cho sinh viên kiến thức tổng quan về địa lý, lịch sử, văn hóa, phong tục, ẩm thực, nghệ thuật và tư tưởng truyền thống Trung Quốc. Môn học giúp sinh viên phát triển tư duy phân tích, tổng hợp, rèn luyện kỹ năng làm việc nhóm, và ý thức trách nhiệm xã hội trong bối cảnh toàn cầu hóa.Sinh viên sẽ biết cách khai thác tài liệu, cập nhật kiến thức chuyên ngành và vận dụng tiếng Trung để giải quyết các vấn đề thực tiễn liên quan đến văn hóa - xã hội.
55	CHN5002	Thực tế trải nghiệm văn hóa và ngôn ngữ Trung Quốc	3	0	0	0	3	1	-Học phần này thông qua nhiều hoạt động trải nghiệm phong phú, giúp sinh viên khám phá văn hóa Trung Quốc. Đầu tiên, sinh viên sẽ được giới thiệu tổng quan về văn hóa, ngôn ngữ vàhướng dẫn phương pháp nghiên cứu thực địa, kỹ năng viết báo cáo,làm việc nhóm. Sau đó, học phần đi sâu vào giao tiếp liên văn hóa và so sánh sự khác biệt giữa văn hóa Việt Nam và Trung Quốc.Các buổi trải nghiệm thực tế bao gồm tham quan không gian văn hóa người Hoa,tham gia các sự kiện văn hóa TrungHoahoặc workshop giao tiếp với người bản ngữ để nâng cao kỹ năng nghe-nói và hiểu biết xã hội.Mỗi chuyến đi đều có nhiệm vụ cụ thể như phỏng vấn, ghi chép, chụp ảnh tư liệu, thử nghiệm ẩm thực, hoặc quan sát nghi lễ truyền thống.-Cuối cùng, sinh viên sẽ làm việc nhóm để xây dựng và thuyết trình một dự án về văn hóa TrungHoa, từ phân tích dữ liệu đến thiết kế sản phẩm như slide, video hoặc brochure.
56	CHN546	Thực tập tốt nghiệp ngành Ngôn ngữ Trung Quốc (*)	3	0	0	0	3	1	Học phần “Thực tập tốt nghiệp ngành Ngôn ngữ Trung Quốc” nhằm trang bị cho sinh viên kiến thức và kỹ năng để áp dụng vào thực tiễn công việc. Trong học phần này, sinh viên sẽ được hướng dẫn lựa chọn doanh nghiệp phù hợp để thực tập, lập kế hoạch thực tập, xác định đề tài và viết đề cương chi tiết. Quá trình thực tập bao gồm việc sinh viên tham gia trực tiếp vào các hoạt động tại đơn vị thực tập, thực hiện các nhiệm vụ được giao, thu thập và phân tích dữ liệu thực tế. Sinh viên sẽ hoàn thiện báo cáo thực tập, bao gồm các tài liệu liên quan như nhật ký thực tập, nhận xét từ giảng viên hướng dẫn và đơn vị thực tập. Học phần kết thúc bằng buổi bảo vệ báo cáo trước hội đồng, đánh giá toàn diện khả năng áp dụng kiến thức, kỹ năng giải quyết vấn đề, và năng lực phản biện của sinh viên.Học phần đặc biệt chú trọng tích hợp công cụ trí tuệ nhân tạo (AI) trong các hoạt động như phân tích dữ liệu, dịch thuật, lập kế hoạch và viết báo cáo, nhằm nâng cao hiệu quả và tính chuyên nghiệp. Đồng thời, năng lực giải quyết vấn đề được phát triển qua các nhiệm vụ thực tiễn, từ việc xác định vấn đề, đề xuất giải pháp đến triển khai và đánh giá hiệu quả thực hiện.
57	CHN135	Thư tín thương mại tiếng Trung	3	3	0	0	0	1	Nội dung môn học xoay quanh các chủ đề về thư tín thương mại, văn phòng như: cách viết thư mời, thư giới thiệu, thư cảm ơn, thư xin lỗi, thư thiết lập mối quan hệ thương mại, thư hỏi giá, báo giá, thư thương lượng định giá,... Môn học trang bị cho người học khối kiến thức và vốn từ vựng, thuật ngữ nhất định về thư tín thương mại, văn phòng, giúp sinh viên nhận biết và biết cách viết các loại thư này.
52	CHN126	Tiếng Trung – Viết 5	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc thuật lại, lên kế hoạch và viết báo cáo tổng kết
58	CHN128	Tiếng Trung Thương mại	3	3	0	0	0	1	Học phần Tiếng Trung thương mại là một môn học trang bị cho người học những kiến thức và kỹ năng giao tiếp tiếng Trung chuyên ngành, phục vụ công việc trong môi trường kinh doanh, thương mại.Thông qua các hoạt động xử lý tình huống thực tế và đóng vai, sinh viên được rèn luyện năng lực sử dụng tiếng Trung trong môi trường thương mại. Học phần cũng góp phần hình thành tư duy ngôn ngữ chuyên ngành, hỗ trợ sinh viên định hướng nghề nghiệp trong các lĩnh vực như phiên dịch thương mại, quan hệ khách hàng, xuất nhập khẩu, và hợp tác quốc tế.
59	CHN137	Tiếng Trung hành chính – văn phòng	3	3	0	0	0	1	Học phần xoay quanh các vấn đề thường gặp khi làm việc trong môi trường công ty/công sở như: tổ chức cuộc họp, mua văn phòng phẩm, giới thiệu về cơ cấu tổ chức của một công ty, cách trình bày ý kiến cá nhân, báo cáo công việc, giải quyết nghỉ việc, quảng cáo tuyên truyền, tuyển dụng, tập huấn,…Mỗi bài đều được thiết kế gồm các phần: từ mới, bài khóa, điểm ngữ pháp cần lưu ý và bài tập. Bài khóa chủ yếu xuất hiện những mẫu câu cơ bản thường được dùng trong giao tiếp hành chính - văn phòng. Bài tập giao tiếp bám sát nội dung kiến thức trong từng bài giúp sinh viên rèn luyện khả năng phản xạ trong các tình huống cụ thể.Môn học này là cơ hội để sinh viên tiếp cận và làm quen với các nghiệp vụ cụ thể trong văn phòng, là nền tảng tốt cho các hoạt động nghề nghiệp sau này liên quan đến ngôn ngữ và văn hóa Trung Quốc.
60	CHN139	Kỹ năng dịch nói tiếng Trung	3	3	0	0	0	1	Học phần cung cấp kiến thức và kỹ năng cần thiết để thực hiện các nhiệm vụ dịch nói Trung-Việt và Việt-Trung trong các tình huống giao tiếp thực tế. Học phần tập trung vào phát triển năng lực nghe hiểu, phân tích, và diễn đạt chính xác thông điệp giữa hai ngôn ngữ, đồng thời rèn luyện khả năng xử lý thông tin nhanh chóng và linh hoạt. Sinh viên sẽ được trang bị các kỹ năng thực hành dịch nói qua các bài tập câu thoại, bài diễn văn ngắn, và tình huống giả định đơn giản.
61	CHN144	Kỹ năng dịch viết tiếng Trung	3	3	0	0	0	1	Học phần giới thiệu môn học, phương pháp học môn phiên dịch viết tiếng Trung. Sau đó, giới thiệu tổng quan về các chủ đề đọc hiểu cùng các mẫu câu thông dụng theo các bài giảng. Thực hành dịch văn bản trong các tình huống cụ thể, dịch văn bản trong các sự kiện ở một số lĩnh vực (văn hóa, giáo dục, thương mại, du lịch…)
62	AIT1021	Ứng dụng AI trong dịch thuật tiếng Trung	3	3	0	0	0	1	Học phần “Ứng dụng AI trong dịch thuật tiếng Trung” giới thiệu tổng quan về các công nghệ trí tuệ nhân tạo đang được sử dụng trong lĩnh vực dịch thuật. Sinh viên sẽ được hướng dẫn cách sử dụng, phân tích đầu ra của các công cụ dịch máy, và kết hợp giữa bản dịch tự động với hiệu chỉnh thủ công nhằm nâng cao chất lượng bản dịch tiếng Trung. Ngoài ra, học phần cũng giúp người học nhận diện các lỗi thường gặp trong dịch máy, từ đó hình thành năng lực lựa chọn công cụ phù hợp với từng ngữ cảnh dịch cụ thể.
63	CHN1003	Thiết kế giáo án và thực hành giảng dạy tiếng Trung	3	3	0	0	0	1	Học phần này cung cấp cho sinh viên những kiến thức và kỹ năng cơ bản để thiết kế giáo án giảng dạy tiếng Trung. Nội dung gồm các bước và nguyên tắc thiết kế giáo án, lựa chọn và sử dụng tài liệu giảng dạy, thiết kế hoạt động học tập và kiểm tra đánh giá. Bên cạnh đó, Sinh viên sẽ được thực hành xây dựng giáo án và giảng dạy thử trong các tình huống lớp học cụ thể.
64	CHN1004	Kỹ năng giảng dạy tiếng Trung	3	3	0	0	0	1	Học phần “Kỹ năng giảng dạy tiếng Trung” nhằm trang bị cho sinh viên những kiến thức và kỹ năng sư phạm thiết yếu trong việc tổ chức giảng dạy bốn kỹ năng ngôn ngữ cơ bản: nghe, nói, đọc, viết trong lớp học tiếng Trung. Sinh viên sẽ được tìm hiểu về mục tiêu giảng dạy của từng kỹ năng, cách chọn lựa phương pháp phù hợp và thiết kế các hoạt động giảng dạy cụ thể.Học phần kết hợp chặt chẽ giữa lý thuyết và thực hành, giúp sinh viên phát triển các kỹ năng chuyên môn như xây dựng giáo án kỹ năng, lựa chọn và khai thác ngữ liệu, thiết kế bài tập, tổ chức hoạt động giao tiếp, và ứng dụng các phần mềm, công cụ số vào quá trình dạy học. Trong suốt học phần, sinh viên sẽ tham gia các hoạt động mô phỏng giảng dạy, phân tích tình huống sư phạm, thảo luận nhóm và nhận phản hồi từ giảng viên nhằm nâng cao khả năng giảng dạy thực tiễn. Những trải nghiệm này không chỉ giúp sinh viên củng cố kiến thức, phát triển năng lực sư phạm, mà còn là bước chuẩn bị vững chắc cho công việc giảng dạy tiếng Trung trong tương lai.
65	AIT1022	Ứng dụng AI trong giảng dạy tiếng Trung	3	3	0	0	0	1	Học phần này giới thiệu một cách hệ thống các lý thuyết và ứng dụng thực tiễn của công nghệ trí tuệ nhân tạo (AI) trong giảng dạy tiếng Trung. Nội dung tập trung vào việc ứng dụng AI trong các khía cạnh như: luyện phát âm, phân tích và sửa lỗi ngữ pháp, chấm và sửa bài văn viết, thiết kế lộ trình học tập cá nhân hóa và phát triển tài nguyên dạy học thông minh. Kết thúc học phần, sinh viên sẽ có năng lực phân tích, lựa chọn và ứng dụng hiệu quả các công cụ AI để đổi mới phương pháp giảng dạy, đồng thời hình thành tư duy phản biện về những cơ hội và thách thức mà AI mang lại cho lĩnh vực giảng dạy tiếng Trung Quốc
66	CHN4005	Khóa luận tốt nghiệp Ngôn  ngữ Trung Quốc (*)	9	0	0	9	0	1	Học phần này trang bị cho sinh viên các kiến thức và các kỹ năng, phương pháp nghiên cứu khoa học, vận dụng các kiến thức chuyên ngành ngôn ngữ Trung Quốc đã học để hoàn thành đề tài nghiên cứu đã chọn.
67	PHT304	Bóng chuyền 1	2	0	0	0	0	1	Học phần trang bị cho sinh viên những kiến thức cơ bản về lịch sử hình thành và phát triển môn Bóng chuyền, tổ chức quản lý môn thể thao này trong nước và quốc tế, hệ thống luật thi đấu và các kỹ thuật chính như chuyền bóng, đệm bóng và phát bóng. Đồng thời, sinh viên được rèn luyện kỹ năng thực hành thông qua các bài tập đệm bóng thấp tay, chuyền bóng cao tay và phát bóng, góp phần nâng cao thể lực, kỹ thuật cá nhân và khả năng phối hợp trong thi đấu.
68	PHT305	Bóng chuyền 1	2	0	0	0	0	1	Cung cấp kiến thức cơ bản và chuyên sâu về bóng chuyền, bao gồm luật chơi, kỹ thuật cơ bản, dinh dưỡng thể thao và phòng tránh chấn thương. Rèn luyện và hoàn thiện kỹ thuật chuyền, đệm, phát bóng; nâng cao kỹ năng xử lý tình huống và phát triển kỹ năng cá nhân trong thi đấu
69	PHT306	Bóng chuyền 1	1	0	0	0	0	1	Học phần Bóng chuyền 3 gồm lý thuyết và thực hành, giúp sinh viên nâng cao kỹ thuật và chiến thuật thi đấu. Phần lý thuyết trang bị kiến thức về luật, tổ chức thi đấu và chiến thuật từ cơ bản đến nâng cao. Phần thực hành tập trung rèn luyện kỹ thuật chuyền đệm, đập bóng, chắn bóng, phòng thủ và phối hợp thi đấu hiệu quả
70	PHT307	Bóng rổ 1	2	0	0	0	0	1	Học phần "Bóng rổ 1" trang bị cho sinh viên những kiến thức cơ bản về môn bóng rổ, bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu khái quát về lịch sử hình thành và phát triển của bóng rổ, các kỹ thuật cơ bản, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, các kỹ thuật chuyền bắt bóng cơ bản trong bóng rổ, kỹ thuật ném rổ, kỹ thuật dẫn bóng, phối hợp bước dân di chuyển thường sử dụng trong môn này. Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng rổ.
71	PHT308	Bóng rổ 2	2	0	0	0	0	1	Học phần được xây dựng nhằm nâng cao kỹ năng thực hành, tư duy chiến thuật và thể lực chuyên môn cho sinh viên, dựa trên nền tảng kiến thức từ học phần Bóng rổ 1. Củng cố và phát triển các kỹ thuật cá nhân, giúp sinh viên nắm vững và vận dụng các chiến thuật thi đấu cơ bản (phối hợp nhóm, tấn công-phòng ngự cá nhân/khu vực), hiểu rõ mối liên hệ giữa kỹ thuật, chiến thuật và thể lực, đồng thời áp dụng kiến thức vào tập luyện, thi đấu thực tế để nâng cao sức khỏe, ý thức kỷ luật và tinh thần đồng đội.
72	PHT309	Bóng rổ 3	1	0	0	0	0	1	Học phần được thiết kế nhằm hoàn thiện các kỹ thuật và kỹ năng bóng rổ nâng cao cho sinh viên, phục vụ cho việc tập luyện và thi đấu. Bên cạnh đó, học phần còn hướng đến việc tạo hứng thú, nâng cao sức khỏe thể chất và tinh thần, đồng thời củng cố kiến thức về vệ sinh và phòng tránh chấn thương trong thể thao
73	PHT310	Thể hình - Thẩm mỹ 1	2	0	0	0	0	1	Học phần Thể hình – Thẩm mỹ 1 cung cấp kiến thức lý thuyết và thực hành cơ bản về Gym – Fitness, giúp sinh viên hiểu về lịch sử, nguyên lý phát triển cơ bắp, phân loại nhóm cơ, kỹ thuật tập luyện và dinh dưỡng phù hợp. Phần thực hành rèn luyện thể lực và kỹ năng sử dụng máy móc, tập đúng kỹ thuật với 6 nhóm cơ chính. Qua học phần, sinh viên nâng cao thể lực, cải thiện vóc dáng và có khả năng tự xây dựng chương trình tập luyện phù hợp với mục tiêu cá nhân
74	PHT311	Thể hình - Thẩm mỹ 2	2	0	0	0	0	1	Học phần Thể hình – Thẩm mỹ 2 giúp sinh viên ôn tập kiến thức về dinh dưỡng, chỉ số BMI – TDEE, nguyên lý phát triển cơ bắp, luật thi đấu và an toàn tập luyện. Phần thực hành tập trung vào nâng cao thể lực, sử dụng thành thạo thiết bị, hoàn thiện kỹ thuật và xây dựng kế hoạch tập luyện cá nhân, từ đó hình thành ý thức tự giác và lan tỏa tinh thần thể thao tích cực.
75	PHT312	Thể hình - Thẩm mỹ 3	1	0	0	0	0	1	Học phần Thể hình – Thẩm mỹ 3 trang bị cho sinh viên kỹ thuật và phương pháp tập luyện nâng cao, bao gồm các phương pháp huấn luyện lặp lại, vòng tròn và các bài tập chuyên sâu tác động hiệu quả lên từng nhóm cơ, tối ưu hóa sự phát triển cơ bắp. Trang bị kiến thức về dinh dưỡng hồi phục và cách tự thiết kế thực đơn ăn uống phù hợp
76	PHT313	Vovinam 1	2	0	0	0	0	1	Học phần Vovinam 1 trang bị cho sinh viên những kiến thức cơ bản và nền tảng về môn võ Vovinam – Việt Võ Đạo. Giới thiệu khái quát về lịch sử hình thành và phát triển của Vovinam, trình bày các nguyên lý, khái niệm và giá trị võ đạo như lối nghiêm lễ, khái niệm “Vovinam là gì”, Mười điều tâm niệm, điều sơ khởi về kỷ luật, quan niệm dụng võ, hệ thống cấp đai, màu đai. Hướng dẫn và rèn luyện các kỹ thuật cơ bản như tấn, gạt, đấm, chém, chỏ, gối và các đòn đá, giúp hình thành kỹ năng thực chiến bước đầu
77	PHT314	Vovinam 2	2	0	0	0	0	1	Học phần Vovinam 2 trang bị sinh viên kiến thức hoàn thiện hơn về môn võ Vovinam.  Hiểu được luật thi đấu, danh dự người võ sĩ, cách rèn luyện tinh thần, khái niệm võ thuật – võ đạo, mục đích tôn chỉ người học võ, cách huấn luyện người học về võ lực – võ thuật – võ đạo, khả năng phối hợp cưng nhu, tác phong người học cần tránh những điều xấu và làm những điều tốt nào, cũng như đi sâu vào môn võ Vovinam khả năng phân tích chiến lược, bài quyền để hiểu hơn về môn võ này. Rèn luyện khả năng di chuyển và phối hợp động tác liên hoàn, thông qua tập luyện các động tác chiến lược từ 1 -5 và bài “Nhập môn quyền”.
78	PHT315	Vovinam 3	1	0	0	0	0	1	Học phần Vovinam 3 trang bị cho sinh viên các kỹ thuật nâng cao, bao gồm khả năng phản xạ, né đỡ đòn và phản đòn hiệu quả. Sinh viên sẽ được huấn luyện các chiến lược tự vệ từ cấp độ 6 đến 10, cùng với các kỹ thuật khóa gỡ trong các tình huống tấn công như ôm, nắm tóc và bóp cổ, giúp nâng cao kỹ năng tự vệ trong thực tiễn
79	PHT316	Bóng đá 1	2	0	0	0	0	1	Học phần "Bóng đá 1" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu khái quát về lịch sử hình thành và phát triển của bóng đá, các kỹ thuật cơ bản, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, tâng bóng, kéo bóng, kỹ thuật đá bóng bằng các phần khác nhau của bàn chân (lòng bàn chân, mu trong, mu giữa), kỹ thuật nhận bóng bằng gan bàn chân, dẫn bóng và đánh đầu bằng trán giữa. Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá .
80	PHT317	Bóng đá 2	2	0	0	0	0	1	Học phần "Bóng đá 2" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu về chiến thuật bóng đá , các chấn thương và phương pháp điều trị chấn thương trong tập luyện và thi đấu, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, kỹ thuật đá bóng bằng mũi bàn chân, các chiến thuật  cơ bản ( Chiến thuật tấn công và phòng ngự 2x1, chiến thuật tấn công và phòng ngự với quả đá biên), phát triển thể lực ( sức mạnh – tốc độ). Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá
81	PHT318	Bóng đá 3	1	0	0	0	0	1	Học phần "Bóng đá 3" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu về đội hình chiến thuật, chiến thuật  cơ bản (Chiến thuật tấn công và phòng ngự 3x2, chiến thuật tấn công và phòng ngự với quả phạt góc), phát triển thể lực (sức bền tốc độ). Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá .
82	NDF108	Quốc phòng, an ninh 1	0	0	0	0	0	1	Học phần gồm 11 chủ đề trong đó giới thiệu về đối tượng và phương pháp nghiên cứu bộ môn quốc phòng – an ninh nói chung; trình bày quan điểm Chủ nghĩa Mác –Lênin, tư tưởng Hồ Chí Minh về chiến tranh, quân đội và bảo vệ Tổ quốc XHCN; xây dựng lực lượng vũ trang nhân dân; xây dựng và bảo vệ chủ quyền biển, đảo, biên giới quốc gia trong tình hình mới; xây dựng lực lượng dân quân tự vệ, lực lượng dự bị động viên và động viên quốc phòng; xây dựng phong trào toàn dân bảo vệ an ninh Tổ quốc; những vấn đề cơ bản về bảo vệ an ninh quốc gia và bảo đảm trật tự an toàn xã hội; về kết hợp phát triển kinh tế với tăng cường quốc phòng an ninh, đối ngoại và một số nôi dung về lịch sử nghệ thuật quân sự Việt Nam.
17	POS104	Triết học Mác - Lênin	3	3	0	0	0	1	Triết học Mác – Lê nin là học phần bắt buộc trong khối kiến thức cơ bản nhằm trang bị các kiến thức cơ bản về triết học học Mác – Lênin, học phần được cấu trúc gồm: (i) Trình bày những nét khái quát về triết học, triết học Mác – Lênin trong đời sống xã hội; (ii) Trình bày những nội dung cơ bản của chủ nghĩa duy vật biện chứng như: vật chất và ý thức; phép biện chứng duy vật; lý luận nhận thức của chủ nghĩa duy vật biện chứng; (iii) Trình bày những nội dung cơ bản của chủ nghĩa duy vật lịch sử, gồm vấn đề hình thái kinh tế - xã hội; giai cấp và dân tộc; nhà nước và cách mạng xã hội; ý thức xã hội; triết học về con người, quần chúng nhân dân.
18	POS105	Kinh tế chính trị Mác - Lênin	2	2	0	0	0	1	Nội dung học phần gồm 6 bài trong đó:Bài 1: Bàn về đối tượng, phương pháp nghiên cứu và chức năng của Kinh tế chính trị Mác – Lênin. Từ bài 2 đến bài 6 trình bày nội dung cốt lõi của kinh tế chính trị Mác – Lênin theo mục tiêu môn học. Cụ thể các vấn đề như: Hàng hóa, thị trường và vai trò của các chủ thể trong nền kinh tế thị trường; Giá trị thặng dư và quan hệ lợi ích trong nền kinh tế thị trường; Cạnh tranh và độc quyền trong nền kinh tế thị trường; Kinh tế thị trường định hướng XHCN ở Việt Nam; Cách mạng công nghiệp và hội nhập kinh tế quốc tế trong phát triển của Việt Nam
83	NDF109	Quốc phòng, an ninh 2	0	0	0	0	0	1	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Nội dung của học phần gồm: Đấu tranh phòng chống chiến lược “Diễn biến hòa bình” bạo loạn lật đổ của các thế lực thù địch; một số vấn đề về dân tộc, tôn giáo; bảo vệ môi trường; an toàn giao thông; bảo vệ danh dự, nhân phẩm con người; an toàn thông tin; phòng ngừa, ứng phó với các mối đe dọa an ninh phi truyền thống.
84	NDF210	Quốc phòng, an ninh 3	0	0	0	0	0	1	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Nội dung của học phần gồm 9 chủ đề: chế độ sinh hoạt, học tập, công tác trong ngày, trong tuần; các chế độ nền nếp chính quy, bố trí trật tự nội vụ trong doanh trại; hiểu biết chung về các quân, binh chủng trong quân đội nhân dân Việt Nam; điều lệnh đội ngũ từng người có súng; điều lệnh đội ngũ đơn vị; hiểu biết chung về bản đồ địa hình quân sự; phòng tránh địch tiến công hỏa lực bằng vũ khí công nghệ cao; ba môn quân sự phối hợp, phòng cháy chữa cháy và cứu hộ cứu nạn.
85	NDF211	Quốc phòng, an ninh 4	0	0	0	0	0	1	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Học phần trang bị những kiến thức cơ bản về kỹ thuật chiến đấu bộ binh và chiến thuật, gồm 5 chủ đề: kỹ thuật bắn súng tiểu liên AK; tính năng, cấu tạo và cách sử dụng một số loại lựu đạn thường dùng; từng người trong chiến đấu tiến công; từng người trong chiến đấu phòng ngự và từng người làm nhiệm vụ canh gác, cảnh giới.
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.departments (id, parent_id, code, name, type, created_at) FROM stdin;
1	\N	HUTECH	Trường Đại học Công nghệ TP.HCM	ROOT	2026-03-25 09:16:56.878689+00
2	1	BGH	Ban Giám Hiệu	PHONG	2026-03-25 09:16:56.881487+00
3	1	PDT	Phòng Đào tạo	PHONG	2026-03-25 09:16:56.882609+00
4	1	K.TQH	Khoa Trung Quốc học	KHOA	2026-03-25 09:16:56.883438+00
5	1	K.CNTT	Khoa CNTT	KHOA	2026-03-25 09:16:56.884207+00
6	1	K.TA	Khoa Tiếng Anh	KHOA	2026-03-25 09:16:56.885036+00
7	1	K.QTKD	Khoa QTKD	KHOA	2026-03-25 09:16:56.886048+00
8	1	K.LUAT	Khoa Luật	KHOA	2026-03-25 09:16:56.886819+00
9	1	K.NBH	Khoa Nhật Bản học	KHOA	2026-03-25 09:16:56.887563+00
10	1	VJIT	Viện CNTT Việt-Nhật	VIEN	2026-03-25 09:16:56.888228+00
11	1	V.KHUD	Viện Khoa học ứng dụng	VIEN	2026-03-25 09:16:56.888943+00
12	1	TT.GDTC	TT Giáo dục Thể chất	TRUNG_TAM	2026-03-25 09:16:56.889591+00
13	1	TT.GDCT-QP	TT Giáo dục CT-QP	TRUNG_TAM	2026-03-25 09:16:56.890319+00
14	1	TT.TH-NN-KN	TT Tin học-NN-KN	TRUNG_TAM	2026-03-25 09:16:56.89095+00
15	5	N.CNPM	Ngành Công nghệ phần mềm	BO_MON	2026-03-25 09:16:56.891551+00
16	5	N.HTTT	Ngành Hệ thống thông tin	BO_MON	2026-03-25 09:16:56.892137+00
17	5	N.KTPM	Ngành Kỹ thuật phần mềm	BO_MON	2026-03-25 09:16:56.892764+00
18	5	N.TTNT	Ngành Trí tuệ nhân tạo	BO_MON	2026-03-25 09:16:56.893387+00
19	7	N.TMDT	Ngành Thương mại điện tử	BO_MON	2026-03-25 09:16:56.894017+00
20	7	N.QTKD-TH	Ngành Quản trị kinh doanh tổng hợp	BO_MON	2026-03-25 09:16:56.894619+00
21	6	N.TACN	Ngành Tiếng Anh chuyên ngành	BO_MON	2026-03-25 09:16:56.89522+00
22	6	N.TATM	Ngành Tiếng Anh thương mại	BO_MON	2026-03-25 09:16:56.895821+00
\.


--
-- Data for Name: knowledge_blocks; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.knowledge_blocks (id, version_id, name, parent_id, total_credits, required_credits, elective_credits, sort_order) FROM stdin;
1	1	Kiến thức giáo dục đại cương	\N	12	12	0	1
2	1	Lý luận chính trị	1	3	3	0	2
3	1	Ngoại ngữ	1	3	3	0	3
4	1	Toán & Khoa học tự nhiên	1	6	6	0	4
5	1	Kiến thức giáo dục chuyên nghiệp	\N	48	42	6	5
6	1	Cơ sở ngành	5	15	15	0	6
7	1	Chuyên ngành	5	18	12	6	7
8	1	Thực tập & Đồ án	5	6	6	0	8
33	4	Kiến thức giáo dục đại cương	\N	44	44	0	1
34	4	Lý luận chính trị	33	11	11	0	2
35	4	Ngoại ngữ	33	12	12	0	3
36	4	Pháp luật	33	3	3	0	4
37	4	Trí tuệ nhân tạo ứng dụng	33	3	3	0	5
38	4	Phát triển bền vững	33	3	3	0	6
39	4	Tư duy thiết kế dự án	33	3	3	0	7
40	4	Khoa học tự nhiên, khoa học xã hội và nhân văn khác	33	9	9	0	8
41	4	Kiến thức giáo dục chuyên nghiệp	\N	81	72	9	9
42	4	Kiến thức không tích luỹ	41	5	0	5	10
43	4	Giáo dục thể chất	41	5	0	5	11
44	4	Giáo dục quốc phòng và an ninh	41	0	0	0	12
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.permissions (id, code, module, description) FROM stdin;
1	programs.view_published	programs	Xem CTĐT đã công bố
2	programs.view_draft	programs	Xem CTĐT bản nháp
3	programs.create	programs	Tạo mới CTĐT
4	programs.edit	programs	Chỉnh sửa CTĐT
5	programs.delete_draft	programs	Xóa CTĐT bản nháp
6	programs.submit	programs	Nộp CTĐT để phê duyệt
7	programs.approve_khoa	programs	Duyệt CTĐT cấp Khoa
8	programs.approve_pdt	programs	Duyệt CTĐT cấp Phòng ĐT
9	programs.approve_bgh	programs	Phê duyệt CTĐT cấp BGH
10	programs.export	programs	Xuất báo cáo CTĐT
11	programs.import_word	programs	Import CTĐT từ Word
12	programs.manage_all	programs	Quản lý CTĐT toàn trường
13	programs.create_version	programs	Tạo phiên bản CTĐT mới
14	programs.po.edit	programs_granular	Chỉnh sửa Mục tiêu PO
15	programs.plo.edit	programs_granular	Chỉnh sửa Chuẩn đầu ra PLO & PI
16	programs.courses.edit	programs_granular	Chỉnh sửa Học phần & Kế hoạch GD
17	programs.matrix.edit	programs_granular	Chỉnh sửa Ma trận liên kết (PO-PLO, HP-PLO)
18	programs.assessment.edit	programs_granular	Chỉnh sửa Đánh giá CĐR
19	syllabus.view	syllabus	Xem đề cương đã công bố
20	syllabus.create	syllabus	Tạo đề cương
21	syllabus.edit	syllabus	Chỉnh sửa đề cương
22	syllabus.submit	syllabus	Nộp đề cương để phê duyệt
23	syllabus.approve_tbm	syllabus	Duyệt cấp Trưởng BM
24	syllabus.approve_khoa	syllabus	Duyệt cấp Trưởng Khoa
25	syllabus.approve_pdt	syllabus	Duyệt cấp Phòng ĐT
26	syllabus.approve_bgh	syllabus	Phê duyệt cấp BGH
27	syllabus.assign	syllabus	Phân công GV soạn đề cương
28	courses.view	courses	Xem danh mục học phần
29	courses.create	courses	Tạo học phần mới
30	courses.edit	courses	Chỉnh sửa học phần
\.


--
-- Data for Name: plo_pis; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.plo_pis (id, plo_id, pi_code, description) FROM stdin;
1	1	PI1.1	Giải các bài toán tối ưu và xác suất thống kê trong CNTT
2	1	PI1.2	Áp dụng cấu trúc dữ liệu và giải thuật phù hợp cho bài toán
3	2	PI2.1	Phân tích yêu cầu chức năng và phi chức năng của hệ thống
4	2	PI2.2	Thiết kế kiến trúc hệ thống theo mô hình phân lớp
5	3	PI3.1	Viết mã nguồn sạch, có cấu trúc theo chuẩn coding convention
6	4	PI4.1	Thiết kế lược đồ CSDL chuẩn hóa đến 3NF
7	5	PI5.1	Trình bày ý tưởng kỹ thuật rõ ràng trước nhóm và khách hàng
8	6	PI6.1	Đánh giá ưu nhược điểm của công nghệ mới so với giải pháp hiện tại
51	21	PI.1.1	Nhận biếtcác vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc.
52	21	PI.1.2	Xây dựng phương án để giải quyết các vấn đề về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc.
53	21	PI.1.3	Kết hợp các kiến thức cơ bản, kiến thức chuyên ngành để đóng góp hữu hiệu vào sự phát triển bền vững của xã hội, cộng đồng.
54	22	PI.2.1	Nhận biếtcác thành phần cấu tạo nên ngôn ngữ Trung Quốc.
55	22	PI.2.2	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc.
56	22	PI.2.3	Sử dụng thành thạo4 kỹ năng tiếng Trungtương đương bậc 5 theo Khung năng lực ngoại ngữ Việt Nam.
57	23	PI.3.1	Sử dụng ngoại ngữ 2 tiếng Anh để nâng cao cơ hội việc làm và hiểu biết thêm về các nền văn hóa khác.
58	24	PI.4.1	Áp dụng thành thạo tiếng Trung vào công việc.
59	24	PI.4.2	Nhận biết chữ Hán phồn thểvà thành thạo chữ Hán giản thểtrong côngviệc.
60	24	PI.4.3	Khai thác thông tin và cập nhật kiến thức chuyên ngành thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c)phương pháp giảng dạy, hoặc (d)khóa luận tốt nghiệp.
61	25	PI.5.1	Phân tích thông tin, đưa ra luận điểm có căn cứ.
62	25	PI.5.2	Hệ thống lại vấn đề, đưa ra kết luận về cách thức vận hành của vấn đề hệ thống.
63	25	PI.5.3	Lập kế hoạch, thực hiện và đánh giá công việc chuyên môn.
64	26	PI.6.1	Sử dụng tốt các chiến lược giao tiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.
65	26	PI.6.2	Áp dụng thành thạo kỹ năng giao tiếp ứng xử cần thiết để thực hiện các nhiệm vụ phức tạp.
66	26	PI.6.3	Sử dụng Word, Excel, Powerpoint ….soạn thảo, trình bày các loại văn bản  trong học tập, nghiên cứu và công việc có hiệu quả.
67	26	PI.6.4	Sử dụng có hiệu quả các phần mềm chuyên dụng để phục vụ học tập và công việc chuyên môn liên quan đến tiếng Trung.
68	27	PI.7.1	Đưa ra các nhận định cá nhân trong điều kiện làm việc thay đổi
69	27	PI.7.2	Xác định được đầy đủ mục tiêu của nhóm, vai trò, trách nhiệm của các thành viên
70	27	PI.7.3	Tham gia hoạch định, lên chương trình và phối hợp trong thực hiện hoạt động nhóm đạt được mục tiêu đã đềra.
71	27	PI.7.4	Nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.
\.


--
-- Data for Name: po_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.po_plo_map (version_id, po_id, plo_id) FROM stdin;
1	1	1
1	1	2
1	1	3
1	1	4
1	2	2
1	2	3
1	2	6
1	3	5
1	3	6
4	12	21
4	12	23
4	12	25
4	12	27
4	13	22
4	13	24
4	13	26
4	14	22
4	14	24
4	14	26
4	15	21
4	15	23
4	15	25
4	15	27
\.


--
-- Data for Name: program_versions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.program_versions (id, program_id, academic_year, version_name, status, is_locked, copied_from_id, completion_pct, total_credits, training_duration, change_type, effective_date, change_summary, grading_scale, graduation_requirements, job_positions, further_education, reference_programs, training_process, admission_targets, admission_criteria, created_at, updated_at, is_rejected, rejection_reason, general_objective) FROM stdin;
1	1	2025-2026	CTĐT CNTT 2025-2026	draft	f	\N	0	130	4 năm	\N	\N	\N	Thang điểm 10 quy đổi sang thang 4 và xếp loại A/B/C/D/F	Hoàn thành tối thiểu 130 TC, đạt chuẩn ngoại ngữ, không nợ học phí	Lập trình viên, Kỹ sư phần mềm, Quản trị mạng, Chuyên viên CNTT, Tư vấn giải pháp CNTT	Thạc sĩ CNTT, Thạc sĩ Khoa học máy tính, MBA chuyên ngành CNTT	\N	Đào tạo theo hệ thống tín chỉ, kết hợp lý thuyết và thực hành	\N	\N	2026-03-25 09:16:57.047572+00	2026-03-25 09:16:57.047572+00	f	\N	Đào tạo kỹ sư CNTT có năng lực chuyên môn, tư duy sáng tạo, đạo đức nghề nghiệp, đáp ứng nhu cầu xã hội và hội nhập quốc tế.
4	4	2026	\N	draft	f	\N	0	125	3.5 năm	\N	\N	\N	Theo Quy chế/Quy định của Bộ GD&ĐT và Quy chế học vụ hiện hành của Trường Đại học Công nghệ TP.HCM.	Theo Quy chế/Quy định của Bộ GD&ĐT và Quy chế học vụ hiện hành của Trường Đại học Công nghệ TP.HCM.	Biên - phiên dịch viên: Làm việc tại các công ty Đài Loan, Trung Quốc, các doanh nghiệp đa quốc gia, hoặc các tổ chức quốc tế.Chuyên viên đối ngoại: Phụ trách giao tiếp và hợp tác quốc tế tại các doanh nghiệp, nhà xuất bản hoặc các cơ quan truyền thông.Chuyên viên trong lĩnh vực thương mại và dịch vụ: Hoạt động trong lĩnh vực marketing, tổ chức sự kiện, hoặc ngành du lịch như hướng dẫn viên du lịch chuyên nghiệp.Giáo viên tiếng Trung: Giảng dạy tại các trung tâm ngoại ngữ, trường học hoặc các cơ sở đào tạo	Tiếp tục học tập ở bậc sau đại học (thạc sĩ, tiến sĩ) tại các trường đại học trong và ngoài nước với chuyên ngành liên quan.Tham gia các khóa học ngắn hạn, chương trình bồi dưỡng chuyên sâu để nâng cao kiến thức và kỹ năng chuyên môn.Nghiên cứu và phát triển các lĩnh vực liên quan đến ngôn ngữ, văn hóa Trung Hoa và ứng dụng trong các ngành nghề	- Đại học KHXHNV-ĐHQG TP.HCM:https://hcmussh.edu.vn- Đại học Ngoại ngữ - Tin học TP. Hồ Chí Minh (HUFLIT):https://huflit.edu.vn/- Nanyang Technological University:https://www.ntu.edu.sg- Lingnan University:https://www.ln.edu.hk	Quy trình đào tạo được thực hiện qua 4 bước: (1) Xác định nhu cầu đào tạo; (2) Lập kế hoạch đào tạo; (3) Thực hiện đào tạo; (4) Đánh giá đào tạo.	Người học phải tốt nghiệp trung học phổ thông hoặc trình độ tương đương.	Theo Quy chế tuyển sinh hiện hành của Bộ GD&ĐT và Đề án tuyển sinh của Trường Đại học Công nghệ TP.HCM.	2026-03-25 11:40:39.636627+00	2026-03-25 11:40:39.636627+00	f	\N	Đào tạo cử nhân ngành Ngôn ngữ Trung Quốc có phẩm chất chính trị, đạo đức, có kiến thức toàn diện về văn hóa, khoa học xã hội và tự nhiên; có năng lực sử dụng tiếng Trung ở trình độ cao để giao tiếp hiệu quả trong các bối cảnh khác nhau; có kiến thức chuyên ngành và kỹ năng mềm đáp ứng nhu cầu phát triển kinh tế - xã hội và hội nhập quốc tế.
\.


--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.programs (id, department_id, name, name_en, code, degree, total_credits, institution, degree_name, training_mode, notes, created_at) FROM stdin;
1	15	Công nghệ thông tin	Information Technology	7480201	Đại học	130	Trường Đại học Công nghệ TP.HCM	Cử nhân Công nghệ thông tin	Chính quy	\N	2026-03-25 09:16:57.046839+00
4	15	Ngôn ngữ Trung Quốc	Chinese Language	7220204	Cử nhân Ngôn ngữ Trung Quốc	125	Trường Đại học Công nghệ TP.HCM	\N	Chính quy	\N	2026-03-25 11:40:39.636627+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	1
1	19
1	20
1	21
1	22
1	28
2	1
2	2
2	19
2	23
2	27
2	28
3	1
3	2
3	3
3	4
3	5
3	6
3	7
3	10
3	11
3	14
3	15
3	16
3	17
3	18
3	19
3	20
3	21
3	22
3	24
3	27
3	28
4	1
4	2
4	3
4	4
4	5
4	8
4	10
4	11
4	12
4	13
4	14
4	15
4	16
4	17
4	18
4	19
4	20
4	21
4	25
4	27
4	28
4	29
4	30
5	1
5	2
5	9
5	10
5	19
5	26
5	27
5	28
6	1
6	2
6	5
6	12
6	13
6	14
6	15
6	16
6	17
6	18
6	19
6	28
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.roles (id, code, name, level, is_system) FROM stdin;
1	GIANG_VIEN	Giảng viên	1	t
2	TRUONG_NGANH	Trưởng ngành / Trưởng BM	2	t
3	LANH_DAO_KHOA	Lãnh đạo Khoa/Viện/TT	3	t
4	PHONG_DAO_TAO	Phòng Đào tạo	4	t
5	BAN_GIAM_HIEU	Ban Giám Hiệu	5	t
6	ADMIN	Quản trị hệ thống	99	t
\.


--
-- Data for Name: syllabus_assignments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.syllabus_assignments (id, version_id, course_id, assigned_to, assigned_by, assigner_role_level, deadline, notes, created_at, updated_at) FROM stdin;
1	1	11	2	1	99	2026-03-31	\N	2026-03-25 16:01:29.092888+00	2026-03-25 16:01:29.092888+00
2	4	26	2	1	99	\N	\N	2026-03-25 16:34:20.651224+00	2026-03-25 16:34:20.651224+00
\.


--
-- Data for Name: teaching_plan; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.teaching_plan (id, version_course_id, total_hours, hours_theory, hours_practice, hours_project, hours_internship, software, managing_dept, batch, notes) FROM stdin;
1	5	45	30	15	0	0	\N	K.CNTT	A	\N
2	6	45	30	15	0	0	\N	K.CNTT	A	\N
3	8	45	30	15	0	0	MySQL Workbench	K.CNTT	B	\N
4	7	45	30	15	0	0	IntelliJ IDEA	K.CNTT	A	\N
5	9	45	30	15	0	0	Cisco Packet Tracer	K.CNTT	B	\N
6	10	45	30	15	0	0	Jira, Draw.io	K.CNTT	A	\N
7	11	45	15	30	0	0	VS Code, Node.js	K.CNTT	B	\N
8	12	45	30	15	0	0	Python, Jupyter	K.CNTT	A	\N
9	15	90	0	0	90	0	\N	K.CNTT	A	\N
10	16	135	0	0	0	135	\N	K.CNTT	B	\N
149	160	45	45	0	0	0	\N	K.TA	B	\N
150	171	45	45	0	0	0	\N	K.TQH	A	\N
151	176	45	45	0	0	0	\N	K.TQH	A	\N
152	181	45	45	0	0	0	\N	K.TQH	B	\N
153	186	45	45	0	0	0	\N	K.TQH	B	\N
154	164	45	45	0	0	0	\N	K.CNTT	A	\N
155	220	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
156	221	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
157	161	45	45	0	0	0	\N	K.TA	B	\N
158	167	45	45	0	0	0	\N	VJIT	B	\N
159	172	45	45	0	0	0	\N	K.TQH	A	\N
160	177	45	45	0	0	0	\N	K.TQH	A	\N
161	182	45	45	0	0	0	\N	K.TQH	B	\N
162	187	45	45	0	0	0	\N	K.TQH	B	\N
163	222	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
164	223	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
165	205	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
166	208	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
167	211	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
168	214	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
169	217	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
170	162	45	45	0	0	0	\N	K.TA	B	\N
171	173	45	45	0	0	0	\N	K.TQH	A	\N
172	178	45	45	0	0	0	\N	K.TQH	A	\N
173	183	45	45	0	0	0	\N	K.TQH	B	\N
174	188	45	45	0	0	0	\N	K.TQH	B	\N
175	155	45	45	0	0	0	\N	TT.GDCT-QP	A	\N
176	206	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
177	209	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
178	212	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
179	215	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
180	218	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
181	163	45	45	0	0	0	\N	K.TA	B	\N
182	165	45	45	0	0	0	\N	V.KHUD	A	\N
183	174	45	45	0	0	0	\N	K.TQH	A	\N
184	179	45	45	0	0	0	\N	K.TQH	A	\N
185	184	45	45	0	0	0	\N	K.TQH	B	\N
186	189	45	45	0	0	0	\N	K.TQH	B	\N
187	207	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
188	210	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
189	213	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
190	216	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
191	219	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
192	158	30	30	0	0	0	\N	TT.GDCT-QP	A	\N
193	156	30	30	0	0	0	\N	TT.GDCT-QP	B	\N
194	169	45	45	0	0	0	\N	K.NBH	A	\N
195	175	45	45	0	0	0	\N	K.TQH	A	\N
196	180	45	45	0	0	0	\N	K.TQH	A	\N
197	185	45	45	0	0	0	\N	K.TQH	B	\N
198	190	45	45	0	0	0	\N	K.TQH	B	\N
199	191	45	45	0	0	0	\N	K.TQH	B	\N
200	159	30	30	0	0	0	\N	TT.GDCT-QP	B	\N
201	157	30	30	0	0	0	\N	TT.GDCT-QP	A	\N
202	193	135	0	0	0	135	\N	K.TQH	B	\N
203	195	45	45	0	0	0	\N	K.TQH	A	\N
204	196	45	45	0	0	0	\N	K.TQH	A	\N
205	197	45	45	0	0	0	\N	K.TQH	B	\N
206	198	45	45	0	0	0	\N	K.TQH	A	\N
207	199	45	45	0	0	0	\N	K.TQH	A	\N
208	200	45	45	0	0	0	\N	K.TQH	B	\N
209	201	45	45	0	0	0	\N	K.TQH	A	\N
210	202	45	45	0	0	0	\N	K.TQH	A	\N
211	203	45	45	0	0	0	\N	K.TQH	B	\N
212	204	405	0	0	405	0	\N	K.TQH	\N	\N
213	168	45	45	0	0	0	\N	K.QTKD	A	\N
214	166	45	45	0	0	0	\N	K.LUAT	A	\N
215	170	45	45	0	0	0	\N	TT.TH-NN-KN	A	\N
216	192	45	45	0	0	0	\N	K.TQH	A	\N
217	194	135	0	0	0	135	\N	K.TQH	B	\N
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.user_roles (id, user_id, role_id, department_id) FROM stdin;
1	1	6	1
2	2	1	15
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.users (id, username, password_hash, display_name, email, is_active, created_at) FROM stdin;
1	admin	$2a$10$yKZNOXJ.bh0rQGDipu5i4.6IraQmwnv1TcThTgCVeXRGEkVuOf62q	Quản trị viên	\N	t	2026-03-25 09:16:57.043389+00
2	giangvien	$2a$10$l49IYdxPJNMHqB2ZB0pR9uOSOhu1uP5is0gDgSZwGX6iBJSRb8GFu	Huy	test@gmail.com	t	2026-03-25 09:27:04.500412+00
\.


--
-- Data for Name: version_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_courses (id, version_id, course_id, semester, course_type, prerequisite_course_ids, corequisite_course_ids, elective_group) FROM stdin;
1	1	11	1	required	\N	\N	\N
2	1	12	1	required	\N	\N	\N
3	1	13	1	required	\N	\N	\N
4	1	14	1	required	\N	\N	\N
5	1	1	1	required	\N	\N	\N
6	1	2	2	required	\N	\N	\N
7	1	4	2	required	\N	\N	\N
8	1	3	3	required	\N	\N	\N
9	1	5	3	required	\N	\N	\N
10	1	6	4	required	\N	\N	\N
11	1	7	4	required	\N	\N	\N
12	1	8	5	required	\N	\N	\N
13	1	15	5	elective	\N	\N	An toàn & Đám mây
14	1	16	5	elective	\N	\N	An toàn & Đám mây
15	1	9	6	required	\N	\N	\N
16	1	10	7	required	\N	\N	\N
155	4	17	3	required	\N	\N	\N
156	4	18	5	required	\N	\N	\N
157	4	19	6	required	\N	\N	\N
158	4	20	5	required	\N	\N	\N
159	4	21	6	required	\N	\N	\N
160	4	22	1	required	\N	\N	\N
164	4	26	1	required	\N	\N	\N
165	4	27	4	required	\N	\N	\N
166	4	28	7	required	\N	\N	\N
167	4	29	2	required	\N	\N	\N
168	4	30	7	required	\N	\N	\N
169	4	31	5	required	\N	\N	\N
170	4	32	7	required	\N	\N	\N
171	4	33	1	required	\N	\N	\N
172	4	34	2	required	\N	\N	\N
173	4	35	3	required	\N	\N	\N
174	4	36	4	required	\N	\N	\N
175	4	37	5	required	\N	\N	\N
176	4	38	1	required	\N	\N	\N
177	4	39	2	required	\N	\N	\N
178	4	40	3	required	\N	\N	\N
179	4	41	4	required	\N	\N	\N
180	4	42	5	required	\N	\N	\N
181	4	43	1	required	\N	\N	\N
182	4	44	2	required	\N	\N	\N
183	4	45	3	required	\N	\N	\N
184	4	46	4	required	\N	\N	\N
185	4	47	5	required	\N	\N	\N
186	4	48	1	required	\N	\N	\N
187	4	49	2	required	\N	\N	\N
188	4	50	3	required	\N	\N	\N
189	4	51	4	required	\N	\N	\N
190	4	52	5	required	\N	\N	\N
191	4	53	6	required	\N	\N	\N
192	4	54	7	required	\N	\N	\N
193	4	55	6	required	\N	\N	\N
194	4	56	7	required	\N	\N	\N
195	4	57	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại
196	4	58	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại
197	4	59	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại
198	4	60	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung
199	4	61	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung
200	4	62	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung
201	4	63	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung
202	4	64	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung
203	4	65	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung
204	4	66	6	elective	\N	\N	Nhóm 4:Khóa luận tốt nghiệp
205	4	67	2	non_accumulative	\N	\N	Nhóm 1
206	4	68	3	non_accumulative	\N	\N	Nhóm 1
207	4	69	4	non_accumulative	\N	\N	Nhóm 1
208	4	70	2	non_accumulative	\N	\N	Nhóm 2
209	4	71	3	non_accumulative	\N	\N	Nhóm 2
210	4	72	4	non_accumulative	\N	\N	Nhóm 2
211	4	73	2	non_accumulative	\N	\N	Nhóm 3
212	4	74	3	non_accumulative	\N	\N	Nhóm 3
213	4	75	4	non_accumulative	\N	\N	Nhóm 3
214	4	76	2	non_accumulative	\N	\N	Nhóm 4
215	4	77	3	non_accumulative	\N	\N	Nhóm 4
216	4	78	4	non_accumulative	\N	\N	Nhóm 4
217	4	79	2	non_accumulative	\N	\N	Nhóm 5
218	4	80	3	non_accumulative	\N	\N	Nhóm 5
219	4	81	4	non_accumulative	\N	\N	Nhóm 5
220	4	82	1	non_accumulative	\N	\N	\N
221	4	83	1	non_accumulative	\N	\N	\N
222	4	84	2	non_accumulative	\N	\N	\N
223	4	85	2	non_accumulative	\N	\N	\N
161	4	23	2	required	{160}	\N	\N
162	4	24	3	required	{161}	\N	\N
163	4	25	4	required	{162}	\N	\N
\.


--
-- Data for Name: version_objectives; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_objectives (id, version_id, code, description) FROM stdin;
1	1	PO1	Vận dụng kiến thức nền tảng CNTT để phân tích, thiết kế và phát triển phần mềm
2	1	PO2	Áp dụng quy trình phát triển phần mềm chuyên nghiệp và công nghệ hiện đại
3	1	PO3	Có năng lực làm việc nhóm, giao tiếp hiệu quả và phát triển nghề nghiệp liên tục
12	4	PO1	Ứng dụng kiến thức: Vận dụng kiến thức vềvăn hóa, xãhội, chính trị, luật pháp, ngôn ngữ, vàcông nghệthông tin vào thực tiễn công việc vàcuộc sống. Cókhảnăng tựnghiên cứu, cập nhật kiến thức mới.
13	4	PO2	Năng lực tiếng Trung: Sửdụng thành thạo 4 kỹnăng Nghe, Nói,Đọc, Viết tiếng Trungởtrìnhđộcao.
14	4	PO3	Kỹnăng chuyên ngành: Vận dụng kiến thức vàkỹnăng chuyên ngành (biên phiên dịch/ thương mại/phương pháp giảng dạy/ Khoáluận tốt nghiệp)đểgiải quyết các vấnđềthực tiễn trong công việc.
15	4	PO4	Kỹnăng mềm vàtháiđộ: Làm việcđộc lập, làm việc nhóm, giao tiếp hiệu quả, cótrách nhiệm, sáng tạo, chủđộng thích nghi với môi trường làm việc, tuân thủchuẩn mựcđạođức nghềnghiệp.
\.


--
-- Data for Name: version_pi_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_pi_courses (id, version_id, pi_id, course_id, contribution_level) FROM stdin;
1	1	2	5	2
2	1	5	5	3
3	1	1	6	2
4	1	2	6	3
5	1	6	8	3
6	1	3	8	2
7	1	4	7	2
8	1	5	7	3
9	1	3	10	3
10	1	4	10	2
11	1	7	10	2
12	1	4	11	2
13	1	5	11	3
14	1	8	11	2
15	1	2	12	2
16	1	8	12	3
501	4	51	155	1
502	4	62	155	1
503	4	70	155	1
504	4	51	156	1
505	4	62	156	1
506	4	71	156	1
507	4	51	157	2
508	4	62	157	2
509	4	70	157	2
510	4	51	158	1
511	4	62	158	1
512	4	70	158	1
513	4	51	159	2
514	4	62	159	2
515	4	68	159	2
516	4	57	160	1
517	4	57	161	1
518	4	57	162	2
519	4	57	163	3
520	4	51	164	1
521	4	67	164	3
522	4	53	165	2
523	4	63	165	2
524	4	70	165	2
525	4	51	166	2
526	4	52	166	2
527	4	63	166	2
528	4	71	166	2
529	4	52	167	3
530	4	70	167	3
531	4	71	167	3
532	4	51	168	2
533	4	66	168	3
534	4	70	168	2
535	4	71	168	2
536	4	51	169	1
537	4	52	169	1
538	4	68	169	1
539	4	51	170	3
540	4	68	170	3
541	4	70	170	3
542	4	71	170	3
543	4	51	171	1
544	4	54	171	1
545	4	55	171	1
546	4	56	171	1
547	4	51	172	1
548	4	54	172	1
549	4	55	172	1
550	4	56	172	1
551	4	51	173	2
552	4	55	173	2
553	4	56	173	2
554	4	51	174	2
555	4	55	174	2
556	4	56	174	2
557	4	51	175	3
558	4	55	175	3
559	4	56	175	3
560	4	51	176	1
561	4	55	176	1
562	4	56	176	1
563	4	58	176	1
564	4	51	177	1
565	4	55	177	1
566	4	56	177	1
567	4	58	177	1
568	4	51	178	2
569	4	55	178	2
570	4	56	178	2
571	4	58	178	2
572	4	51	179	2
573	4	55	179	2
574	4	56	179	2
575	4	58	179	2
576	4	51	180	3
577	4	55	180	3
578	4	56	180	3
579	4	58	180	3
580	4	51	181	1
581	4	54	181	1
582	4	56	181	1
583	4	51	182	1
584	4	54	182	1
585	4	55	182	1
586	4	56	182	1
587	4	51	183	2
588	4	55	183	2
589	4	56	183	2
590	4	61	183	2
591	4	51	184	2
592	4	55	184	2
593	4	58	184	2
594	4	61	184	2
595	4	51	185	3
596	4	55	185	3
597	4	56	185	3
598	4	58	185	3
599	4	59	185	3
600	4	62	185	3
601	4	51	186	1
602	4	54	186	1
603	4	56	186	1
604	4	59	186	1
605	4	51	187	1
606	4	54	187	1
607	4	56	187	1
608	4	59	187	1
609	4	51	188	2
610	4	54	188	2
611	4	56	188	2
612	4	59	188	2
613	4	51	189	2
614	4	54	189	2
615	4	56	189	2
616	4	59	189	2
617	4	51	190	3
618	4	54	190	3
619	4	56	190	3
620	4	59	190	3
621	4	54	191	3
622	4	55	191	3
623	4	61	191	3
624	4	64	191	3
625	4	71	191	3
626	4	53	192	3
627	4	60	192	3
628	4	63	192	3
629	4	65	192	3
630	4	70	192	3
631	4	71	192	3
632	4	53	193	3
633	4	60	193	3
634	4	63	193	3
635	4	65	193	3
636	4	70	193	3
637	4	71	193	3
638	4	51	194	3
639	4	52	194	3
640	4	60	194	3
641	4	63	194	3
642	4	66	194	3
643	4	69	194	3
644	4	55	195	3
645	4	58	195	3
646	4	60	195	3
647	4	71	195	3
648	4	60	196	3
649	4	64	196	3
650	4	67	196	3
651	4	71	196	3
652	4	61	197	3
653	4	64	197	3
654	4	71	197	3
655	4	61	198	3
656	4	64	198	3
657	4	67	198	3
658	4	71	198	3
659	4	58	199	3
660	4	60	199	3
661	4	71	199	3
662	4	55	200	3
663	4	58	200	3
664	4	60	200	3
665	4	71	200	3
666	4	55	201	3
667	4	61	201	3
668	4	64	201	3
669	4	71	201	3
670	4	58	202	3
671	4	64	202	3
672	4	67	202	3
673	4	71	202	3
674	4	58	203	3
675	4	60	203	3
676	4	61	203	3
677	4	67	203	3
678	4	71	203	3
679	4	55	204	3
680	4	58	204	3
681	4	60	204	3
682	4	61	204	3
683	4	64	204	3
684	4	67	204	3
685	4	71	204	3
686	4	51	205	1
687	4	52	205	1
688	4	53	205	1
689	4	51	206	1
690	4	52	206	1
691	4	53	206	1
692	4	51	207	1
693	4	52	207	1
694	4	53	207	1
695	4	51	208	1
696	4	52	208	1
697	4	53	208	1
698	4	51	209	1
699	4	52	209	1
700	4	53	209	1
701	4	51	210	1
702	4	52	210	1
703	4	53	210	1
704	4	51	211	1
705	4	52	211	1
706	4	53	211	1
707	4	51	212	1
708	4	52	212	1
709	4	53	212	1
710	4	51	213	1
711	4	52	213	1
712	4	53	213	1
713	4	51	214	1
714	4	52	214	1
715	4	53	214	1
716	4	51	215	1
717	4	52	215	1
718	4	53	215	1
719	4	51	216	1
720	4	52	216	1
721	4	53	216	1
722	4	51	217	1
723	4	52	217	1
724	4	53	217	1
725	4	51	218	1
726	4	52	218	1
727	4	53	218	1
728	4	51	219	1
729	4	52	219	1
730	4	53	219	1
731	4	51	220	1
732	4	53	220	1
733	4	71	220	1
734	4	51	221	1
735	4	53	221	1
736	4	71	221	1
737	4	51	222	2
738	4	53	222	2
739	4	71	222	2
740	4	51	223	2
741	4	53	223	2
742	4	71	223	2
\.


--
-- Data for Name: version_plos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_plos (id, version_id, code, bloom_level, description) FROM stdin;
1	1	PLO1	3	Áp dụng kiến thức toán học, khoa học tự nhiên và CNTT vào giải quyết bài toán thực tế
2	1	PLO2	4	Phân tích yêu cầu, thiết kế kiến trúc và triển khai hệ thống phần mềm
3	1	PLO3	3	Lập trình thành thạo ít nhất 2 ngôn ngữ lập trình hiện đại
4	1	PLO4	4	Thiết kế và quản trị cơ sở dữ liệu quan hệ và NoSQL
5	1	PLO5	2	Làm việc nhóm hiệu quả, giao tiếp chuyên nghiệp bằng tiếng Việt và tiếng Anh
6	1	PLO6	5	Nghiên cứu, đánh giá và ứng dụng công nghệ mới vào dự án thực tế
21	4	PLO1	3	Vận dụng kiến thức cơ bản về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc để đóng góp tích cực vào sự phát triển bền vững của xã hội, cộng đồng.
22	4	PLO2	5	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc đồng thời sử dụng thành thạo 4 kỹ năng tiếng Trung.
23	4	PLO3	3	Sử dụng ngoại ngữ 2 tiếng Anh trong các tình huống quen thuộc để nâng cao cơ hội việc làm và hiểu biết thêm về các nền văn hóa khác.
24	4	PLO4	5	Áp dụng thành thạo tiếng Trung vào công việc, nhận biết chữ Hán phồn thể và thành thạo chữ Hán giản thể trong công việc; sử dụng có hiệu quả  kiến thức và kỹ năng chuyên ngành tiếng Trung thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c)phương pháp giảng dạy, hoặc (d)khóaluậntốt nghiệp.
25	4	PLO5	5	Thểhiện kỹnăng nhận thức liên quanđến tưduy phản biện, phân tích, tổng hợp vào công việc.
26	4	PLO6	3	Vận dụng kỹ năng giao tiếp và công nghệ thông tin cần thiết để thực hiện các nhiệm vụ phức tạp trong môi trường làm việc liên ngành, đa văn hóa, đa quốc gia.
27	4	PLO7	4	Làm việc độc lập và làm việc theo nhóm trong điều kiện làm việc thay đổi; nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.
\.


--
-- Data for Name: version_syllabi; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_syllabi (id, version_id, course_id, author_id, status, content, is_rejected, rejection_reason, created_at, updated_at) FROM stdin;
1	1	11	2	draft	{"textbooks": ["Khoa Công nghệ Thông tin. Tài liệu học tập học phần \\"TRÍ TUỆ NHÂN TẠO ỨNG DỤNG\\". HUTECH"], "references": ["Thông tư quy định Khung năng lực số (Số 02 /2025/TT-BGDĐT)", "Tài liệu về Prompt Engineering, RAG, Multimodal AI.", "AI Competency Framework for Students (2024). UNESCO."], "prerequisites": "", "course_outline": [{"clos": ["CLO1", "CLO4"], "hours": 5, "title": "GIỚI THIỆU VỂ TRÍ TUỆ NHÂN TẠO", "lesson": 1, "topics": ["1.1. Định nghĩa TTNT", "1.2. Sự phát triển của TTNT và ứng dụng trong cuộc sống", "1.3. Các loại TTNT", "1.4. Ứng dụng TTNT trong các ngành nghề"], "teaching_methods": "Giảng dạy tích cực về TTNT từ khái niệm đến các ứng dụng thực tế. Thảo luận và bài tập: \\"Trình bày ứng dụng của TTNT đến các lĩnh vực như Kinh tế, KHXH, Sức khỏe, Kỹ thuật, Ngoại ngữ\\". Làm việc nhóm và trình bày tổng quan các ứng dụng (tại lớp). Tìm hiểu ứng dụng cụ thể (về nhà)."}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 10, "title": "TRÍ TUỆ NHÂN TẠO VÀ DỮ LIỆU", "lesson": 2, "topics": ["2.1. Vai trò của TTNT và dữ liệu lớn", "2.2. Cách TTNT học từ dữ liệu", "2.3. Tổ chức và quản lý dữ liệu", "2.4. Phân tích dữ liệu cơ bản"], "teaching_methods": "Giảng dạy tích cực về chiếc lược khai thác dữ liệu số hiện nay. Thảo luận và bài tập: \\"Phân tích một bộ dữ liệu thực tế liên quan đến các nhóm ngành học\\". Khảo sát các nguồn dữ liệu (tại lớp). Thực hiện phân tích và trình bày trực quan kết quả qua biểu đồ, kết hợp giải thích ý nghĩa thực tế (về nhà)."}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 5, "title": "VAI TRÒ CỦA TRÍ TUỆ NHÂN TẠO TRONG THỰC TẾ", "lesson": 3, "topics": ["3.1. TTNT trong lĩnh vực Kinh tế", "3.2. TTNT trong lĩnh vực Khoa học xã hội", "3.3. TTNT trong lĩnh vực Y tế", "3.4. TTNT trong lĩnh vực Kỹ thuật", "3.5. TTNT trong lĩnh vực Ngoại ngữ"], "teaching_methods": "Giảng dạy tích cực về vai trò TTNT trong các lĩnh vực. Thảo luận: \\"Khảo sát các công cụ TTNT liên quan đến nhóm ngành học\\". SV chọn hướng ứng dụng TTNT phù hợp với nhóm ngành học tương ứng. Trình bày kết quả khảo sát và lựa chọn các công cụ TTNT phù hợp. (tại lớp)"}, {"clos": ["CLO2", "CLO4"], "hours": 10, "title": "SỬ DỤNG CÔNG CỤ TRÍ TUỆ NHÂN TẠO", "lesson": 4, "topics": ["4.1. Google AutoML", "4.2. Microsoft AI Builder", "4.3. IBM Watson", "4.4. TTNT trong sáng tạo nội dung"], "teaching_methods": "Giảng dạy tích cực về cách sử dụng các công cụ TTNT phổ biến. Bài tập: \\"Sử dụng công cụ TTNT vào Học tập\\". SV tạo ra một sản phẩm cá nhân như bài viết, hình ảnh minh họa, hoặc báo cáo dữ liệu bằng công cụ TTNT. (về nhà)"}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 5, "title": "TRÍ TUỆ NHÂN TẠO - ĐẠO ĐỨC VÀ THÁCH THỨC", "lesson": 5, "topics": ["5.1. Tương lai của TTNT", "5.2. Đạo đức khi sử dụng TTNT", "5.3. TTNT và quyền riêng tư", "5.4. Quy định và chính sách TTNT trên thế giới"], "teaching_methods": "Giảng dạy tích cực về đạo đức TTNT và những thách thức đối với xã hội hiện nay. Thảo luận: \\"Sử dụng TTNT có trách nhiệm\\" liên quan đến các ngành học. SV làm việc nhóm và trình bày các vấn đề liên quan. (tại lớp)"}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 10, "title": "DỰ ÁN TỔNG HỢP", "lesson": 6, "topics": ["6.1. Xác định vấn đề", "6.2. Thiết kế giải pháp", "6.3. Triển khai hệ thống", "6.4. Đánh giá và hoàn thiện"], "teaching_methods": "SV chọn một lĩnh vực và tìm cách ứng dụng TTNT và lĩnh vực đó. SV có thể phân tích dữ liệu bằng TTNT, xây dựng chatbot, sử dụng AutoML. Viết báo cáo và trình bày trước lớp."}], "_schema_version": 2, "learning_methods": [{"method": "Giảng dạy tích cực", "objective": "Lấy người học làm trung tâm, khuyến khích sự tham gia chủ động, tư duy phản biện và áp dụng kiến thức vào thực tiễn."}, {"method": "Thảo luận", "objective": "Thông qua việc hỏi đáp giữa giảng viên và sinh viên để làm rõ các nội dung kiến thức trong học phần."}, {"method": "Bài tập", "objective": "Giúp sinh viên hiểu rõ và biết vận dụng các nội dung học phần vào các vấn đề thực tiễn."}, {"method": "Tự nghiên cứu", "objective": "Giúp người học tăng cường năng lực tự học, tự nghiên cứu."}], "course_objectives": "Học phần này cung cấp cho sinh viên các kiến thức và kỹ năng cơ bản nhằm khai thác, quản lý và phân tích dữ liệu, ứng dụng trí tuệ nhân tạo (TTNT) để để cá nhân hóa học tập và giải quyết vấn đề thực tiễn. Hoàn thành xong học phần này, sinh viên sẽ có thể: -Có kiến thức cơ bản về TTNT và hiểu biết cách thức hoạt động của TTNT. -Biết cách sử dụng các công cụ TTNT để giải quyết các vấn đề trong thực tiễn một cách phù hợp.", "assessment_methods": [{"clos": ["CLO4"], "weight": 20, "component": "Điểm thành phần", "assessment_tool": "Chuyên cần và hoạt động tích cực"}, {"clos": ["CLO1", "CLO2"], "weight": 20, "component": "Bài tập nhóm", "assessment_tool": "Bài tập nhóm"}, {"clos": ["CLO1", "CLO2"], "weight": 10, "component": "Bài tập cá nhân", "assessment_tool": "Bài tập cá nhân"}, {"clos": ["CLO2", "CLO3"], "weight": 50, "component": "Điểm thi kết thúc HP", "assessment_tool": "Đồ án học phần"}], "course_description": "Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn.", "course_requirements": {"hardware": [], "software": ["Google Search", "Scholar", "ChatGPT", "Google AutoML", "Microsoft AI Builder", "IBM Watson"], "lab_equipment": [], "classroom_setup": ""}, "language_instruction": "Tiếng Việt"}	f	\N	2026-03-25 16:01:38.994898+00	2026-03-25 16:29:59.761648+00
2	4	26	2	draft	{"textbooks": ["Khoa Công nghệ Thông tin. Tài liệu học tập học phần \\"TRÍ TUỆ NHÂN TẠO ỨNG DỤNG\\". HUTECH"], "references": ["Thông tư quy định Khung năng lực số (Số 02 /2025/TT-BGDĐT)", "Tài liệu về Prompt Engineering, RAG, Multimodal AI.", "AI Competency Framework for Students (2024). UNESCO."], "prerequisites": "", "course_outline": [{"clos": ["CLO1", "CLO4"], "hours": 5, "title": "GIỚI THIỆU VỂ TRÍ TUỆ NHÂN TẠO", "lesson": 1, "topics": ["1.1. Định nghĩa TTNT", "1.2. Sự phát triển của TTNT và ứng dụng trong cuộc sống", "1.3. Các loại TTNT", "1.4. Ứng dụng TTNT trong các ngành nghề"], "teaching_methods": "Giảng dạy tích cực về TTNT từ khái niệm đến các ứng dụng thực tế. Thảo luận và bài tập: \\"Trình bày ứng dụng của TTNT đến các lĩnh vực như Kinh tế, KHXH, Sức khỏe, Kỹ thuật, Ngoại ngữ\\". Làm việc nhóm và trình bày tổng quan các ứng dụng (tại lớp). Tìm hiểu ứng dụng cụ thể (về nhà)."}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 10, "title": "TRÍ TUỆ NHÂN TẠO VÀ DỮ LIỆU", "lesson": 2, "topics": ["2.1. Vai trò của TTNT và dữ liệu lớn", "2.2. Cách TTNT học từ dữ liệu", "2.3. Tổ chức và quản lý dữ liệu", "2.4. Phân tích dữ liệu cơ bản"], "teaching_methods": "Giảng dạy tích cực về chiếc lược khai thác dữ liệu số hiện nay. Thảo luận và bài tập: \\"Phân tích một bộ dữ liệu thực tế liên quan đến các nhóm ngành học\\". Khảo sát các nguồn dữ liệu (tại lớp). Thực hiện phân tích và trình bày trực quan kết quả qua biểu đồ, kết hợp giải thích ý nghĩa thực tế (về nhà)."}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 5, "title": "VAI TRÒ CỦA TRÍ TUỆ NHÂN TẠO TRONG THỰC TẾ", "lesson": 3, "topics": ["3.1. TTNT trong lĩnh vực Kinh tế", "3.2. TTNT trong lĩnh vực Khoa học xã hội", "3.3. TTNT trong lĩnh vực Y tế", "3.4. TTNT trong lĩnh vực Kỹ thuật", "3.5. TTNT trong lĩnh vực Ngoại ngữ"], "teaching_methods": "Giảng dạy tích cực về vai trò TTNT trong các lĩnh vực. Thảo luận: \\"Khảo sát các công cụ TTNT liên quan đến nhóm ngành học\\". SV chọn hướng ứng dụng TTNT phù hợp với nhóm ngành học tương ứng. Trình bày kết quả khảo sát và lựa chọn các công cụ TTNT phù hợp. (tại lớp)"}, {"clos": ["CLO2", "CLO4"], "hours": 10, "title": "SỬ DỤNG CÔNG CỤ TRÍ TUỆ NHÂN TẠO", "lesson": 4, "topics": ["4.1. Google AutoML", "4.2. Microsoft AI Builder", "4.3. IBM Watson", "4.4. TTNT trong sáng tạo nội dung"], "teaching_methods": "Giảng dạy tích cực về cách sử dụng các công cụ TTNT phổ biến. Bài tập: \\"Sử dụng công cụ TTNT vào Học tập\\". SV tạo ra một sản phẩm cá nhân như bài viết, hình ảnh minh họa, hoặc báo cáo dữ liệu bằng công cụ TTNT. (về nhà)"}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 5, "title": "TRÍ TUỆ NHÂN TẠO - ĐẠO ĐỨC VÀ THÁCH THỨC", "lesson": 5, "topics": ["5.1. Tương lai của TTNT", "5.2. Đạo đức khi sử dụng TTNT", "5.3. TTNT và quyền riêng tư", "5.4. Quy định và chính sách TTNT trên thế giới"], "teaching_methods": "Giảng dạy tích cực về đạo đức TTNT và những thách thức đối với xã hội hiện nay. Thảo luận: \\"Sử dụng TTNT có trách nhiệm\\" liên quan đến các ngành học. SV làm việc nhóm và trình bày các vấn đề liên quan. (tại lớp)"}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 10, "title": "DỰ ÁN TỔNG HỢP", "lesson": 6, "topics": ["6.1. Xác định vấn đề", "6.2. Thiết kế giải pháp", "6.3. Triển khai hệ thống", "6.4. Đánh giá và hoàn thiện"], "teaching_methods": "SV chọn một lĩnh vực và tìm cách ứng dụng TTNT và lĩnh vực đó. SV có thể phân tích dữ liệu bằng TTNT, xây dựng chatbot, sử dụng AutoML. Viết báo cáo và trình bày trước lớp."}], "_schema_version": 2, "learning_methods": "[object Object],[object Object],[object Object],[object Object]", "course_objectives": "Học phần này cung cấp cho sinh viên các kiến thức và kỹ năng cơ bản nhằm khai thác, quản lý và phân tích dữ liệu, ứng dụng trí tuệ nhân tạo (TTNT) để để cá nhân hóa học tập và giải quyết vấn đề thực tiễn. Hoàn thành xong học phần này, sinh viên sẽ có thể: -Có kiến thức cơ bản về TTNT và hiểu biết cách thức hoạt động của TTNT. -Biết cách sử dụng các công cụ TTNT để giải quyết các vấn đề trong thực tiễn một cách phù hợp.", "assessment_methods": [{"clos": ["CLO4"], "weight": 20, "component": "Điểm thành phần", "assessment_tool": "Chuyên cần và hoạt động tích cực"}, {"clos": ["CLO1", "CLO2"], "weight": 20, "component": "Bài tập nhóm", "assessment_tool": "Bài tập nhóm"}, {"clos": ["CLO1", "CLO2"], "weight": 10, "component": "Bài tập cá nhân", "assessment_tool": "Bài tập cá nhân"}, {"clos": ["CLO2", "CLO3"], "weight": 50, "component": "Điểm thi kết thúc HP", "assessment_tool": "Đồ án học phần"}], "course_description": "Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn.", "course_requirements": {"hardware": [], "software": ["Google Search", "Scholar", "ChatGPT", "Google AutoML", "Microsoft AI Builder", "IBM Watson", "TTNT trong sáng tạo nội dung"], "lab_equipment": [], "classroom_setup": ""}, "language_instruction": "Tiếng Việt"}	f	\N	2026-03-25 16:35:43.283427+00	2026-03-25 16:39:56.946624+00
\.


--
-- Name: approval_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.approval_logs_id_seq', 1, false);


--
-- Name: assessment_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.assessment_plans_id_seq', 84, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 37, true);


--
-- Name: course_clos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.course_clos_id_seq', 4, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.courses_id_seq', 223, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.departments_id_seq', 330, true);


--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.knowledge_blocks_id_seq', 44, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.permissions_id_seq', 450, true);


--
-- Name: plo_pis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.plo_pis_id_seq', 71, true);


--
-- Name: program_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.program_versions_id_seq', 4, true);


--
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.programs_id_seq', 4, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.roles_id_seq', 90, true);


--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.syllabus_assignments_id_seq', 2, true);


--
-- Name: teaching_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.teaching_plan_id_seq', 217, true);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: version_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_courses_id_seq', 223, true);


--
-- Name: version_objectives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_objectives_id_seq', 15, true);


--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_pi_courses_id_seq', 742, true);


--
-- Name: version_plos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_plos_id_seq', 27, true);


--
-- Name: version_syllabi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_syllabi_id_seq', 2, true);


--
-- Name: approval_logs approval_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_pkey PRIMARY KEY (id);


--
-- Name: assessment_plans assessment_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clo_plo_map clo_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_pkey PRIMARY KEY (clo_id, plo_id);


--
-- Name: course_clos course_clos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_pkey PRIMARY KEY (id);


--
-- Name: course_plo_map course_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_pkey PRIMARY KEY (course_id, plo_id);


--
-- Name: courses courses_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_code_key UNIQUE (code);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: departments departments_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_code_key UNIQUE (code);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: knowledge_blocks knowledge_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plo_pis plo_pis_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_pkey PRIMARY KEY (id);


--
-- Name: po_plo_map po_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_pkey PRIMARY KEY (po_id, plo_id);


--
-- Name: program_versions program_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_pkey PRIMARY KEY (id);


--
-- Name: program_versions program_versions_program_id_academic_year_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_academic_year_key UNIQUE (program_id, academic_year);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_code_key UNIQUE (code);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: syllabus_assignments syllabus_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_pkey PRIMARY KEY (id);


--
-- Name: syllabus_assignments syllabus_assignments_version_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_version_id_course_id_key UNIQUE (version_id, course_id);


--
-- Name: teaching_plan teaching_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan
    ADD CONSTRAINT teaching_plan_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_department_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_department_id_key UNIQUE (user_id, role_id, department_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: version_courses version_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_pkey PRIMARY KEY (id);


--
-- Name: version_objectives version_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_pkey PRIMARY KEY (id);


--
-- Name: version_pi_courses version_pi_courses_pi_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pi_id_course_id_key UNIQUE (pi_id, course_id);


--
-- Name: version_pi_courses version_pi_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pkey PRIMARY KEY (id);


--
-- Name: version_plos version_plos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_pkey PRIMARY KEY (id);


--
-- Name: version_syllabi version_syllabi_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_pkey PRIMARY KEY (id);


--
-- Name: idx_sa_assigned_to; Type: INDEX; Schema: public; Owner: program
--

CREATE INDEX idx_sa_assigned_to ON public.syllabus_assignments USING btree (assigned_to);


--
-- Name: idx_sa_version; Type: INDEX; Schema: public; Owner: program
--

CREATE INDEX idx_sa_version ON public.syllabus_assignments USING btree (version_id);


--
-- Name: approval_logs approval_logs_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: assessment_plans assessment_plans_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id);


--
-- Name: assessment_plans assessment_plans_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: assessment_plans assessment_plans_sample_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_sample_course_id_fkey FOREIGN KEY (sample_course_id) REFERENCES public.courses(id);


--
-- Name: assessment_plans assessment_plans_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_clo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_clo_id_fkey FOREIGN KEY (clo_id) REFERENCES public.course_clos(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_clos course_clos_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: courses courses_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id);


--
-- Name: knowledge_blocks knowledge_blocks_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_blocks(id) ON DELETE CASCADE;


--
-- Name: knowledge_blocks knowledge_blocks_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: plo_pis plo_pis_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.version_objectives(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: program_versions program_versions_copied_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_copied_from_id_fkey FOREIGN KEY (copied_from_id) REFERENCES public.program_versions(id);


--
-- Name: program_versions program_versions_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.programs(id) ON DELETE CASCADE;


--
-- Name: programs programs_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: syllabus_assignments syllabus_assignments_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: syllabus_assignments syllabus_assignments_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: syllabus_assignments syllabus_assignments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: syllabus_assignments syllabus_assignments_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: teaching_plan teaching_plan_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan
    ADD CONSTRAINT teaching_plan_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_objectives version_objectives_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_plos version_plos_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_syllabi version_syllabi_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: version_syllabi version_syllabi_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: version_syllabi version_syllabi_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: program
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict a6reIuL5ABTi8mPZJnPo6wcFakhl6uHzSQweWHUqpPXZVSd7shVmx0w5ty0dHk4

