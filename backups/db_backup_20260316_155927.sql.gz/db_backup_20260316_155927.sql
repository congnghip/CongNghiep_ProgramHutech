--
-- PostgreSQL database dump
--

\restrict EderElyDUuFhhtNkNxVKfLrKNC1yeL6UJxTCiHqQjNqmZkvwMpAHSVBSFwmy6Do

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.approval_logs (
    id integer NOT NULL,
    entity_type character varying(30) NOT NULL,
    entity_id integer NOT NULL,
    step character varying(30) NOT NULL,
    action character varying(20) NOT NULL,
    reviewer_id integer,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.approval_logs OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.approval_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_logs_id_seq OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.approval_logs_id_seq OWNED BY public.approval_logs.id;


--
-- Name: assessment_plans; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.assessment_plans (
    id integer NOT NULL,
    version_id integer,
    plo_id integer,
    pi_id integer,
    sample_course_id integer,
    assessment_tool character varying(200),
    criteria character varying(200),
    threshold character varying(200),
    semester character varying(30),
    assessor character varying(200),
    dept_code character varying(20)
);


ALTER TABLE public.assessment_plans OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.assessment_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assessment_plans_id_seq OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.assessment_plans_id_seq OWNED BY public.assessment_plans.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100),
    target character varying(200),
    details text,
    ip character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clo_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.clo_plo_map (
    clo_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 1
);


ALTER TABLE public.clo_plo_map OWNER TO program;

--
-- Name: course_clos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_clos (
    id integer NOT NULL,
    version_course_id integer,
    code character varying(20),
    description text
);


ALTER TABLE public.course_clos OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.course_clos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_clos_id_seq OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.course_clos_id_seq OWNED BY public.course_clos.id;


--
-- Name: course_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_plo_map (
    version_id integer,
    course_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.course_plo_map OWNER TO program;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(300) NOT NULL,
    credits integer DEFAULT 3,
    department_id integer,
    description text
);


ALTER TABLE public.courses OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    parent_id integer,
    code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(20) DEFAULT 'KHOA'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.departments OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    code character varying(60) NOT NULL,
    module character varying(30) NOT NULL,
    description character varying(200)
);


ALTER TABLE public.permissions OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: plo_pis; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.plo_pis (
    id integer NOT NULL,
    plo_id integer,
    pi_code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.plo_pis OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.plo_pis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plo_pis_id_seq OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.plo_pis_id_seq OWNED BY public.plo_pis.id;


--
-- Name: po_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.po_plo_map (
    version_id integer,
    po_id integer NOT NULL,
    plo_id integer NOT NULL
);


ALTER TABLE public.po_plo_map OWNER TO program;

--
-- Name: program_versions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.program_versions (
    id integer NOT NULL,
    program_id integer,
    academic_year character varying(20) NOT NULL,
    status character varying(30) DEFAULT 'draft'::character varying,
    is_locked boolean DEFAULT false,
    copied_from_id integer,
    completion_pct integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.program_versions OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.program_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_versions_id_seq OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.program_versions_id_seq OWNED BY public.program_versions.id;


--
-- Name: programs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.programs (
    id integer NOT NULL,
    department_id integer,
    name character varying(300) NOT NULL,
    code character varying(30),
    degree character varying(50) DEFAULT 'Đại học'::character varying,
    total_credits integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.programs OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.programs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.programs_id_seq OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.programs_id_seq OWNED BY public.programs.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO program;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    is_system boolean DEFAULT true
);


ALTER TABLE public.roles OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    department_id integer
);


ALTER TABLE public.user_roles OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(200) NOT NULL,
    email character varying(200),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_courses (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    semester integer,
    course_type character varying(20) DEFAULT 'required'::character varying
);


ALTER TABLE public.version_courses OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_courses_id_seq OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_courses_id_seq OWNED BY public.version_courses.id;


--
-- Name: version_objectives; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_objectives (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.version_objectives OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_objectives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_objectives_id_seq OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_objectives_id_seq OWNED BY public.version_objectives.id;


--
-- Name: version_plos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_plos (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    bloom_level integer DEFAULT 1,
    description text
);


ALTER TABLE public.version_plos OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_plos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_plos_id_seq OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_plos_id_seq OWNED BY public.version_plos.id;


--
-- Name: version_syllabi; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_syllabi (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    author_id integer,
    status character varying(30) DEFAULT 'draft'::character varying,
    content jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.version_syllabi OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_syllabi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_syllabi_id_seq OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_syllabi_id_seq OWNED BY public.version_syllabi.id;


--
-- Name: approval_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs ALTER COLUMN id SET DEFAULT nextval('public.approval_logs_id_seq'::regclass);


--
-- Name: assessment_plans id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans ALTER COLUMN id SET DEFAULT nextval('public.assessment_plans_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: course_clos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos ALTER COLUMN id SET DEFAULT nextval('public.course_clos_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: plo_pis id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis ALTER COLUMN id SET DEFAULT nextval('public.plo_pis_id_seq'::regclass);


--
-- Name: program_versions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions ALTER COLUMN id SET DEFAULT nextval('public.program_versions_id_seq'::regclass);


--
-- Name: programs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs ALTER COLUMN id SET DEFAULT nextval('public.programs_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses ALTER COLUMN id SET DEFAULT nextval('public.version_courses_id_seq'::regclass);


--
-- Name: version_objectives id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives ALTER COLUMN id SET DEFAULT nextval('public.version_objectives_id_seq'::regclass);


--
-- Name: version_plos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos ALTER COLUMN id SET DEFAULT nextval('public.version_plos_id_seq'::regclass);


--
-- Name: version_syllabi id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi ALTER COLUMN id SET DEFAULT nextval('public.version_syllabi_id_seq'::regclass);


--
-- Data for Name: approval_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.approval_logs (id, entity_type, entity_id, step, action, reviewer_id, notes, created_at) FROM stdin;
1	program_version	2	submit	submitted	1	Nộp duyệt	2026-03-16 08:31:43.316475+00
2	program_version	2	submitted	approved	1	Đã duyệt	2026-03-16 08:31:49.515335+00
3	program_version	2	approved_khoa	rejected	1	Từ chối	2026-03-16 08:31:54.280693+00
4	program_version	2	submit	submitted	1	Nộp duyệt	2026-03-16 08:32:28.131497+00
5	program_version	2	submitted	approved	1	Đã duyệt	2026-03-16 08:32:37.110168+00
6	program_version	2	approved_khoa	approved	1	Đã duyệt	2026-03-16 08:32:38.161231+00
7	program_version	2	approved_pdt	approved	1	Đã duyệt	2026-03-16 08:32:40.281436+00
8	program_version	3	submit	submitted	1	Nộp duyệt	2026-03-16 08:33:10.912689+00
9	program_version	3	submitted	approved	1	Đã duyệt	2026-03-16 08:33:14.954663+00
10	program_version	3	approved_khoa	approved	1	Đã duyệt	2026-03-16 08:33:19.062148+00
11	program_version	3	approved_pdt	rejected	1	Từ chối	2026-03-16 08:33:20.898091+00
\.


--
-- Data for Name: assessment_plans; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.assessment_plans (id, version_id, plo_id, pi_id, sample_course_id, assessment_tool, criteria, threshold, semester, assessor, dept_code) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.audit_logs (id, user_id, action, target, details, ip, created_at) FROM stdin;
1	1	POST /api/versions/1/syllabi	/api/versions/1/syllabi	{"params":{"vId":"1"},"bodyKeys":["course_id","content"]}	172.18.0.1	2026-03-16 07:57:13.23541+00
2	1	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-16 07:59:44.270217+00
3	1	PUT /api/programs/1	/api/programs/1	{"params":{"id":"1"},"bodyKeys":["name","code","department_id","degree","total_credits"]}	172.18.0.1	2026-03-16 08:27:44.499454+00
4	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-16 08:29:03.162912+00
5	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-16 08:29:08.414838+00
6	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:29:09.644118+00
7	2	POST /api/versions/1/syllabi	/api/versions/1/syllabi	{"params":{"vId":"1"},"bodyKeys":["course_id","content"]}	172.18.0.1	2026-03-16 08:29:41.605565+00
8	1	POST /api/programs	/api/programs	{"params":{},"bodyKeys":["name","code","department_id","degree","total_credits"]}	172.18.0.1	2026-03-16 08:31:14.822202+00
9	1	POST /api/programs/2/versions	/api/programs/2/versions	{"params":{"programId":"2"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-16 08:31:31.053903+00
10	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-16 08:31:43.319652+00
11	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-16 08:31:49.51672+00
12	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-16 08:31:54.282342+00
13	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-16 08:32:28.134794+00
14	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-16 08:32:37.111596+00
15	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-16 08:32:38.162682+00
16	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-16 08:32:40.282679+00
17	1	POST /api/programs/2/versions	/api/programs/2/versions	{"params":{"programId":"2"},"bodyKeys":["academic_year","copy_from_version_id"]}	172.18.0.1	2026-03-16 08:33:00.853362+00
18	1	POST /api/approval/submit	/api/approval/submit	{"params":{},"bodyKeys":["entity_type","entity_id"]}	172.18.0.1	2026-03-16 08:33:10.915686+00
19	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-16 08:33:14.956076+00
20	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action"]}	172.18.0.1	2026-03-16 08:33:19.06345+00
21	1	POST /api/approval/review	/api/approval/review	{"params":{},"bodyKeys":["entity_type","entity_id","action","notes"]}	172.18.0.1	2026-03-16 08:33:20.89962+00
22	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:08.2203+00
23	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:08.516205+00
24	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:09.62682+00
25	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:09.804273+00
26	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:09.983848+00
27	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:10.162115+00
28	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:10.340547+00
29	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:10.517618+00
30	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:10.689621+00
31	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:10.867742+00
32	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:11.046069+00
33	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:11.301988+00
34	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:11.551728+00
35	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:11.721802+00
36	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:11.907326+00
37	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:12.093972+00
38	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:12.287561+00
39	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:12.459706+00
40	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:12.646139+00
41	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:12.840446+00
42	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:13.009889+00
43	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:13.196484+00
44	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:13.36017+00
45	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:13.546559+00
46	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:13.71529+00
47	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:13.9099+00
48	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:14.082227+00
49	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:14.289909+00
50	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:14.470184+00
51	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:14.663871+00
52	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:14.85745+00
53	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:15.106803+00
54	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:15.283656+00
55	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:15.470493+00
56	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:15.679792+00
57	1	DELETE /api/users/2/roles/GIANG_VIEN/0	/api/users/2/roles/GIANG_VIEN/0	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"0"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:42:15.889366+00
58	1	DELETE /api/users/2/roles/GIANG_VIEN/1	/api/users/2/roles/GIANG_VIEN/1	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:46:28.718522+00
59	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-16 08:46:30.134186+00
60	1	DELETE /api/users/2/roles/GIANG_VIEN/1	/api/users/2/roles/GIANG_VIEN/1	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:46:31.401153+00
61	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-16 08:46:32.014129+00
62	1	DELETE /api/users/2/roles/GIANG_VIEN/1	/api/users/2/roles/GIANG_VIEN/1	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:46:32.689288+00
63	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-16 08:46:33.434173+00
64	1	DELETE /api/users/2/roles/GIANG_VIEN/1	/api/users/2/roles/GIANG_VIEN/1	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:46:34.304106+00
65	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-16 08:46:36.606741+00
66	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-16 08:47:29.21641+00
67	1	DELETE /api/users/2/roles/GIANG_VIEN/1	/api/users/2/roles/GIANG_VIEN/1	{"params":{"userId":"2","roleCode":"GIANG_VIEN","deptId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:47:30.169722+00
68	2	POST /api/versions/3/objectives	/api/versions/3/objectives	{"params":{"vId":"3"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-16 08:48:22.651808+00
69	2	DELETE /api/objectives/4	/api/objectives/4	{"params":{"id":"4"},"bodyKeys":[]}	172.18.0.1	2026-03-16 08:48:25.686511+00
\.


--
-- Data for Name: clo_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.clo_plo_map (clo_id, plo_id, contribution_level) FROM stdin;
\.


--
-- Data for Name: course_clos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_clos (id, version_course_id, code, description) FROM stdin;
1	4	CLO1	test
\.


--
-- Data for Name: course_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_plo_map (version_id, course_id, plo_id, contribution_level) FROM stdin;
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.courses (id, code, name, credits, department_id, description) FROM stdin;
1	IT001	Nhập môn lập trình	3	5	\N
2	IT002	Cấu trúc dữ liệu và giải thuật	4	5	\N
3	IT003	Cơ sở dữ liệu	3	5	\N
4	GEN001	Toán rời rạc	3	5	\N
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.departments (id, parent_id, code, name, type, created_at) FROM stdin;
1	\N	HUTECH	Trường Đại học Công nghệ TP.HCM	ROOT	2026-03-16 07:48:23.471703+00
2	1	BGH	Ban Giám Hiệu	PHONG	2026-03-16 07:48:23.474905+00
3	1	PDT	Phòng Đào tạo	PHONG	2026-03-16 07:48:23.475853+00
4	1	K.TQH	Khoa Trung Quốc học	KHOA	2026-03-16 07:48:23.476582+00
5	1	K.CNTT	Khoa CNTT	KHOA	2026-03-16 07:48:23.477335+00
6	1	K.TA	Khoa Tiếng Anh	KHOA	2026-03-16 07:48:23.478044+00
7	1	K.QTKD	Khoa QTKD	KHOA	2026-03-16 07:48:23.478737+00
8	1	K.LUAT	Khoa Luật	KHOA	2026-03-16 07:48:23.479468+00
9	1	K.NBH	Khoa Nhật Bản học	KHOA	2026-03-16 07:48:23.480237+00
10	1	VJIT	Viện CNTT Việt-Nhật	VIEN	2026-03-16 07:48:23.481005+00
11	1	V.KHUD	Viện Khoa học ứng dụng	VIEN	2026-03-16 07:48:23.481678+00
12	1	TT.GDTC	TT Giáo dục Thể chất	TRUNG_TAM	2026-03-16 07:48:23.482399+00
13	1	TT.GDCT-QP	TT Giáo dục CT-QP	TRUNG_TAM	2026-03-16 07:48:23.483058+00
14	1	TT.TH-NN-KN	TT Tin học-NN-KN	TRUNG_TAM	2026-03-16 07:48:23.483679+00
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.permissions (id, code, module, description) FROM stdin;
1	programs.view_published	programs	Xem CTĐT đã công bố
2	programs.view_draft	programs	Xem CTĐT bản nháp
3	programs.create	programs	Tạo mới CTĐT
4	programs.edit	programs	Chỉnh sửa CTĐT
5	programs.delete_draft	programs	Xóa CTĐT bản nháp
6	programs.submit	programs	Nộp CTĐT để phê duyệt
7	programs.approve_khoa	programs	Duyệt CTĐT cấp Khoa
8	programs.approve_pdt	programs	Duyệt CTĐT cấp Phòng ĐT
9	programs.approve_bgh	programs	Phê duyệt CTĐT cấp BGH
10	programs.export	programs	Xuất báo cáo CTĐT
11	programs.import_word	programs	Import CTĐT từ Word
12	programs.manage_all	programs	Quản lý CTĐT toàn trường
13	programs.create_version	programs	Tạo phiên bản CTĐT mới
14	plo.view	plo	Xem chuẩn đầu ra
15	plo.create	plo	Tạo/chỉnh sửa PLO
16	plo.submit	plo	Nộp PLO để phê duyệt
17	plo.approve_khoa	plo	Duyệt PLO cấp Khoa
18	plo.approve_pdt	plo	Duyệt PLO cấp Phòng ĐT
19	plo.approve_bgh	plo	Phê duyệt PLO cấp BGH
20	syllabus.view	syllabus	Xem đề cương đã công bố
21	syllabus.create	syllabus	Tạo đề cương
22	syllabus.edit	syllabus	Chỉnh sửa đề cương
23	syllabus.submit	syllabus	Nộp đề cương để phê duyệt
24	syllabus.approve_tbm	syllabus	Duyệt cấp Trưởng BM
25	syllabus.approve_khoa	syllabus	Duyệt cấp Trưởng Khoa
26	syllabus.approve_pdt	syllabus	Duyệt cấp Phòng ĐT
27	syllabus.approve_bgh	syllabus	Phê duyệt cấp BGH
28	syllabus.assign	syllabus	Phân công GV soạn đề cương
29	courses.view	courses	Xem danh mục học phần
30	courses.create	courses	Tạo học phần mới
31	courses.edit	courses	Chỉnh sửa học phần
32	portfolio.own	portfolio	Quản lý hồ sơ GD của mình
33	portfolio.view_dept	portfolio	Xem hồ sơ GD của Khoa
34	rbac.manage_users	rbac	Quản lý tài khoản
35	rbac.manage_roles	rbac	Quản lý vai trò & phân quyền
36	rbac.manage_departments	rbac	Quản lý đơn vị tổ chức
37	rbac.view_audit_logs	rbac	Xem nhật ký hệ thống
38	rbac.system_config	rbac	Cấu hình hệ thống
\.


--
-- Data for Name: plo_pis; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.plo_pis (id, plo_id, pi_code, description) FROM stdin;
\.


--
-- Data for Name: po_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.po_plo_map (version_id, po_id, plo_id) FROM stdin;
\.


--
-- Data for Name: program_versions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.program_versions (id, program_id, academic_year, status, is_locked, copied_from_id, completion_pct, created_at, updated_at) FROM stdin;
1	1	2023-2027	published	f	\N	0	2026-03-16 07:51:28.060707+00	2026-03-16 07:51:28.060707+00
2	2	2025-2026	published	f	\N	0	2026-03-16 08:31:31.01021+00	2026-03-16 08:32:40.240307+00
3	2	2026-2027	draft	f	\N	0	2026-03-16 08:33:00.798783+00	2026-03-16 08:33:20.856953+00
\.


--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.programs (id, department_id, name, code, degree, total_credits, created_at) FROM stdin;
1	5	Công nghệ thông tin	7480201	Đại học	150	2026-03-16 07:51:28.016001+00
2	6	Ngôn Ngữ Anh	1234567	Đại học	150	2026-03-16 08:31:14.796819+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	1
1	14
1	20
1	21
1	22
1	23
1	29
1	32
2	1
2	2
2	14
2	20
2	24
2	29
2	32
3	1
3	2
3	3
3	4
3	5
3	6
3	7
3	10
3	11
3	14
3	15
3	16
3	17
3	20
3	21
3	22
3	23
3	25
3	28
3	29
3	32
3	33
4	1
4	2
4	3
4	4
4	5
4	8
4	10
4	11
4	12
4	13
4	14
4	15
4	18
4	20
4	21
4	22
4	26
4	28
4	29
4	30
4	31
4	33
4	37
5	1
5	2
5	9
5	10
5	14
5	19
5	20
5	27
5	29
6	1
6	2
6	5
6	12
6	13
6	14
6	20
6	29
6	33
6	34
6	35
6	36
6	37
6	38
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.roles (id, code, name, level, is_system) FROM stdin;
1	GIANG_VIEN	Giảng viên	1	t
2	TRUONG_NGANH	Trưởng ngành / Trưởng BM	2	t
3	LANH_DAO_KHOA	Lãnh đạo Khoa/Viện/TT	3	t
4	PHONG_DAO_TAO	Phòng Đào tạo	4	t
5	BAN_GIAM_HIEU	Ban Giám Hiệu	5	t
6	ADMIN	Quản trị hệ thống	99	t
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.user_roles (id, user_id, role_id, department_id) FROM stdin;
1	1	6	1
7	2	1	5
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.users (id, username, password_hash, display_name, email, is_active, created_at) FROM stdin;
1	admin	$2a$10$EI.5Zm7Ik7I8BoWuNBo2rO2FLB1rWyuNTILkiWbQfNbgYm7/ftzgm	Quản trị viên	\N	t	2026-03-16 07:48:23.631192+00
2	giangvien	$2a$10$TgbN5tNqsB.wvYeSPNC2sOmcjtZA5uMLJTE5e8ym/VhLxmdf2nGWG	Giang Viên	giangvien@gmail.com	t	2026-03-16 08:29:03.1614+00
\.


--
-- Data for Name: version_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_courses (id, version_id, course_id, semester, course_type) FROM stdin;
1	1	1	1	required
2	1	2	1	required
3	1	3	1	required
4	1	4	1	required
\.


--
-- Data for Name: version_objectives; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_objectives (id, version_id, code, description) FROM stdin;
1	1	PO1	Có kiến thức cơ bản về toán học, khoa học tự nhiên và xã hội.
2	1	PO2	Có khả năng thiết kế, xây dựng và quản lý các hệ thống phần mềm.
3	1	PO3	Có kỹ năng làm việc nhóm và giao tiếp hiệu quả.
\.


--
-- Data for Name: version_plos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_plos (id, version_id, code, bloom_level, description) FROM stdin;
1	1	PLO1	3	Vận dụng kiến thức toán học và khoa học cơ bản vào giải quyết vấn đề CNTT.
2	1	PLO2	4	Thiết kế hệ thống phần mềm đáp ứng yêu cầu khách hàng.
3	1	PLO3	3	Sử dụng thành thạo các ngôn ngữ lập trình phổ biến.
\.


--
-- Data for Name: version_syllabi; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_syllabi (id, version_id, course_id, author_id, status, content, created_at, updated_at) FROM stdin;
1	1	4	1	draft	{}	2026-03-16 07:57:13.190646+00	2026-03-16 07:57:13.190646+00
2	1	1	2	draft	{}	2026-03-16 08:29:41.561885+00	2026-03-16 08:29:41.561885+00
\.


--
-- Name: approval_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.approval_logs_id_seq', 11, true);


--
-- Name: assessment_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.assessment_plans_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 69, true);


--
-- Name: course_clos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.course_clos_id_seq', 1, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.courses_id_seq', 4, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.departments_id_seq', 28, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.permissions_id_seq', 76, true);


--
-- Name: plo_pis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.plo_pis_id_seq', 1, false);


--
-- Name: program_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.program_versions_id_seq', 3, true);


--
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.programs_id_seq', 2, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.roles_id_seq', 12, true);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 7, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: version_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_courses_id_seq', 4, true);


--
-- Name: version_objectives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_objectives_id_seq', 4, true);


--
-- Name: version_plos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_plos_id_seq', 3, true);


--
-- Name: version_syllabi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_syllabi_id_seq', 2, true);


--
-- Name: approval_logs approval_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_pkey PRIMARY KEY (id);


--
-- Name: assessment_plans assessment_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clo_plo_map clo_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_pkey PRIMARY KEY (clo_id, plo_id);


--
-- Name: course_clos course_clos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_pkey PRIMARY KEY (id);


--
-- Name: course_plo_map course_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_pkey PRIMARY KEY (course_id, plo_id);


--
-- Name: courses courses_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_code_key UNIQUE (code);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: departments departments_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_code_key UNIQUE (code);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plo_pis plo_pis_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_pkey PRIMARY KEY (id);


--
-- Name: po_plo_map po_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_pkey PRIMARY KEY (po_id, plo_id);


--
-- Name: program_versions program_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_pkey PRIMARY KEY (id);


--
-- Name: program_versions program_versions_program_id_academic_year_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_academic_year_key UNIQUE (program_id, academic_year);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_code_key UNIQUE (code);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_department_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_department_id_key UNIQUE (user_id, role_id, department_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: version_courses version_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_pkey PRIMARY KEY (id);


--
-- Name: version_objectives version_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_pkey PRIMARY KEY (id);


--
-- Name: version_plos version_plos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_pkey PRIMARY KEY (id);


--
-- Name: version_syllabi version_syllabi_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_pkey PRIMARY KEY (id);


--
-- Name: approval_logs approval_logs_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: assessment_plans assessment_plans_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id);


--
-- Name: assessment_plans assessment_plans_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: assessment_plans assessment_plans_sample_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_sample_course_id_fkey FOREIGN KEY (sample_course_id) REFERENCES public.courses(id);


--
-- Name: assessment_plans assessment_plans_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_clo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_clo_id_fkey FOREIGN KEY (clo_id) REFERENCES public.course_clos(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_clos course_clos_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: courses courses_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id);


--
-- Name: plo_pis plo_pis_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.version_objectives(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: program_versions program_versions_copied_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_copied_from_id_fkey FOREIGN KEY (copied_from_id) REFERENCES public.program_versions(id);


--
-- Name: program_versions program_versions_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.programs(id) ON DELETE CASCADE;


--
-- Name: programs programs_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_objectives version_objectives_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_plos version_plos_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_syllabi version_syllabi_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: version_syllabi version_syllabi_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: version_syllabi version_syllabi_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict EderElyDUuFhhtNkNxVKfLrKNC1yeL6UJxTCiHqQjNqmZkvwMpAHSVBSFwmy6Do

