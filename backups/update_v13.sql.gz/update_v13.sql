--
-- PostgreSQL database dump
--

\restrict whNVNdPyY6EOsHxaecOleF4xUtSSSe4TsKvwNRpHOLxJJaSHa3lgFQzlbhW5QHs

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: program
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO program;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: program
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.approval_logs (
    id integer NOT NULL,
    entity_type character varying(30) NOT NULL,
    entity_id integer NOT NULL,
    step character varying(30) NOT NULL,
    action character varying(20) NOT NULL,
    reviewer_id integer,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.approval_logs OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.approval_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_logs_id_seq OWNER TO program;

--
-- Name: approval_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.approval_logs_id_seq OWNED BY public.approval_logs.id;


--
-- Name: assessment_plans; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.assessment_plans (
    id integer NOT NULL,
    version_id integer,
    plo_id integer,
    pi_id integer,
    sample_course_id integer,
    assessment_tool character varying(200),
    criteria character varying(200),
    threshold character varying(200),
    semester character varying(30),
    assessor character varying(200),
    dept_code character varying(20),
    direct_evidence character varying(200),
    expected_result character varying(200),
    contributing_course_codes text
);


ALTER TABLE public.assessment_plans OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.assessment_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assessment_plans_id_seq OWNER TO program;

--
-- Name: assessment_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.assessment_plans_id_seq OWNED BY public.assessment_plans.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100),
    target character varying(200),
    details text,
    ip character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO program;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clo_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.clo_plo_map (
    clo_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 1
);


ALTER TABLE public.clo_plo_map OWNER TO program;

--
-- Name: course_clos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_clos (
    id integer NOT NULL,
    version_course_id integer,
    code character varying(20),
    description text
);


ALTER TABLE public.course_clos OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.course_clos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_clos_id_seq OWNER TO program;

--
-- Name: course_clos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.course_clos_id_seq OWNED BY public.course_clos.id;


--
-- Name: course_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.course_plo_map (
    version_id integer,
    course_id integer NOT NULL,
    plo_id integer NOT NULL,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.course_plo_map OWNER TO program;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(300) NOT NULL,
    credits integer DEFAULT 3,
    credits_theory integer DEFAULT 0,
    credits_practice integer DEFAULT 0,
    credits_project integer DEFAULT 0,
    credits_internship integer DEFAULT 0,
    department_id integer,
    description text
);


ALTER TABLE public.courses OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO program;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    parent_id integer,
    code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(20) DEFAULT 'KHOA'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.departments OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO program;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: knowledge_blocks; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.knowledge_blocks (
    id integer NOT NULL,
    version_id integer,
    name character varying(200) NOT NULL,
    parent_id integer,
    total_credits integer DEFAULT 0,
    required_credits integer DEFAULT 0,
    elective_credits integer DEFAULT 0,
    sort_order integer DEFAULT 0,
    level integer DEFAULT 1
);


ALTER TABLE public.knowledge_blocks OWNER TO program;

--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.knowledge_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knowledge_blocks_id_seq OWNER TO program;

--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.knowledge_blocks_id_seq OWNED BY public.knowledge_blocks.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    code character varying(60) NOT NULL,
    module character varying(30) NOT NULL,
    description character varying(200)
);


ALTER TABLE public.permissions OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO program;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: plo_pis; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.plo_pis (
    id integer NOT NULL,
    plo_id integer,
    pi_code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.plo_pis OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.plo_pis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plo_pis_id_seq OWNER TO program;

--
-- Name: plo_pis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.plo_pis_id_seq OWNED BY public.plo_pis.id;


--
-- Name: po_plo_map; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.po_plo_map (
    version_id integer,
    po_id integer NOT NULL,
    plo_id integer NOT NULL
);


ALTER TABLE public.po_plo_map OWNER TO program;

--
-- Name: program_versions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.program_versions (
    id integer NOT NULL,
    program_id integer,
    academic_year character varying(20) NOT NULL,
    version_name character varying(300),
    status character varying(30) DEFAULT 'draft'::character varying,
    is_locked boolean DEFAULT false,
    copied_from_id integer,
    completion_pct integer DEFAULT 0,
    total_credits integer,
    training_duration character varying(50),
    change_type character varying(50),
    effective_date date,
    change_summary text,
    grading_scale text,
    graduation_requirements text,
    job_positions text,
    further_education text,
    reference_programs text,
    training_process text,
    admission_targets text,
    admission_criteria text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_rejected boolean DEFAULT false,
    rejection_reason text,
    general_objective text
);


ALTER TABLE public.program_versions OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.program_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_versions_id_seq OWNER TO program;

--
-- Name: program_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.program_versions_id_seq OWNED BY public.program_versions.id;


--
-- Name: programs; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.programs (
    id integer NOT NULL,
    department_id integer,
    name character varying(300) NOT NULL,
    name_en character varying(300),
    code character varying(30),
    degree character varying(50) DEFAULT 'Đại học'::character varying,
    total_credits integer,
    institution character varying(300),
    degree_name character varying(300),
    training_mode character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.programs OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.programs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.programs_id_seq OWNER TO program;

--
-- Name: programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.programs_id_seq OWNED BY public.programs.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO program;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(100) NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    is_system boolean DEFAULT true
);


ALTER TABLE public.roles OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO program;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: syllabus_assignments; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.syllabus_assignments (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    assigned_to integer,
    assigned_by integer,
    assigner_role_level integer DEFAULT 1,
    deadline date,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.syllabus_assignments OWNER TO program;

--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.syllabus_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.syllabus_assignments_id_seq OWNER TO program;

--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.syllabus_assignments_id_seq OWNED BY public.syllabus_assignments.id;


--
-- Name: teaching_plan; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.teaching_plan (
    id integer NOT NULL,
    version_course_id integer,
    total_hours integer DEFAULT 0,
    hours_theory integer DEFAULT 0,
    hours_practice integer DEFAULT 0,
    hours_project integer DEFAULT 0,
    hours_internship integer DEFAULT 0,
    software character varying(500),
    managing_dept character varying(200),
    batch character varying(10),
    notes text
);


ALTER TABLE public.teaching_plan OWNER TO program;

--
-- Name: teaching_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.teaching_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teaching_plan_id_seq OWNER TO program;

--
-- Name: teaching_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.teaching_plan_id_seq OWNED BY public.teaching_plan.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    department_id integer
);


ALTER TABLE public.user_roles OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO program;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(200) NOT NULL,
    email character varying(200),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO program;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_courses (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    semester integer,
    course_type character varying(20) DEFAULT 'required'::character varying,
    prerequisite_course_ids integer[],
    corequisite_course_ids integer[],
    elective_group character varying(100),
    knowledge_block_id integer
);


ALTER TABLE public.version_courses OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_courses_id_seq OWNER TO program;

--
-- Name: version_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_courses_id_seq OWNED BY public.version_courses.id;


--
-- Name: version_objectives; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_objectives (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.version_objectives OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_objectives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_objectives_id_seq OWNER TO program;

--
-- Name: version_objectives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_objectives_id_seq OWNED BY public.version_objectives.id;


--
-- Name: version_pi_courses; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_pi_courses (
    id integer NOT NULL,
    version_id integer,
    pi_id integer,
    course_id integer,
    contribution_level integer DEFAULT 0
);


ALTER TABLE public.version_pi_courses OWNER TO program;

--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_pi_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_pi_courses_id_seq OWNER TO program;

--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_pi_courses_id_seq OWNED BY public.version_pi_courses.id;


--
-- Name: version_plos; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_plos (
    id integer NOT NULL,
    version_id integer,
    code character varying(20) NOT NULL,
    bloom_level integer DEFAULT 1,
    description text
);


ALTER TABLE public.version_plos OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_plos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_plos_id_seq OWNER TO program;

--
-- Name: version_plos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_plos_id_seq OWNED BY public.version_plos.id;


--
-- Name: version_syllabi; Type: TABLE; Schema: public; Owner: program
--

CREATE TABLE public.version_syllabi (
    id integer NOT NULL,
    version_id integer,
    course_id integer,
    author_id integer,
    status character varying(30) DEFAULT 'draft'::character varying,
    content jsonb DEFAULT '{}'::jsonb,
    is_rejected boolean DEFAULT false,
    rejection_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.version_syllabi OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE; Schema: public; Owner: program
--

CREATE SEQUENCE public.version_syllabi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_syllabi_id_seq OWNER TO program;

--
-- Name: version_syllabi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: program
--

ALTER SEQUENCE public.version_syllabi_id_seq OWNED BY public.version_syllabi.id;


--
-- Name: approval_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs ALTER COLUMN id SET DEFAULT nextval('public.approval_logs_id_seq'::regclass);


--
-- Name: assessment_plans id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans ALTER COLUMN id SET DEFAULT nextval('public.assessment_plans_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: course_clos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos ALTER COLUMN id SET DEFAULT nextval('public.course_clos_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: knowledge_blocks id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks ALTER COLUMN id SET DEFAULT nextval('public.knowledge_blocks_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: plo_pis id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis ALTER COLUMN id SET DEFAULT nextval('public.plo_pis_id_seq'::regclass);


--
-- Name: program_versions id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions ALTER COLUMN id SET DEFAULT nextval('public.program_versions_id_seq'::regclass);


--
-- Name: programs id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs ALTER COLUMN id SET DEFAULT nextval('public.programs_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: syllabus_assignments id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments ALTER COLUMN id SET DEFAULT nextval('public.syllabus_assignments_id_seq'::regclass);


--
-- Name: teaching_plan id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan ALTER COLUMN id SET DEFAULT nextval('public.teaching_plan_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses ALTER COLUMN id SET DEFAULT nextval('public.version_courses_id_seq'::regclass);


--
-- Name: version_objectives id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives ALTER COLUMN id SET DEFAULT nextval('public.version_objectives_id_seq'::regclass);


--
-- Name: version_pi_courses id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses ALTER COLUMN id SET DEFAULT nextval('public.version_pi_courses_id_seq'::regclass);


--
-- Name: version_plos id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos ALTER COLUMN id SET DEFAULT nextval('public.version_plos_id_seq'::regclass);


--
-- Name: version_syllabi id; Type: DEFAULT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi ALTER COLUMN id SET DEFAULT nextval('public.version_syllabi_id_seq'::regclass);


--
-- Data for Name: approval_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.approval_logs (id, entity_type, entity_id, step, action, reviewer_id, notes, created_at) FROM stdin;
\.


--
-- Data for Name: assessment_plans; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.assessment_plans (id, version_id, plo_id, pi_id, sample_course_id, assessment_tool, criteria, threshold, semester, assessor, dept_code, direct_evidence, expected_result, contributing_course_codes) FROM stdin;
1	1	1	\N	2	Bài kiểm tra cuối kỳ	Giải đúng bài toán CTDL	≥70% SV đạt từ 5/10	HK2	GV phụ trách	\N	\N	\N	\N
2	1	2	\N	6	Đồ án môn học	Thiết kế đúng quy trình UML	≥70% SV đạt yêu cầu	HK4	GV + Doanh nghiệp	\N	\N	\N	\N
3	1	3	\N	7	Bài tập thực hành	Chạy đúng chức năng web app	≥80% SV hoàn thành	HK4	GV phụ trách	\N	\N	\N	\N
4	1	4	\N	3	Bài kiểm tra cuối kỳ	Thiết kế CSDL chuẩn 3NF	≥70% SV đạt từ 5/10	HK3	GV phụ trách	\N	\N	\N	\N
5	1	5	\N	9	Báo cáo nhóm	Trình bày rõ ràng, logic	≥75% SV đạt	HK6	Hội đồng chấm	\N	\N	\N	\N
6	1	6	\N	8	Tiểu luận	Phân tích công nghệ AI mới	≥70% SV đạt	HK5	GV phụ trách	\N	\N	\N	\N
137	9	42	114	37	Điểm chuyên cần	Nhận biết các vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK1 / năm 3	Trần Phương Anh	\N	Chuyên cần	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,LAW158,MAN116,ENG183,SLK122,CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN120,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211,AIT129
138	9	42	114	37	Điểm chuyên cần	Nhận biết các vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK1 / năm 3	Trần Phương Anh	\N	Chuyên cần	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,LAW158,MAN116,ENG183,SLK122,CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN120,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211,AIT129
139	9	42	115	29	Rubric	Xây dựng phương án để giải quyết các vấn đề về chính trị và pháp luật, khoa học xã hội và nhânvăn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc	\N	HK2 / năm 1	\N	VJIT	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	LAW158,SKL115,ENG183,CHN546,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318
140	9	42	116	54	Thang điểm bài thi viết	Kết hợp các kiến thức cơ bản, kiến thức chuyên ngành để đóng góp hữu hiệu vào sự phát triển bền vững của xã hội, cộng đồng	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	ENS192,SOS118,CHN5002,PHT304,PHT305,PHT306,PHT307,PHT308,PHT309,PHT310,PHT311,PHT312,PHT313,PHT314,PHT315,PHT316,PHT317,PHT318,NDF108,NDF109,NDF210,NDF211
141	9	43	117	52	Thang điểm bài thi viết	Nhận biết các thành phần cấu tạo nên ngôn ngữ Trung Quốc	\N	HK1/ năm 3	Khuất Thị Tú Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN117,CHN118,CHN122,CHN123,CHN124,CHN125,CHN126,CHN134
142	9	43	118	37	Thang điểm bài thi viết	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc	\N	HK1/ năm 3	Trần Phương Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN118,CHN119,CHN120,CHN121,CHN134,CHN135,AIT1021,CHN1003,CHN4005
143	9	43	119	47	Thang điểm bài thi viết	Sử dụng thành thạo 4 kỹ năng tiếng Trung	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN107,CHN108,CHN109,CHN110,CHN111,CHN112,CHN113,CHN114,CHN115,CHN116,CHN117,CHN118,CHN119,CHN121,CHN122,CHN123,CHN124,CHN125,CHN126
144	9	44	120	25	Thang điểm bài thi viết	Sử dụng ngoại ngữ 2 tiếng Anh trong các tình huống quen thuộc để nâng cao cơ hội việc làm và mở rộng hiểu biết về các nền văn hóa khác.	\N	HK2/ năm 2	\N	K.TA	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	ENC120,ENC121,ENC122,ENC123
145	9	45	121	57	Thang điểm bài thi viết	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Trần Phương Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
146	9	45	121	61	Thang điểm bài thi viết	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Khuất Thị Tú Anh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
147	9	45	121	64	Rubric	Áp dụng thành thạo tiếng Trung vào công việc.	\N	HK2/ năm 3	Lê Quốc Huỳnh	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN112,CHN113,CHN114,CHN115,CHN116,CHN120,CHN121,CHN135,CHN144,AIT1021,CHN1004,AIT1022,CHN4005
148	9	45	122	47	Thang điểm bài thi viết	Nhận biết chữ Hán phồn thể và thành thạo chữ Hán giản thể trong công việc.	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN121,CHN122,CHN123,CHN124,CHN125,CHN126
149	9	45	123	54	Thang điểm bài thi viết	Khai thác thông tin và cập nhật kiến thức chuyên ngành thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c) văn hóa Trung Hoa, hoặc (d) khóa luận tốt nghiệp.	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	SOS118,CHN5002,CHN546,CHN135,CHN128,CHN144,AIT1021,AIT1022,CHN4005
150	9	46	124	53	Thang điểm bài thi viết	Phân tích thông tin, đưa ra luận điểm có căn cứ.	\N	HK2/ năm 3	Sú Xuân Thanh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN119,CHN120,CHN134,CHN137,CHN139,AIT1022,CHN4005,CHN1003
151	9	46	125	47	Thang điểm bài thi viết	Hệ thống lại vấn đề, đưa ra kết luận về cách thức vận hành của vấn đề hệ thống.	\N	HK1/ năm 3	Phạm Minh Thông	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	POS104,POS105,POS106,POS107,POS103,CHN121
152	9	47	126	27	Rubric	Lập kế hoạch, thực hiện và đánh giá công việc chuyên môn	\N	HK2/ năm 2	\N	K.TA	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	ENS192,LAW158,SOS118,CHN5002,CHN546
153	9	47	127	59	Thang điểm bài thi viết	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Lê Quốc Huỳnh	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
154	9	47	127	60	Thang điểm bài thi viết	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Đào Thị Châu Giang	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
155	9	47	127	63	Rubric	Sử dụng tốt các chiến lược giaotiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.	\N	HK2/ năm 3	Thái Thị Ngọc Hương	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN134,CHN128,CHN137,CHN139,CHN4005,CHN1003,CHN1004
156	9	47	128	55	Rubric	Áp dụng thành thạo kỹ năng giao tiếp ứng xử cần thiết để thực hiện các nhiệm vụ phức tạp.	\N	HK2/ năm 3	Ngô Thế Sử	K.TQH	Bài thu hoạch	Tối thiểu 70% người học đáp ứng	SOS118,CHN5002
157	9	47	129	56	Rubric	Ứng dụng công nghệ thông tin để soạn thảo, trình bày các loại văn bản  trong học tập, nghiên cứu và công việc có hiệu quả.	\N	HK1/ năm 4	Đào Thị Châu Giang	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	MAN116,CHN546
158	9	47	130	26	Rubric	Sử dụng có hiệu quả các phần mềm chuyên dụng để phục vụ học tập và công việc chuyên môn liên quan đến tiếng Trung	\N	HK1/ năm1	\N	K.CNTT	Đồ án	Tối thiểu 70% người học đáp ứng	AIT129,SOS118,CHN139,AIT1022,CHN1004,CHN4005
159	9	48	131	\N	Rubric	Đưa ra các nhận định cá nhân trong điều kiện làm việc thay đổi	\N	HK2 / năm 1	\N	VJIT	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	POS103,ENG183,SLK122
160	9	48	132	56	Rubric	Xác định được đầy đủ mục tiêu của nhóm, vai trò, trách nhiệm của các thành viên	\N	HK1/ năm 4	Đào Thị Châu Giang	K.TQH	Báo cáo cuối kỳ	Tối thiểu 70% người học đáp ứng	CHN546
161	9	48	133	54	Thang điểm bài thi viết	Tham gia hoạch định, lên chương trình và phối hợp trong thực hiện hoạt động nhóm đạt được mục tiêu đã đề ra.	\N	HK1/ năm 4	Ngô Thế Sử	K.TQH	Câu hỏi bài kiểm tra	Tối thiểu 70% người học đáp ứng	POS104,POS106,POS107,ENS192,SKL115,MAN116,SLK122,SOS118,CHN5002
162	9	48	134	53	Điểm chuyên cần	Nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.	\N	HK2/ năm 3	Sú Xuân Thanh	K.TQH	Chuyên cần	Tối thiểu 70% người học đáp ứng	LAW158,SKL115,MAN116,SLK122,CHN134,SOS118,CHN5002,CHN135,CHN128,CHN137,CHN139,CHN144,AIT1021,CHN1003,CHN1004,AIT1022,CHN4005,NDF108,NDF109,NDF210,NDF211
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.audit_logs (id, user_id, action, target, details, ip, created_at) FROM stdin;
1	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:23:30.661034+00
2	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 09:24:13.773942+00
3	1	POST /api/users	/api/users	{"params":{},"bodyKeys":["display_name","email","password","username"]}	172.18.0.1	2026-03-25 09:27:04.502129+00
4	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-25 09:27:18.799021+00
5	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:30:47.424145+00
6	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:35:15.254903+00
7	1	DELETE /api/programs/2	/api/programs/2	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:45:40.754262+00
8	1	PUT /api/programs/1	/api/programs/1	{"params":{"id":"1"},"bodyKeys":["name","name_en","code","department_id","degree","total_credits","institution","degree_name","training_mode","notes"]}	172.18.0.1	2026-03-25 09:45:53.226523+00
9	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:46:02.928121+00
10	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 09:47:20.3843+00
11	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 09:48:01.640783+00
12	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 10:45:17.058544+00
13	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:12:35.754412+00
14	1	DELETE /api/programs/3	/api/programs/3	{"params":{"id":"3"},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:25.846238+00
15	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:31.906452+00
16	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:38:41.139763+00
17	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 11:40:24.894399+00
18	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id"]}	172.18.0.1	2026-03-25 11:40:39.845973+00
19	1	POST /api/versions/1/assignments	/api/versions/1/assignments	{"params":{"vId":"1"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-25 16:01:29.145986+00
20	2	POST /api/my-assignments/1/create-syllabus	/api/my-assignments/1/create-syllabus	{"params":{"assignmentId":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:01:39.037698+00
21	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:29:59.750868+00
22	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:29:59.7676+00
23	1	POST /api/versions/4/assignments	/api/versions/4/assignments	{"params":{"vId":"4"},"bodyKeys":["course_id","assigned_to","deadline"]}	172.18.0.1	2026-03-25 16:34:20.695698+00
24	2	POST /api/my-assignments/2/create-syllabus	/api/my-assignments/2/create-syllabus	{"params":{"assignmentId":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:35:43.326965+00
25	2	POST /api/syllabi/2/import-pdf	/api/syllabi/2/import-pdf	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:35:52.671848+00
26	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:35:52.713731+00
27	2	POST /api/syllabi/2/import-pdf	/api/syllabi/2/import-pdf	{"params":{"id":"2"},"bodyKeys":[]}	172.18.0.1	2026-03-25 16:39:31.010983+00
28	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:31.053356+00
29	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:35.479796+00
30	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.97764+00
31	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.984787+00
32	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:38.991555+00
33	2	POST /api/syllabi/2/clos	/api/syllabi/2/clos	{"params":{"sId":"2"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-25 16:39:39.002067+00
34	2	PUT /api/syllabi/2/clo-plo-map	/api/syllabi/2/clo-plo-map	{"params":{"sId":"2"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-25 16:39:39.010138+00
35	2	PUT /api/syllabi/2/clo-plo-map	/api/syllabi/2/clo-plo-map	{"params":{"sId":"2"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-25 16:39:49.155541+00
36	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:54.767459+00
37	2	PUT /api/syllabi/2	/api/syllabi/2	{"params":{"id":"2"},"bodyKeys":["content"]}	172.18.0.1	2026-03-25 16:39:56.988855+00
38	1	PUT /api/versions/1	/api/versions/1	{"params":{"id":"1"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-25 17:19:05.283295+00
39	1	PUT /api/versions/1	/api/versions/1	{"params":{"id":"1"},"bodyKeys":["academic_year","version_name","total_credits","training_duration","change_type","effective_date","change_summary","grading_scale","graduation_requirements","job_positions","further_education","reference_programs","training_process","admission_targets","admission_criteria"]}	172.18.0.1	2026-03-25 17:19:08.479909+00
40	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:26:39.837052+00
41	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:26:52.457649+00
42	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:27:55.651607+00
43	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:28:49.327553+00
44	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:29:59.442515+00
45	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:30:09.231489+00
46	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:30:28.310459+00
47	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:36:32.045461+00
48	1	DELETE /api/programs/4	/api/programs/4	{"params":{"id":"4"},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:37:26.43357+00
49	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-25 17:37:30.592353+00
50	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 05:09:35.837338+00
51	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 05:09:35.860188+00
52	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.40093+00
53	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.411296+00
54	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.421176+00
55	2	POST /api/syllabi/1/clos	/api/syllabi/1/clos	{"params":{"sId":"1"},"bodyKeys":["code","description"]}	172.18.0.1	2026-03-26 05:09:46.430976+00
56	2	PUT /api/syllabi/1/clo-plo-map	/api/syllabi/1/clo-plo-map	{"params":{"sId":"1"},"bodyKeys":["mappings"]}	172.18.0.1	2026-03-26 05:09:46.447184+00
57	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	172.18.0.1	2026-03-26 05:11:25.546117+00
58	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 06:30:19.217774+00
59	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 06:30:19.260318+00
60	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	172.18.0.1	2026-03-26 06:30:49.304025+00
61	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	172.18.0.1	2026-03-26 06:30:49.345982+00
62	2	POST /api/syllabi/1/import-pdf	/api/syllabi/1/import-pdf	{"params":{"id":"1"},"bodyKeys":[]}	127.0.0.1	2026-03-26 07:17:42.072728+00
63	2	PUT /api/syllabi/1	/api/syllabi/1	{"params":{"id":"1"},"bodyKeys":["content"]}	127.0.0.1	2026-03-26 07:17:42.082392+00
64	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 07:20:05.107968+00
65	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 07:20:56.605184+00
66	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 07:21:12.66151+00
67	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 08:09:10.144588+00
68	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 08:28:16.744112+00
69	1	PUT /api/courses/67	/api/courses/67	{"params":{"id":"67"},"bodyKeys":["code","name","credits","credits_theory","credits_practice","credits_project","credits_internship","department_id","description"]}	127.0.0.1	2026-03-26 09:21:39.025677+00
70	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 09:23:06.721232+00
71	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name"]}	127.0.0.1	2026-03-26 09:31:16.115496+00
72	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name"]}	127.0.0.1	2026-03-26 09:31:16.122904+00
73	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name","parent_id"]}	127.0.0.1	2026-03-26 09:31:16.130069+00
74	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name","parent_id"]}	127.0.0.1	2026-03-26 09:31:16.138977+00
75	1	POST /api/versions/1/knowledge-blocks	/api/versions/1/knowledge-blocks	{"params":{"vId":"1"},"bodyKeys":["name"]}	127.0.0.1	2026-03-26 09:31:16.143749+00
76	1	DELETE /api/programs/5	/api/programs/5	{"params":{"id":"5"},"bodyKeys":[]}	127.0.0.1	2026-03-26 09:31:33.525165+00
77	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 09:31:37.141983+00
78	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 09:31:47.552843+00
79	1	DELETE /api/programs/6	/api/programs/6	{"params":{"id":"6"},"bodyKeys":[]}	127.0.0.1	2026-03-26 11:49:56.784201+00
80	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 11:50:00.845715+00
81	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 11:50:09.417915+00
82	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:48:59.169083+00
83	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:51:41.19564+00
84	1	POST /api/import/save	/api/import/save	{"params":{},"bodyKeys":["program","version","general_objective","objectives","plos","pis","poploMatrix","knowledgeBlocks","courses","coursePIMatrix","courseDescriptions","teachingPlan","assessmentPlan","warnings","department_id","existing_program_id"]}	127.0.0.1	2026-03-26 12:56:06.415183+00
85	1	DELETE /api/versions/11	/api/versions/11	{"params":{"id":"11"},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:56:26.075192+00
86	1	POST /api/import/parse-word	/api/import/parse-word	{"params":{},"bodyKeys":[]}	127.0.0.1	2026-03-26 12:56:32.528098+00
87	1	PUT /api/roles/1/permissions	/api/roles/1/permissions	{"params":{"id":"1"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.271977+00
88	1	PUT /api/roles/2/permissions	/api/roles/2/permissions	{"params":{"id":"2"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.281656+00
89	1	PUT /api/roles/3/permissions	/api/roles/3/permissions	{"params":{"id":"3"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.297212+00
90	1	PUT /api/roles/4/permissions	/api/roles/4/permissions	{"params":{"id":"4"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.307684+00
91	1	PUT /api/roles/5/permissions	/api/roles/5/permissions	{"params":{"id":"5"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.316465+00
92	1	PUT /api/roles/6/permissions	/api/roles/6/permissions	{"params":{"id":"6"},"bodyKeys":["permission_ids"]}	172.18.0.1	2026-03-26 15:07:44.322664+00
93	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 15:28:12.255438+00
94	1	DELETE /api/users/2/roles/TRUONG_NGANH/16	/api/users/2/roles/TRUONG_NGANH/16	{"params":{"userId":"2","roleCode":"TRUONG_NGANH","deptId":"16"},"bodyKeys":[]}	172.18.0.1	2026-03-26 15:28:26.758255+00
95	1	POST /api/users/2/roles	/api/users/2/roles	{"params":{"id":"2"},"bodyKeys":["role_code","department_id"]}	172.18.0.1	2026-03-26 15:28:32.504205+00
\.


--
-- Data for Name: clo_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.clo_plo_map (clo_id, plo_id, contribution_level) FROM stdin;
5	6	3
6	6	3
7	6	3
8	1	3
\.


--
-- Data for Name: course_clos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_clos (id, version_course_id, code, description) FROM stdin;
5	1	CLO1	Giải thích các khái niệm cơ bản về TTNT và cách TTNT hoạt động.
6	1	CLO2	Sử dụng các công cụ TTNT hiệu quả và có trách nhiệm.
7	1	CLO3	Áp dụng TTNT để phát triển các giải pháp một cách sáng tạo
8	1	CLO4	Thể hiện thái độ chuyên cần và tích cực trong học tập để tự điều chỉnh và phát triển năng lực học tập suốt đời
\.


--
-- Data for Name: course_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.course_plo_map (version_id, course_id, plo_id, contribution_level) FROM stdin;
1	5	1	2
1	5	3	3
1	6	1	3
1	6	3	2
1	8	4	3
1	8	2	2
1	7	2	2
1	7	3	3
1	9	1	1
1	9	2	2
1	10	2	3
1	10	5	2
1	10	6	1
1	11	2	2
1	11	3	3
1	11	6	2
1	12	1	2
1	12	6	3
1	15	2	3
1	15	5	2
1	15	6	2
1	16	5	3
1	16	6	2
9	362	42	1
9	362	46	1
9	362	48	1
9	363	42	1
9	363	46	1
9	363	48	1
9	364	42	2
9	364	46	2
9	364	48	2
9	365	42	1
9	365	46	1
9	365	48	1
9	366	42	2
9	366	46	2
9	366	48	2
9	367	44	1
9	368	44	1
9	369	44	2
9	370	44	3
9	371	42	1
9	371	47	3
9	372	42	2
9	372	46	2
9	372	48	2
9	373	42	2
9	373	46	2
9	373	48	2
9	374	42	3
9	374	48	3
9	375	42	2
9	375	47	3
9	375	48	2
9	376	42	1
9	376	48	1
9	377	42	3
9	377	48	3
9	378	42	1
9	378	43	1
9	379	42	1
9	379	43	1
9	380	42	2
9	380	43	2
9	381	42	2
9	381	43	2
9	382	42	3
9	382	43	3
9	383	42	1
9	383	43	1
9	383	45	1
9	384	42	1
9	384	43	1
9	384	45	1
9	385	42	2
9	385	43	2
9	385	45	2
9	386	42	2
9	386	43	2
9	386	45	2
9	387	42	3
9	387	43	3
9	387	45	3
9	388	42	1
9	388	43	1
9	389	42	1
9	389	43	1
9	390	42	2
9	390	43	2
9	390	46	2
9	391	42	2
9	391	43	2
9	391	45	2
9	391	46	2
9	392	42	3
9	392	43	3
9	392	45	3
9	392	46	3
9	393	42	1
9	393	43	1
9	393	45	1
9	394	42	1
9	394	43	1
9	394	45	1
9	395	42	2
9	395	43	2
9	395	45	2
9	396	42	2
9	396	43	2
9	396	45	2
9	397	42	3
9	397	43	3
9	397	45	3
9	398	43	3
9	398	46	3
9	398	47	3
9	398	48	3
9	399	42	3
9	399	45	3
9	399	46	3
9	399	47	3
9	399	48	3
9	400	42	3
9	400	45	3
9	400	46	3
9	400	47	3
9	400	48	3
9	401	42	3
9	401	45	3
9	401	46	3
9	401	47	3
9	401	48	3
9	402	43	3
9	402	45	3
9	402	48	3
9	403	45	3
9	403	47	3
9	403	48	3
9	404	46	3
9	404	47	3
9	404	48	3
9	405	46	3
9	405	47	3
9	405	48	3
9	406	45	3
9	406	48	3
9	407	43	3
9	407	45	3
9	407	48	3
9	408	43	3
9	408	46	3
9	408	47	3
9	408	48	3
9	409	45	3
9	409	47	3
9	409	48	3
9	410	45	3
9	410	46	3
9	410	47	3
9	410	48	3
9	411	43	3
9	411	45	3
9	411	46	3
9	411	47	3
9	411	48	3
9	412	42	1
9	413	42	1
9	414	42	1
9	415	42	1
9	416	42	1
9	417	42	1
9	418	42	1
9	419	42	1
9	420	42	1
9	421	42	1
9	422	42	1
9	423	42	1
9	424	42	1
9	425	42	1
9	426	42	1
9	427	42	1
9	427	48	1
9	428	42	1
9	428	48	1
9	429	42	2
9	429	48	2
9	430	42	2
9	430	48	2
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.courses (id, code, name, credits, credits_theory, credits_practice, credits_project, credits_internship, department_id, description) FROM stdin;
1	IT001	Nhập môn lập trình	3	2	1	0	0	5	Giới thiệu tư duy lập trình, cú pháp C/C++, cấu trúc điều khiển, hàm, mảng
2	IT002	Cấu trúc dữ liệu và giải thuật	3	2	1	0	0	5	Danh sách liên kết, ngăn xếp, hàng đợi, cây, đồ thị, sắp xếp, tìm kiếm
3	IT003	Cơ sở dữ liệu	3	2	1	0	0	5	Mô hình quan hệ, SQL, chuẩn hóa, transaction, thiết kế CSDL
4	IT004	Lập trình hướng đối tượng	3	2	1	0	0	5	OOP với Java: class, kế thừa, đa hình, interface, design pattern cơ bản
5	IT005	Mạng máy tính	3	2	1	0	0	5	Mô hình OSI/TCP-IP, định tuyến, giao thức mạng, bảo mật mạng cơ bản
6	IT006	Công nghệ phần mềm	3	2	1	0	0	5	Quy trình SDLC, Agile/Scrum, UML, kiểm thử phần mềm, quản lý dự án
7	IT007	Phát triển ứng dụng Web	3	1	2	0	0	5	HTML/CSS/JS, React/Vue, Node.js, REST API, triển khai ứng dụng web
8	IT008	Trí tuệ nhân tạo	3	2	1	0	0	5	Tìm kiếm, học máy, mạng nơ-ron, xử lý ngôn ngữ tự nhiên, ứng dụng AI
9	IT009	Đồ án chuyên ngành	3	0	0	3	0	5	Thực hiện dự án CNTT theo nhóm, áp dụng quy trình phát triển phần mềm
10	IT010	Thực tập doanh nghiệp	3	0	0	0	3	5	Thực tập tại doanh nghiệp CNTT, báo cáo kết quả thực tập
11	GE001	Triết học Mác - Lênin	3	3	0	0	0	5	Các nguyên lý cơ bản của chủ nghĩa Mác-Lênin về triết học
12	GE002	Tiếng Anh 1	3	2	1	0	0	5	Ngữ pháp, từ vựng, kỹ năng nghe-nói-đọc-viết trình độ A2-B1
13	GE003	Toán cao cấp	3	3	0	0	0	5	Đại số tuyến tính, giải tích, xác suất thống kê ứng dụng trong CNTT
14	GE004	Vật lý đại cương	3	2	1	0	0	5	Cơ học, điện từ, quang học — nền tảng cho kỹ thuật phần cứng
15	IT011	An toàn thông tin	3	2	1	0	0	5	Mã hóa, xác thực, bảo mật hệ thống, tấn công và phòng thủ mạng
16	IT012	Điện toán đám mây	3	1	2	0	0	5	AWS/Azure/GCP, container, microservices, CI/CD, serverless
45	CHN119	Tiếng Trung – Đọc 3	3	3	0	0	0	1	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, các điểm ngữ pháp ở mức độ trung cấp, các mẫu câu thường gặp thông qua nội dung các bài khóa xoay quanh các chủ đề như văn hóa, xã hội, kinh tế,... Mỗi bài học đều có bài khóa, từ vựng, điểm ngữ pháp cũng như phần luyện tập. Những bài tập này cũng được nâng lên một tầm cao mới, từ việc đọc đúng âm, rõ nghĩa, hiểu nội dung chính đến khả năng phân tích, đánh giá và đưa ra luận điểm cá nhân.
17	POS104	Triết học Mác - Lênin	3	3	0	0	0	1	Triết học Mác – Lê nin là học phần bắt buộc trong khối kiến thức cơ bản nhằm trang bị các kiến thức cơ bản về triết học học Mác – Lênin, học phần được cấu trúc gồm: (i) Trình bày những nét khái quát về triết học, triết học Mác – Lênin trong đời sống xã hội; (ii) Trình bày những nội dung cơ bản của chủ nghĩa duy vật biện chứng như: vật chất và ý thức; phép biện chứng duy vật; lý luận nhận thức của chủ nghĩa duy vật biện chứng; (iii) Trình bày những nội dung cơ bản của chủ nghĩa duy vật lịch sử, gồm vấn đề hình thái kinh tế - xã hội; giai cấp và dân tộc; nhà nước và cách mạng xã hội; ý thức xã hội; triết học về con người, quần chúng nhân dân.
18	POS105	Kinh tế chính trị Mác - Lênin	2	2	0	0	0	1	Nội dung học phần gồm 6 bài trong đó:Bài 1: Bàn về đối tượng, phương pháp nghiên cứu và chức năng của Kinh tế chính trị Mác – Lênin. Từ bài 2 đến bài 6 trình bày nội dung cốt lõi của kinh tế chính trị Mác – Lênin theo mục tiêu môn học. Cụ thể các vấn đề như: Hàng hóa, thị trường và vai trò của các chủ thể trong nền kinh tế thị trường; Giá trị thặng dư và quan hệ lợi ích trong nền kinh tế thị trường; Cạnh tranh và độc quyền trong nền kinh tế thị trường; Kinh tế thị trường định hướng XHCN ở Việt Nam; Cách mạng công nghiệp và hội nhập kinh tế quốc tế trong phát triển của Việt Nam
19	POS106	Chủ nghĩa xã hội khoa học	2	2	0	0	0	1	Chủ nghĩa xã hội khoa học là học phần bắt buộc trong khối kiến thức cơ bản, cung cấp những hiểu biết nền tảng về quá trình hình thành và phát triển của CNXHKH. Học phần gồm 7 bài, tập trung vào các nội dung chính: (1) sự ra đời và các giai đoạn phát triển của Chủ nghĩa xã hội khoa học; (2) sứ mệnh lịch sử của giai cấp công nhân, đặc biệt trong bối cảnh Việt Nam; (3) khái niệm chủ nghĩa xã hội và thời kỳ quá độ; (4) những vấn đề quy luật trong cách mạng xã hội chủ nghĩa như dân chủ, nhà nước pháp quyền; (5) cơ cấu xã hội - giai cấp và liên minh giai cấp trong thời kỳ quá độ; (6) vấn đề dân tộc, tôn giáo và mối quan hệ giữa chúng trong chủ nghĩa xã hội; (7) vai trò, chức năng của gia đình và định hướng xây dựng gia đình trong thời kỳ quá độ lên chủ nghĩa xã hội tại Việt Nam.
20	POS107	Lịch sử Đảng Cộng sản Việt Nam	2	2	0	0	0	1	Nội dung học phần gồm 5 bài: (1) trình bày đối tượng, chức năng, nhiệm vụ, phương pháp nghiên cứu, học tập môn Lịch sử Đảng; (2) Đảng cộng sản Việt Nam ra đời và lãnh đạo cách mạng giải phóng dân tộc (1930-1945); (3) trình bày về quá trình lãnh đạo của Đảng trong hai cuộc kháng chiến chống ngoại xâm chống Pháp và chống Mỹ (1945-1975); (4) trình bày những nội dung cơ bản về quá trình phát triển đường lối và lãnh đạo của Đảng trong quá trình đưa cả nước quá độ lên chủ nghĩa xã hội và tiến hành công cuộc đổi mới (1975 đến nay); (5) tổng kết những thắng lợi vĩ đại của dân tộc dưới sự lãnh đạo của Đảng và những bài học kinh nghiệm của Đảng trong quá trình lãnh đạo cách mạng.
21	POS103	Tư tưởng Hồ Chí Minh	2	2	0	0	0	1	Tư tưởng Hồ Chí Minh là học phần cơ sở bắt buộc trong chương trình đào tạo Đại học của tất cả các chuyên ngành; với cấu trúc nội dung bao gồm 6 bài: (1) Khái niệm, đối tượng, phương pháp nghiên cứu và ý nghĩa học tập môn Tư tưởng Hồ Chí Minh; (2) Cơ sở, quá trình hình thành và phát triển tư tưởng Hồ Chí Minh; (3) Tư tưởng Hồ Chí Minh về độc lập dân tộc và chủ nghĩa xã hội; (4) Tư tưởng Hồ Chí Minh về Đảng Cộng sản Việt Nam và Nhà nước của nhân dân, do nhân dân, vì nhân dân; (5) Tư tưởng Hồ Chí Minh về đại đoàn kết toàn dân tộc và đoàn kết quốc tế; (6) Tư tưởng Hồ Chí Minh về văn hóa, đạo đức và con người
22	ENC120	Anh ngữ 1	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 1 được thiết kế giảng dạy với 6 đơn vị bài học, bao gồm kiến thức ngôn ngữ về từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc trong cuộc sống, trải nghiệm cá nhân, quản lý thời gian, du lịch thế giới, cảnh quan, thời trang,  tương đương trình độ Bậc 2 theo khung NLNNVN.
23	ENC121	Anh ngữ 2	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 2 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần trang bị kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc như âm nhạc, cuộc sống, các mối quan hệ, du lịch, môi trường, tương đương trình độ trung cấp B1.
24	ENC122	Anh ngữ 3	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 3 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần cung cấp kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề quen thuộc trong cuộc sống như giao tiếp, trao đổi thông tin, thói quen, thực phẩm, du lịch, tương đương trình độ trung cấp B1+
25	ENC123	Anh ngữ 4	3	3	0	0	0	1	Nội dung học phần Anh Ngữ 4 được thiết kế giảng dạy với 6 đơn vị bài học. Học phần trang bị kiến thức tiếng Anh với từ vựng, cấu trúc ngữ pháp và kỹ năng giao tiếp về các chủ đề trong cuộc sống thường ngày, nêu cách suy nghĩ, giải quyết vấn đề, tương đương trình độ trung cấp B1+
26	AIT129	Trí tuệ nhân tạo ứng dụng	3	3	0	0	0	1	Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn
27	ENS192	Phát triển bền vững	3	3	0	0	0	1	Học phần Phát triển bền vững cung cấp nền tảng kiến thức về khái niệm, nguyên tắc và thực tiễn nhằm đạt được sự cân bằng giữa các mục tiêu kinh tế, xã hội và môi trường. Nội dung học phần bao gồm: tổng quan về phát triển bền vững, lịch sử hình thành và các thách thức hiện tại; vai trò của tài nguyên môi trường, chiến lược khai thác và bảo vệ tài nguyên bền vững; mối quan hệ giữa kinh tế xanh, kinh tế tuần hoàn và bảo vệ môi trường; yếu tố xã hội như giáo dục, y tế, bình đẳng và cộng đồng trong phát triển bền vững; cùng với các công cụ quản trị và chính sách quốc gia, quốc tế nhằm thúc đẩy mục tiêu này.  Qua đó, học phần trang bị cho sinh viên khả năng phân tích vấn đề, đề xuất giải pháp và ứng dụng tư duy hệ thống vào thực tế, đặc biệt trong việc giải quyết các thách thức phát triển bền vững như quản lý và bảo vệ tài nguyên, giảm thiểu tác động tiêu cực đến môi trường, thúc đẩy kinh tế xanh và phát triển xã hội bền vững.
28	LAW158	Luật và Khởi nghiệp	3	3	0	0	0	1	Học phần cung cấp những kiến thức cơ bản về Nhà nước, Pháp luật và Khởi nghiệp, giúp sinh viên áp dụng vào thực tiễn, đặc biệt trong bối cảnh khởi nghiệp kinh doanh. Nội dung gồm hai phần chính:(1) Những vấn đề cơ bản về Nhà nước và Pháp luật, giúp sinh viên hiểu về bộ máy Nhà nước, hệ thống pháp luật Việt Nam và các ngành luật quan trọng;(2) Tổng quan về Khởi nghiệp, trang bị kiến thức về ý tưởng kinh doanh, nghiên cứu thị trường, lập kế hoạch kinh doanh, tài chính, nhân sự và quản lý rủi ro. Học phần hướng đến việc nâng cao nhận thức, khả năng phân tích và lập kế hoạch, đồng thời khuyến khích tinh thần chủ động, trách nhiệm, tuân thủ pháp luật và đạo đức kinh doanh.
29	SKL115	Tư duy thiết kế dự án	3	3	0	0	0	1	Học phần "Tư duy thiết kế dự án" cung cấp kiến thức và kỹ năng thiết yếu để phát hiện và giải quyết vấn đề thông qua quy trình tư duy thiết kế. Nội dung học phần xoay quanh quy trình gồm 7 bước chính: (1) Phát hiện vấn đề; (2) Khảo sát thực trạng vấn đề; (3) Khảo sát nhu cầu giải quyết vấn đề của các bên liên quan; (4) Khảo sát và đánh giá các giải pháp hiện có; (5) Phân tích cấu trúc nguyên nhân vấn đề; (6) Thiết lập điều kiện tiên quyết và (7) Sáng tạo và đề xuất giải pháp. Với định hướng thực tiễn và bền vững, học phần không chỉ hỗ trợ phát triển các kỹ năng cá nhân mà còn góp phần giải quyết các vấn đề xã hội theo các mục tiêu phát triển bền vững của Liên Hợp Quốc (SDGs).
30	MAN116	Quản trị học	3	3	0	0	0	1	Quản trị học là học phần cung cấp kiến thức cơ bản về công tác quản trị một tổ chức. Học phần này trang bị cho người học những nội dung về khái niệm, vai trò của công tác quản trị trong một tổ chức, phân loại môi trường và cách thức quản trị sự bất trắc môi trường, các chức năng của quản trị (Hoạch định, tổ chức, điều khiển, kiểm soát). Ngoài ra, học phần còn đề cập đến các vấn đề liên quan tác động đến hiệu quả quản trị tổ chức như thông tin quản lý, văn hóa tổ chức, kỹ năng ra quyết định của nhà quản trị.
31	ENG183	Dẫn luận ngôn ngữ	3	3	0	0	0	1	Học phần gồm 05 đơn vị bài học cung cấp cho sinh viên:- Kiến thức cơ bản về ngôn ngữ và ngôn ngữ học: đặc trưng, chức năng, hệ thống, cấu trúc, loại hình ngôn ngữ; các  bình diện sử dụng ngôn ngữ: cú pháp, từ vựng, ngữ nghĩa…- Môn học còn cung cấp những kiến thức cơ bản của tiếng Việt, giúp người học phát triển các kỹ năng sử dụng từ, viết câu; có khả năng phát hiện và sửa chữa các lỗi sử dụng tiếng Việt, các hình thức và cách diễn đạt ngôn ngữ.
32	SLK122	Kỹ năng phát triển bản thân	3	3	0	0	0	1	Học phần trang bị cho sinh viên các kiến thức và kỹ năng cần thiết để phát triển bản thân và sự nghiệp trong tương lai thông qua các kỹ năng như kỹ năng tìm kiếm nguồn lực hỗ trợ phát triển bản thân, xây dựng tác phong làm việc, kỹ năng tìm việc. Học phần gồm 5 bài học về hiểu bản thân, các nguồn lực và phát triển bản thân, kỹ năng tìm kiếm và khai thác nguồn lực, tác phong làm việc chuyên nghiệp, và dự án phát triển bản thân. Thông qua các bài học lý thuyết và thực hành, sinh viên sẽ có thể: (1) Hiểu rõ bản thân và chủ động tìm kiếm các nguồn lực phù hợp để phát triển bản thân; (2) Xây dựng phong cách làm việc chuyên nghiệp và áp dụng tác phong đó vào học tập và công việc (3) Lập kế hoạch và xây dựng được dự án phát triển bản thân.
33	CHN107	Tiếng Trung – Nghe 1	3	3	0	0	0	1	Nội dung luyện tập gồm nghe và đọc hệ thống phiên âm, nghe những câu văn dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc
34	CHN108	Tiếng Trung – Nghe 2	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những câu văn, đoạn đối thoại dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc.
35	CHN109	Tiếng Trung – Nghe 3	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những đoạn văn, bài hội thoại dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc.
36	CHN110	Tiếng Trung – Nghe 4	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những đoạn văn dài, đoạn hội thoại dài dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên sẽ dần dần quen cách sử dụng các mẫu câu theo văn phong của người Trung Quốc
37	CHN111	Tiếng Trung – Nghe 5	3	3	0	0	0	1	Nội dung luyện tập gồm nghe những đoạn văn dài, đoạn hội thoại dài dựa trên các kiến thức ngữ pháp và từ vựng đã được học. Bên cạnh đó, sinh viên có khả năng phân tích thông tin trong các tình huống giao tiếp phức tạp
38	CHN112	Tiếng Trung – Nói 1	3	3	0	0	0	1	Học phần Tiếng Trung Nói 1 gồm 12 bài học và 3 bài ôn tập, tập trung vào việc giới thiệu hệ thống phiên âm, thanh điệu và ngữ âm cơ bản trong tiếng Trung. Sinh viên được học cách viết phiên âm, luyện đọc và sử dụng các mẫu câu cơ bản trong các chủ đề giao tiếp hàng ngày như giới thiệu bản thân, chào hỏi, hỏi thăm sức khỏe, số lượng, tiền tệ, nơi chốn. Học phần giúp sinh viên xây dựng khả năng phản xạ giao tiếp, luyện tập các đoạn hội thoại ngắn và làm quen với cách diễn đạt của người bản địa. Ngoài ra, các bài tập thực hành như đóng vai, luyện tập theo cặp và nhóm được lồng ghép để tăng sự hứng thú và hiệu quả học tập
39	CHN113	Tiếng Trung – Nói 2	3	3	0	0	0	1	Học phần Tiếng Trung Nói 2 gồm 12 bài học và 3 bài ôn tập, tiếp tục củng cố kỹ năng nói thông qua các chủ đề quen thuộc trong cuộc sống hàng ngày như mua sắm, gọi món ăn, giới thiệu quê hương, gọi điện thoại và tìm bạn học ngoại ngữ. Sinh viên được học cách nắm bắt ý chính của bài khóa, luyện tập các đoạn hội thoại ngắn và áp dụng từ vựng, ngữ pháp đã học vào giao tiếp. Học phần chú trọng vào việc thực hành nghe – nói, giúp sinh viên phản xạ nhanh hơn và giao tiếp tự tin hơn trong các tình huống thường gặp. Các hoạt động nhóm và bài tập thực hành giúp sinh viên nâng cao khả năng giao tiếp và phát triển kỹ năng làm việc nhóm.
40	CHN114	Tiếng Trung – Nói 3	3	3	0	0	0	1	Học phần Tiếng Trung Nói 3 gồm 12 bài học và 3 bài ôn tập, xoay quanh các chủ đề giao tiếp thực tiễn như đi tàu xe, gửi bưu phẩm, khám bệnh, và các vấn đề sinh hoạt thường ngày. Sinh viên được học các mẫu câu mới, tích lũy vốn từ vựng và luyện tập các đoạn hội thoại phù hợp với văn phong của người bản địa. Học phần giúp sinh viên rèn luyện kỹ năng phản xạ, thực hành xây dựng và trình bày các đoạn hội thoại ngắn, cũng như bày tỏ quan điểm cá nhân trong các tình huống cụ thể. Các bài tập nhóm, đóng vai và thuyết trình được lồng ghép để tăng cường khả năng giao tiếp hiệu quả
41	CHN115	Tiếng Trung – Nói 4	3	3	0	0	0	1	Học phần Tiếng Trung Nói 4 gồm 12 bài học và 3 bài ôn tập, bao gồm các chủ đề đa dạng về cuộc sống, xã hội, gia đình và học tập. Sinh viên sẽ được học cách xây dựng bài nói theo từng chủ đề, vận dụng từ vựng và ngữ pháp đã học để thảo luận, tranh luận và giải quyết vấn đề. Học phần tập trung vào việc phát triển khả năng tư duy logic, diễn đạt ý tưởng rõ ràng và tự nhiên. Thông qua các bài tập nhóm, thuyết trình và tranh luận, sinh viên sẽ cải thiện khả năng giao tiếp, trình bày và phản biện trong các ngữ cảnh cụ thể.
42	CHN116	Tiếng Trung – Nói 5	3	3	0	0	0	1	Học phần Tiếng Trung Nói 5 tập trung phát triển kỹ năng giao tiếp nâng cao bằng tiếng Trung trong các tình huống thực tế và chuyên môn. Nội dung học phần bao gồm việc củng cố và mở rộng vốn từ vựng, cấu trúc ngữ pháp, cùng cách diễn đạt phong phú trong các chủ đề nâng cao. Sinh viên sẽ được thực hành các kỹ năng như thuyết trình, tranh luận, và xử lý tình huống giao tiếp trong các bối cảnh học tập, công việc và đời sống hàng ngày. Ngoài ra, học phần tích hợp các bài tập nhóm, bài nói cá nhân để rèn luyện tư duy phản biện, khả năng làm việc nhóm và sự tự tin trong giao tiếp. Đặc biệt, sinh viên sẽ có cơ hội trải nghiệm thực tế nghề nghiệp thông qua các hoạt động với sự tham gia của doanh nghiệp hoặc chuyên gia trong ngành, giúp làm quen với môi trường làm việc thực tế và phát triển kỹ năng chuyên môn cơ bản. Học phần không chỉ giúp sinh viên thành thạo hơn trong kỹ năng nói tiếng Trung mà còn trang bị hành trang cần thiết để đáp ứng các yêu cầu công việc trong tương lai.
43	CHN117	Tiếng Trung – Đọc 1	3	3	0	0	0	1	Nội dung môn học chủ yếu gồm có bài khóa, từ vựng, điểm ngữ pháp và phần luyện tập. Bài khóa có nội dung đa dạng, ngắn và dễ hiểu, giúp sinh viên làm quen với văn phong của tiếng Trung, từ đó mở rộng vốn từ vựng và ngữ pháp. Phần luyện tập có nội dung xoay quanh chủ đề của bài khóa, giúp sinh viên ghi chép, đánh dấu các thông tin có được từ bài khóa.
44	CHN118	Tiếng Trung – Đọc 2	3	3	0	0	0	1	Nội dung môn học tập trung chủ yếu vào vốn từ vựng, ngữ pháp cơ bản và kỹ năng đọc hiểu của sinh viên ở mức độ sơ cấp bằng việc mở rộng thêm vốn từ vựng, tìm hiểu sâu hơn về các điểm ngữ pháp sau mỗi bài khóa. Phần luyện tập sau mỗi bài khóa trang bị thêm cho sinh viên những kiến thức về văn hóa, xã hội thông qua việc đọc hiểu và trả lời các câu hỏi xoay quanh các mẫu hội thoại, các văn bản có nội dung gần gũi với đời sống thường ngày.
46	CHN120	Tiếng Trung – Đọc 4	3	3	0	0	0	1	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, các điểm ngữ pháp ở mức độ trung và cao cấp, các cấu trúc ngữ pháp phức tạp thông qua nội dung các bài khóa xoay quanh các chủ đề như văn hóa, xã hội, kinh tế,... Mỗi bài học đều có bài khóa, từ vựng, điểm ngữ pháp cũng như phần luyện tập. Những bài tập này cũng được nâng lên mức tương đối khó, nhằm phát triển khả năng phân tích, đánh giá và đưa ra luận điểm cá nhân.
47	CHN121	Tiếng Trung – Đọc 5	3	3	0	0	0	1	Nội dung học phần được thiết kế để trang bị cho sinh viên vốn từ vựng phong phú, bao gồm cả những từ vựng chuyên ngành, thành ngữ, tục ngữ, các phép tu từ,… thông qua các bài khóa có nội dung liên quan đến các chủ đề kinh tế, văn hóa và xã hội. Sau mỗi bài khóa, học phần còn cung cấp thêm nhiều điểm ngữ pháp cao cấp, các cấu trúc câu phức tạp cũng như bài tập minh họa để ví dụ, từ đó làm rõ các kiến thức đang học cũng như áp dụng các kiến thức đã học vào các bài tập thực tế.
48	CHN122	Tiếng Trung – Viết 1	3	3	0	0	0	1	Học phần cung cấp cho sinh viên kiến thức cơ bản về quy tắc viết chữ Hán ( quy tắc bút thuận), cung cấp kiến thức về lịch sử hình thành và phát triển của chữ Hán, cách viết chữ Hán, các bộ, các tự dạng chữ Hán ở mức độ nhập môn.Kết thúc học phần sinh viên có thể thực hành viết chữ Hán giản thể và nhận biết chữ Hán phồn thể ở mức độ sơ cấp; Sinh viên có thể viết các mẫu câu đa dạng theo những chủ đề quen thuộc như giới thiệu bản thân, gia đình, sở thích…
49	CHN123	Tiếng Trung – Viết 2	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Biết phân biệt và viết đúng dấu câu trong tiếng Hán; Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên có thể soạn thảo các mẫu thư tín xã giao, các đơn từ trong hành chính…; Sinh viên làm quen và phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc quan sát sự việc hoặc hình ảnh.
50	CHN124	Tiếng Trung – Viết 3	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên có thể soạn thảo các mẫu thư tín xã giao, các đơn từ trong hành chính…; Sinh viên làm quen và phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc quan sát sự việc hoặc hình ảnh
51	CHN125	Tiếng Trung – Viết 4	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Củng cố văn phạm để diễn đạt các ý tưởng ở dạng câu đơn đúng ngữ pháp; Sinh viên làm quen và phát triển kỹ năng viết độc lập, sáng tạo và logic theo chủ đề.
52	CHN126	Tiếng Trung – Viết 5	3	3	0	0	0	1	Môn học thông qua các bài viết giúp sinh viên: Phát triễn kỹ năng viết độc lập, sáng tạo và logic thông qua việc thuật lại, lên kế hoạch và viết báo cáo tổng kết
53	CHN134	Lý thuyết tiếng Trung Quốc	3	3	0	0	0	1	Môn học cung cấp kiến thức nền tảng về ngữ âm, văn tự, từ vựng và ngữ pháp tiếng Hán hiện đại, giúp sinh viên nhận biết cấu trúc, chức năng của các thành phần ngôn ngữ, phân tích mối quan hệ giữa hình - âm - nghĩa của chữ Hán . Sinh viên được rèn luyện khả năng tư duy phản biện, phân tích và đánh giá các vấn đề ngôn ngữ để áp dụng chính xác vào thực tiễn giao tiếp và học thuật. Thông qua các bài giảng lý thuyết, bài tập thực hành và thảo luận, sinh viên sẽ nắm vững hệ thống kiến thức về tiếng Hán hiện đại, từ đó áp dụng hiệu quả vào học tập và công việc.
54	SOS118	Văn hoá, xã hội Trung Quốc	3	3	0	0	0	1	Học phần Văn hóa – Xã hội Trung Quốc (SOS118) trang bị cho sinh viên kiến thức tổng quan về địa lý, lịch sử, văn hóa, phong tục, ẩm thực, nghệ thuật và tư tưởng truyền thống Trung Quốc. Môn học giúp sinh viên phát triển tư duy phân tích, tổng hợp, rèn luyện kỹ năng làm việc nhóm, và ý thức trách nhiệm xã hội trong bối cảnh toàn cầu hóa.Sinh viên sẽ biết cách khai thác tài liệu, cập nhật kiến thức chuyên ngành và vận dụng tiếng Trung để giải quyết các vấn đề thực tiễn liên quan đến văn hóa - xã hội.
55	CHN5002	Thực tế trải nghiệm văn hóa và ngôn ngữ Trung Quốc	3	0	0	0	3	1	-Học phần này thông qua nhiều hoạt động trải nghiệm phong phú, giúp sinh viên khám phá văn hóa Trung Quốc. Đầu tiên, sinh viên sẽ được giới thiệu tổng quan về văn hóa, ngôn ngữ vàhướng dẫn phương pháp nghiên cứu thực địa, kỹ năng viết báo cáo,làm việc nhóm. Sau đó, học phần đi sâu vào giao tiếp liên văn hóa và so sánh sự khác biệt giữa văn hóa Việt Nam và Trung Quốc.Các buổi trải nghiệm thực tế bao gồm tham quan không gian văn hóa người Hoa,tham gia các sự kiện văn hóa TrungHoahoặc workshop giao tiếp với người bản ngữ để nâng cao kỹ năng nghe-nói và hiểu biết xã hội.Mỗi chuyến đi đều có nhiệm vụ cụ thể như phỏng vấn, ghi chép, chụp ảnh tư liệu, thử nghiệm ẩm thực, hoặc quan sát nghi lễ truyền thống.-Cuối cùng, sinh viên sẽ làm việc nhóm để xây dựng và thuyết trình một dự án về văn hóa TrungHoa, từ phân tích dữ liệu đến thiết kế sản phẩm như slide, video hoặc brochure.
56	CHN546	Thực tập tốt nghiệp ngành Ngôn ngữ Trung Quốc (*)	3	0	0	0	3	1	Học phần “Thực tập tốt nghiệp ngành Ngôn ngữ Trung Quốc” nhằm trang bị cho sinh viên kiến thức và kỹ năng để áp dụng vào thực tiễn công việc. Trong học phần này, sinh viên sẽ được hướng dẫn lựa chọn doanh nghiệp phù hợp để thực tập, lập kế hoạch thực tập, xác định đề tài và viết đề cương chi tiết. Quá trình thực tập bao gồm việc sinh viên tham gia trực tiếp vào các hoạt động tại đơn vị thực tập, thực hiện các nhiệm vụ được giao, thu thập và phân tích dữ liệu thực tế. Sinh viên sẽ hoàn thiện báo cáo thực tập, bao gồm các tài liệu liên quan như nhật ký thực tập, nhận xét từ giảng viên hướng dẫn và đơn vị thực tập. Học phần kết thúc bằng buổi bảo vệ báo cáo trước hội đồng, đánh giá toàn diện khả năng áp dụng kiến thức, kỹ năng giải quyết vấn đề, và năng lực phản biện của sinh viên.Học phần đặc biệt chú trọng tích hợp công cụ trí tuệ nhân tạo (AI) trong các hoạt động như phân tích dữ liệu, dịch thuật, lập kế hoạch và viết báo cáo, nhằm nâng cao hiệu quả và tính chuyên nghiệp. Đồng thời, năng lực giải quyết vấn đề được phát triển qua các nhiệm vụ thực tiễn, từ việc xác định vấn đề, đề xuất giải pháp đến triển khai và đánh giá hiệu quả thực hiện.
57	CHN135	Thư tín thương mại tiếng Trung	3	3	0	0	0	1	Nội dung môn học xoay quanh các chủ đề về thư tín thương mại, văn phòng như: cách viết thư mời, thư giới thiệu, thư cảm ơn, thư xin lỗi, thư thiết lập mối quan hệ thương mại, thư hỏi giá, báo giá, thư thương lượng định giá,... Môn học trang bị cho người học khối kiến thức và vốn từ vựng, thuật ngữ nhất định về thư tín thương mại, văn phòng, giúp sinh viên nhận biết và biết cách viết các loại thư này.
58	CHN128	Tiếng Trung Thương mại	3	3	0	0	0	1	Học phần Tiếng Trung thương mại là một môn học trang bị cho người học những kiến thức và kỹ năng giao tiếp tiếng Trung chuyên ngành, phục vụ công việc trong môi trường kinh doanh, thương mại.Thông qua các hoạt động xử lý tình huống thực tế và đóng vai, sinh viên được rèn luyện năng lực sử dụng tiếng Trung trong môi trường thương mại. Học phần cũng góp phần hình thành tư duy ngôn ngữ chuyên ngành, hỗ trợ sinh viên định hướng nghề nghiệp trong các lĩnh vực như phiên dịch thương mại, quan hệ khách hàng, xuất nhập khẩu, và hợp tác quốc tế.
59	CHN137	Tiếng Trung hành chính – văn phòng	3	3	0	0	0	1	Học phần xoay quanh các vấn đề thường gặp khi làm việc trong môi trường công ty/công sở như: tổ chức cuộc họp, mua văn phòng phẩm, giới thiệu về cơ cấu tổ chức của một công ty, cách trình bày ý kiến cá nhân, báo cáo công việc, giải quyết nghỉ việc, quảng cáo tuyên truyền, tuyển dụng, tập huấn,…Mỗi bài đều được thiết kế gồm các phần: từ mới, bài khóa, điểm ngữ pháp cần lưu ý và bài tập. Bài khóa chủ yếu xuất hiện những mẫu câu cơ bản thường được dùng trong giao tiếp hành chính - văn phòng. Bài tập giao tiếp bám sát nội dung kiến thức trong từng bài giúp sinh viên rèn luyện khả năng phản xạ trong các tình huống cụ thể.Môn học này là cơ hội để sinh viên tiếp cận và làm quen với các nghiệp vụ cụ thể trong văn phòng, là nền tảng tốt cho các hoạt động nghề nghiệp sau này liên quan đến ngôn ngữ và văn hóa Trung Quốc.
60	CHN139	Kỹ năng dịch nói tiếng Trung	3	3	0	0	0	1	Học phần cung cấp kiến thức và kỹ năng cần thiết để thực hiện các nhiệm vụ dịch nói Trung-Việt và Việt-Trung trong các tình huống giao tiếp thực tế. Học phần tập trung vào phát triển năng lực nghe hiểu, phân tích, và diễn đạt chính xác thông điệp giữa hai ngôn ngữ, đồng thời rèn luyện khả năng xử lý thông tin nhanh chóng và linh hoạt. Sinh viên sẽ được trang bị các kỹ năng thực hành dịch nói qua các bài tập câu thoại, bài diễn văn ngắn, và tình huống giả định đơn giản.
61	CHN144	Kỹ năng dịch viết tiếng Trung	3	3	0	0	0	1	Học phần giới thiệu môn học, phương pháp học môn phiên dịch viết tiếng Trung. Sau đó, giới thiệu tổng quan về các chủ đề đọc hiểu cùng các mẫu câu thông dụng theo các bài giảng. Thực hành dịch văn bản trong các tình huống cụ thể, dịch văn bản trong các sự kiện ở một số lĩnh vực (văn hóa, giáo dục, thương mại, du lịch…)
62	AIT1021	Ứng dụng AI trong dịch thuật tiếng Trung	3	3	0	0	0	1	Học phần “Ứng dụng AI trong dịch thuật tiếng Trung” giới thiệu tổng quan về các công nghệ trí tuệ nhân tạo đang được sử dụng trong lĩnh vực dịch thuật. Sinh viên sẽ được hướng dẫn cách sử dụng, phân tích đầu ra của các công cụ dịch máy, và kết hợp giữa bản dịch tự động với hiệu chỉnh thủ công nhằm nâng cao chất lượng bản dịch tiếng Trung. Ngoài ra, học phần cũng giúp người học nhận diện các lỗi thường gặp trong dịch máy, từ đó hình thành năng lực lựa chọn công cụ phù hợp với từng ngữ cảnh dịch cụ thể.
63	CHN1003	Thiết kế giáo án và thực hành giảng dạy tiếng Trung	3	3	0	0	0	1	Học phần này cung cấp cho sinh viên những kiến thức và kỹ năng cơ bản để thiết kế giáo án giảng dạy tiếng Trung. Nội dung gồm các bước và nguyên tắc thiết kế giáo án, lựa chọn và sử dụng tài liệu giảng dạy, thiết kế hoạt động học tập và kiểm tra đánh giá. Bên cạnh đó, Sinh viên sẽ được thực hành xây dựng giáo án và giảng dạy thử trong các tình huống lớp học cụ thể.
64	CHN1004	Kỹ năng giảng dạy tiếng Trung	3	3	0	0	0	1	Học phần “Kỹ năng giảng dạy tiếng Trung” nhằm trang bị cho sinh viên những kiến thức và kỹ năng sư phạm thiết yếu trong việc tổ chức giảng dạy bốn kỹ năng ngôn ngữ cơ bản: nghe, nói, đọc, viết trong lớp học tiếng Trung. Sinh viên sẽ được tìm hiểu về mục tiêu giảng dạy của từng kỹ năng, cách chọn lựa phương pháp phù hợp và thiết kế các hoạt động giảng dạy cụ thể.Học phần kết hợp chặt chẽ giữa lý thuyết và thực hành, giúp sinh viên phát triển các kỹ năng chuyên môn như xây dựng giáo án kỹ năng, lựa chọn và khai thác ngữ liệu, thiết kế bài tập, tổ chức hoạt động giao tiếp, và ứng dụng các phần mềm, công cụ số vào quá trình dạy học. Trong suốt học phần, sinh viên sẽ tham gia các hoạt động mô phỏng giảng dạy, phân tích tình huống sư phạm, thảo luận nhóm và nhận phản hồi từ giảng viên nhằm nâng cao khả năng giảng dạy thực tiễn. Những trải nghiệm này không chỉ giúp sinh viên củng cố kiến thức, phát triển năng lực sư phạm, mà còn là bước chuẩn bị vững chắc cho công việc giảng dạy tiếng Trung trong tương lai.
65	AIT1022	Ứng dụng AI trong giảng dạy tiếng Trung	3	3	0	0	0	1	Học phần này giới thiệu một cách hệ thống các lý thuyết và ứng dụng thực tiễn của công nghệ trí tuệ nhân tạo (AI) trong giảng dạy tiếng Trung. Nội dung tập trung vào việc ứng dụng AI trong các khía cạnh như: luyện phát âm, phân tích và sửa lỗi ngữ pháp, chấm và sửa bài văn viết, thiết kế lộ trình học tập cá nhân hóa và phát triển tài nguyên dạy học thông minh. Kết thúc học phần, sinh viên sẽ có năng lực phân tích, lựa chọn và ứng dụng hiệu quả các công cụ AI để đổi mới phương pháp giảng dạy, đồng thời hình thành tư duy phản biện về những cơ hội và thách thức mà AI mang lại cho lĩnh vực giảng dạy tiếng Trung Quốc
67	PHT304	Bóng chuyền 1	2	0	0	0	0	1	Học phần trang bị cho sinh viên những kiến thức cơ bản về lịch sử hình thành và phát triển môn Bóng chuyền, tổ chức quản lý môn thể thao này trong nước và quốc tế, hệ thống luật thi đấu và các kỹ thuật chính như chuyền bóng, đệm bóng và phát bóng. Đồng thời, sinh viên được rèn luyện kỹ năng thực hành thông qua các bài tập đệm bóng thấp tay, chuyền bóng cao tay và phát bóng, góp phần nâng cao thể lực, kỹ thuật cá nhân và khả năng phối hợp trong thi đấu.
68	PHT305	Bóng chuyền 1	2	0	0	0	0	1	Cung cấp kiến thức cơ bản và chuyên sâu về bóng chuyền, bao gồm luật chơi, kỹ thuật cơ bản, dinh dưỡng thể thao và phòng tránh chấn thương. Rèn luyện và hoàn thiện kỹ thuật chuyền, đệm, phát bóng; nâng cao kỹ năng xử lý tình huống và phát triển kỹ năng cá nhân trong thi đấu
69	PHT306	Bóng chuyền 1	1	0	0	0	0	1	Học phần Bóng chuyền 3 gồm lý thuyết và thực hành, giúp sinh viên nâng cao kỹ thuật và chiến thuật thi đấu. Phần lý thuyết trang bị kiến thức về luật, tổ chức thi đấu và chiến thuật từ cơ bản đến nâng cao. Phần thực hành tập trung rèn luyện kỹ thuật chuyền đệm, đập bóng, chắn bóng, phòng thủ và phối hợp thi đấu hiệu quả
70	PHT307	Bóng rổ 1	2	0	0	0	0	1	Học phần "Bóng rổ 1" trang bị cho sinh viên những kiến thức cơ bản về môn bóng rổ, bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu khái quát về lịch sử hình thành và phát triển của bóng rổ, các kỹ thuật cơ bản, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, các kỹ thuật chuyền bắt bóng cơ bản trong bóng rổ, kỹ thuật ném rổ, kỹ thuật dẫn bóng, phối hợp bước dân di chuyển thường sử dụng trong môn này. Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng rổ.
71	PHT308	Bóng rổ 2	2	0	0	0	0	1	Học phần được xây dựng nhằm nâng cao kỹ năng thực hành, tư duy chiến thuật và thể lực chuyên môn cho sinh viên, dựa trên nền tảng kiến thức từ học phần Bóng rổ 1. Củng cố và phát triển các kỹ thuật cá nhân, giúp sinh viên nắm vững và vận dụng các chiến thuật thi đấu cơ bản (phối hợp nhóm, tấn công-phòng ngự cá nhân/khu vực), hiểu rõ mối liên hệ giữa kỹ thuật, chiến thuật và thể lực, đồng thời áp dụng kiến thức vào tập luyện, thi đấu thực tế để nâng cao sức khỏe, ý thức kỷ luật và tinh thần đồng đội.
72	PHT309	Bóng rổ 3	1	0	0	0	0	1	Học phần được thiết kế nhằm hoàn thiện các kỹ thuật và kỹ năng bóng rổ nâng cao cho sinh viên, phục vụ cho việc tập luyện và thi đấu. Bên cạnh đó, học phần còn hướng đến việc tạo hứng thú, nâng cao sức khỏe thể chất và tinh thần, đồng thời củng cố kiến thức về vệ sinh và phòng tránh chấn thương trong thể thao
73	PHT310	Thể hình - Thẩm mỹ 1	2	0	0	0	0	1	Học phần Thể hình – Thẩm mỹ 1 cung cấp kiến thức lý thuyết và thực hành cơ bản về Gym – Fitness, giúp sinh viên hiểu về lịch sử, nguyên lý phát triển cơ bắp, phân loại nhóm cơ, kỹ thuật tập luyện và dinh dưỡng phù hợp. Phần thực hành rèn luyện thể lực và kỹ năng sử dụng máy móc, tập đúng kỹ thuật với 6 nhóm cơ chính. Qua học phần, sinh viên nâng cao thể lực, cải thiện vóc dáng và có khả năng tự xây dựng chương trình tập luyện phù hợp với mục tiêu cá nhân
74	PHT311	Thể hình - Thẩm mỹ 2	2	0	0	0	0	1	Học phần Thể hình – Thẩm mỹ 2 giúp sinh viên ôn tập kiến thức về dinh dưỡng, chỉ số BMI – TDEE, nguyên lý phát triển cơ bắp, luật thi đấu và an toàn tập luyện. Phần thực hành tập trung vào nâng cao thể lực, sử dụng thành thạo thiết bị, hoàn thiện kỹ thuật và xây dựng kế hoạch tập luyện cá nhân, từ đó hình thành ý thức tự giác và lan tỏa tinh thần thể thao tích cực.
75	PHT312	Thể hình - Thẩm mỹ 3	1	0	0	0	0	1	Học phần Thể hình – Thẩm mỹ 3 trang bị cho sinh viên kỹ thuật và phương pháp tập luyện nâng cao, bao gồm các phương pháp huấn luyện lặp lại, vòng tròn và các bài tập chuyên sâu tác động hiệu quả lên từng nhóm cơ, tối ưu hóa sự phát triển cơ bắp. Trang bị kiến thức về dinh dưỡng hồi phục và cách tự thiết kế thực đơn ăn uống phù hợp
76	PHT313	Vovinam 1	2	0	0	0	0	1	Học phần Vovinam 1 trang bị cho sinh viên những kiến thức cơ bản và nền tảng về môn võ Vovinam – Việt Võ Đạo. Giới thiệu khái quát về lịch sử hình thành và phát triển của Vovinam, trình bày các nguyên lý, khái niệm và giá trị võ đạo như lối nghiêm lễ, khái niệm “Vovinam là gì”, Mười điều tâm niệm, điều sơ khởi về kỷ luật, quan niệm dụng võ, hệ thống cấp đai, màu đai. Hướng dẫn và rèn luyện các kỹ thuật cơ bản như tấn, gạt, đấm, chém, chỏ, gối và các đòn đá, giúp hình thành kỹ năng thực chiến bước đầu
77	PHT314	Vovinam 2	2	0	0	0	0	1	Học phần Vovinam 2 trang bị sinh viên kiến thức hoàn thiện hơn về môn võ Vovinam.  Hiểu được luật thi đấu, danh dự người võ sĩ, cách rèn luyện tinh thần, khái niệm võ thuật – võ đạo, mục đích tôn chỉ người học võ, cách huấn luyện người học về võ lực – võ thuật – võ đạo, khả năng phối hợp cưng nhu, tác phong người học cần tránh những điều xấu và làm những điều tốt nào, cũng như đi sâu vào môn võ Vovinam khả năng phân tích chiến lược, bài quyền để hiểu hơn về môn võ này. Rèn luyện khả năng di chuyển và phối hợp động tác liên hoàn, thông qua tập luyện các động tác chiến lược từ 1 -5 và bài “Nhập môn quyền”.
79	PHT316	Bóng đá 1	2	0	0	0	0	1	Học phần "Bóng đá 1" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu khái quát về lịch sử hình thành và phát triển của bóng đá, các kỹ thuật cơ bản, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, tâng bóng, kéo bóng, kỹ thuật đá bóng bằng các phần khác nhau của bàn chân (lòng bàn chân, mu trong, mu giữa), kỹ thuật nhận bóng bằng gan bàn chân, dẫn bóng và đánh đầu bằng trán giữa. Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá .
80	PHT317	Bóng đá 2	2	0	0	0	0	1	Học phần "Bóng đá 2" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu về chiến thuật bóng đá , các chấn thương và phương pháp điều trị chấn thương trong tập luyện và thi đấu, cùng với hệ thống luật thi đấu hiện hành. Phần thực hành tập trung rèn luyện các kỹ năng chuyên môn như: khởi động chuyên biệt, kỹ thuật đá bóng bằng mũi bàn chân, các chiến thuật  cơ bản ( Chiến thuật tấn công và phòng ngự 2x1, chiến thuật tấn công và phòng ngự với quả đá biên), phát triển thể lực ( sức mạnh – tốc độ). Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá
81	PHT318	Bóng đá 3	1	0	0	0	0	1	Học phần "Bóng đá 3" trang bị cho sinh viên những kiến thức cơ bản về môn bóng đá , bao gồm nội dung lý thuyết và thực hành. Về lý thuyết, học phần giới thiệu về đội hình chiến thuật, chiến thuật  cơ bản (Chiến thuật tấn công và phòng ngự 3x2, chiến thuật tấn công và phòng ngự với quả phạt góc), phát triển thể lực (sức bền tốc độ). Thông qua học phần này, sinh viên được phát triển thể lực, kỹ năng cá nhân và hiểu biết nền tảng để tiếp cận sâu hơn với môn bóng đá .
82	NDF108	Quốc phòng, an ninh 1	0	0	0	0	0	1	Học phần gồm 11 chủ đề trong đó giới thiệu về đối tượng và phương pháp nghiên cứu bộ môn quốc phòng – an ninh nói chung; trình bày quan điểm Chủ nghĩa Mác –Lênin, tư tưởng Hồ Chí Minh về chiến tranh, quân đội và bảo vệ Tổ quốc XHCN; xây dựng lực lượng vũ trang nhân dân; xây dựng và bảo vệ chủ quyền biển, đảo, biên giới quốc gia trong tình hình mới; xây dựng lực lượng dân quân tự vệ, lực lượng dự bị động viên và động viên quốc phòng; xây dựng phong trào toàn dân bảo vệ an ninh Tổ quốc; những vấn đề cơ bản về bảo vệ an ninh quốc gia và bảo đảm trật tự an toàn xã hội; về kết hợp phát triển kinh tế với tăng cường quốc phòng an ninh, đối ngoại và một số nôi dung về lịch sử nghệ thuật quân sự Việt Nam.
66	CHN4005	Khóa luận tốt nghiệp Ngôn  ngữ Trung Quốc (*)	9	0	0	9	0	1	Học phần này trang bị cho sinh viên các kiến thức và các kỹ năng, phương pháp nghiên cứu khoa học, vận dụng các kiến thức chuyên ngành ngôn ngữ Trung Quốc đã học để hoàn thành đề tài nghiên cứu đã chọn.
78	PHT315	Vovinam 3	1	0	0	0	0	1	Học phần Vovinam 3 trang bị cho sinh viên các kỹ thuật nâng cao, bao gồm khả năng phản xạ, né đỡ đòn và phản đòn hiệu quả. Sinh viên sẽ được huấn luyện các chiến lược tự vệ từ cấp độ 6 đến 10, cùng với các kỹ thuật khóa gỡ trong các tình huống tấn công như ôm, nắm tóc và bóp cổ, giúp nâng cao kỹ năng tự vệ trong thực tiễn
83	NDF109	Quốc phòng, an ninh 2	0	0	0	0	0	1	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Nội dung của học phần gồm: Đấu tranh phòng chống chiến lược “Diễn biến hòa bình” bạo loạn lật đổ của các thế lực thù địch; một số vấn đề về dân tộc, tôn giáo; bảo vệ môi trường; an toàn giao thông; bảo vệ danh dự, nhân phẩm con người; an toàn thông tin; phòng ngừa, ứng phó với các mối đe dọa an ninh phi truyền thống.
84	NDF210	Quốc phòng, an ninh 3	0	0	0	0	0	1	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Nội dung của học phần gồm 9 chủ đề: chế độ sinh hoạt, học tập, công tác trong ngày, trong tuần; các chế độ nền nếp chính quy, bố trí trật tự nội vụ trong doanh trại; hiểu biết chung về các quân, binh chủng trong quân đội nhân dân Việt Nam; điều lệnh đội ngũ từng người có súng; điều lệnh đội ngũ đơn vị; hiểu biết chung về bản đồ địa hình quân sự; phòng tránh địch tiến công hỏa lực bằng vũ khí công nghệ cao; ba môn quân sự phối hợp, phòng cháy chữa cháy và cứu hộ cứu nạn.
85	NDF211	Quốc phòng, an ninh 4	0	0	0	0	0	1	Học phần này nằm trong khối kiến thức giáo dục quốc phòng, an ninh bắt buộc. Học phần trang bị những kiến thức cơ bản về kỹ thuật chiến đấu bộ binh và chiến thuật, gồm 5 chủ đề: kỹ thuật bắn súng tiểu liên AK; tính năng, cấu tạo và cách sử dụng một số loại lựu đạn thường dùng; từng người trong chiến đấu tiến công; từng người trong chiến đấu phòng ngự và từng người làm nhiệm vụ canh gác, cảnh giới.
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.departments (id, parent_id, code, name, type, created_at) FROM stdin;
1	\N	HUTECH	Trường Đại học Công nghệ TP.HCM	ROOT	2026-03-25 09:16:56.878689+00
2	1	BGH	Ban Giám Hiệu	PHONG	2026-03-25 09:16:56.881487+00
3	1	PDT	Phòng Đào tạo	PHONG	2026-03-25 09:16:56.882609+00
4	1	K.TQH	Khoa Trung Quốc học	KHOA	2026-03-25 09:16:56.883438+00
5	1	K.CNTT	Khoa CNTT	KHOA	2026-03-25 09:16:56.884207+00
6	1	K.TA	Khoa Tiếng Anh	KHOA	2026-03-25 09:16:56.885036+00
7	1	K.QTKD	Khoa QTKD	KHOA	2026-03-25 09:16:56.886048+00
8	1	K.LUAT	Khoa Luật	KHOA	2026-03-25 09:16:56.886819+00
9	1	K.NBH	Khoa Nhật Bản học	KHOA	2026-03-25 09:16:56.887563+00
10	1	VJIT	Viện CNTT Việt-Nhật	VIEN	2026-03-25 09:16:56.888228+00
11	1	V.KHUD	Viện Khoa học ứng dụng	VIEN	2026-03-25 09:16:56.888943+00
12	1	TT.GDTC	TT Giáo dục Thể chất	TRUNG_TAM	2026-03-25 09:16:56.889591+00
13	1	TT.GDCT-QP	TT Giáo dục CT-QP	TRUNG_TAM	2026-03-25 09:16:56.890319+00
14	1	TT.TH-NN-KN	TT Tin học-NN-KN	TRUNG_TAM	2026-03-25 09:16:56.89095+00
15	5	N.CNPM	Ngành Công nghệ phần mềm	BO_MON	2026-03-25 09:16:56.891551+00
16	5	N.HTTT	Ngành Hệ thống thông tin	BO_MON	2026-03-25 09:16:56.892137+00
17	5	N.KTPM	Ngành Kỹ thuật phần mềm	BO_MON	2026-03-25 09:16:56.892764+00
18	5	N.TTNT	Ngành Trí tuệ nhân tạo	BO_MON	2026-03-25 09:16:56.893387+00
19	7	N.TMDT	Ngành Thương mại điện tử	BO_MON	2026-03-25 09:16:56.894017+00
20	7	N.QTKD-TH	Ngành Quản trị kinh doanh tổng hợp	BO_MON	2026-03-25 09:16:56.894619+00
21	6	N.TACN	Ngành Tiếng Anh chuyên ngành	BO_MON	2026-03-25 09:16:56.89522+00
22	6	N.TATM	Ngành Tiếng Anh thương mại	BO_MON	2026-03-25 09:16:56.895821+00
\.


--
-- Data for Name: knowledge_blocks; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.knowledge_blocks (id, version_id, name, parent_id, total_credits, required_credits, elective_credits, sort_order, level) FROM stdin;
57	1	Kiến thức giáo dục đại cương	\N	0	0	0	1	1
58	1	Kiến thức giáo dục chuyên nghiệp	\N	0	0	0	2	1
59	1	Kiến thức bắt buộc	58	0	0	0	3	2
60	1	Kiến thức tự chọn	58	0	0	0	4	2
61	1	Kiến thức không tích lũy	\N	0	0	0	5	1
74	9	Kiến thức giáo dục đại cương	\N	44	0	0	1	1
75	9	Kiến thức giáo dục chuyên nghiệp	\N	81	0	0	2	1
76	9	Kiến thức bắt buộc	75	72	0	0	3	2
77	9	Kiến thức tự chọn	75	9	0	0	4	2
78	9	Nhóm 1:Tiếng Trung thương mại	77	0	0	0	5	3
79	9	Nhóm 2:Biên phiên dịch tiếng Trung	77	0	0	0	6	3
80	9	Nhóm 3:Phương pháp giảng dạy tiếng Trung	77	0	0	0	7	3
81	9	Nhóm 4:Khóa luận tốt nghiệp	77	0	0	0	8	3
82	9	Kiến thức không tích lũy	\N	0	0	0	9	1
83	9	Giáo dục thể chất (tự chọn 1 trong 5 nhóm)	82	5	0	0	10	2
84	9	Nhóm 1	83	0	0	0	11	3
85	9	Nhóm 2	83	0	0	0	12	3
86	9	Nhóm 3	83	0	0	0	13	3
87	9	Nhóm 4	83	0	0	0	14	3
88	9	Nhóm 5	83	0	0	0	15	3
89	9	Chương trình Giáo dục quốc phòng và an ninh (theo quy định của Bộ GD&ĐT)	82	0	0	0	16	2
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.permissions (id, code, module, description) FROM stdin;
23	syllabus.approve_tbm	syllabus	Duyệt cấp Trưởng BM
24	syllabus.approve_khoa	syllabus	Duyệt cấp Trưởng Khoa
25	syllabus.approve_pdt	syllabus	Duyệt cấp Phòng ĐT
26	syllabus.approve_bgh	syllabus	Phê duyệt cấp BGH
27	syllabus.assign	syllabus	Phân công GV soạn đề cương
28	courses.view	courses	Xem danh mục học phần
29	courses.create	courses	Tạo học phần mới
30	courses.edit	courses	Chỉnh sửa học phần
1	programs.view_published	programs	Xem CTĐT đã công bố
2	programs.view_draft	programs	Xem CTĐT bản nháp
3	programs.create	programs	Tạo mới CTĐT
4	programs.edit	programs	Chỉnh sửa CTĐT
5	programs.delete_draft	programs	Xóa CTĐT bản nháp
6	programs.submit	programs	Nộp CTĐT để phê duyệt
7	programs.approve_khoa	programs	Duyệt CTĐT cấp Khoa
8	programs.approve_pdt	programs	Duyệt CTĐT cấp Phòng ĐT
9	programs.approve_bgh	programs	Phê duyệt CTĐT cấp BGH
10	programs.export	programs	Xuất báo cáo CTĐT
11	programs.import_word	programs	Import CTĐT từ Word
12	programs.manage_all	programs	Quản lý CTĐT toàn trường
13	programs.create_version	programs	Tạo phiên bản CTĐT mới
19	syllabus.view	syllabus	Xem đề cương đã công bố
20	syllabus.create	syllabus	Tạo đề cương
21	syllabus.edit	syllabus	Chỉnh sửa đề cương
22	syllabus.submit	syllabus	Nộp đề cương để phê duyệt
\.


--
-- Data for Name: plo_pis; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.plo_pis (id, plo_id, pi_code, description) FROM stdin;
1	1	PI1.1	Giải các bài toán tối ưu và xác suất thống kê trong CNTT
2	1	PI1.2	Áp dụng cấu trúc dữ liệu và giải thuật phù hợp cho bài toán
3	2	PI2.1	Phân tích yêu cầu chức năng và phi chức năng của hệ thống
4	2	PI2.2	Thiết kế kiến trúc hệ thống theo mô hình phân lớp
5	3	PI3.1	Viết mã nguồn sạch, có cấu trúc theo chuẩn coding convention
6	4	PI4.1	Thiết kế lược đồ CSDL chuẩn hóa đến 3NF
7	5	PI5.1	Trình bày ý tưởng kỹ thuật rõ ràng trước nhóm và khách hàng
8	6	PI6.1	Đánh giá ưu nhược điểm của công nghệ mới so với giải pháp hiện tại
114	42	PI.1.1	Nhận biếtcác vấn đề cần giải quyết về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc.
115	42	PI.1.2	Xây dựng phương án để giải quyết các vấn đề về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc.
116	42	PI.1.3	Kết hợp các kiến thức cơ bản, kiến thức chuyên ngành để đóng góp hữu hiệu vào sự phát triển bền vững của xã hội, cộng đồng.
117	43	PI.2.1	Nhận biếtcác thành phần cấu tạo nên ngôn ngữ Trung Quốc.
118	43	PI.2.2	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc.
119	43	PI.2.3	Sử dụng thành thạo4 kỹ năng tiếng Trungtương đương bậc 5 theo Khung năng lực ngoại ngữ Việt Nam.
120	44	PI.3.1	Sử dụng ngoại ngữ 2 tiếng Anh để nâng cao cơ hội việc làm và hiểu biết thêm về các nền văn hóa khác.
121	45	PI.4.1	Áp dụng thành thạo tiếng Trung vào công việc.
122	45	PI.4.2	Nhận biết chữ Hán phồn thểvà thành thạo chữ Hán giản thểtrong côngviệc.
123	45	PI.4.3	Khai thác thông tin và cập nhật kiến thức chuyên ngành thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c)phương pháp giảng dạy, hoặc (d)khóa luận tốt nghiệp.
124	46	PI.5.1	Phân tích thông tin, đưa ra luận điểm có căn cứ.
125	46	PI.5.2	Hệ thống lại vấn đề, đưa ra kết luận về cách thức vận hành của vấn đề hệ thống.
126	46	PI.5.3	Lập kế hoạch, thực hiện và đánh giá công việc chuyên môn.
127	47	PI.6.1	Sử dụng tốt các chiến lược giao tiếp bằng văn bản và bằng lời như thuyết trình, thương lượng, truyền đạt thông tin.
128	47	PI.6.2	Áp dụng thành thạo kỹ năng giao tiếp ứng xử cần thiết để thực hiện các nhiệm vụ phức tạp.
129	47	PI.6.3	Sử dụng Word, Excel, Powerpoint ….soạn thảo, trình bày các loại văn bản  trong học tập, nghiên cứu và công việc có hiệu quả.
130	47	PI.6.4	Sử dụng có hiệu quả các phần mềm chuyên dụng để phục vụ học tập và công việc chuyên môn liên quan đến tiếng Trung.
131	48	PI.7.1	Đưa ra các nhận định cá nhân trong điều kiện làm việc thay đổi
132	48	PI.7.2	Xác định được đầy đủ mục tiêu của nhóm, vai trò, trách nhiệm của các thành viên
133	48	PI.7.3	Tham gia hoạch định, lên chương trình và phối hợp trong thực hiện hoạt động nhóm đạt được mục tiêu đã đềra.
134	48	PI.7.4	Nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.
\.


--
-- Data for Name: po_plo_map; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.po_plo_map (version_id, po_id, plo_id) FROM stdin;
1	1	1
1	1	2
1	1	3
1	1	4
1	2	2
1	2	3
1	2	6
1	3	5
1	3	6
9	24	42
9	24	44
9	24	46
9	24	48
9	25	43
9	25	45
9	25	47
9	26	43
9	26	45
9	26	47
9	27	42
9	27	44
9	27	46
9	27	48
\.


--
-- Data for Name: program_versions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.program_versions (id, program_id, academic_year, version_name, status, is_locked, copied_from_id, completion_pct, total_credits, training_duration, change_type, effective_date, change_summary, grading_scale, graduation_requirements, job_positions, further_education, reference_programs, training_process, admission_targets, admission_criteria, created_at, updated_at, is_rejected, rejection_reason, general_objective) FROM stdin;
1	1	2025-2026	CTĐT CNTT 2025-2026	draft	f	\N	0	130	4 năm	\N	\N	\N	Thang điểm 10 quy đổi sang thang 4 và xếp loại A/B/C/D/F	Hoàn thành tối thiểu 130 TC, đạt chuẩn ngoại ngữ, không nợ học phí	Lập trình viên, Kỹ sư phần mềm, Quản trị mạng, Chuyên viên CNTT, Tư vấn giải pháp CNTT	Thạc sĩ CNTT, Thạc sĩ Khoa học máy tính, MBA chuyên ngành CNTT	\N	Đào tạo theo hệ thống tín chỉ, kết hợp lý thuyết và thực hành	\N	\N	2026-03-25 09:16:57.047572+00	2026-03-25 17:19:08.438016+00	f	\N	Đào tạo kỹ sư CNTT có năng lực chuyên môn, tư duy sáng tạo, đạo đức nghề nghiệp, đáp ứng nhu cầu xã hội và hội nhập quốc tế.
9	7	2026-2027	\N	draft	f	\N	0	125	3.5 năm	\N	\N	\N	Theo Quy chế/Quy định của Bộ GD&ĐT và Quy chế học vụ hiện hành của Trường Đại học Công nghệ TP.HCM.	Theo Quy chế/Quy định của Bộ GD&ĐT và Quy chế học vụ hiện hành của Trường Đại học Công nghệ TP.HCM.	Biên - phiên dịch viên: Làm việc tại các công ty Đài Loan, Trung Quốc, các doanh nghiệp đa quốc gia, hoặc các tổ chức quốc tế.Chuyên viên đối ngoại: Phụ trách giao tiếp và hợp tác quốc tế tại các doanh nghiệp, nhà xuất bản hoặc các cơ quan truyền thông.Chuyên viên trong lĩnh vực thương mại và dịch vụ: Hoạt động trong lĩnh vực marketing, tổ chức sự kiện, hoặc ngành du lịch như hướng dẫn viên du lịch chuyên nghiệp.Giáo viên tiếng Trung: Giảng dạy tại các trung tâm ngoại ngữ, trường học hoặc các cơ sở đào tạo	Tiếp tục học tập ở bậc sau đại học (thạc sĩ, tiến sĩ) tại các trường đại học trong và ngoài nước với chuyên ngành liên quan.Tham gia các khóa học ngắn hạn, chương trình bồi dưỡng chuyên sâu để nâng cao kiến thức và kỹ năng chuyên môn.Nghiên cứu và phát triển các lĩnh vực liên quan đến ngôn ngữ, văn hóa Trung Hoa và ứng dụng trong các ngành nghề	- Đại học KHXHNV-ĐHQG TP.HCM:https://hcmussh.edu.vn- Đại học Ngoại ngữ - Tin học TP. Hồ Chí Minh (HUFLIT):https://huflit.edu.vn/- Nanyang Technological University:https://www.ntu.edu.sg- Lingnan University:https://www.ln.edu.hk	Quy trình đào tạo được thực hiện qua 4 bước: (1) Xác định nhu cầu đào tạo; (2) Lập kế hoạch đào tạo; (3) Thực hiện đào tạo; (4) Đánh giá đào tạo.	Người học phải tốt nghiệp trung học phổ thông hoặc trình độ tương đương.	Theo Quy chế tuyển sinh hiện hành của Bộ GD&ĐT và Đề án tuyển sinh của Trường Đại học Công nghệ TP.HCM.	2026-03-26 11:50:08.760992+00	2026-03-26 11:50:08.760992+00	f	\N	Đào tạo cử nhân ngành Ngôn ngữ Trung Quốc có phẩm chất chính trị, đạo đức, có kiến thức toàn diện về văn hóa, khoa học xã hội và tự nhiên; có năng lực sử dụng tiếng Trung ở trình độ cao để giao tiếp hiệu quả trong các bối cảnh khác nhau; có kiến thức chuyên ngành và kỹ năng mềm đáp ứng nhu cầu phát triển kinh tế - xã hội và hội nhập quốc tế.
\.


--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.programs (id, department_id, name, name_en, code, degree, total_credits, institution, degree_name, training_mode, notes, created_at) FROM stdin;
1	15	Công nghệ thông tin	Information Technology	7480201	Đại học	130	Trường Đại học Công nghệ TP.HCM	Cử nhân Công nghệ thông tin	Chính quy	\N	2026-03-25 09:16:57.046839+00
7	15	Ngôn ngữ Trung Quốc	Chinese Language	7220204	Cử nhân Ngôn ngữ Trung Quốc	125	Trường Đại học Công nghệ TP.HCM	\N	Chính quy	\N	2026-03-26 11:50:08.760992+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	1
1	20
1	21
1	22
1	19
2	28
2	2
2	1
2	23
2	27
2	19
3	28
3	7
3	3
3	5
3	4
3	10
3	11
3	6
3	2
3	1
3	24
3	27
3	20
3	21
3	22
3	19
4	29
4	30
4	28
4	8
4	3
4	13
4	5
4	4
4	10
4	11
4	12
4	2
4	1
4	25
4	27
4	20
4	21
4	19
5	28
5	9
5	10
5	2
5	1
5	26
5	27
5	19
6	28
6	13
6	5
6	12
6	2
6	1
6	19
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.roles (id, code, name, level, is_system) FROM stdin;
1	GIANG_VIEN	Giảng viên	1	t
2	TRUONG_NGANH	Trưởng ngành / Trưởng BM	2	t
3	LANH_DAO_KHOA	Lãnh đạo Khoa/Viện/TT	3	t
4	PHONG_DAO_TAO	Phòng Đào tạo	4	t
5	BAN_GIAM_HIEU	Ban Giám Hiệu	5	t
6	ADMIN	Quản trị hệ thống	99	t
\.


--
-- Data for Name: syllabus_assignments; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.syllabus_assignments (id, version_id, course_id, assigned_to, assigned_by, assigner_role_level, deadline, notes, created_at, updated_at) FROM stdin;
1	1	11	2	1	99	2026-03-31	\N	2026-03-25 16:01:29.092888+00	2026-03-25 16:01:29.092888+00
\.


--
-- Data for Name: teaching_plan; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.teaching_plan (id, version_course_id, total_hours, hours_theory, hours_practice, hours_project, hours_internship, software, managing_dept, batch, notes) FROM stdin;
1	5	45	30	15	0	0	\N	K.CNTT	A	\N
2	6	45	30	15	0	0	\N	K.CNTT	A	\N
3	8	45	30	15	0	0	MySQL Workbench	K.CNTT	B	\N
4	7	45	30	15	0	0	IntelliJ IDEA	K.CNTT	A	\N
5	9	45	30	15	0	0	Cisco Packet Tracer	K.CNTT	B	\N
6	10	45	30	15	0	0	Jira, Draw.io	K.CNTT	A	\N
7	11	45	15	30	0	0	VS Code, Node.js	K.CNTT	B	\N
8	12	45	30	15	0	0	Python, Jupyter	K.CNTT	A	\N
9	15	90	0	0	90	0	\N	K.CNTT	A	\N
10	16	135	0	0	0	135	\N	K.CNTT	B	\N
356	367	45	45	0	0	0	\N	K.TA	B	\N
357	378	45	45	0	0	0	\N	K.TQH	A	\N
358	383	45	45	0	0	0	\N	K.TQH	A	\N
359	388	45	45	0	0	0	\N	K.TQH	B	\N
360	393	45	45	0	0	0	\N	K.TQH	B	\N
361	371	45	45	0	0	0	\N	K.CNTT	A	\N
362	427	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
363	428	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
364	368	45	45	0	0	0	\N	K.TA	B	\N
365	374	45	45	0	0	0	\N	VJIT	B	\N
366	379	45	45	0	0	0	\N	K.TQH	A	\N
367	384	45	45	0	0	0	\N	K.TQH	A	\N
368	389	45	45	0	0	0	\N	K.TQH	B	\N
369	394	45	45	0	0	0	\N	K.TQH	B	\N
370	429	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
371	430	0	0	0	0	0	\N	TT.GDCT-QP	\N	Không tích lũy
372	412	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
373	415	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
374	418	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
375	421	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
376	424	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
377	369	45	45	0	0	0	\N	K.TA	B	\N
378	380	45	45	0	0	0	\N	K.TQH	A	\N
379	385	45	45	0	0	0	\N	K.TQH	A	\N
380	390	45	45	0	0	0	\N	K.TQH	B	\N
381	395	45	45	0	0	0	\N	K.TQH	B	\N
382	362	45	45	0	0	0	\N	TT.GDCT-QP	A	\N
383	413	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
384	416	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
385	419	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
386	422	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
387	425	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
388	370	45	45	0	0	0	\N	K.TA	B	\N
389	372	45	45	0	0	0	\N	V.KHUD	A	\N
390	381	45	45	0	0	0	\N	K.TQH	A	\N
391	386	45	45	0	0	0	\N	K.TQH	A	\N
392	391	45	45	0	0	0	\N	K.TQH	B	\N
393	396	45	45	0	0	0	\N	K.TQH	B	\N
394	414	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
395	417	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
396	420	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
397	423	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
398	426	0	0	0	0	0	\N	TT.GDTC	\N	Không tích lũy
399	365	30	30	0	0	0	\N	TT.GDCT-QP	A	\N
400	363	30	30	0	0	0	\N	TT.GDCT-QP	B	\N
401	376	45	45	0	0	0	\N	K.NBH	A	\N
402	382	45	45	0	0	0	\N	K.TQH	A	\N
403	387	45	45	0	0	0	\N	K.TQH	A	\N
404	392	45	45	0	0	0	\N	K.TQH	B	\N
405	397	45	45	0	0	0	\N	K.TQH	B	\N
406	398	45	45	0	0	0	\N	K.TQH	B	\N
407	366	30	30	0	0	0	\N	TT.GDCT-QP	B	\N
408	364	30	30	0	0	0	\N	TT.GDCT-QP	A	\N
409	400	135	0	0	0	135	\N	K.TQH	B	\N
410	402	45	45	0	0	0	\N	K.TQH	A	\N
411	403	45	45	0	0	0	\N	K.TQH	A	\N
412	404	45	45	0	0	0	\N	K.TQH	B	\N
413	405	45	45	0	0	0	\N	K.TQH	A	\N
414	406	45	45	0	0	0	\N	K.TQH	A	\N
415	407	45	45	0	0	0	\N	K.TQH	B	\N
416	408	45	45	0	0	0	\N	K.TQH	A	\N
417	409	45	45	0	0	0	\N	K.TQH	A	\N
418	410	45	45	0	0	0	\N	K.TQH	B	\N
419	411	405	0	0	405	0	\N	K.TQH	\N	\N
420	375	45	45	0	0	0	\N	K.QTKD	A	\N
421	373	45	45	0	0	0	\N	K.LUAT	A	\N
422	377	45	45	0	0	0	\N	TT.TH-NN-KN	A	\N
423	399	45	45	0	0	0	\N	K.TQH	A	\N
424	401	135	0	0	0	135	\N	K.TQH	B	\N
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.user_roles (id, user_id, role_id, department_id) FROM stdin;
1	1	6	1
2	2	1	15
4	2	2	15
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.users (id, username, password_hash, display_name, email, is_active, created_at) FROM stdin;
1	admin	$2a$10$yKZNOXJ.bh0rQGDipu5i4.6IraQmwnv1TcThTgCVeXRGEkVuOf62q	Quản trị viên	\N	t	2026-03-25 09:16:57.043389+00
2	giangvien	$2a$10$l49IYdxPJNMHqB2ZB0pR9uOSOhu1uP5is0gDgSZwGX6iBJSRb8GFu	Huy	test@gmail.com	t	2026-03-25 09:27:04.500412+00
\.


--
-- Data for Name: version_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_courses (id, version_id, course_id, semester, course_type, prerequisite_course_ids, corequisite_course_ids, elective_group, knowledge_block_id) FROM stdin;
1	1	11	1	required	\N	\N	\N	\N
2	1	12	1	required	\N	\N	\N	\N
3	1	13	1	required	\N	\N	\N	\N
4	1	14	1	required	\N	\N	\N	\N
5	1	1	1	required	\N	\N	\N	\N
6	1	2	2	required	\N	\N	\N	\N
7	1	4	2	required	\N	\N	\N	\N
8	1	3	3	required	\N	\N	\N	\N
9	1	5	3	required	\N	\N	\N	\N
10	1	6	4	required	\N	\N	\N	\N
11	1	7	4	required	\N	\N	\N	\N
12	1	8	5	required	\N	\N	\N	\N
13	1	15	5	elective	\N	\N	An toàn & Đám mây	\N
14	1	16	5	elective	\N	\N	An toàn & Đám mây	\N
15	1	9	6	required	\N	\N	\N	\N
16	1	10	7	required	\N	\N	\N	\N
362	9	17	3	required	\N	\N	\N	74
363	9	18	5	required	\N	\N	\N	74
364	9	19	6	required	\N	\N	\N	74
365	9	20	5	required	\N	\N	\N	74
366	9	21	6	required	\N	\N	\N	74
367	9	22	1	required	\N	\N	\N	74
368	9	23	2	required	{367}	\N	\N	74
369	9	24	3	required	{368}	\N	\N	74
370	9	25	4	required	{369}	\N	\N	74
371	9	26	1	required	\N	\N	\N	74
372	9	27	4	required	\N	\N	\N	74
373	9	28	7	required	\N	\N	\N	74
374	9	29	2	required	\N	\N	\N	74
375	9	30	7	required	\N	\N	\N	74
376	9	31	5	required	\N	\N	\N	74
377	9	32	7	required	\N	\N	\N	74
378	9	33	1	required	\N	\N	\N	76
379	9	34	2	required	\N	\N	\N	76
380	9	35	3	required	\N	\N	\N	76
381	9	36	4	required	\N	\N	\N	76
382	9	37	5	required	\N	\N	\N	76
383	9	38	1	required	\N	\N	\N	76
384	9	39	2	required	\N	\N	\N	76
385	9	40	3	required	\N	\N	\N	76
386	9	41	4	required	\N	\N	\N	76
387	9	42	5	required	\N	\N	\N	76
388	9	43	1	required	\N	\N	\N	76
389	9	44	2	required	\N	\N	\N	76
390	9	45	3	required	\N	\N	\N	76
391	9	46	4	required	\N	\N	\N	76
392	9	47	5	required	\N	\N	\N	76
393	9	48	1	required	\N	\N	\N	76
394	9	49	2	required	\N	\N	\N	76
395	9	50	3	required	\N	\N	\N	76
396	9	51	4	required	\N	\N	\N	76
397	9	52	5	required	\N	\N	\N	76
398	9	53	6	required	\N	\N	\N	76
399	9	54	7	required	\N	\N	\N	76
400	9	55	6	required	\N	\N	\N	76
401	9	56	7	required	\N	\N	\N	76
402	9	57	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại	78
403	9	58	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại	78
404	9	59	6	elective	\N	\N	Nhóm 1:Tiếng Trung thương mại	78
405	9	60	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung	79
406	9	61	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung	79
407	9	62	6	elective	\N	\N	Nhóm 2:Biên phiên dịch tiếng Trung	79
408	9	63	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung	80
409	9	64	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung	80
410	9	65	6	elective	\N	\N	Nhóm 3:Phương pháp giảng dạy tiếng Trung	80
411	9	66	6	elective	\N	\N	Nhóm 4:Khóa luận tốt nghiệp	81
412	9	67	2	non_accumulative	\N	\N	Nhóm 1	84
413	9	68	3	non_accumulative	\N	\N	Nhóm 1	84
414	9	69	4	non_accumulative	\N	\N	Nhóm 1	84
415	9	70	2	non_accumulative	\N	\N	Nhóm 2	85
416	9	71	3	non_accumulative	\N	\N	Nhóm 2	85
417	9	72	4	non_accumulative	\N	\N	Nhóm 2	85
418	9	73	2	non_accumulative	\N	\N	Nhóm 3	86
419	9	74	3	non_accumulative	\N	\N	Nhóm 3	86
420	9	75	4	non_accumulative	\N	\N	Nhóm 3	86
421	9	76	2	non_accumulative	\N	\N	Nhóm 4	87
422	9	77	3	non_accumulative	\N	\N	Nhóm 4	87
423	9	78	4	non_accumulative	\N	\N	Nhóm 4	87
424	9	79	2	non_accumulative	\N	\N	Nhóm 5	88
425	9	80	3	non_accumulative	\N	\N	Nhóm 5	88
426	9	81	4	non_accumulative	\N	\N	Nhóm 5	88
427	9	82	1	non_accumulative	\N	\N	\N	89
428	9	83	1	non_accumulative	\N	\N	\N	89
429	9	84	2	non_accumulative	\N	\N	\N	89
430	9	85	2	non_accumulative	\N	\N	\N	89
\.


--
-- Data for Name: version_objectives; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_objectives (id, version_id, code, description) FROM stdin;
1	1	PO1	Vận dụng kiến thức nền tảng CNTT để phân tích, thiết kế và phát triển phần mềm
2	1	PO2	Áp dụng quy trình phát triển phần mềm chuyên nghiệp và công nghệ hiện đại
3	1	PO3	Có năng lực làm việc nhóm, giao tiếp hiệu quả và phát triển nghề nghiệp liên tục
24	9	PO1	Ứng dụng kiến thức: Vận dụng kiến thức vềvăn hóa, xãhội, chính trị, luật pháp, ngôn ngữ, vàcông nghệthông tin vào thực tiễn công việc vàcuộc sống. Cókhảnăng tựnghiên cứu, cập nhật kiến thức mới.
25	9	PO2	Năng lực tiếng Trung: Sửdụng thành thạo 4 kỹnăng Nghe, Nói,Đọc, Viết tiếng Trungởtrìnhđộcao.
26	9	PO3	Kỹnăng chuyên ngành: Vận dụng kiến thức vàkỹnăng chuyên ngành (biên phiên dịch/ thương mại/phương pháp giảng dạy/ Khoáluận tốt nghiệp)đểgiải quyết các vấnđềthực tiễn trong công việc.
27	9	PO4	Kỹnăng mềm vàtháiđộ: Làm việcđộc lập, làm việc nhóm, giao tiếp hiệu quả, cótrách nhiệm, sáng tạo, chủđộng thích nghi với môi trường làm việc, tuân thủchuẩn mựcđạođức nghềnghiệp.
\.


--
-- Data for Name: version_pi_courses; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_pi_courses (id, version_id, pi_id, course_id, contribution_level) FROM stdin;
1	1	2	5	2
2	1	5	5	3
3	1	1	6	2
4	1	2	6	3
5	1	6	8	3
6	1	3	8	2
7	1	4	7	2
8	1	5	7	3
9	1	3	10	3
10	1	4	10	2
11	1	7	10	2
12	1	4	11	2
13	1	5	11	3
14	1	8	11	2
15	1	2	12	2
16	1	8	12	3
1227	9	114	362	1
1228	9	125	362	1
1229	9	133	362	1
1230	9	114	363	1
1231	9	125	363	1
1232	9	134	363	1
1233	9	114	364	2
1234	9	125	364	2
1235	9	133	364	2
1236	9	114	365	1
1237	9	125	365	1
1238	9	133	365	1
1239	9	114	366	2
1240	9	125	366	2
1241	9	131	366	2
1242	9	120	367	1
1243	9	120	368	1
1244	9	120	369	2
1245	9	120	370	3
1246	9	114	371	1
1247	9	130	371	3
1248	9	116	372	2
1249	9	126	372	2
1250	9	133	372	2
1251	9	114	373	2
1252	9	115	373	2
1253	9	126	373	2
1254	9	134	373	2
1255	9	115	374	3
1256	9	133	374	3
1257	9	134	374	3
1258	9	114	375	2
1259	9	129	375	3
1260	9	133	375	2
1261	9	134	375	2
1262	9	114	376	1
1263	9	115	376	1
1264	9	131	376	1
1265	9	114	377	3
1266	9	131	377	3
1267	9	133	377	3
1268	9	134	377	3
1269	9	114	378	1
1270	9	117	378	1
1271	9	118	378	1
1272	9	119	378	1
1273	9	114	379	1
1274	9	117	379	1
1275	9	118	379	1
1276	9	119	379	1
1277	9	114	380	2
1278	9	118	380	2
1279	9	119	380	2
1280	9	114	381	2
1281	9	118	381	2
1282	9	119	381	2
1283	9	114	382	3
1284	9	118	382	3
1285	9	119	382	3
1286	9	114	383	1
1287	9	118	383	1
1288	9	119	383	1
1289	9	121	383	1
1290	9	114	384	1
1291	9	118	384	1
1292	9	119	384	1
1293	9	121	384	1
1294	9	114	385	2
1295	9	118	385	2
1296	9	119	385	2
1297	9	121	385	2
1298	9	114	386	2
1299	9	118	386	2
1300	9	119	386	2
1301	9	121	386	2
1302	9	114	387	3
1303	9	118	387	3
1304	9	119	387	3
1305	9	121	387	3
1306	9	114	388	1
1307	9	117	388	1
1308	9	119	388	1
1309	9	114	389	1
1310	9	117	389	1
1311	9	118	389	1
1312	9	119	389	1
1313	9	114	390	2
1314	9	118	390	2
1315	9	119	390	2
1316	9	124	390	2
1317	9	114	391	2
1318	9	118	391	2
1319	9	121	391	2
1320	9	124	391	2
1321	9	114	392	3
1322	9	118	392	3
1323	9	119	392	3
1324	9	121	392	3
1325	9	122	392	3
1326	9	125	392	3
1327	9	114	393	1
1328	9	117	393	1
1329	9	119	393	1
1330	9	122	393	1
1331	9	114	394	1
1332	9	117	394	1
1333	9	119	394	1
1334	9	122	394	1
1335	9	114	395	2
1336	9	117	395	2
1337	9	119	395	2
1338	9	122	395	2
1339	9	114	396	2
1340	9	117	396	2
1341	9	119	396	2
1342	9	122	396	2
1343	9	114	397	3
1344	9	117	397	3
1345	9	119	397	3
1346	9	122	397	3
1347	9	117	398	3
1348	9	118	398	3
1349	9	124	398	3
1350	9	127	398	3
1351	9	134	398	3
1352	9	116	399	3
1353	9	123	399	3
1354	9	126	399	3
1355	9	128	399	3
1356	9	133	399	3
1357	9	134	399	3
1358	9	116	400	3
1359	9	123	400	3
1360	9	126	400	3
1361	9	128	400	3
1362	9	133	400	3
1363	9	134	400	3
1364	9	114	401	3
1365	9	115	401	3
1366	9	123	401	3
1367	9	126	401	3
1368	9	129	401	3
1369	9	132	401	3
1370	9	118	402	3
1371	9	121	402	3
1372	9	123	402	3
1373	9	134	402	3
1374	9	123	403	3
1375	9	127	403	3
1376	9	130	403	3
1377	9	134	403	3
1378	9	124	404	3
1379	9	127	404	3
1380	9	134	404	3
1381	9	124	405	3
1382	9	127	405	3
1383	9	130	405	3
1384	9	134	405	3
1385	9	121	406	3
1386	9	123	406	3
1387	9	134	406	3
1388	9	118	407	3
1389	9	121	407	3
1390	9	123	407	3
1391	9	134	407	3
1392	9	118	408	3
1393	9	124	408	3
1394	9	127	408	3
1395	9	134	408	3
1396	9	121	409	3
1397	9	127	409	3
1398	9	130	409	3
1399	9	134	409	3
1400	9	121	410	3
1401	9	123	410	3
1402	9	124	410	3
1403	9	130	410	3
1404	9	134	410	3
1405	9	118	411	3
1406	9	121	411	3
1407	9	123	411	3
1408	9	124	411	3
1409	9	127	411	3
1410	9	130	411	3
1411	9	134	411	3
1412	9	114	412	1
1413	9	115	412	1
1414	9	116	412	1
1415	9	114	413	1
1416	9	115	413	1
1417	9	116	413	1
1418	9	114	414	1
1419	9	115	414	1
1420	9	116	414	1
1421	9	114	415	1
1422	9	115	415	1
1423	9	116	415	1
1424	9	114	416	1
1425	9	115	416	1
1426	9	116	416	1
1427	9	114	417	1
1428	9	115	417	1
1429	9	116	417	1
1430	9	114	418	1
1431	9	115	418	1
1432	9	116	418	1
1433	9	114	419	1
1434	9	115	419	1
1435	9	116	419	1
1436	9	114	420	1
1437	9	115	420	1
1438	9	116	420	1
1439	9	114	421	1
1440	9	115	421	1
1441	9	116	421	1
1442	9	114	422	1
1443	9	115	422	1
1444	9	116	422	1
1445	9	114	423	1
1446	9	115	423	1
1447	9	116	423	1
1448	9	114	424	1
1449	9	115	424	1
1450	9	116	424	1
1451	9	114	425	1
1452	9	115	425	1
1453	9	116	425	1
1454	9	114	426	1
1455	9	115	426	1
1456	9	116	426	1
1457	9	114	427	1
1458	9	116	427	1
1459	9	134	427	1
1460	9	114	428	1
1461	9	116	428	1
1462	9	134	428	1
1463	9	114	429	2
1464	9	116	429	2
1465	9	134	429	2
1466	9	114	430	2
1467	9	116	430	2
1468	9	134	430	2
\.


--
-- Data for Name: version_plos; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_plos (id, version_id, code, bloom_level, description) FROM stdin;
1	1	PLO1	3	Áp dụng kiến thức toán học, khoa học tự nhiên và CNTT vào giải quyết bài toán thực tế
2	1	PLO2	4	Phân tích yêu cầu, thiết kế kiến trúc và triển khai hệ thống phần mềm
3	1	PLO3	3	Lập trình thành thạo ít nhất 2 ngôn ngữ lập trình hiện đại
4	1	PLO4	4	Thiết kế và quản trị cơ sở dữ liệu quan hệ và NoSQL
5	1	PLO5	2	Làm việc nhóm hiệu quả, giao tiếp chuyên nghiệp bằng tiếng Việt và tiếng Anh
6	1	PLO6	5	Nghiên cứu, đánh giá và ứng dụng công nghệ mới vào dự án thực tế
42	9	PLO1	3	Vận dụng kiến thức cơ bản về chính trị và pháp luật, khoa học xã hội và nhân văn phù hợp với chuyên ngành Ngôn ngữ Trung Quốc để đóng góp tích cực vào sự phát triển bền vững của xã hội, cộng đồng.
43	9	PLO2	5	Phân biệt chức năng của các thành phần cấu thành nên ngôn ngữ Trung Quốc đồng thời sử dụng thành thạo 4 kỹ năng tiếng Trung.
44	9	PLO3	3	Sử dụng ngoại ngữ 2 tiếng Anh trong các tình huống quen thuộc để nâng cao cơ hội việc làm và hiểu biết thêm về các nền văn hóa khác.
45	9	PLO4	5	Áp dụng thành thạo tiếng Trung vào công việc, nhận biết chữ Hán phồn thể và thành thạo chữ Hán giản thể trong công việc; sử dụng có hiệu quả  kiến thức và kỹ năng chuyên ngành tiếng Trung thuộc lĩnh vực (a) thương mại, hoặc (b) biên phiên dịch, hoặc (c)phương pháp giảng dạy, hoặc (d)khóaluậntốt nghiệp.
46	9	PLO5	5	Thểhiện kỹnăng nhận thức liên quanđến tưduy phản biện, phân tích, tổng hợp vào công việc.
47	9	PLO6	3	Vận dụng kỹ năng giao tiếp và công nghệ thông tin cần thiết để thực hiện các nhiệm vụ phức tạp trong môi trường làm việc liên ngành, đa văn hóa, đa quốc gia.
48	9	PLO7	4	Làm việc độc lập và làm việc theo nhóm trong điều kiện làm việc thay đổi; nhận thức và tuân thủ chuẩn mực đạo đức và trách nhiệm xã hội và nghề nghiệp trong bối cảnh toàn cầu hóa.
\.


--
-- Data for Name: version_syllabi; Type: TABLE DATA; Schema: public; Owner: program
--

COPY public.version_syllabi (id, version_id, course_id, author_id, status, content, is_rejected, rejection_reason, created_at, updated_at) FROM stdin;
1	1	11	2	draft	{"textbooks": ["Khoa Công nghệ Thông tin. Tài liệu học tập học phần \\"TRÍ TUỆ NHÂN TẠO ỨNG DỤNG\\". HUTECH"], "references": ["Thông tư quy định Khung năng lực số (Số 02 /2025/TT-BGDĐT)", "Tài liệu về Prompt Engineering, RAG, Multimodal AI.", "AI Competency Framework for Students (2024). UNESCO."], "prerequisites": "", "course_outline": [{"clos": ["CLO1", "CLO4"], "hours": 5, "title": "GIỚI THIỆU VỂ TRÍ TUỆ NHÂN TẠO", "lesson": 1, "topics": ["1.1. Định nghĩa TTNT", "1.2. Sự phát triển của TTNT và ứng dụng trong cuộc sống", "1.3. Các loại TTNT", "1.4. Ứng dụng TTNT trong các ngành nghề"], "teaching_methods": "Giảng dạy tích cực về TTNT từ khái niệm đến các ứng dụng thực tế. Thảo luận và bài tập: \\"Trình bày ứng dụng của TTNT đến các lĩnh vực như Kinh tế, KHXH, Sức khỏe, Kỹ thuật, Ngoại ngữ\\". Làm việc nhóm và trình bày tổng quan các ứng dụng (tại lớp). Tìm hiểu ứng dụng cụ thể (về nhà)."}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 10, "title": "TRÍ TUỆ NHÂN TẠO VÀ DỮ LIỆU", "lesson": 2, "topics": ["2.1. Vai trò của TTNT và dữ liệu lớn", "2.2. Cách TTNT học từ dữ liệu", "2.3. Tổ chức và quản lý dữ liệu", "2.4. Phân tích dữ liệu cơ bản"], "teaching_methods": "Giảng dạy tích cực về chiếc lược khai thác dữ liệu số hiện nay. Thảo luận và bài tập: \\"Phân tích một bộ dữ liệu thực tế liên quan đến các nhóm ngành học\\". Khảo sát các nguồn dữ liệu (tại lớp). Thực hiện phân tích và trình bày trực quan kết quả qua biểu đồ, kết hợp giải thích ý nghĩa thực tế (về nhà)."}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 5, "title": "VAI TRÒ CỦA TRÍ TUỆ NHÂN TẠO TRONG THỰC TẾ", "lesson": 3, "topics": ["3.1. TTNT trong lĩnh vực Kinh tế", "3.2. TTNT trong lĩnh vực Khoa học xã hội", "3.3. TTNT trong lĩnh vực Y tế", "3.4. TTNT trong lĩnh vực Kỹ thuật", "3.5. TTNT trong lĩnh vực Ngoại ngữ"], "teaching_methods": "Giảng dạy tích cực về vai trò TTNT trong các lĩnh vực. Thảo luận: \\"Khảo sát các công cụ TTNT liên quan đến nhóm ngành học\\". SV chọn hướng ứng dụng TTNT phù hợp với nhóm ngành học tương ứng. Trình bày kết quả khảo sát và lựa chọn các công cụ TTNT phù hợp. (tại lớp)"}, {"clos": ["CLO2", "CLO4"], "hours": 10, "title": "SỬ DỤNG CÔNG CỤ TRÍ TUỆ NHÂN TẠO", "lesson": 4, "topics": ["4.1. Google AutoML", "4.2. Microsoft AI Builder", "4.3. IBM Watson", "4.4. TTNT trong sáng tạo nội dung"], "teaching_methods": "Giảng dạy tích cực về cách sử dụng các công cụ TTNT phổ biến. Bài tập: \\"Sử dụng công cụ TTNT vào Học tập\\". SV tạo ra một sản phẩm cá nhân như bài viết, hình ảnh minh họa, hoặc báo cáo dữ liệu bằng công cụ TTNT. (về nhà)"}, {"clos": ["CLO1", "CLO2", "CLO4"], "hours": 5, "title": "TRÍ TUỆ NHÂN TẠO - ĐẠO ĐỨC VÀ THÁCH THỨC", "lesson": 5, "topics": ["5.1. Tương lai của TTNT", "5.2. Đạo đức khi sử dụng TTNT", "5.3. TTNT và quyền riêng tư", "5.4. Quy định và chính sách TTNT trên thế giới"], "teaching_methods": "Giảng dạy tích cực về đạo đức TTNT và những thách thức đối với xã hội hiện nay. Thảo luận: \\"Sử dụng TTNT có trách nhiệm\\" liên quan đến các ngành học. SV làm việc nhóm và trình bày các vấn đề liên quan. (tại lớp)"}, {"clos": ["CLO2", "CLO3", "CLO4"], "hours": 10, "title": "DỰ ÁN TỔNG HỢP", "lesson": 6, "topics": ["6.1. Xác định vấn đề", "6.2. Thiết kế giải pháp", "6.3. Triển khai hệ thống", "6.4. Đánh giá và hoàn thiện"], "teaching_methods": "SV chọn một lĩnh vực và tìm cách ứng dụng TTNT và lĩnh vực đó. SV có thể phân tích dữ liệu bằng TTNT, xây dựng chatbot, sử dụng AutoML. Viết báo cáo và trình bày trước lớp."}], "_schema_version": 2, "learning_methods": [{"method": "Giảng dạy tích cực", "objective": "Lấy người học làm trung tâm, khuyến khích sự tham gia chủ động, tư duy phản biện và áp dụng kiến thức vào thực tiễn."}, {"method": "Thảo luận", "objective": "Thông qua việc hỏi đáp giữa giảng viên và sinh viên để làm rõ các nội dung kiến thức trong học phần."}, {"method": "Bài tập", "objective": "Giúp sinh viên hiểu rõ và biết vận dụng các nội dung học phần vào các vấn đề thực tiễn."}, {"method": "Tự nghiên cứu", "objective": "Giúp người học tăng cường năng lực tự học, tự nghiên cứu."}], "course_objectives": "Học phần này cung cấp cho sinh viên các kiến thức và kỹ năng cơ bản nhằm khai thác, quản lý và phân tích dữ liệu, ứng dụng trí tuệ nhân tạo (TTNT) để để cá nhân hóa học tập và giải quyết vấn đề thực tiễn. Hoàn thành xong học phần này, sinh viên sẽ có thể: -Có kiến thức cơ bản về TTNT và hiểu biết cách thức hoạt động của TTNT. -Biết cách sử dụng các công cụ TTNT để giải quyết các vấn đề trong thực tiễn một cách phù hợp.", "assessment_methods": [{"clos": ["CLO4"], "weight": 20, "component": "Điểm thành phần", "assessment_tool": "Chuyên cần và hoạt động tích cực"}, {"clos": ["CLO1", "CLO2"], "weight": 20, "component": "Bài tập nhóm", "assessment_tool": "Bài tập nhóm"}, {"clos": ["CLO1", "CLO2"], "weight": 10, "component": "Bài tập cá nhân", "assessment_tool": "Bài tập cá nhân"}, {"clos": ["CLO2", "CLO3"], "weight": 50, "component": "Điểm thi kết thúc HP", "assessment_tool": "Đồ án học phần"}], "course_description": "Học phần Trí tuệ nhân tạo ứng dụng cung cấp cho sinh viên các kiến thức cơ bản và kỹ năng cần thiết về trí tuệ nhân tạo, tìm kiếm, quản lý và phân tích dữ liệu số. Học phần này cũng trang bị cho sinh viên nền tảng về TTNT và các ứng dụng của nó trong giải quyết các vấn đề thực tiễn, giúp sinh viên phát triển khả năng sáng tạo, tư duy phản biện và ứng xử có trách nhiệm trong việc áp dụng TTNT vào các tình huống thực tiễn.", "course_requirements": {"hardware": [], "software": ["Google Search", "Scholar", "ChatGPT", "Google AutoML", "Microsoft AI Builder", "IBM Watson"], "lab_equipment": [], "classroom_setup": ""}, "language_instruction": "Tiếng Việt"}	f	\N	2026-03-25 16:01:38.994898+00	2026-03-26 07:17:42.079571+00
\.


--
-- Name: approval_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.approval_logs_id_seq', 1, false);


--
-- Name: assessment_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.assessment_plans_id_seq', 188, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 95, true);


--
-- Name: course_clos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.course_clos_id_seq', 8, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.courses_id_seq', 499, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.departments_id_seq', 858, true);


--
-- Name: knowledge_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.knowledge_blocks_id_seq', 105, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1060, true);


--
-- Name: plo_pis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.plo_pis_id_seq', 155, true);


--
-- Name: program_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.program_versions_id_seq', 12, true);


--
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.programs_id_seq', 7, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.roles_id_seq', 234, true);


--
-- Name: syllabus_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.syllabus_assignments_id_seq', 2, true);


--
-- Name: teaching_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.teaching_plan_id_seq', 493, true);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: version_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_courses_id_seq', 499, true);


--
-- Name: version_objectives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_objectives_id_seq', 31, true);


--
-- Name: version_pi_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_pi_courses_id_seq', 1710, true);


--
-- Name: version_plos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_plos_id_seq', 55, true);


--
-- Name: version_syllabi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: program
--

SELECT pg_catalog.setval('public.version_syllabi_id_seq', 2, true);


--
-- Name: approval_logs approval_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_pkey PRIMARY KEY (id);


--
-- Name: assessment_plans assessment_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clo_plo_map clo_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_pkey PRIMARY KEY (clo_id, plo_id);


--
-- Name: course_clos course_clos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_pkey PRIMARY KEY (id);


--
-- Name: course_plo_map course_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_pkey PRIMARY KEY (course_id, plo_id);


--
-- Name: courses courses_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_code_key UNIQUE (code);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: departments departments_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_code_key UNIQUE (code);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: knowledge_blocks knowledge_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plo_pis plo_pis_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_pkey PRIMARY KEY (id);


--
-- Name: po_plo_map po_plo_map_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_pkey PRIMARY KEY (po_id, plo_id);


--
-- Name: program_versions program_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_pkey PRIMARY KEY (id);


--
-- Name: program_versions program_versions_program_id_academic_year_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_academic_year_key UNIQUE (program_id, academic_year);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_code_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_code_key UNIQUE (code);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: syllabus_assignments syllabus_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_pkey PRIMARY KEY (id);


--
-- Name: syllabus_assignments syllabus_assignments_version_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_version_id_course_id_key UNIQUE (version_id, course_id);


--
-- Name: teaching_plan teaching_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan
    ADD CONSTRAINT teaching_plan_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_department_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_department_id_key UNIQUE (user_id, role_id, department_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: version_courses version_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_pkey PRIMARY KEY (id);


--
-- Name: version_objectives version_objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_pkey PRIMARY KEY (id);


--
-- Name: version_pi_courses version_pi_courses_pi_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pi_id_course_id_key UNIQUE (pi_id, course_id);


--
-- Name: version_pi_courses version_pi_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pkey PRIMARY KEY (id);


--
-- Name: version_plos version_plos_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_pkey PRIMARY KEY (id);


--
-- Name: version_syllabi version_syllabi_pkey; Type: CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_pkey PRIMARY KEY (id);


--
-- Name: idx_sa_assigned_to; Type: INDEX; Schema: public; Owner: program
--

CREATE INDEX idx_sa_assigned_to ON public.syllabus_assignments USING btree (assigned_to);


--
-- Name: idx_sa_version; Type: INDEX; Schema: public; Owner: program
--

CREATE INDEX idx_sa_version ON public.syllabus_assignments USING btree (version_id);


--
-- Name: teaching_plan_vc_unique; Type: INDEX; Schema: public; Owner: program
--

CREATE UNIQUE INDEX teaching_plan_vc_unique ON public.teaching_plan USING btree (version_course_id);


--
-- Name: approval_logs approval_logs_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.approval_logs
    ADD CONSTRAINT approval_logs_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: assessment_plans assessment_plans_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id);


--
-- Name: assessment_plans assessment_plans_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: assessment_plans assessment_plans_sample_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_sample_course_id_fkey FOREIGN KEY (sample_course_id) REFERENCES public.courses(id);


--
-- Name: assessment_plans assessment_plans_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.assessment_plans
    ADD CONSTRAINT assessment_plans_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_clo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_clo_id_fkey FOREIGN KEY (clo_id) REFERENCES public.course_clos(id) ON DELETE CASCADE;


--
-- Name: clo_plo_map clo_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.clo_plo_map
    ADD CONSTRAINT clo_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_clos course_clos_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_clos
    ADD CONSTRAINT course_clos_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: course_plo_map course_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.course_plo_map
    ADD CONSTRAINT course_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: courses courses_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id);


--
-- Name: knowledge_blocks knowledge_blocks_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_blocks(id) ON DELETE CASCADE;


--
-- Name: knowledge_blocks knowledge_blocks_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.knowledge_blocks
    ADD CONSTRAINT knowledge_blocks_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: plo_pis plo_pis_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.plo_pis
    ADD CONSTRAINT plo_pis_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_plo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_plo_id_fkey FOREIGN KEY (plo_id) REFERENCES public.version_plos(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.version_objectives(id) ON DELETE CASCADE;


--
-- Name: po_plo_map po_plo_map_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.po_plo_map
    ADD CONSTRAINT po_plo_map_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: program_versions program_versions_copied_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_copied_from_id_fkey FOREIGN KEY (copied_from_id) REFERENCES public.program_versions(id);


--
-- Name: program_versions program_versions_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.program_versions
    ADD CONSTRAINT program_versions_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.programs(id) ON DELETE CASCADE;


--
-- Name: programs programs_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: syllabus_assignments syllabus_assignments_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: syllabus_assignments syllabus_assignments_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: syllabus_assignments syllabus_assignments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: syllabus_assignments syllabus_assignments_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.syllabus_assignments
    ADD CONSTRAINT syllabus_assignments_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: teaching_plan teaching_plan_version_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.teaching_plan
    ADD CONSTRAINT teaching_plan_version_course_id_fkey FOREIGN KEY (version_course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: version_courses version_courses_knowledge_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_knowledge_block_id_fkey FOREIGN KEY (knowledge_block_id) REFERENCES public.knowledge_blocks(id) ON DELETE SET NULL;


--
-- Name: version_courses version_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_courses
    ADD CONSTRAINT version_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_objectives version_objectives_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_objectives
    ADD CONSTRAINT version_objectives_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.version_courses(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_pi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_pi_id_fkey FOREIGN KEY (pi_id) REFERENCES public.plo_pis(id) ON DELETE CASCADE;


--
-- Name: version_pi_courses version_pi_courses_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_pi_courses
    ADD CONSTRAINT version_pi_courses_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_plos version_plos_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_plos
    ADD CONSTRAINT version_plos_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: version_syllabi version_syllabi_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: version_syllabi version_syllabi_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: version_syllabi version_syllabi_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: program
--

ALTER TABLE ONLY public.version_syllabi
    ADD CONSTRAINT version_syllabi_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.program_versions(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: program
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict whNVNdPyY6EOsHxaecOleF4xUtSSSe4TsKvwNRpHOLxJJaSHa3lgFQzlbhW5QHs

